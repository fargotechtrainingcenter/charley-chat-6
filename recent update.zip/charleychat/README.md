# Charley Chat — Source for Replit

This zip contains the full, current source code for Charley Chat: the mobile
app, the backend API, the admin dashboard, and the shared database/API-client
libraries. It's meant to **replace the contents of your existing Replit
project folder-by-folder**, not to be run standalone from your own computer
(though it can be — see the bottom of this file).

## How to update your existing Replit project with this zip

1. In your Replit project's file pane, delete (or rename, if you want a
   backup) the folders this zip replaces: `artifacts/charleychat`,
   `artifacts/api-server`, `artifacts/admin-dashboard`, `lib/db`,
   `lib/api-client-react`, `lib/api-spec`.
2. Upload this zip into your Replit project (drag it into the file pane, or
   use Replit's "Upload folder/file" option), then extract it there — or use
   the Shell tab:
   ```bash
   unzip charleychat.zip -d /tmp/charleychat-update
   cp -r /tmp/charleychat-update/charleychat/artifacts/charleychat/* artifacts/charleychat/
   cp -r /tmp/charleychat-update/charleychat/artifacts/api-server/* artifacts/api-server/
   cp -r /tmp/charleychat-update/charleychat/artifacts/admin-dashboard/* artifacts/admin-dashboard/
   cp -r /tmp/charleychat-update/charleychat/lib/db/* lib/db/
   cp -r /tmp/charleychat-update/charleychat/lib/api-client-react/* lib/api-client-react/
   cp -r /tmp/charleychat-update/charleychat/lib/api-spec/* lib/api-spec/
   ```
3. In the Replit Shell, reinstall and re-push the schema so the new tables
   from recent work (disputes, ad platform, vendor/movie subscriptions,
   wallet funding requests, audit logs, push subscriptions) get created:
   ```bash
   pnpm install
   cd lib/db && pnpm run push && cd ../..
   ```
4. Restart your Repl / re-run each app (`api-server`, `charleychat`,
   `admin-dashboard`) from Replit's run button or workflow panel as usual.

Replit already knows how to run each app via the `.replit-artifact/artifact.toml`
file inside each `artifacts/*` folder — those are included and unchanged, so
you don't need to reconfigure anything on the Replit side.

## What's new since your last update

- **Admins can now upload real movies.** New "Movies" page in the admin
  dashboard: upload a poster + video file (with progress bars), set title,
  description, genre, year, duration, rating, and whether it requires a
  subscription. The mobile app's Stream tab and movie detail screen now
  pull this real catalog instead of the old static mock list, and Play
  actually streams the uploaded video (gated by the existing subscription
  paywall).
- Phone number normalization fixed everywhere (contacts, wallet send,
  escrow, user search) — previously only worked at login/registration
- Push notifications: fixed a missing database table, added native
  Android/iOS push (previously web-only)
- Message delivery/seen ticks, cross-platform chat sounds, real video
  sending, full-screen media viewer, working Reels playback on native
- Fixed a stale duplicate file that silently broke "create trend" on mobile
- Nearby Users button loading state, safer back-navigation across 17 screens
- 22 new database indexes (conversations, notifications, stories, reels,
  discussions, escrow were all doing full table scans before)
- Wallet transaction fees (1%/2%/0.65%/1% tiers) with a fee-preview endpoint
- KYC gating extended to escrow and marketplace selling
- Wallet-funding-failure support form + admin verification workflow
- Full escrow dispute system: evidence thread, admin queue, resolution
  (release/refund/partial split) — all wallet-integrated
- Real marketplace seller subscriptions (replacing the old mocked one-time
  fee) with product-limit enforcement and auto-renewal
- Ghana bank list + account verification (Paystack); bank withdrawal
  endpoint — *actual payout transfers still need live Paystack credentials,
  see code comments in `artifacts/api-server/src/routes/banks.ts`*
- Advertisement platform: create/pay, admin approval, interest-targeted
  placement, full analytics
- Movie streaming subscription (GH₵70/month) with a real paywall — note the
  movie catalog itself is still a static mockup with no real video source

See `TEST_REPORT.md` (if included) for the full verification details behind
each of the above.

## Running standalone (not via Replit)

```bash
npm install -g pnpm
pnpm install
cd lib/db && DATABASE_URL="postgresql://..." pnpm run push && cd ../..
cd artifacts/api-server && DATABASE_URL="..." JWT_SECRET="..." JWT_REFRESH_SECRET="..." ADMIN_JWT_SECRET="..." pnpm run dev
```
Then in separate terminals:
```bash
cd artifacts/charleychat && pnpm run dev      # mobile app (Expo)
cd artifacts/admin-dashboard && pnpm run dev  # admin web dashboard
```
