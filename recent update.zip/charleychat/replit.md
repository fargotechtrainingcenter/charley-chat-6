# KASUWAA / FargoPay / CharLey Admin

A multi-artifact monorepo: KASUWAA (AfricartGH e-commerce web app), FargoPay (Expo wallet/social/marketplace mobile app), and CharLey Admin (admin dashboard), all backed by one shared API server.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied at `/api`)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Web artifacts: React + Vite (africart-web, admin-dashboard)
- Mobile artifact: Expo Router (fargopay)

## Where things live

- `artifacts/api-server` — shared Express API for all artifacts
- `artifacts/africart-web` — KASUWAA storefront (products, orders, AliExpress sync)
- `artifacts/admin-dashboard` — FargoPay's admin (branded "FargoPay Admin"; super_admin auth, native fetch + authHeaders pattern, not the generated api-client). KASUWAA has its own separate admin baked directly into `artifacts/africart-web` (`src/pages/admin/*`, same login as buyers) — it does NOT use this dashboard.
- `artifacts/fargopay` — FargoPay Expo app: wallet, escrow, chat/messaging, groups, marketplace, KYC, reels, discussions (Discover/Trending), pay bills
- `lib/db` — Drizzle schema, source of truth for all tables
- `lib/api-spec` — OpenAPI spec (source of truth for API contracts) + Orval codegen output

## Product

- **KASUWAA**: e-commerce storefront with AliExpress product sync, categories, vendor accounts.
- **FargoPay**: mobile wallet + social app — wallet/send money/escrow/pay-link, KYC-gated transfers, chat messaging with image uploads, contacts, groups (free/paid join), marketplace reels, Discover tab with trending Discussions (categories, threads, anonymous replies), and Pay Bills (internal wallet debit against Electricity/Water/TV/Internet billers — no live Hubtel/biller integration yet, since `HUBTEL_CLIENT_ID`/`HUBTEL_CLIENT_SECRET` are not configured).
- **CharLey Admin** (`admin-dashboard` artifact): internal admin dashboard for FargoPay only. KASUWAA is administered through its own built-in admin pages inside `africart-web`, not this dashboard.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- KASUWAA and FargoPay currently share one Postgres database and one deployment (both `kasuwaa.com` and `charleychat.app` point at the same autoscale deployment; routing between artifacts is path-based, not host-based). Fully disconnecting them (separate DB + separate domain-bound deployment) requires forking/creating a second Replit project — there is no in-project tool to provision a second managed DB or bind a domain to only one artifact within a single deployment.

- FargoPay wallet balances are stored in pesewas (integer) in the DB/API, but the client's `balance` value in `AppContext` is already converted to GHS (float) for display. Never mix the two directly — always convert explicitly before comparing or subtracting.
- When testing the FargoPay Expo web build, always navigate to `$REPLIT_EXPO_DEV_DOMAIN` directly — the shared proxy root routes to a different artifact.
- Missing `JWT_SECRET`/`JWT_REFRESH_SECRET`/`ADMIN_JWT_SECRET` causes the API server to `process.exit(1)` at startup.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
