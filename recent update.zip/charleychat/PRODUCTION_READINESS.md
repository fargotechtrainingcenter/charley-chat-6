# FargoPay — Production Readiness Report
Generated: 2026-06-22

---

## Summary

| Area | Status | Notes |
|------|--------|-------|
| Demo credentials removed | ✅ Done | All hardcoded phone/PIN/hints removed from welcome, register, pay screens |
| Registration — full fields | ✅ Done | Accepts fullName, phone, email, ghanaCardId, dateOfBirth, pin, otpCode |
| Sequential FP-IDs | ✅ Done | Format FP-000001…FP-999999; MAX-based SQL with zero-pad |
| Server-side OTP validation | ✅ Done | OTP stored in DB (5-min expiry); register rejects invalid/expired codes |
| OTP API endpoint | ✅ Done | `POST /api/auth/otp/request` — logs code, returns 300s expiry |
| SMS delivery (Twilio) | ⚠️ Needs setup | Twilio connector available in Replit; OTP stub ready to activate |
| Wallet KYC gating | ✅ Done | deposit / withdraw / send return 403 + `kycRequired:true` if user not KYC-verified |
| Admin KYC reject reason | ✅ Done | `rejectionReason` written to DB on reject; available in admin dashboard |
| Object storage | ✅ Done | GCS bucket provisioned; presigned PUT URL via `POST /api/storage/uploads/request-url` |
| OpenAPI + codegen | ✅ Done | Spec updated for OTP, Storage, RegisterInput, UserProfile; Zod schemas regenerated |
| Mobile register passes OTP | ✅ Done | `otpCode` passed from OTP step to server; fpId shown on success screen |
| UserProfile fields | ✅ Done | `GET /api/users/me` returns fpId, email, ghanaCardId, dateOfBirth |
| Register returns fpId | ✅ Done | Register response includes fpId for mobile success screen |
| Typecheck | ✅ Clean | `pnpm run typecheck` passes with zero errors |
| All workflows | ✅ Running | API server, Expo, admin dashboard, mockup sandbox — all healthy |

---

## What's Done

### Authentication & Registration
- **Full registration fields**: `email`, `ghanaCardId`, `dateOfBirth`, `otpCode` accepted and stored.
- **Sequential FP-IDs**: Every new user gets `FP-000001`, `FP-000002`, … guaranteed sequential via `MAX()` SQL.
- **OTP flow**: `POST /api/auth/otp/request` generates a 6-digit code, stores it in `otp_codes` table with 5-minute expiry. The register endpoint validates it server-side before creating the account.
- **Suspended accounts**: Login returns 403 with `{ error: "Account suspended" }` for suspended users.

### Wallet
- **KYC gate**: All transaction routes (deposit, withdraw, send) check `isKycVerified` on the user. Non-verified users get `403 { error: "KYC verification required...", kycRequired: true }`.
- Wallet read (`GET /api/wallets/me`) remains ungated — users can see their balance.

### KYC (Admin)
- **Rejection reason**: When an admin rejects a KYC submission, the `reason` string is written to `rejection_reason` on the `kyc_verifications` row.
- **Reject also sets `isKycVerified = false`** on the user, preventing any race-condition bypass.

### Object Storage
- **GCS bucket provisioned**: `replit-objstore-f26eab83-aed8-4b7d-bb1f-028acf07d023`
- **Presigned upload URLs**: `POST /api/storage/uploads/request-url` returns a GCS signed PUT URL + `objectPath`. Clients upload directly to GCS — the server never receives the file bytes.
- Use for: KYC selfie, Ghana Card photo, profile avatar uploads.
- Server routes: `POST /api/storage/uploads/request-url`, `GET /api/storage/objects/:path`

### OpenAPI & Codegen
- New schemas: `OtpRequestInput`, `OtpRequestResponse`, `UploadUrlRequest`, `UploadUrlResponse`
- `RegisterInput` extended: `email`, `ghanaCardId`, `dateOfBirth`, `otpCode`
- `UserProfile` extended: `fpId`, `email`, `ghanaCardId`, `dateOfBirth`
- New paths: `/auth/otp/request`, `/storage/uploads/request-url`, `/storage/objects/{objectPath}`
- All Zod schemas and React Query hooks regenerated.

### Mobile App
- Registration step 5 passes `otpCode` to the server.
- Register callback returns fpId for display on the success screen.
- `AppContext.register` passes all fields: `fullName`, `phone`, `email`, `ghanaCardId`, `dateOfBirth`, `pin`, `otpCode`.

---

## What Needs Manual Setup Before Go-Live

### 1. Twilio SMS (CRITICAL)
**Status**: Stub ready; Twilio connector available in Replit but not yet authorized.

The OTP code is already generated and stored. The only missing piece is the Twilio API call.

**To activate**:
1. Open the Replit Integrations panel → search "Twilio"
2. Connect your Twilio account (OAuth or API key)
3. In `artifacts/api-server/src/routes/otp.ts`, the `sendSms()` stub block is marked — replace it with:
```typescript
import twilio from "twilio";
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
await client.messages.create({
  body: `Your FargoPay verification code is: ${code}. Valid for 5 minutes.`,
  from: process.env.TWILIO_PHONE_NUMBER,
  to: `+233${phone.replace(/^0/, "")}`,  // Ghana: 0XX → +233XX
});
```

### 2. JWT Secrets (CRITICAL)
Production deployment **requires** these three secrets to be set:
- `JWT_SECRET` — access token signing key (min 32 chars)
- `JWT_REFRESH_SECRET` — refresh token signing key (min 32 chars)
- `ADMIN_JWT_SECRET` — admin JWT signing key (min 32 chars)

The server calls `process.exit(1)` at startup if any are missing.

### 3. Database URL (CRITICAL)
- `DATABASE_URL` must point to a production Postgres instance.

### 4. KYC Document Upload (Mobile)
The storage infrastructure is in place. The mobile KYC submission screen needs to:
1. Call `POST /api/storage/uploads/request-url` with `{ name, size, contentType }`.
2. PUT the file directly to the returned `uploadURL`.
3. POST the returned `objectPath` to `POST /api/kyc` as `documentUrl`.

### 5. Rate Limiting on OTP Endpoint
`POST /api/auth/otp/request` has no rate limiting. Before production:
- Add IP-based rate limit: max 3 requests per phone per 15 minutes.
- Consider adding CAPTCHA for web.

### 6. Admin Dashboard — Rejection Reason Display
The `rejectionReason` is now stored in DB but needs a UI field in the admin KYC review panel to display it to reviewers.

---

## Database Schema State

| Table | New Columns Added |
|-------|------------------|
| `users` | `fp_id TEXT UNIQUE`, `email TEXT`, `ghana_card_id TEXT`, `date_of_birth TEXT` |
| `kyc_verifications` | `rejection_reason TEXT` |
| `otp_codes` | New table: `id, phone, code, expires_at, used, created_at` |

---

## API Endpoints Reference

| Method | Path | Auth | KYC Required | Description |
|--------|------|------|--------------|-------------|
| POST | `/api/auth/otp/request` | None | No | Request 6-digit SMS OTP |
| POST | `/api/auth/register` | None | No | Register with all fields + OTP |
| POST | `/api/auth/login` | None | No | Login with phone + PIN |
| GET | `/api/users/me` | JWT | No | Profile (includes fpId, email, ghanaCardId, dob) |
| GET | `/api/wallets/me` | JWT | No | View wallet balance |
| POST | `/api/wallets/deposit` | JWT | **Yes** | Add funds |
| POST | `/api/wallets/withdraw` | JWT | **Yes** | Withdraw funds |
| POST | `/api/wallets/send` | JWT | **Yes** | Send to another user |
| POST | `/api/storage/uploads/request-url` | JWT | No | Get presigned GCS upload URL |
| GET | `/api/storage/objects/:path` | JWT | No | Serve stored file |
| POST | `/api/kyc` | JWT | No | Submit KYC documents |
| PATCH | `/api/admin/kyc/:id/approve` | Admin | — | Approve KYC |
| PATCH | `/api/admin/kyc/:id/reject` | Admin | — | Reject KYC with reason |

---

## Test Accounts

| Name | Phone | PIN | KYC | FP-ID |
|------|-------|-----|-----|-------|
| Kwame Mensah | 0244000001 | 1234 | No | null |
| Abena Asante | 0244000002 | 1234 | No | null |
| E2E Tester | 0209991122 | 5678 | No | null |
| Ama Boateng | 0277001122 | 2024 | No | null |

Admin: `admin@fargopay.com` / `FargoPay2024!`

---

## Architecture Decisions

- **OTP in DB not cache**: `otp_codes` table used instead of Redis/in-memory to survive server restarts and allow distributed deployments.
- **KYC gate at route level**: `requireKyc()` async helper in `wallets.ts` keeps gate logic isolated and testable.
- **FP-ID via MAX SQL**: Deterministic sequential IDs without a sequence object; works with any Postgres version.
- **Presigned GCS uploads**: Server never proxies file bytes — client uploads directly to GCS, keeping API server memory and bandwidth lean.
- **OTP stub pattern**: The OTP route always stores the code and logs it; SMS is a pluggable side effect — easy to activate without changing the core logic.
