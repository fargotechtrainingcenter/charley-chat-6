# FargoPay Backend Audit Report

**Generated:** 2026-06-21  
**Scope:** `artifacts/api-server` + `lib/db` (Drizzle schema) + `lib/api-spec` (OpenAPI 3.1)  
**Stack:** Express 5 · PostgreSQL · Drizzle ORM · Zod v4 · JWT (jsonwebtoken)

---

## 1. Database Schema

### Tables (13 total)

| Table | Primary Key | Notable Columns |
|---|---|---|
| `users` | uuid | `phone` (unique), `pinHash`, `fullName`, `role` (user/admin), `kycStatus` |
| `wallets` | uuid | `userId` (unique FK), `balancePesewas` (integer cents) |
| `transactions` | uuid | `type` enum, `amountPesewas`, `feePesewas`, `network`, `counterpartyPhone` |
| `escrow_transactions` | uuid | `buyerId`, `sellerId`, `status` enum, `releaseCode`, `dueDate` |
| `payment_links` | uuid | `code` (unique 8-char), `isFixedAmount`, `amountPesewas`, `status` |
| `contacts` | uuid | `ownerId`, `contactUserId`, `contactPhone`, `nickname` |
| `stories` | uuid | `userId`, `storyType` enum, `mediaUrl`, `caption`, `isAgeRestricted` (new), `expiresAt` |
| `kyc_verifications` | uuid | `userId`, `status` enum, `ghanaCardId`, `selfieUrl`, `documentUrl` |
| `vendors` | uuid | `userId` (FK), `businessName`, `category`, `verified` |
| `vendor_reviews` | uuid | `vendorId`, `reviewerId`, `rating` (1-5), `comment` |
| `notifications` | uuid | `userId`, `type`, `title`, `body`, `isRead` |
| `sessions` | uuid | `userId`, `refreshToken`, `expiresAt`, `revoked` |
| `sms_logs` | uuid | `phone`, `message`, `status`, `provider` |
| `admin_users` | uuid | `email` (unique), `passwordHash`, `role` (admin/superadmin) |

### Schema Observations
- ✅ **All monetary values stored in pesewas (integer)** — no floating-point precision risk.
- ✅ **Cascade deletes** configured on user-owned data (wallets, transactions via wallet FK).
- ✅ **UUID primary keys** throughout — no guessable integer IDs.
- ⚠️ **`stories.expiresAt` not enforced server-side** — expired stories are returned from `GET /stories` unless filtered. Consider adding a `WHERE expiresAt > NOW()` guard in the list query.
- ⚠️ **`transactions` has no wallet FK** — transactions link to `walletId` via wallets table but the FK is not declared in the Drizzle schema, reducing referential integrity.
- ⚠️ **`contacts` can have orphaned `contactUserId`** — if a user deletes their account, the referenced contact UUID may no longer resolve to a user. No cascade is defined.

---

## 2. API Endpoints (43 total)

### Auth (`/api/auth`)
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/auth/register` | None | Register with `{phone, pin, fullName}` → JWT pair |
| POST | `/auth/login` | None | Login with `{phone, pin}` → JWT pair |
| POST | `/auth/logout` | JWT | Revoke refresh token |
| POST | `/auth/refresh` | None | Exchange refresh token → new access token |

### Users (`/api/users`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/users/me` | JWT | Get current user profile |
| GET | `/users/:phone` | JWT | Lookup user by phone number |

### Wallets (`/api/wallets`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/wallets/balance` | JWT | Get balance in pesewas |
| POST | `/wallets/deposit` | JWT | Record MoMo/bank/card deposit |
| POST | `/wallets/withdraw` | JWT | Record withdrawal |
| POST | `/wallets/send` | JWT | P2P transfer to another phone |

### Transactions (`/api/transactions`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/transactions` | JWT | List user transactions (paginated) |
| GET | `/transactions/:id` | JWT | Get single transaction |

### Escrow (`/api/escrow`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/escrow` | JWT | List escrows (buyer or seller) |
| POST | `/escrow` | JWT | Create escrow `{sellerPhone, title, amountPesewas}` |
| GET | `/escrow/:id` | JWT | Get single escrow |
| POST | `/escrow/:id/release` | JWT | Release with `{releaseCode}` |
| POST | `/escrow/:id/dispute` | JWT | Open dispute |

### Stories (`/api/stories`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/stories` | JWT | List active stories |
| POST | `/stories` | JWT | Create story |
| DELETE | `/stories/:id` | JWT (owner) | Delete own story |

### Contacts (`/api/contacts`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/contacts` | JWT | List user contacts |
| POST | `/contacts` | JWT | Add contact by phone |
| DELETE | `/contacts/:id` | JWT | Remove contact |

### Payment Links (`/api/payment-links`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/payment-links` | JWT | List user's payment links |
| POST | `/payment-links` | JWT | Create payment link |
| GET | `/payment-links/:code` | None | Public: get link by code |
| POST | `/payment-links/:code/pay` | None | Pay a link (guest) |
| POST | `/payment-links/:code/confirm` | JWT | Seller confirms delivery |
| DELETE | `/payment-links/:id` | JWT | Cancel link |

### Notifications (`/api/notifications`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/notifications` | JWT | List notifications |
| PATCH | `/notifications/:id/read` | JWT | Mark as read |

### KYC (`/api/kyc`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/kyc/status` | JWT | Get user's KYC status |
| POST | `/kyc/submit` | JWT | Submit KYC documents |

### Vendors (`/api/vendors`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/vendors` | JWT | List vendors (filterable) |
| GET | `/vendors/:id` | JWT | Get vendor profile |
| POST | `/vendors/:id/reviews` | JWT | Submit review |
| GET | `/vendors/:id/reviews` | JWT | List vendor reviews |

### Admin (`/api/admin`) — requires admin JWT
| Method | Path | Description |
|---|---|---|
| POST | `/admin/auth/login` | Admin login |
| POST | `/admin/auth/logout` | Admin logout |
| GET | `/admin/stats` | Platform KPIs |
| GET/PATCH | `/admin/users` + `/:id` | User management |
| POST | `/admin/users/:id/ban` | Ban user |
| GET/PATCH | `/admin/wallets` | Wallet management + balance adjust |
| GET | `/admin/transactions` | All transactions (paginated) |
| GET | `/admin/escrow` | All escrow transactions |
| POST | `/admin/escrow/:id/resolve-dispute` | Resolve dispute |
| GET | `/admin/stories` | All stories for moderation |
| DELETE | `/admin/stories/:id` | Delete story |
| **PATCH** | **`/admin/stories/:id/restrict`** | **Toggle 18+ age restriction** *(new)* |
| GET | `/admin/kyc` | KYC submissions |
| POST | `/admin/kyc/:id/approve` | Approve KYC |
| POST | `/admin/kyc/:id/reject` | Reject KYC |
| GET | `/admin/vendors` | Vendor list |
| POST | `/admin/vendors/:id/verify` | Verify vendor |
| GET | `/admin/payment-links` | All payment links |
| GET | `/admin/sms-logs` | SMS delivery logs |
| POST | `/admin/users` | Create admin user |
| POST | `/admin/broadcast` | Send bulk notification |

---

## 3. Authentication & Authorization

### JWT Architecture
- **Access tokens:** short-lived (15 min by default), signed with `SESSION_SECRET`
- **Refresh tokens:** longer-lived, stored in `sessions` table with `expiresAt` and `revoked` flag
- **Token revocation:** `POST /auth/logout` marks the session row as `revoked = true`
- **Admin tokens:** separate signing flow via `signAdminToken`, checked by `requireAdminAuth` middleware

### Security Observations
- ✅ **Passwords/PINs are bcrypt-hashed** using `bcryptjs`
- ✅ **Role-based access:** `requireAdminAuth` and `requireSuperAdmin` middleware on all admin routes
- ✅ **Input validation:** all route handlers use Zod schemas from `@workspace/api-zod` before processing
- ✅ **No raw SQL** — all queries use Drizzle ORM with parameterized placeholders (SQL injection protection)
- ✅ **Refresh token rotation:** each `/auth/refresh` call creates a new session row (the old one can be revoked)
- ⚠️ **PIN is 4-6 digits only** — if users set a 4-digit PIN, the entropy is ~13 bits. Rate-limiting on `/auth/login` is recommended to prevent brute force.
- ⚠️ **`SESSION_SECRET` is a single shared key** — if rotated, all existing JWTs are instantly invalidated. Consider a key-id header for graceful rotation.
- ⚠️ **No CORS configuration observed** — Express default allows all origins. The proxy handles this in development but production should set `cors({ origin: REPLIT_DOMAINS })`.
- ⚠️ **Admin JWT uses same `SESSION_SECRET`** — admin and user tokens share the same signing secret. A dedicated `ADMIN_JWT_SECRET` would fully isolate the two systems.

---

## 4. Data Flows

### Mobile Money Deposit
1. Client calls `POST /wallets/deposit` `{amountPesewas, network}`
2. Server creates a `transactions` row with `type: "momo_in"`, `status: "completed"`
3. Server increments `wallets.balancePesewas` in the same DB transaction
4. Returns the new `TransactionRecord`

### Escrow Flow
1. Buyer calls `POST /escrow` → creates row with status `"pending"`, generates `releaseCode`
2. Server debits buyer's wallet, creates `transactions` row with `type: "escrow_hold"`
3. Seller ships/delivers goods and shares the `releaseCode` with buyer out-of-band
4. Buyer calls `POST /escrow/:id/release` `{releaseCode}` → status → `"released"`
5. Server credits seller's wallet, creates `transactions` row with `type: "escrow_release"`

### Payment Link Flow
1. Seller calls `POST /payment-links` → creates link with unique 8-char `code`
2. Buyer calls `POST /payment-links/:code/pay` `{buyerPhone, network, amountPesewas}` (no auth required)
3. Status → `"in_escrow"`, funds held
4. Seller calls `POST /payment-links/:code/confirm` → status `"completed"`, funds released

### Stories 18+ Restriction Flow *(new)*
1. Admin views `GET /admin/stories` — stories with `isAgeRestricted: true` show a badge
2. Admin calls `PATCH /admin/stories/:id/restrict` `{isAgeRestricted: true/false}`
3. The `storiesTable.isAgeRestricted` column is updated
4. The mobile app `GET /stories` returns this flag; client-side logic can gate display

---

## 5. Known Gaps & Recommendations

### Critical
| # | Issue | Recommendation |
|---|---|---|
| C1 | `GET /stories` returns expired stories (no `expiresAt > NOW()` filter) | Add `where(gt(storiesTable.expiresAt, new Date()))` in stories route |
| C2 | No rate limiting on login endpoint | Add `express-rate-limit` to `POST /auth/login` (e.g., 10 req/min per IP) |
| C3 | `GET /payment-links/:code/pay` requires no auth — amount is caller-supplied and not server-validated against link's `amountPesewas` | Validate `amountPesewas` matches `link.amountPesewas` when `isFixedAmount = true` |

### High
| # | Issue | Recommendation |
|---|---|---|
| H1 | PIN brute-force possible | Rate-limit + account lockout after N failed attempts |
| H2 | OTP verification is simulated (demo code) | Integrate Twilio/Africa's Talking for real SMS OTP |
| H3 | No CORS headers | Add `cors` middleware with allowed origins from `REPLIT_DOMAINS` |
| H4 | `EXPO_PUBLIC_DOMAIN` must be set for mobile API calls | Document in `replit.md`; add startup check |

### Medium
| # | Issue | Recommendation |
|---|---|---|
| M1 | Stories `18+` flag is enforced client-side only | Optionally have `GET /stories` exclude age-restricted items for non-verified users |
| M2 | No pagination on `GET /escrow` or `GET /contacts` | Add `page`/`limit` params to prevent large payloads |
| M3 | `wallets.balancePesewas` can go negative (no DB-level check constraint) | Add `CHECK (balance_pesewas >= 0)` constraint in Drizzle schema |
| M4 | Transactions table has no wallet FK declared in Drizzle | Add `.references(() => walletsTable.id)` to `transactionsTable.walletId` |

### Low
| # | Issue | Recommendation |
|---|---|---|
| L1 | Admin and user share `SESSION_SECRET` | Consider a dedicated `ADMIN_JWT_SECRET` env var |
| L2 | No request logging for non-200 responses in routes | Pino already logs; ensure error responses include enough context |
| L3 | `vendorsTable` has no FK to `usersTable` in Drizzle | Add explicit reference declaration |
| L4 | `sms_logs` table has no index on `phone` | Add index if SMS log queries by phone become frequent |

---

## 6. Code Quality Summary

| Area | Score | Notes |
|---|---|---|
| Input validation | ✅ Excellent | Zod schemas on all route inputs, generated from OpenAPI spec |
| Error handling | ✅ Good | Consistent `{error: string}` JSON responses with appropriate status codes |
| Logging | ✅ Good | Pino structured logging via `req.log` in all handlers |
| DB queries | ✅ Good | Drizzle ORM throughout, no raw SQL |
| Auth | ✅ Good | JWT + bcrypt; admin/user separation |
| Monetary math | ✅ Excellent | All pesewa integers; no floats |
| Test coverage | ❌ None | No unit or integration tests exist yet |
| API contract | ✅ Excellent | OpenAPI spec → codegen → Zod + React Query hooks |

---

*Report generated by automated audit against FargoPay backend codebase. All findings should be reviewed and triaged by the development team before production deployment.*
