import { db, vendorsTable, productsTable, flashDealsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const SEED_USER_ID = "00000000-0000-0000-0000-000000000001";

async function main() {
  console.log("Seeding AfricartGH data...");

  await db.execute(`
    INSERT INTO users (id, phone, full_name, is_kyc_verified, is_vendor)
    VALUES ('${SEED_USER_ID}', '+233200000001', 'AfricartGH Seed User', true, true)
    ON CONFLICT (id) DO NOTHING
  `);

  await db.execute(`
    INSERT INTO wallets (user_id, balance_pesewas, currency)
    VALUES ('${SEED_USER_ID}', 0, 'GHS')
    ON CONFLICT (user_id) DO NOTHING
  `);

  const seedVendors = [
    {
      externalId: "v1",
      businessName: "Kantanka Tech Hub",
      description: "Ghana-made electronics, EVs, and smart home solutions.",
      logoUrl: "https://picsum.photos/seed/vendor1/100/100",
      coverImageUrl: "https://picsum.photos/seed/vendor1cover/800/300",
      location: "Accra, Greater Accra",
      isVerified: true,
      ratingAvg: "4.80",
    },
    {
      externalId: "v2",
      businessName: "Kente Kingdom",
      description: "Premium hand-woven Ashanti Kente cloth and Ankara fashion.",
      logoUrl: "https://picsum.photos/seed/vendor2/100/100",
      coverImageUrl: "https://picsum.photos/seed/vendor2cover/800/300",
      location: "Kumasi, Ashanti",
      isVerified: true,
      ratingAvg: "4.60",
    },
    {
      externalId: "v3",
      businessName: "Accra Fresh Market",
      description: "Fresh produce, fish, and wholesale food products from across Ghana.",
      logoUrl: "https://picsum.photos/seed/vendor3/100/100",
      coverImageUrl: "https://picsum.photos/seed/vendor3cover/800/300",
      location: "Accra, Greater Accra",
      isVerified: false,
      ratingAvg: "4.20",
    },
    {
      externalId: "v4",
      businessName: "Beauty by Ama",
      description: "Natural Ghanaian beauty and skincare products.",
      logoUrl: "https://picsum.photos/seed/vendor4/100/100",
      coverImageUrl: "https://picsum.photos/seed/vendor4cover/800/300",
      location: "Tema, Greater Accra",
      isVerified: true,
      ratingAvg: "4.90",
    },
  ];

  const vendorIdMap: Record<string, string> = {};
  for (const v of seedVendors) {
    let [existing] = await db
      .select({ id: vendorsTable.id })
      .from(vendorsTable)
      .where(eq(vendorsTable.businessName, v.businessName));

    if (!existing) {
      const [inserted] = await db
        .insert(vendorsTable)
        .values({
          userId: SEED_USER_ID,
          businessName: v.businessName,
          description: v.description,
          logoUrl: v.logoUrl,
          coverImageUrl: v.coverImageUrl,
          location: v.location,
          isVerified: v.isVerified,
          ratingAvg: v.ratingAvg,
          totalReviews: 0,
        })
        .returning({ id: vendorsTable.id });
      existing = inserted;
      console.log(`Created vendor: ${v.businessName}`);
    } else {
      await db
        .update(vendorsTable)
        .set({
          coverImageUrl: v.coverImageUrl,
          location: v.location,
          isVerified: v.isVerified,
          ratingAvg: v.ratingAvg,
        })
        .where(eq(vendorsTable.id, existing.id));
      console.log(`Updated vendor: ${v.businessName}`);
    }
    vendorIdMap[v.externalId] = existing.id;
  }

  type ProductCategory = "Electronics" | "Fashion" | "EV & Bikes" | "Wholesale" | "Food & Agri" | "Beauty";

  const seedProducts: Array<{
    externalId: string;
    vendorExternalId: string;
    name: string;
    description: string;
    category: ProductCategory;
    pricePesewas: number;
    images: string[];
    inStock: boolean;
    isWholesale: boolean;
    moq: number | null;
    ratingAvg: string;
    totalReviews: number;
  }> = [
    {
      externalId: "p1",
      vendorExternalId: "v1",
      name: 'Kantanka Smart TV 43"',
      description: "Ghana-made 43-inch Smart TV with Android OS, built-in Wi-Fi, and crystal-clear 4K display. Perfect for the modern Ghanaian home.",
      category: "Electronics",
      pricePesewas: 185000,
      images: ["https://picsum.photos/seed/tv1/600/400", "https://picsum.photos/seed/tv2/600/400", "https://picsum.photos/seed/tv3/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.70",
      totalReviews: 234,
    },
    {
      externalId: "p2",
      vendorExternalId: "v2",
      name: "Kente Fabric Roll (6 yards)",
      description: "Premium hand-woven Ashanti Kente cloth in vibrant royal gold and green. 100% authentic, made in Bonwire, Kumasi. Perfect for special occasions.",
      category: "Fashion",
      pricePesewas: 42000,
      images: ["https://picsum.photos/seed/kente1/600/400", "https://picsum.photos/seed/kente2/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.90",
      totalReviews: 567,
    },
    {
      externalId: "p3",
      vendorExternalId: "v1",
      name: "Kantanka Electric Bicycle",
      description: "Ghana's own electric bicycle with 80km range per charge, lightweight aluminum frame, and smart power management. Ideal for Accra's traffic.",
      category: "EV & Bikes",
      pricePesewas: 420000,
      images: ["https://picsum.photos/seed/evbike1/600/400", "https://picsum.photos/seed/evbike2/600/400", "https://picsum.photos/seed/evbike3/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.50",
      totalReviews: 89,
    },
    {
      externalId: "p4",
      vendorExternalId: "v4",
      name: "Ghanaian Shea Butter (Bulk 25kg)",
      description: "Unrefined raw shea butter sourced from Northern Ghana. Cold-pressed, 100% natural. Ideal for cosmetics manufacturers and bulk buyers.",
      category: "Wholesale",
      pricePesewas: 85000,
      images: ["https://picsum.photos/seed/shea1/600/400", "https://picsum.photos/seed/shea2/600/400"],
      inStock: true,
      isWholesale: true,
      moq: 5,
      ratingAvg: "4.80",
      totalReviews: 145,
    },
    {
      externalId: "p5",
      vendorExternalId: "v3",
      name: "Plantain Chips (Case of 24)",
      description: "Crispy, lightly salted plantain chips made from fresh Ghanaian plantains. No artificial preservatives. Perfect for retail stocking.",
      category: "Food & Agri",
      pricePesewas: 18000,
      images: ["https://picsum.photos/seed/chips1/600/400", "https://picsum.photos/seed/chips2/600/400"],
      inStock: true,
      isWholesale: true,
      moq: 10,
      ratingAvg: "4.40",
      totalReviews: 312,
    },
    {
      externalId: "p6",
      vendorExternalId: "v4",
      name: "African Black Soap (Premium)",
      description: "Traditional Ghanaian black soap made from plantain skin ash, cocoa pod, and shea butter. Handcrafted in small batches for maximum potency.",
      category: "Beauty",
      pricePesewas: 4500,
      images: ["https://picsum.photos/seed/soap1/600/400", "https://picsum.photos/seed/soap2/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.90",
      totalReviews: 891,
    },
    {
      externalId: "p7",
      vendorExternalId: "v1",
      name: "Samsung Galaxy A54 (Official)",
      description: "Samsung Galaxy A54 5G with 128GB storage, 50MP camera, and 5000mAh battery. Official warranty, imported and distributed by authorized Ghanaian dealer.",
      category: "Electronics",
      pricePesewas: 290000,
      images: ["https://picsum.photos/seed/phone1/600/400", "https://picsum.photos/seed/phone2/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.60",
      totalReviews: 421,
    },
    {
      externalId: "p8",
      vendorExternalId: "v2",
      name: "Ankara Print Dress (Women)",
      description: "Vibrant Ankara wax print wrap dress in assorted patterns. Machine washable, breathable cotton fabric. Available in sizes XS-3XL.",
      category: "Fashion",
      pricePesewas: 12000,
      images: ["https://picsum.photos/seed/dress1/600/400", "https://picsum.photos/seed/dress2/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.30",
      totalReviews: 178,
    },
    {
      externalId: "p9",
      vendorExternalId: "v3",
      name: "Tilapia (Fresh, 1kg)",
      description: "Fresh whole tilapia from Volta Lake farms. Same-day harvest and delivery in Greater Accra. Rich in protein, perfect for light soups and frying.",
      category: "Food & Agri",
      pricePesewas: 3800,
      images: ["https://picsum.photos/seed/fish1/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.70",
      totalReviews: 234,
    },
    {
      externalId: "p10",
      vendorExternalId: "v4",
      name: "Natural Hair Growth Oil",
      description: "Blend of castor oil, coconut oil, and shea butter infused with Ghanaian herbs. Promotes scalp health and accelerates natural hair growth.",
      category: "Beauty",
      pricePesewas: 8500,
      images: ["https://picsum.photos/seed/haircare1/600/400", "https://picsum.photos/seed/haircare2/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.80",
      totalReviews: 567,
    },
    {
      externalId: "p11",
      vendorExternalId: "v1",
      name: "Kantanka Solar Lantern",
      description: "Durable solar-powered LED lantern with 8-hour runtime. Ideal for areas with power outages. Made in Ghana, designed for Ghana.",
      category: "Electronics",
      pricePesewas: 22000,
      images: ["https://picsum.photos/seed/lantern1/600/400"],
      inStock: true,
      isWholesale: false,
      moq: null,
      ratingAvg: "4.50",
      totalReviews: 156,
    },
    {
      externalId: "p12",
      vendorExternalId: "v3",
      name: "Rice (Bagged, 50kg)",
      description: "Premium locally grown rice from Northern Ghana. Long-grain, aromatic, and great for jollof. Bulk pricing available for resellers.",
      category: "Wholesale",
      pricePesewas: 38000,
      images: ["https://picsum.photos/seed/rice1/600/400"],
      inStock: true,
      isWholesale: true,
      moq: 3,
      ratingAvg: "4.20",
      totalReviews: 89,
    },
  ];

  const productIdMap: Record<string, string> = {};
  for (const p of seedProducts) {
    const vendorId = vendorIdMap[p.vendorExternalId];
    if (!vendorId) {
      console.error(`Vendor ${p.vendorExternalId} not found, skipping product ${p.name}`);
      continue;
    }

    const [existing] = await db
      .select({ id: productsTable.id })
      .from(productsTable)
      .where(eq(productsTable.name, p.name));

    if (!existing) {
      const [inserted] = await db
        .insert(productsTable)
        .values({
          vendorId,
          name: p.name,
          description: p.description,
          category: p.category,
          pricePesewas: p.pricePesewas,
          images: p.images,
          inStock: p.inStock,
          isWholesale: p.isWholesale,
          moq: p.moq,
          ratingAvg: p.ratingAvg,
          totalReviews: p.totalReviews,
        })
        .returning({ id: productsTable.id });
      productIdMap[p.externalId] = inserted.id;
      console.log(`Created product: ${p.name}`);
    } else {
      productIdMap[p.externalId] = existing.id;
      console.log(`Product already exists: ${p.name}`);
    }
  }

  const now = new Date();
  const flashDealData = [
    { productExternalId: "p1", dealPricePesewas: 145000, hoursFromNow: 12 },
    { productExternalId: "p3", dealPricePesewas: 380000, hoursFromNow: 6 },
    { productExternalId: "p5", dealPricePesewas: 14000, hoursFromNow: 3 },
    { productExternalId: "p8", dealPricePesewas: 9500, hoursFromNow: 18 },
    { productExternalId: "p10", dealPricePesewas: 6800, hoursFromNow: 24 },
  ];

  for (const fd of flashDealData) {
    const productId = productIdMap[fd.productExternalId];
    if (!productId) {
      console.log(`Skipping flash deal for ${fd.productExternalId} — product not seeded`);
      continue;
    }

    const [existing] = await db
      .select({ id: flashDealsTable.id })
      .from(flashDealsTable)
      .where(eq(flashDealsTable.productId, productId));

    if (!existing) {
      const endsAt = new Date(now.getTime() + fd.hoursFromNow * 60 * 60 * 1000);
      await db.insert(flashDealsTable).values({
        productId,
        dealPricePesewas: fd.dealPricePesewas,
        endsAt,
        isActive: true,
      });
      console.log(`Created flash deal for product ${fd.productExternalId}`);
    } else {
      console.log(`Flash deal already exists for product ${fd.productExternalId}`);
    }
  }

  console.log("AfricartGH seed complete!");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
