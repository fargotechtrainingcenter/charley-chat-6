import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());

// ── AliExpress webhook: capture raw body BEFORE json() parses it ─────────────
// AliExpress signs the raw JSON body; once JSON.parse runs the bytes change and
// signature verification fails. We stash the raw string on req.rawBody.
app.use(
  "/api/aliexpress/webhook",
  express.raw({ type: "*/*" }),
  (req: Request, _res: Response, next: NextFunction) => {
    const buf = req.body as Buffer | undefined;
    if (Buffer.isBuffer(buf)) {
      (req as any).rawBody = buf.toString("utf-8");
      try {
        req.body = JSON.parse((req as any).rawBody as string);
      } catch {
        req.body = {};
      }
    } else {
      (req as any).rawBody = "";
    }
    next();
  },
);

// ── Paystack webhook: capture raw body BEFORE json() parses it ────────────────
// Paystack signs the raw body with HMAC-SHA512; once JSON.parse runs the bytes
// change and the signature check fails. We stash the raw buffer on req.rawBody
// for the webhook handler and still call next() so the route can read req.body.
app.use(
  "/api/paystack/webhook",
  express.raw({ type: "*/*" }),
  (req: Request, _res: Response, next: NextFunction) => {
    (req as any).rawBody = req.body as Buffer;
    // Re-parse so req.body is a plain object (webhook handler also needs it)
    try {
      req.body = JSON.parse((req as any).rawBody.toString("utf-8"));
    } catch {
      req.body = {};
    }
    next();
  },
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// ── 404 for unmatched /api routes — keep responses JSON, never Express's HTML page ──
app.use("/api", (_req: Request, res: Response) => {
  res.status(404).json({ error: "Not found" });
});

// ── Global error handler ──────────────────────────────────────────────────────
// Express 5 forwards rejected promises from async route handlers here automatically.
// Without this, Express falls back to its default HTML error page, which leaks
// stack traces/SQL/file paths outside production and — worse — returns HTML where
// every other endpoint returns JSON, breaking client-side error parsing everywhere.
app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  req.log?.error({ err }, "Unhandled error");
  if (res.headersSent) return;
  const isProd = process.env.NODE_ENV === "production";
  const message = err instanceof Error ? err.message : "Internal server error";
  res.status(500).json({
    error: isProd ? "Something went wrong. Please try again." : message,
  });
});

export default app;
