import { Router, type IRouter } from "express";
import { eq, and, sql } from "drizzle-orm";
import crypto from "crypto";
import { db, paymentLinksTable, walletsTable, transactionsTable, notificationsTable } from "@workspace/db";
import {
  CreatePaymentLinkBody,
  GetPaymentLinkParams,
  GetPaymentLinkResponse,
  PayPaymentLinkParams,
  PayPaymentLinkBody,
  ListPaymentLinksResponse,
  DeletePaymentLinkParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

function generateCode(): string {
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}

router.get("/payment-links", requireAuth, async (req, res): Promise<void> => {
  const links = await db
    .select()
    .from(paymentLinksTable)
    .where(eq(paymentLinksTable.sellerId, req.userId!));
  res.json(ListPaymentLinksResponse.parse(links));
});

router.post("/payment-links", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreatePaymentLinkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { title, description, amountPesewas, isFixedAmount } = parsed.data;

  const code = generateCode();
  const [link] = await db
    .insert(paymentLinksTable)
    .values({
      sellerId: req.userId!,
      title,
      description: description ?? null,
      amountPesewas: amountPesewas ?? null,
      isFixedAmount,
      code,
      isActive: true,
    })
    .returning();

  res.status(201).json(link);
});

router.get("/payment-links/:code", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
  const params = GetPaymentLinkParams.safeParse({ code: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [link] = await db
    .select()
    .from(paymentLinksTable)
    .where(eq(paymentLinksTable.code, params.data.code));

  if (!link) {
    res.status(404).json({ error: "Payment link not found" });
    return;
  }
  res.json(GetPaymentLinkResponse.parse(link));
});

router.post("/payment-links/:code/pay", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
  const params = PayPaymentLinkParams.safeParse({ code: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = PayPaymentLinkBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { buyerPhone, network, amountPesewas: requestedAmount } = parsed.data;

  const [link] = await db
    .select()
    .from(paymentLinksTable)
    .where(and(eq(paymentLinksTable.code, params.data.code), eq(paymentLinksTable.isActive, true)));

  if (!link) {
    res.status(400).json({ error: "Payment link not found or inactive" });
    return;
  }

  if (link.isFixedAmount && link.amountPesewas == null) {
    res.status(400).json({ error: "Payment link has no amount configured" });
    return;
  }

  const amountPesewas = link.isFixedAmount && link.amountPesewas != null
    ? link.amountPesewas
    : requestedAmount;

  if (!amountPesewas || amountPesewas <= 0) {
    res.status(400).json({ error: "Amount is required for flexible payment links" });
    return;
  }

  const [sellerWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, link.sellerId));
  if (!sellerWallet) {
    res.status(400).json({ error: "Seller wallet not found" });
    return;
  }

  // This is a public MoMo payment endpoint — funds arrive from an external MoMo network.
  // Internal wallet debits require authentication; only credit the seller here.
  const reference = crypto.randomUUID();

  let tx: typeof transactionsTable.$inferSelect;
  try {
    [tx] = await db.transaction(async (trx) => {
      // Atomically credit seller wallet
      const [updated] = await trx
        .update(walletsTable)
        .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${amountPesewas}` })
        .where(eq(walletsTable.id, sellerWallet.id))
        .returning({ balancePesewas: walletsTable.balancePesewas });

      if (!updated) {
        throw Object.assign(new Error("Seller wallet update failed"), { statusCode: 400 });
      }

      // Record incoming MoMo transaction for seller
      const [t] = await trx
        .insert(transactionsTable)
        .values({
          walletId: sellerWallet.id,
          type: "momo_in",
          amountPesewas,
          feePesewas: 0,
          network,
          reference,
          status: "completed",
          counterpartyPhone: buyerPhone,
          note: link.title,
        })
        .returning();

      // Increment paid count
      await trx
        .update(paymentLinksTable)
        .set({ totalPaidCount: sql`${paymentLinksTable.totalPaidCount} + 1` })
        .where(eq(paymentLinksTable.id, link.id));

      // Notify seller
      await trx.insert(notificationsTable).values({
        userId: link.sellerId,
        title: "Payment received",
        body: `You received GH₵${(amountPesewas / 100).toFixed(2)} via "${link.title}" from ${buyerPhone}`,
        type: "payment_link",
        referenceId: t.id,
      });

      return [t];
    });
  } catch (err) {
    const statusCode = (err as { statusCode?: number }).statusCode ?? 500;
    const message = err instanceof Error ? err.message : "Payment failed";
    res.status(statusCode).json({ error: message });
    return;
  }

  res.status(201).json(tx);
});

router.post("/payment-links/:code/confirm-delivery", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
  const [link] = await db.select().from(paymentLinksTable).where(eq(paymentLinksTable.code, raw));
  if (!link) { res.status(404).json({ error: "Payment link not found" }); return; }
  await db.insert(notificationsTable).values({
    userId: link.sellerId,
    title: "Delivery confirmed",
    body: `Buyer confirmed they received "${link.title}"`,
    type: "payment_link",
    referenceId: link.id,
  });
  res.json({ ok: true });
});

router.post("/payment-links/:code/dispute", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;
  const reason: string = (req.body as any)?.reason ?? "No reason provided";
  const [link] = await db.select().from(paymentLinksTable).where(eq(paymentLinksTable.code, raw));
  if (!link) { res.status(404).json({ error: "Payment link not found" }); return; }
  await db.insert(notificationsTable).values({
    userId: link.sellerId,
    title: "Payment disputed",
    body: `A buyer has disputed "${link.title}": ${reason}`,
    type: "payment_link",
    referenceId: link.id,
  });
  res.json({ ok: true });
});

router.delete("/payment-links/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeletePaymentLinkParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(paymentLinksTable)
    .where(and(eq(paymentLinksTable.id, params.data.id), eq(paymentLinksTable.sellerId, req.userId!)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Payment link not found" });
    return;
  }
  res.status(204).send();
});

export default router;
