/**
 * AliExpress Webhook Integration
 *
 * Endpoints:
 *  GET  /api/aliexpress/webhook — endpoint verification handshake
 *  POST /api/aliexpress/webhook — receive & process AliExpress webhook events
 *
 * Supported event categories:
 *  - Order Information   (ALIEXPRESS_ORDER_*)
 *  - Product Information (ALIEXPRESS_PRODUCT_*)
 *  - Instant Messaging   (ALIEXPRESS_MESSAGE_*)
 *  - Logistics Information (ALIEXPRESS_LOGISTICS_*)
 *
 * Signature verification uses HMAC-MD5 with ALIEXPRESS_APP_SECRET env var.
 * If the secret is not set, verification is skipped and events are still stored.
 *
 * Public endpoint — no auth middleware — accessible at:
 *   https://kasuwaa.com/api/aliexpress/webhook
 */

import { Router, type IRouter, type Request, type Response } from "express";
import crypto from "crypto";
import { db } from "@workspace/db";
import { aliexpressWebhookEventsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const ALIEXPRESS_APP_SECRET = process.env["ALIEXPRESS_APP_SECRET"] ?? "";

if (!ALIEXPRESS_APP_SECRET) {
  logger.warn(
    "ALIEXPRESS_APP_SECRET is not set — webhook signature verification will be skipped",
  );
}

// ── Signature Verification ────────────────────────────────────────────────────
//
// AliExpress signs webhook POSTs by:
//  1. Collecting all top-level fields from the JSON body (including "sign" key excluded)
//  2. Sorting keys alphabetically
//  3. Concatenating as: APP_SECRET + key1 + val1 + key2 + val2 + ... + APP_SECRET
//  4. MD5-hashing the result, uppercased

function verifySignature(
  payload: Record<string, unknown>,
  secret: string,
): boolean {
  const receivedSign = typeof payload["sign"] === "string" ? payload["sign"] : "";

  const params = Object.entries(payload)
    .filter(([k]) => k !== "sign")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}${v}`)
    .join("");

  const stringToSign = `${secret}${params}${secret}`;
  const expected = crypto
    .createHash("md5")
    .update(stringToSign, "utf8")
    .digest("hex")
    .toUpperCase();

  return expected === (receivedSign as string).toUpperCase();
}

// ── Event Handlers ────────────────────────────────────────────────────────────

async function handleOrderEvent(
  eventType: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const orderId = payload["order_id"] ?? payload["orderId"] ?? payload["id"];
  logger.info({ eventType, orderId }, "AliExpress order event");
  // TODO: sync order status to africart_orders or aliexpress_orders table
}

async function handleProductEvent(
  eventType: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const productId = payload["product_id"] ?? payload["productId"] ?? payload["id"];
  logger.info({ eventType, productId }, "AliExpress product event");
  // TODO: update product stock/price/status in africart_products if imported
}

async function handleMessageEvent(
  eventType: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const msgId = payload["msg_id"] ?? payload["msgId"];
  logger.info({ eventType, msgId }, "AliExpress instant message event");
  // TODO: forward to KASUWAA messaging system if buyer is linked
}

async function handleLogisticsEvent(
  eventType: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const orderId = payload["order_id"] ?? payload["orderId"];
  const trackingNo = payload["logistics_no"] ?? payload["trackingNo"];
  logger.info({ eventType, orderId, trackingNo }, "AliExpress logistics event");
  // TODO: update shipment tracking in order record
}

async function dispatchEvent(
  eventType: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const upper = eventType.toUpperCase();
  if (upper.includes("ORDER")) {
    await handleOrderEvent(eventType, payload);
  } else if (upper.includes("PRODUCT")) {
    await handleProductEvent(eventType, payload);
  } else if (upper.includes("MESSAGE") || upper.includes("MSG") || upper.includes("IM")) {
    await handleMessageEvent(eventType, payload);
  } else if (upper.includes("LOGISTICS") || upper.includes("SHIPPING") || upper.includes("TRACKING")) {
    await handleLogisticsEvent(eventType, payload);
  } else {
    logger.info({ eventType }, "AliExpress webhook: unhandled event type stored");
  }
}

// ── GET /api/aliexpress/webhook — Verification Handshake ─────────────────────
//
// AliExpress sends a GET request during endpoint setup to verify the URL is live.
// Responding with HTTP 200 confirms the endpoint is reachable.

router.get("/aliexpress/webhook", (req: Request, res: Response) => {
  req.log.info({ query: req.query }, "AliExpress webhook verification GET");
  res.status(200).send("OK");
});

// ── POST /api/aliexpress/webhook — Event Processing ───────────────────────────

router.post("/aliexpress/webhook", async (req: Request, res: Response) => {
  const rawBody: string =
    typeof (req as any).rawBody === "string"
      ? (req as any).rawBody
      : Buffer.isBuffer((req as any).rawBody)
        ? ((req as any).rawBody as Buffer).toString("utf-8")
        : JSON.stringify(req.body ?? {});

  const payload: Record<string, unknown> =
    req.body && typeof req.body === "object" ? (req.body as Record<string, unknown>) : {};

  // Resolve event type from multiple possible field names AliExpress uses
  const eventType = String(
    payload["topic"] ??
    payload["event_type"] ??
    payload["eventType"] ??
    payload["msgType"] ??
    payload["msg_type"] ??
    "unknown",
  );

  const msgId = payload["msg_id"] != null ? String(payload["msg_id"]) : null;
  const sellerId = payload["seller_id"] != null ? String(payload["seller_id"]) : null;

  req.log.info({ eventType, msgId, sellerId }, "AliExpress webhook POST received");

  // Respond 200 immediately so AliExpress doesn't retry while we process
  res.status(200).json({ received: true });

  // Signature check (best-effort — log result but don't drop event if secret missing)
  let signatureValid: "valid" | "invalid" | "skipped" = "skipped";
  if (ALIEXPRESS_APP_SECRET) {
    try {
      signatureValid = verifySignature(payload, ALIEXPRESS_APP_SECRET) ? "valid" : "invalid";
      if (signatureValid === "invalid") {
        logger.warn({ eventType, msgId }, "AliExpress webhook: signature INVALID — storing event anyway");
      }
    } catch (err) {
      logger.warn({ err }, "AliExpress webhook: signature check threw");
      signatureValid = "skipped";
    }
  }

  // Persist event to DB
  try {
    await db.insert(aliexpressWebhookEventsTable).values({
      eventType,
      topic: eventType !== "unknown" ? eventType : null,
      msgId,
      sellerId,
      payload,
      rawBody,
      signatureValid,
      processedAt: new Date(),
    });
  } catch (err) {
    logger.error({ err, eventType }, "AliExpress webhook: failed to persist event");
  }

  // Dispatch to domain handler (fire and forget — response already sent)
  dispatchEvent(eventType, payload).catch((err) => {
    logger.error({ err, eventType }, "AliExpress webhook: dispatchEvent threw");
  });
});

export default router;
