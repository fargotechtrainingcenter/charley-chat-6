import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, and, gt, lt, sql, desc, inArray } from "drizzle-orm";
import {
  db,
  adsTable,
  adEventsTable,
  walletsTable,
  transactionsTable,
  notificationsTable,
  auditLogsTable,
  usersTable,
  PRICE_PER_DAY_PESEWAS,
} from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { sendPushToUser } from "./push";

const router: IRouter = Router();

// ── Advertiser: create + pay for an ad ──────────────────────────────────────

const CreateAdBody = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  mediaUrl: z.string().min(1),
  mediaType: z.enum(["image", "video"]),
  linkType: z.enum(["marketplace", "website"]),
  linkUrl: z.string().min(1),
  audienceInterests: z.array(z.string()).default([]),
  durationDays: z.number().int().min(1).max(90),
});

router.post("/ads", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const parsed = CreateAdBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { durationDays } = parsed.data;
  const totalCostPesewas = durationDays * PRICE_PER_DAY_PESEWAS;

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet || wallet.balancePesewas < totalCostPesewas) {
    res.status(400).json({ error: "Insufficient wallet balance", totalCostPesewas, needsFunding: true });
    return;
  }

  const [ad] = await db.transaction(async (trx) => {
    await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${totalCostPesewas}` }).where(eq(walletsTable.id, wallet.id));
    await trx.insert(transactionsTable).values({
      walletId: wallet.id,
      type: "bill_payment",
      amountPesewas: totalCostPesewas,
      feePesewas: 0,
      reference: `AD-${Date.now()}`,
      status: "completed",
      note: `Advertisement: ${parsed.data.title} (${durationDays} day${durationDays > 1 ? "s" : ""})`,
    });
    return trx
      .insert(adsTable)
      .values({
        advertiserId: req.userId!,
        title: parsed.data.title,
        description: parsed.data.description,
        mediaUrl: parsed.data.mediaUrl,
        mediaType: parsed.data.mediaType,
        linkType: parsed.data.linkType,
        linkUrl: parsed.data.linkUrl,
        audienceInterests: parsed.data.audienceInterests,
        durationDays,
        totalCostPesewas,
        status: "pending_approval",
      })
      .returning();
  });

  res.status(201).json(ad);
});

router.get("/ads/mine", requireAuth, async (req, res): Promise<void> => {
  const ads = await db.select().from(adsTable).where(eq(adsTable.advertiserId, req.userId!)).orderBy(desc(adsTable.createdAt));
  res.json(ads);
});

// ── Public: fetch active ads for a placement, ranked by interest match ──────

router.get("/ads/active", requireAuth, async (req, res): Promise<void> => {
  const placement = String(req.query.placement ?? "discover");
  const interests = (req.query.interests ? String(req.query.interests).split(",") : []).filter(Boolean);
  const limit = Math.min(Number(req.query.limit ?? 5), 20);

  const candidates = await db
    .select()
    .from(adsTable)
    .where(and(eq(adsTable.status, "active"), gt(adsTable.endsAt, new Date())))
    .orderBy(desc(adsTable.createdAt))
    .limit(50);

  // Simple interest-based ranking: ads whose audienceInterests overlap the
  // caller's interests are boosted to the front; ties broken by recency.
  const ranked = candidates
    .map((ad) => {
      const overlap = interests.length && ad.audienceInterests.length
        ? ad.audienceInterests.filter((i) => interests.includes(i)).length
        : 0;
      return { ad, overlap };
    })
    .sort((a, b) => b.overlap - a.overlap)
    .slice(0, limit)
    .map((r) => r.ad);

  res.json(ranked.map((ad) => ({
    id: ad.id,
    title: ad.title,
    description: ad.description,
    mediaUrl: ad.mediaUrl,
    mediaType: ad.mediaType,
    linkType: ad.linkType,
    linkUrl: ad.linkUrl,
  })));

  // Fire-and-forget impression events for whatever was actually served
  void Promise.all(
    ranked.map((ad) =>
      db.insert(adEventsTable).values({ adId: ad.id, eventType: "impression", placement: placement as any, userId: req.userId! }),
    ),
  );
});

const TrackEventBody = z.object({
  eventType: z.enum(["view", "click", "purchase"]),
  placement: z.enum(["story", "reel", "discover", "marketplace"]),
});

router.post("/ads/:id/track", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = TrackEventBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  await db.insert(adEventsTable).values({
    adId: id,
    eventType: parsed.data.eventType,
    placement: parsed.data.placement,
    userId: req.userId!,
  });
  res.status(201).json({ ok: true });
});

// ── Advertiser analytics ─────────────────────────────────────────────────────

router.get("/ads/:id/analytics", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [ad] = await db.select().from(adsTable).where(eq(adsTable.id, id));
  if (!ad || ad.advertiserId !== req.userId) { res.status(404).json({ error: "Ad not found" }); return; }

  const events = await db.select().from(adEventsTable).where(eq(adEventsTable.adId, id));

  const reach = new Set(events.filter((e) => e.userId).map((e) => e.userId)).size;
  const impressions = events.filter((e) => e.eventType === "impression").length;
  const views = events.filter((e) => e.eventType === "view").length;
  const clicks = events.filter((e) => e.eventType === "click").length;
  const purchases = events.filter((e) => e.eventType === "purchase").length;
  const engagementRate = impressions > 0 ? Math.round(((views + clicks) / impressions) * 1000) / 10 : 0;

  // Daily breakdown for the ad's active window
  const dailyMap = new Map<string, { impressions: number; views: number; clicks: number; purchases: number }>();
  for (const e of events) {
    const day = e.createdAt.toISOString().slice(0, 10);
    const bucket = dailyMap.get(day) ?? { impressions: 0, views: 0, clicks: 0, purchases: 0 };
    bucket[e.eventType === "impression" ? "impressions" : e.eventType === "view" ? "views" : e.eventType === "click" ? "clicks" : "purchases"]++;
    dailyMap.set(day, bucket);
  }
  const daily = [...dailyMap.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([date, stats]) => ({ date, ...stats }));

  res.json({ adId: id, reach, impressions, views, clicks, purchases, engagementRate, daily });
});

// ── Admin: approval queue ────────────────────────────────────────────────────

router.get("/admin/ads", requireAdminAuth, async (req, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const rows = await db
    .select({
      id: adsTable.id,
      advertiserId: adsTable.advertiserId,
      advertiserName: usersTable.fullName,
      title: adsTable.title,
      mediaUrl: adsTable.mediaUrl,
      mediaType: adsTable.mediaType,
      durationDays: adsTable.durationDays,
      totalCostPesewas: adsTable.totalCostPesewas,
      status: adsTable.status,
      createdAt: adsTable.createdAt,
    })
    .from(adsTable)
    .innerJoin(usersTable, eq(usersTable.id, adsTable.advertiserId))
    .where(status ? eq(adsTable.status, status as any) : undefined)
    .orderBy(desc(adsTable.createdAt));
  res.json(rows);
});

router.patch("/admin/ads/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [ad] = await db.select().from(adsTable).where(eq(adsTable.id, id));
  if (!ad) { res.status(404).json({ error: "Ad not found" }); return; }
  if (ad.status !== "pending_approval") { res.status(400).json({ error: `Ad is already ${ad.status}` }); return; }

  const startedAt = new Date();
  const endsAt = new Date(startedAt.getTime() + ad.durationDays * 24 * 60 * 60 * 1000);

  await db.transaction(async (trx) => {
    await trx.update(adsTable).set({ status: "active", startedAt, endsAt }).where(eq(adsTable.id, id));
    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "ad.approve",
      entityType: "ad",
      entityId: id,
      metadata: { durationDays: ad.durationDays },
    });
    await trx.insert(notificationsTable).values({
      userId: ad.advertiserId,
      title: "Advertisement approved",
      body: `Your ad "${ad.title}" is now live for ${ad.durationDays} day${ad.durationDays > 1 ? "s" : ""}.`,
      type: "ad_approved",
      referenceId: id,
    });
  });

  void sendPushToUser(ad.advertiserId, { title: "Ad approved", body: `Your ad "${ad.title}" is now live.` });
  res.json({ ok: true, startedAt, endsAt });
});

const RejectAdBody = z.object({ reason: z.string().min(1) });

router.patch("/admin/ads/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = RejectAdBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [ad] = await db.select().from(adsTable).where(eq(adsTable.id, id));
  if (!ad) { res.status(404).json({ error: "Ad not found" }); return; }
  if (ad.status !== "pending_approval") { res.status(400).json({ error: `Ad is already ${ad.status}` }); return; }

  await db.transaction(async (trx) => {
    // Refund the advertiser since they already paid at creation time
    const [wallet] = await trx.select().from(walletsTable).where(eq(walletsTable.userId, ad.advertiserId));
    if (wallet) {
      await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${ad.totalCostPesewas}` }).where(eq(walletsTable.id, wallet.id));
      await trx.insert(transactionsTable).values({
        walletId: wallet.id,
        type: "escrow_refund",
        amountPesewas: ad.totalCostPesewas,
        feePesewas: 0,
        reference: `AD-REFUND-${Date.now()}`,
        status: "completed",
        note: `Refund: ad "${ad.title}" rejected — ${parsed.data.reason}`,
      });
    }

    await trx.update(adsTable).set({ status: "rejected", rejectionReason: parsed.data.reason }).where(eq(adsTable.id, id));
    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "ad.reject",
      entityType: "ad",
      entityId: id,
      metadata: { reason: parsed.data.reason },
    });
    await trx.insert(notificationsTable).values({
      userId: ad.advertiserId,
      title: "Advertisement rejected",
      body: `Your ad "${ad.title}" was rejected: ${parsed.data.reason}. You've been refunded GH₵${(ad.totalCostPesewas / 100).toFixed(2)}.`,
      type: "ad_rejected",
      referenceId: id,
    });
  });

  void sendPushToUser(ad.advertiserId, { title: "Ad rejected", body: `Your ad "${ad.title}" was rejected. You've been refunded.` });
  res.json({ ok: true });
});

export default router;
