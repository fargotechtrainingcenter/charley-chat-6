import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, and, or, asc, desc, sql } from "drizzle-orm";
import {
  db,
  disputesTable,
  disputeMessagesTable,
  escrowTransactionsTable,
  walletsTable,
  transactionsTable,
  notificationsTable,
  auditLogsTable,
  usersTable,
  messagesTable,
} from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { emitToUser } from "../lib/socket";
import { sendPushToUser } from "./push";

const router: IRouter = Router();

async function notifyBothParties(
  dispute: { id: string; buyerId: string; sellerId: string },
  title: string,
  body: string,
) {
  for (const userId of [dispute.buyerId, dispute.sellerId]) {
    await db.insert(notificationsTable).values({ userId, title, body, type: "dispute", referenceId: dispute.id });
    emitToUser(userId, "dispute_updated", { disputeId: dispute.id });
    void sendPushToUser(userId, { title, body, url: `/dispute/${dispute.id}`, tag: `dispute-${dispute.id}` });
  }
}

// ── User-facing: view + participate in a dispute ────────────────────────────

router.get("/disputes/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute || (dispute.buyerId !== req.userId && dispute.sellerId !== req.userId)) {
    res.status(404).json({ error: "Dispute not found" });
    return;
  }
  const [escrow] = await db.select().from(escrowTransactionsTable).where(eq(escrowTransactionsTable.id, dispute.escrowId));
  const messages = await db
    .select()
    .from(disputeMessagesTable)
    .where(eq(disputeMessagesTable.disputeId, id))
    .orderBy(asc(disputeMessagesTable.createdAt));

  res.json({ dispute, escrow, messages });
});

router.get("/disputes/by-escrow/:escrowId", requireAuth, async (req, res): Promise<void> => {
  const escrowId = String(req.params.escrowId);
  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.escrowId, escrowId));
  if (!dispute || (dispute.buyerId !== req.userId && dispute.sellerId !== req.userId)) {
    res.status(404).json({ error: "Dispute not found" });
    return;
  }
  res.json(dispute);
});

const PostDisputeMessageBody = z.object({
  content: z.string().optional(),
  mediaUrl: z.string().optional(),
  mediaType: z.enum(["image", "video", "voice", "document"]).optional(),
});

router.post("/disputes/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = PostDisputeMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  if (!parsed.data.content && !parsed.data.mediaUrl) {
    res.status(400).json({ error: "Message must include text or an evidence attachment" });
    return;
  }

  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute || (dispute.buyerId !== req.userId && dispute.sellerId !== req.userId)) {
    res.status(404).json({ error: "Dispute not found" });
    return;
  }
  if (dispute.status === "resolved") {
    res.status(400).json({ error: "This dispute has already been resolved" });
    return;
  }

  const role = dispute.buyerId === req.userId ? "buyer" : "seller";
  const [message] = await db
    .insert(disputeMessagesTable)
    .values({
      disputeId: id,
      senderRole: role,
      senderUserId: req.userId!,
      content: parsed.data.content,
      mediaUrl: parsed.data.mediaUrl,
      mediaType: parsed.data.mediaType,
    })
    .returning();

  const otherUserId = role === "buyer" ? dispute.sellerId : dispute.buyerId;
  emitToUser(otherUserId, "dispute_message", { disputeId: id, message });

  res.status(201).json(message);
});

// ── Admin-facing: dispute queue + resolution ─────────────────────────────────

router.get("/admin/disputes", requireAdminAuth, async (req, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const rows = await db
    .select({
      id: disputesTable.id,
      escrowId: disputesTable.escrowId,
      buyerId: disputesTable.buyerId,
      sellerId: disputesTable.sellerId,
      assignedAdminId: disputesTable.assignedAdminId,
      status: disputesTable.status,
      resolution: disputesTable.resolution,
      escrowTitle: escrowTransactionsTable.title,
      amountPesewas: escrowTransactionsTable.amountPesewas,
      createdAt: disputesTable.createdAt,
    })
    .from(disputesTable)
    .innerJoin(escrowTransactionsTable, eq(escrowTransactionsTable.id, disputesTable.escrowId))
    .where(status ? eq(disputesTable.status, status as "open" | "evidence_requested" | "resolved") : undefined)
    .orderBy(desc(disputesTable.createdAt));
  res.json(rows);
});

router.get("/admin/disputes/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute) { res.status(404).json({ error: "Dispute not found" }); return; }

  const [escrow] = await db.select().from(escrowTransactionsTable).where(eq(escrowTransactionsTable.id, dispute.escrowId));
  const [buyer] = await db.select({ id: usersTable.id, fullName: usersTable.fullName, phone: usersTable.phone }).from(usersTable).where(eq(usersTable.id, dispute.buyerId));
  const [seller] = await db.select({ id: usersTable.id, fullName: usersTable.fullName, phone: usersTable.phone }).from(usersTable).where(eq(usersTable.id, dispute.sellerId));
  const messages = await db
    .select()
    .from(disputeMessagesTable)
    .where(eq(disputeMessagesTable.disputeId, id))
    .orderBy(asc(disputeMessagesTable.createdAt));
  // Prior 1:1 chat history between buyer and seller, for admin context
  const chatHistory = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(eq(messagesTable.senderId, dispute.buyerId), eq(messagesTable.receiverId, dispute.sellerId)),
        and(eq(messagesTable.senderId, dispute.sellerId), eq(messagesTable.receiverId, dispute.buyerId)),
      ),
    )
    .orderBy(asc(messagesTable.createdAt));

  res.json({ dispute, escrow, buyer, seller, messages, chatHistory });
});

router.patch("/admin/disputes/:id/claim", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute) { res.status(404).json({ error: "Dispute not found" }); return; }

  await db.update(disputesTable).set({ assignedAdminId: req.adminId ?? null }).where(eq(disputesTable.id, id));
  await db.insert(auditLogsTable).values({
    adminId: req.adminId ?? null,
    action: "dispute.claim",
    entityType: "dispute",
    entityId: id,
    metadata: {},
  });
  res.json({ ok: true });
});

const PostAdminDisputeMessageBody = z.object({
  content: z.string().optional(),
  mediaUrl: z.string().optional(),
  mediaType: z.enum(["image", "video", "voice", "document"]).optional(),
});

router.post("/admin/disputes/:id/messages", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = PostAdminDisputeMessageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute) { res.status(404).json({ error: "Dispute not found" }); return; }

  const [message] = await db
    .insert(disputeMessagesTable)
    .values({
      disputeId: id,
      senderRole: "admin",
      senderAdminId: req.adminId ?? null,
      content: parsed.data.content,
      mediaUrl: parsed.data.mediaUrl,
      mediaType: parsed.data.mediaType,
    })
    .returning();

  emitToUser(dispute.buyerId, "dispute_message", { disputeId: id, message });
  emitToUser(dispute.sellerId, "dispute_message", { disputeId: id, message });
  res.status(201).json(message);
});

router.post("/admin/disputes/:id/request-evidence", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { note } = z.object({ note: z.string().optional() }).parse(req.body ?? {});
  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute) { res.status(404).json({ error: "Dispute not found" }); return; }
  if (dispute.status === "resolved") { res.status(400).json({ error: "Dispute already resolved" }); return; }

  await db.transaction(async (trx) => {
    await trx.update(disputesTable).set({ status: "evidence_requested" }).where(eq(disputesTable.id, id));
    await trx.insert(disputeMessagesTable).values({
      disputeId: id,
      senderRole: "system",
      content: note ? `Support requested more evidence: ${note}` : "Support requested more evidence for this dispute.",
    });
    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "dispute.request_evidence",
      entityType: "dispute",
      entityId: id,
      metadata: { note: note ?? null },
    });
  });

  await notifyBothParties(dispute, "More evidence requested", note ?? "Support has requested more evidence for your dispute. Please respond in the dispute chat.");
  res.json({ ok: true });
});

const ResolveDisputeBody = z.object({
  resolution: z.enum(["released_to_seller", "refunded_to_buyer", "partial_refund"]),
  buyerRefundPesewas: z.number().int().nonnegative().optional(),
  notes: z.string().optional(),
});

router.patch("/admin/disputes/:id/resolve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = ResolveDisputeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [dispute] = await db.select().from(disputesTable).where(eq(disputesTable.id, id));
  if (!dispute) { res.status(404).json({ error: "Dispute not found" }); return; }
  if (dispute.status === "resolved") { res.status(400).json({ error: "Dispute already resolved" }); return; }

  const [escrow] = await db.select().from(escrowTransactionsTable).where(eq(escrowTransactionsTable.id, dispute.escrowId));
  if (!escrow) { res.status(404).json({ error: "Escrow not found" }); return; }

  const { resolution, notes } = parsed.data;
  let buyerRefundPesewas = 0;
  let sellerAmountPesewas = 0;

  if (resolution === "released_to_seller") {
    sellerAmountPesewas = escrow.amountPesewas;
  } else if (resolution === "refunded_to_buyer") {
    buyerRefundPesewas = escrow.amountPesewas;
  } else {
    const refund = parsed.data.buyerRefundPesewas;
    if (refund === undefined || refund > escrow.amountPesewas) {
      res.status(400).json({ error: "buyerRefundPesewas is required and must not exceed the escrow amount for a partial refund" });
      return;
    }
    buyerRefundPesewas = refund;
    sellerAmountPesewas = escrow.amountPesewas - refund;
  }

  await db.transaction(async (trx) => {
    if (buyerRefundPesewas > 0) {
      const [buyerWallet] = await trx.select().from(walletsTable).where(eq(walletsTable.userId, dispute.buyerId));
      if (buyerWallet) {
        await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${buyerRefundPesewas}` }).where(eq(walletsTable.id, buyerWallet.id));
        await trx.insert(transactionsTable).values({
          walletId: buyerWallet.id,
          type: "escrow_refund",
          amountPesewas: buyerRefundPesewas,
          feePesewas: 0,
          reference: crypto.randomUUID(),
          status: "completed",
          note: `Dispute refund: ${escrow.title}`,
        });
      }
    }
    if (sellerAmountPesewas > 0) {
      const [sellerWallet] = await trx.select().from(walletsTable).where(eq(walletsTable.userId, dispute.sellerId));
      if (sellerWallet) {
        await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${sellerAmountPesewas}` }).where(eq(walletsTable.id, sellerWallet.id));
        await trx.insert(transactionsTable).values({
          walletId: sellerWallet.id,
          type: "escrow_release",
          amountPesewas: sellerAmountPesewas,
          feePesewas: 0,
          reference: crypto.randomUUID(),
          status: "completed",
          note: `Dispute resolution: ${escrow.title}`,
        });
      }
    }

    await trx.update(escrowTransactionsTable).set({ status: "released" }).where(eq(escrowTransactionsTable.id, escrow.id));

    await trx.update(disputesTable).set({
      status: "resolved",
      resolution,
      buyerRefundPesewas: resolution === "released_to_seller" ? null : buyerRefundPesewas,
      resolvedByAdminId: req.adminId ?? null,
      resolvedAt: new Date(),
      resolutionNotes: notes ?? null,
    }).where(eq(disputesTable.id, id));

    await trx.insert(disputeMessagesTable).values({
      disputeId: id,
      senderRole: "system",
      content: `Dispute resolved: ${resolution.replace(/_/g, " ")}.${notes ? ` Note: ${notes}` : ""}`,
    });

    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "dispute.resolve",
      entityType: "dispute",
      entityId: id,
      metadata: { resolution, buyerRefundPesewas, sellerAmountPesewas, notes: notes ?? null },
    });
  });

  emitToUser(dispute.buyerId, "balance_updated", { userId: dispute.buyerId });
  emitToUser(dispute.sellerId, "balance_updated", { userId: dispute.sellerId });

  const resolutionSummary =
    resolution === "released_to_seller"
      ? `The funds for "${escrow.title}" have been released to the seller.`
      : resolution === "refunded_to_buyer"
        ? `You've been fully refunded GH₵${(buyerRefundPesewas / 100).toFixed(2)} for "${escrow.title}".`
        : `The dispute for "${escrow.title}" has been resolved with a partial refund.`;
  await notifyBothParties(dispute, "Dispute resolved", resolutionSummary);

  res.json({ ok: true, resolution, buyerRefundPesewas, sellerAmountPesewas });
});

export default router;
