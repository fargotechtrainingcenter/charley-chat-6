import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, reviewsTable, vendorsTable } from "@workspace/db";
import { ListVendorReviewsParams, ListVendorReviewsResponse, CreateReviewBody } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.get("/reviews/vendor/:vendorId", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.vendorId) ? req.params.vendorId[0] : req.params.vendorId;
  const params = ListVendorReviewsParams.safeParse({ vendorId: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const reviews = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.vendorId, params.data.vendorId));

  res.json(ListVendorReviewsResponse.parse(reviews));
});

router.post("/reviews", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateReviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { vendorId, transactionId, rating, comment } = parsed.data;

  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, vendorId));
  if (!vendor) {
    res.status(404).json({ error: "Vendor not found" });
    return;
  }

  const [review] = await db.transaction(async (trx) => {
    const [r] = await trx
      .insert(reviewsTable)
      .values({
        reviewerId: req.userId!,
        vendorId,
        transactionId: transactionId ?? null,
        rating,
        comment: comment ?? null,
      })
      .returning();

    // Recalculate vendor rating average
    await trx
      .update(vendorsTable)
      .set({
        totalReviews: sql`${vendorsTable.totalReviews} + 1`,
        ratingAvg: sql`
          (${vendorsTable.ratingAvg}::numeric * ${vendorsTable.totalReviews} + ${rating})
          / (${vendorsTable.totalReviews} + 1)
        `,
      })
      .where(eq(vendorsTable.id, vendorId));

    return [r];
  });

  res.status(201).json(review);
});

export default router;
