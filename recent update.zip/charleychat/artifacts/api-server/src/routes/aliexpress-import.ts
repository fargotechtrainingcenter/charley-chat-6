/**
 * AliExpress Vendor Import Routes
 *
 * All routes require auth + verified vendor account.
 * Credentials live server-side only — never returned to clients.
 *
 * GET  /api/aliexpress/search              — search AliExpress products
 * GET  /api/aliexpress/product/:productId  — full product detail
 * POST /api/aliexpress/import             — start import job
 * GET  /api/aliexpress/imports            — vendor's import job history
 * POST /api/aliexpress/imports/:jobId/retry — re-queue failed job
 * POST /api/aliexpress/sync              — admin: manual sync trigger
 */

import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { logger } from "../lib/logger";
import {
  searchProducts,
  getProductDetail,
  AliexpressApiError,
} from "../lib/aliexpress-client";
import { syncAliexpressProducts } from "../lib/aliexpress-sync";

const router: IRouter = Router();

// ── requireVendor middleware ───────────────────────────────────────────────────

async function requireVendor(req: Request, res: Response, next: NextFunction): Promise<void> {
  const userId = (req as any).userId;
  const result = await db.execute(
    sql`SELECT id FROM vendors
        WHERE user_id = ${userId}::uuid
          AND is_suspended = false
          AND is_verified = true
          AND status = 'approved'
        LIMIT 1`,
  );
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) {
    res.status(403).json({ error: "Only verified and approved vendors can access AliExpress import" });
    return;
  }
  (req as any).vendorId = rows[0].id;
  next();
}

// ── Error normalizer ──────────────────────────────────────────────────────────

function userFriendlyError(err: unknown): string {
  if (err instanceof AliexpressApiError) {
    const msg = err.message.toLowerCase();
    if (msg.includes("rate") || err.code === 27) return "Too many requests to AliExpress. Please wait a moment and try again.";
    if (msg.includes("not found") || msg.includes("invalid product")) return "This product is no longer available on AliExpress.";
    if (msg.includes("timeout") || msg.includes("network")) return "AliExpress is temporarily unavailable. Please try again later.";
    return "AliExpress returned an error. Please try again.";
  }
  return "An unexpected error occurred. Please try again.";
}

// ── GET /api/aliexpress/search ────────────────────────────────────────────────

router.get(
  "/aliexpress/search",
  requireAuth,
  requireVendor,
  async (req: Request, res: Response): Promise<void> => {
    const { keyword = "", category, page = "1", pageSize = "20" } = req.query as Record<string, string>;

    if (!keyword.trim()) {
      res.status(400).json({ error: "keyword is required" });
      return;
    }

    const start = Date.now();
    try {
      const results = await searchProducts(
        keyword.trim(),
        category || undefined,
        parseInt(page),
        Math.min(parseInt(pageSize), 50),
      );
      req.log.info(
        { keyword, page, elapsedMs: Date.now() - start, total: results.total },
        "AliExpress search complete",
      );
      res.json(results);
    } catch (err) {
      logger.error({ err, keyword, page }, "AliExpress search failed");
      res.status(502).json({ error: userFriendlyError(err) });
    }
  },
);

// ── GET /api/aliexpress/product/:productId ────────────────────────────────────

router.get(
  "/aliexpress/product/:productId",
  requireAuth,
  requireVendor,
  async (req: Request, res: Response): Promise<void> => {
    const productId = String(req.params.productId);
    const start = Date.now();

    try {
      const detail = await getProductDetail(productId);
      req.log.info(
        { productId, elapsedMs: Date.now() - start },
        "AliExpress product detail fetched",
      );
      res.json(detail);
    } catch (err) {
      logger.error({ err, productId }, "AliExpress product detail failed");
      res.status(502).json({ error: userFriendlyError(err) });
    }
  },
);

// ── POST /api/aliexpress/import ───────────────────────────────────────────────

router.post(
  "/aliexpress/import",
  requireAuth,
  requireVendor,
  async (req: Request, res: Response): Promise<void> => {
    const vendorId = (req as any).vendorId as string;
    const { aliexpressProductId, vendorPricePesewas } = req.body as {
      aliexpressProductId?: string;
      vendorPricePesewas?: number;
    };

    if (!aliexpressProductId) {
      res.status(400).json({ error: "aliexpressProductId is required" });
      return;
    }
    if (!vendorPricePesewas || vendorPricePesewas <= 0) {
      res.status(400).json({ error: "vendorPricePesewas must be a positive integer" });
      return;
    }

    // Create import job
    const jobResult = await db.execute(sql`
      INSERT INTO aliexpress_import_jobs
        (vendor_id, aliexpress_product_id, status, vendor_price_pesewas)
      VALUES
        (${vendorId}::uuid, ${aliexpressProductId}, 'queued', ${String(vendorPricePesewas)})
      RETURNING id
    `);
    const jobId = ((jobResult.rows ?? jobResult) as any[])[0].id as string;

    res.status(202).json({ jobId, status: "queued" });

    // Process asynchronously — response already sent
    processImportJob(jobId, vendorId, aliexpressProductId, vendorPricePesewas).catch((err) => {
      logger.error({ err, jobId, aliexpressProductId }, "Import job processing threw unexpectedly");
    });
  },
);

async function processImportJob(
  jobId: string,
  vendorId: string,
  aliexpressProductId: string,
  vendorPricePesewas: number,
): Promise<void> {
  try {
    // Mark as importing
    await db.execute(sql`
      UPDATE aliexpress_import_jobs SET status = 'importing', updated_at = NOW() WHERE id = ${jobId}::uuid
    `);

    const detail = await getProductDetail(aliexpressProductId);

    // Map AliExpress category to a KASUWAA category
    const category = mapCategory(detail.category);

    // Build postgres text[] literal for images
    const imgsPg =
      "{" +
      detail.images
        .slice(0, 10)
        .map((s) => '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"')
        .join(",") +
      "}";

    const customerPrice = Math.ceil(vendorPricePesewas * 1.1);
    const USD_TO_GHS = 15.5;
    const aliexpressPricePesewas = Math.round(detail.price * USD_TO_GHS * 100);

    const aliexpressRaw = JSON.stringify(detail);

    const prodResult = await db.execute(sql`
      INSERT INTO africart_products
        (vendor_id, name, description, category, seller_price_pesewas, price_pesewas,
         images, in_stock, is_wholesale, status, is_approved,
         aliexpress_product_id, aliexpress_price_pesewas, aliexpress_synced_at, aliexpress_raw)
      VALUES
        (${vendorId}::uuid,
         ${detail.title.slice(0, 255)},
         ${detail.description || null},
         ${category},
         ${vendorPricePesewas},
         ${customerPrice},
         ${imgsPg}::text[],
         ${detail.stock > 0},
         false,
         'pending',
         false,
         ${aliexpressProductId},
         ${aliexpressPricePesewas},
         NOW(),
         ${aliexpressRaw}::jsonb)
      RETURNING id
    `);
    const africartProductId = ((prodResult.rows ?? prodResult) as any[])[0].id as string;

    await db.execute(sql`
      UPDATE aliexpress_import_jobs
      SET status = 'done',
          africart_product_id = ${africartProductId}::uuid,
          aliexpress_title = ${detail.title.slice(0, 255)},
          updated_at = NOW()
      WHERE id = ${jobId}::uuid
    `);

    logger.info({ jobId, africartProductId, aliexpressProductId }, "AliExpress import job done");
  } catch (err) {
    // Log the raw error server-side; store only a user-safe message in the DB
    logger.error({ err, jobId, aliexpressProductId }, "AliExpress import job failed");
    const safeMsg = userFriendlyError(err);
    await db.execute(sql`
      UPDATE aliexpress_import_jobs
      SET status = 'failed', error = ${safeMsg}, updated_at = NOW()
      WHERE id = ${jobId}::uuid
    `).catch(() => {});
  }
}

function mapCategory(aliexpressCategory: string): string {
  const cat = aliexpressCategory.toLowerCase();
  if (cat.includes("phone") || cat.includes("mobile") || cat.includes("gadget")) return "Phones & Gadgets";
  if (cat.includes("electron") || cat.includes("computer") || cat.includes("laptop")) return "Electronics";
  if (cat.includes("cloth") || cat.includes("fashion") || cat.includes("apparel") || cat.includes("wear")) return "Fashion";
  if (cat.includes("beauty") || cat.includes("cosmetic") || cat.includes("makeup")) return "Beauty & Personal Care";
  if (cat.includes("home") || cat.includes("furniture") || cat.includes("interior")) return "Furniture & Interior";
  if (cat.includes("applian")) return "Home Appliances";
  if (cat.includes("sport") || cat.includes("outdoor")) return "Sports & Outdoors";
  if (cat.includes("baby") || cat.includes("kid") || cat.includes("child")) return "Baby Products";
  if (cat.includes("auto") || cat.includes("car") || cat.includes("vehicle")) return "Automobiles";
  if (cat.includes("health") || cat.includes("medical")) return "Health & Pharmacy";
  if (cat.includes("book") || cat.includes("education")) return "Books & Education";
  if (cat.includes("pet")) return "Pet Supplies";
  if (cat.includes("industrial") || cat.includes("tool")) return "Industrial Equipment";
  if (cat.includes("building") || cat.includes("construct")) return "Building Materials";
  if (cat.includes("wholesale") || cat.includes("bulk")) return "Wholesale Market";
  return "Imported Products";
}

// ── GET /api/aliexpress/imports ───────────────────────────────────────────────

router.get(
  "/aliexpress/imports",
  requireAuth,
  requireVendor,
  async (req: Request, res: Response): Promise<void> => {
    const vendorId = (req as any).vendorId as string;
    const { status } = req.query as { status?: string };

    const statusFilter = status ? sql`AND status = ${status}` : sql``;

    const result = await db.execute(sql`
      SELECT id, aliexpress_product_id, aliexpress_title, status, error,
             africart_product_id, vendor_price_pesewas, created_at, updated_at
      FROM aliexpress_import_jobs
      WHERE vendor_id = ${vendorId}::uuid ${statusFilter}
      ORDER BY created_at DESC
      LIMIT 100
    `);
    const rows = (result.rows ?? result) as any[];

    res.json(rows.map((r) => ({
      id: r.id,
      aliexpressProductId: r.aliexpress_product_id,
      aliexpressTitle: r.aliexpress_title ?? null,
      status: r.status,
      error: r.error ?? null,
      africartProductId: r.africart_product_id ?? null,
      vendorPricePesewas: r.vendor_price_pesewas ? parseInt(r.vendor_price_pesewas) : null,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    })));
  },
);

// ── POST /api/aliexpress/imports/:jobId/retry ─────────────────────────────────

router.post(
  "/aliexpress/imports/:jobId/retry",
  requireAuth,
  requireVendor,
  async (req: Request, res: Response): Promise<void> => {
    const vendorId = (req as any).vendorId as string;
    const jobId = String(req.params.jobId);

    const jobResult = await db.execute(sql`
      SELECT id, vendor_id, aliexpress_product_id, vendor_price_pesewas, status
      FROM aliexpress_import_jobs
      WHERE id = ${jobId}::uuid AND vendor_id = ${vendorId}::uuid
      LIMIT 1
    `);
    const rows = (jobResult.rows ?? jobResult) as any[];

    if (!rows.length) {
      res.status(404).json({ error: "Import job not found" });
      return;
    }
    const job = rows[0];
    if (job.status !== "failed") {
      res.status(409).json({ error: "Only failed jobs can be retried" });
      return;
    }

    await db.execute(sql`
      UPDATE aliexpress_import_jobs
      SET status = 'queued', error = NULL, updated_at = NOW()
      WHERE id = ${jobId}::uuid
    `);

    res.status(202).json({ jobId, status: "queued" });

    processImportJob(
      jobId,
      vendorId,
      job.aliexpress_product_id,
      parseInt(job.vendor_price_pesewas ?? 0),
    ).catch((err) => {
      logger.error({ err, jobId }, "Retry import job threw unexpectedly");
    });
  },
);

// ── POST /api/aliexpress/sync — admin manual trigger ─────────────────────────

router.post(
  "/aliexpress/sync",
  requireAdminAuth,
  async (_req: Request, res: Response): Promise<void> => {
    res.status(202).json({ message: "Sync started in background" });
    syncAliexpressProducts().catch((err) => {
      logger.error({ err }, "Manual AliExpress sync failed");
    });
  },
);

export default router;
