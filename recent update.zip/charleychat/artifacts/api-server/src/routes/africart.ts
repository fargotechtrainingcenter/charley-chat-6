import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { requireAuth, requireAdminAuth, optionalAuth } from "../lib/auth";
import { logger } from "../lib/logger";
import { GoogleGenAI } from "@google/genai";

const router: IRouter = Router();

const CATEGORIES = [
  "Electronics",
  "Home Appliances",
  "Fashion",
  "Beauty & Personal Care",
  "Health & Pharmacy",
  "Groceries",
  "Agriculture",
  "Automobiles",
  "Industrial Equipment",
  "Building Materials",
  "Furniture & Interior",
  "Phones & Gadgets",
  "Books & Education",
  "Sports & Outdoors",
  "Baby Products",
  "Pet Supplies",
  "Services",
  "Wholesale Market",
  "Imported Products",
];

function pgTextArray(arr: string[]): string {
  return "{" + arr.map((s) => '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"').join(",") + "}";
}

function rowToProduct(r: any) {
  return {
    id: r.id,
    name: r.name,
    description: r.description,
    category: r.category,
    sellerPricePesewas: parseInt(r.seller_price_pesewas ?? 0),
    pricePesewas: parseInt(r.price_pesewas),
    flashDealPricePesewas: r.flash_deal_price_pesewas ? parseInt(r.flash_deal_price_pesewas) : null,
    flashDealEndsAt: r.flash_deal_ends_at ?? null,
    images: Array.isArray(r.images) ? r.images : [],
    vendorId: r.vendor_id,
    vendorName: r.business_name ?? r.vendor_name ?? "",
    rating: parseFloat(r.rating_avg ?? 0),
    reviewCount: parseInt(r.review_count ?? 0),
    inStock: r.in_stock,
    isWholesale: r.is_wholesale,
    moq: r.moq ?? null,
    status: r.status ?? (r.is_approved ? "approved" : "pending"),
    isApproved: r.is_approved,
    rejectionReason: r.rejection_reason ?? null,
  };
}

async function requireVendor(req: Request, res: Response, next: NextFunction): Promise<void> {
  const userId = (req as any).userId;
  const result = await db.execute(sql`SELECT id FROM vendors WHERE user_id = ${userId}::uuid AND is_suspended = false LIMIT 1`);
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) {
    res.status(403).json({ error: "Vendor account required" });
    return;
  }
  (req as any).vendorId = rows[0].id;
  next();
}

// ── Public Stats ──────────────────────────────────────────────────────────────

router.get("/africart/stats", async (_req, res): Promise<void> => {
  const [pResult, vResult] = await Promise.all([
    db.execute(sql`SELECT COUNT(*) AS cnt FROM africart_products WHERE is_deleted = false AND status = 'approved'`),
    db.execute(sql`SELECT COUNT(*) AS cnt FROM vendors WHERE is_suspended = false`),
  ]);
  const pRows = (pResult.rows ?? pResult) as any[];
  const vRows = (vResult.rows ?? vResult) as any[];
  res.json({
    totalProducts: parseInt(pRows[0]?.cnt ?? "0"),
    totalVendors: parseInt(vRows[0]?.cnt ?? "0"),
  });
});

// ── Categories ────────────────────────────────────────────────────────────────

router.get("/africart/categories", async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT category, COUNT(*) AS cnt
    FROM africart_products
    WHERE is_deleted = false AND status = 'approved'
    GROUP BY category
  `);
  const rows = (result.rows ?? result) as any[];
  const countMap: Record<string, number> = {};
  rows.forEach((r) => { countMap[r.category] = parseInt(r.cnt); });

  res.json(CATEGORIES.map((name, i) => ({
    id: `c${i + 1}`,
    name,
    slug: name,
    productCount: countMap[name] ?? 0,
  })));
});

// ── Banners ───────────────────────────────────────────────────────────────────

router.get("/africart/banners", async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT * FROM africart_banners WHERE is_active = true ORDER BY sort_order ASC, created_at DESC
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((b) => ({
    id: b.id,
    title: b.title,
    subtitle: b.subtitle ?? "",
    imageUrl: b.image_url,
    linkUrl: b.link_url ?? "",
    isActive: b.is_active,
    sortOrder: b.sort_order,
  })));
});

// ── Ads (public) ─────────────────────────────────────────────────────────────

router.get("/africart/ads", async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT a.*, v.business_name AS vendor_business_name
    FROM africart_ads a
    LEFT JOIN vendors v ON v.id = a.vendor_id
    WHERE a.status = 'active'
      AND a.is_paid = true
      AND (a.start_date IS NULL OR a.start_date <= NOW())
      AND (a.end_date IS NULL OR a.end_date >= NOW())
    ORDER BY a.created_at DESC
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((r) => ({
    id: r.id,
    vendorId: r.vendor_id,
    vendorName: r.vendor_name ?? r.vendor_business_name ?? "",
    title: r.title,
    description: r.description ?? "",
    imageUrl: r.image_url ?? "",
    linkUrl: r.link_url ?? "",
    discountPercent: r.discount_percent ?? null,
    promoLabel: r.promo_label ?? null,
    adType: r.ad_type,
    startDate: r.start_date,
    endDate: r.end_date,
  })));
});

// ── Products ──────────────────────────────────────────────────────────────────

router.get("/africart/products", async (req, res): Promise<void> => {
  const {
    category, q, inStock, isWholesale,
    minPrice, maxPrice, sort, limit = 50, offset = 0,
  } = req.query as any;

  const catFilter       = category       ? sql`AND p.category = ${String(category)}`                                                              : sql``;
  const qFilter         = q              ? sql`AND (p.name ILIKE ${`%${String(q)}%`} OR p.description ILIKE ${`%${String(q)}%`})`                : sql``;
  const stockFilter     = inStock === "true"     ? sql`AND p.in_stock = true`                                                                     : sql``;
  const wholesaleFilter = isWholesale === "true" ? sql`AND p.is_wholesale = true`                                                                 : sql``;
  const minFilter       = minPrice       ? sql`AND p.price_pesewas >= ${parseInt(String(minPrice))}`                                              : sql``;
  const maxFilter       = maxPrice       ? sql`AND p.price_pesewas <= ${parseInt(String(maxPrice))}`                                              : sql``;

  const orderByMap: Record<string, string> = {
    price_asc: "p.price_pesewas ASC",
    price_desc: "p.price_pesewas DESC",
    rating: "p.rating_avg DESC",
    popular: "p.review_count DESC",
  };
  const orderBy = sql.raw(orderByMap[String(sort)] ?? "p.created_at DESC");

  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.is_deleted = false AND p.status = 'approved'
    ${catFilter} ${qFilter} ${stockFilter} ${wholesaleFilter} ${minFilter} ${maxFilter}
    ORDER BY ${orderBy}
    LIMIT ${parseInt(String(limit))} OFFSET ${parseInt(String(offset))}
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

router.get("/africart/products/:id", async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const result = await db.execute(sql`
    SELECT p.*, v.business_name, v.logo_url, v.rating_avg AS vendor_rating,
           v.is_verified AS vendor_verified, v.location AS vendor_location,
           v.description AS vendor_description
    FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.id = ${id}::uuid AND p.is_deleted = false AND p.status = 'approved'
    LIMIT 1
  `);
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) { res.status(404).json({ error: "Product not found" }); return; }
  const p = rows[0];
  res.json({
    ...rowToProduct(p),
    vendor: {
      id: p.vendor_id,
      name: p.business_name,
      avatar: p.logo_url,
      rating: parseFloat(p.vendor_rating ?? 0),
      verified: p.vendor_verified,
      location: p.vendor_location,
      description: p.vendor_description,
    },
  });
});

router.post("/africart/products", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const { name, description, category, sellerPricePesewas, images, inStock, isWholesale, moq } = req.body;
  if (!name || !category || !sellerPricePesewas) {
    res.status(400).json({ error: "name, category, and sellerPricePesewas are required" }); return;
  }
  if (!CATEGORIES.includes(category)) {
    res.status(400).json({ error: `category must be one of: ${CATEGORIES.join(", ")}` }); return;
  }
  const sellerPrice = parseInt(sellerPricePesewas);
  const customerPrice = Math.ceil(sellerPrice * 1.1);
  const imgs = Array.isArray(images) ? (images as string[]) : [];
  const imgsPg = pgTextArray(imgs);
  const result = await db.execute(sql`
    INSERT INTO africart_products
      (vendor_id, name, description, category, seller_price_pesewas, price_pesewas, images, in_stock, is_wholesale, moq, status, is_approved)
    VALUES
      (${vendorId}::uuid, ${name}, ${description ?? null}, ${category},
       ${sellerPrice}, ${customerPrice}, ${imgsPg}::text[], ${inStock ?? true}, ${isWholesale ?? false},
       ${moq ? parseInt(moq) : null}, 'pending', false)
    RETURNING *
  `);
  const row = ((result.rows ?? result) as any[])[0];
  // Notify admin of new pending product
  await insertAdminNotification(
    "new_product",
    "New Product Pending Approval",
    `Vendor submitted "${name}" for review — category: ${category}.`,
    { productId: row?.id ?? null },
  );
  res.status(201).json(rowToProduct(row));
});

router.patch("/africart/products/:id", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const vendorId = (req as any).vendorId;
  const { name, description, category, sellerPricePesewas, images, inStock, isWholesale, moq,
          flashDealPricePesewas, flashDealEndsAt } = req.body;

  const existing = await db.execute(sql`SELECT id, seller_price_pesewas FROM africart_products WHERE id=${id}::uuid AND vendor_id=${vendorId}::uuid AND is_deleted=false`);
  if (!((existing.rows ?? existing) as any[]).length) {
    res.status(404).json({ error: "Product not found" }); return;
  }

  const newSellerPrice = sellerPricePesewas ? parseInt(sellerPricePesewas) : null;
  const newCustomerPrice = newSellerPrice ? Math.ceil(newSellerPrice * 1.1) : null;

  const result = await db.execute(sql`
    UPDATE africart_products SET
      name = COALESCE(${name ?? null}, name),
      description = COALESCE(${description ?? null}, description),
      category = COALESCE(${category ?? null}, category),
      seller_price_pesewas = COALESCE(${newSellerPrice}, seller_price_pesewas),
      price_pesewas = COALESCE(${newCustomerPrice}, price_pesewas),
      images = COALESCE(${Array.isArray(images) ? pgTextArray(images as string[]) : null}::text[], images),
      in_stock = COALESCE(${inStock ?? null}, in_stock),
      is_wholesale = COALESCE(${isWholesale ?? null}, is_wholesale),
      moq = COALESCE(${moq !== undefined ? moq : null}, moq),
      flash_deal_price_pesewas = COALESCE(${flashDealPricePesewas !== undefined ? flashDealPricePesewas : null}, flash_deal_price_pesewas),
      flash_deal_ends_at = COALESCE(${flashDealEndsAt ?? null}, flash_deal_ends_at),
      status = 'pending',
      is_approved = false,
      rejection_reason = null,
      updated_at = NOW()
    WHERE id = ${id}::uuid
    RETURNING *
  `);
  res.json(rowToProduct(((result.rows ?? result) as any[])[0]));
});

router.delete("/africart/products/:id", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const vendorId = (req as any).vendorId;
  await db.execute(sql`UPDATE africart_products SET is_deleted=true WHERE id=${id}::uuid AND vendor_id=${vendorId}::uuid`);
  res.sendStatus(204);
});

// Quick stock toggle — does NOT reset approval status
router.patch("/africart/seller/products/:id/stock", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const vendorId = (req as any).vendorId;
  const { inStock } = req.body as { inStock?: boolean };
  if (typeof inStock !== "boolean") {
    res.status(400).json({ error: "inStock must be a boolean" }); return;
  }
  const existing = await db.execute(sql`SELECT id FROM africart_products WHERE id=${id}::uuid AND vendor_id=${vendorId}::uuid AND is_deleted=false`);
  if (!((existing.rows ?? existing) as any[]).length) {
    res.status(404).json({ error: "Product not found" }); return;
  }
  await db.execute(sql`UPDATE africart_products SET in_stock=${inStock}, updated_at=NOW() WHERE id=${id}::uuid`);
  res.json({ success: true, inStock });
});

// ── Flash Deals ───────────────────────────────────────────────────────────────

router.get("/africart/flash-deals", async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT p.*, v.business_name
    FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.is_deleted = false AND p.status = 'approved'
      AND p.flash_deal_price_pesewas IS NOT NULL
      AND (p.flash_deal_ends_at IS NULL OR p.flash_deal_ends_at > NOW())
    ORDER BY p.updated_at DESC
    LIMIT 20
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((p) => ({
    id: p.id,
    productId: p.id,
    productName: p.name,
    originalPricePesewas: parseInt(p.price_pesewas),
    dealPricePesewas: parseInt(p.flash_deal_price_pesewas),
    image: (Array.isArray(p.images) ? p.images : [])[0] ?? "",
    endsAt: p.flash_deal_ends_at ?? new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    percentOff: Math.round((1 - parseInt(p.flash_deal_price_pesewas) / parseInt(p.price_pesewas)) * 100),
  })));
});

// ── Search ────────────────────────────────────────────────────────────────────

router.get("/africart/search", async (req, res): Promise<void> => {
  const q = String(req.query.q ?? "");
  if (!q.trim()) { res.json([]); return; }
  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.is_deleted = false AND p.status = 'approved'
      AND (p.name ILIKE ${"%" + q + "%"} OR p.description ILIKE ${"%" + q + "%"} OR p.category ILIKE ${"%" + q + "%"})
    ORDER BY p.rating_avg DESC LIMIT 50
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

// ── Vendors ───────────────────────────────────────────────────────────────────

router.get("/africart/vendors", async (req, res): Promise<void> => {
  const { q, limit = 50, offset = 0 } = req.query as any;
  const qFilter = q
    ? sql`AND (v.business_name ILIKE ${`%${String(q)}%`} OR v.description ILIKE ${`%${String(q)}%`})`
    : sql``;
  const result = await db.execute(sql`
    SELECT v.id, v.business_name, v.description, v.logo_url, v.cover_image_url,
           v.location, v.is_verified, v.created_at,
           COALESCE(ROUND(v.rating_avg::numeric, 1), 0) AS rating_avg,
           COUNT(DISTINCT p.id) AS total_products
    FROM vendors v
    LEFT JOIN africart_products p ON p.vendor_id = v.id AND p.is_deleted = false AND p.status = 'approved'
    WHERE v.is_suspended = false ${qFilter}
    GROUP BY v.id
    ORDER BY v.created_at DESC
    LIMIT ${parseInt(String(limit))} OFFSET ${parseInt(String(offset))}
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((v) => ({
    id: v.id,
    name: v.business_name ?? "",
    description: v.description ?? "",
    avatar: v.logo_url ?? `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(v.business_name ?? "")}`,
    coverImage: v.cover_image_url ?? "",
    location: v.location ?? "Ghana",
    verified: Boolean(v.is_verified),
    rating: parseFloat(v.rating_avg ?? 0),
    totalProducts: parseInt(v.total_products ?? 0),
    createdAt: v.created_at,
  })));
});

router.get("/africart/vendors/:id", async (req, res): Promise<void> => {
  const vendorId = String(req.params.id);
  const result = await db.execute(sql`
    SELECT v.id, v.user_id, v.business_name, v.business_type, v.description,
           v.logo_url, v.cover_image_url, v.location, v.is_verified, v.created_at,
           COALESCE(ROUND(AVG(r.rating)::numeric, 1), 0) AS rating_avg,
           COUNT(DISTINCT r.id) AS total_reviews,
           COUNT(DISTINCT p.id) AS total_products,
           COUNT(DISTINCT o.id) AS total_sales
    FROM vendors v
    LEFT JOIN africart_products p ON p.vendor_id = v.id AND p.is_deleted = false AND p.status = 'approved'
    LEFT JOIN africart_order_items oi ON oi.product_id = p.id
    LEFT JOIN africart_orders o ON o.id = oi.order_id
    LEFT JOIN reviews r ON r.vendor_id = v.id
    WHERE v.id = ${vendorId}::uuid
    GROUP BY v.id, v.user_id, v.business_name, v.business_type, v.description,
             v.logo_url, v.cover_image_url, v.location, v.is_verified, v.created_at
  `);
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) { res.status(404).json({ error: "Vendor not found" }); return; }
  const v = rows[0];
  const businessName = v.business_name ?? "";
  res.json({
    id: v.id,
    userId: v.user_id,
    businessName,
    businessType: v.business_type ?? null,
    description: v.description ?? null,
    logoUrl: v.logo_url ?? null,
    coverImageUrl: v.cover_image_url ?? null,
    location: v.location ?? null,
    isVerified: v.is_verified ?? false,
    ratingAvg: parseFloat(v.rating_avg ?? 0).toFixed(1),
    totalReviews: parseInt(v.total_reviews ?? 0),
    totalProducts: parseInt(v.total_products ?? 0),
    totalSales: parseInt(v.total_sales ?? 0),
    createdAt: v.created_at,
    avatar: v.logo_url ?? `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(businessName)}`,
    name: businessName,
    verified: v.is_verified ?? false,
    rating: parseFloat(v.rating_avg ?? 0),
  });
});

router.get("/africart/vendors/:id/products", async (req, res): Promise<void> => {
  const vendorId = String(req.params.id);
  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.vendor_id = ${vendorId}::uuid AND p.is_deleted = false AND p.status = 'approved'
    ORDER BY p.created_at DESC
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

// ── Orders ────────────────────────────────────────────────────────────────────

router.get("/africart/orders", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  const result = await db.execute(sql`
    SELECT o.*, u.full_name AS buyer_name
    FROM africart_orders o
    JOIN users u ON u.id = o.buyer_id
    WHERE o.buyer_id = ${userId}::uuid
    ORDER BY o.created_at DESC
  `);
  const rows = (result.rows ?? result) as any[];
  const orders = await Promise.all(rows.map(async (o) => {
    const items = await db.execute(sql`SELECT * FROM africart_order_items WHERE order_id = ${o.id}::uuid`);
    return { ...o, items: (items.rows ?? items) as any[] };
  }));
  res.json(orders.map((o) => ({
    id: o.id,
    buyerName: o.buyer_name,
    status: o.status,
    totalPesewas: parseInt(o.total_pesewas),
    createdAt: o.created_at,
    deliveryAddress: o.delivery_address,
    deliveryRegion: o.delivery_region,
    deliveryPhone: o.delivery_phone,
    deliveryFullName: o.delivery_full_name,
    momoPhone: o.momo_phone,
    items: o.items.map((i: any) => ({
      productId: i.product_id,
      name: i.product_name,
      image: i.product_image ?? "",
      qty: parseInt(i.qty),
      pricePesewas: parseInt(i.price_pesewas),
    })),
  })));
});

router.post("/africart/orders", optionalAuth, async (req, res): Promise<void> => {
  const userId: string | undefined = (req as any).userId;
  const { items, totalPesewas, delivery, momoPhone, deliveryFeePesewas: rawDeliveryFee, guestEmail, guestName } = req.body;
  if (!items?.length || !totalPesewas) {
    res.status(400).json({ error: "items and totalPesewas are required" }); return;
  }
  const productTotalPesewas = parseInt(totalPesewas);
  const deliveryFeePesewas = parseInt(rawDeliveryFee ?? 0) || 0;
  const deliveryCommissionPesewas = Math.round(deliveryFeePesewas * 0.03);
  const grandTotalPesewas = productTotalPesewas + deliveryFeePesewas + deliveryCommissionPesewas;

  const orderResult = await db.execute(sql`
    INSERT INTO africart_orders
      (buyer_id, total_pesewas, status, delivery_full_name, delivery_phone, delivery_address, delivery_region,
       momo_phone, delivery_fee_pesewas, delivery_commission_pesewas, guest_email, guest_name)
    VALUES
      (${userId ?? null}::uuid, ${grandTotalPesewas}, 'in_escrow',
       ${delivery?.fullName ?? null}, ${delivery?.phone ?? null},
       ${delivery?.address ?? null}, ${delivery?.region ?? null}, ${momoPhone ?? null},
       ${deliveryFeePesewas}, ${deliveryCommissionPesewas},
       ${guestEmail ?? null}, ${guestName ?? delivery?.fullName ?? null})
    RETURNING *
  `);
  const order = ((orderResult.rows ?? orderResult) as any[])[0];

  for (const item of items) {
    const prodId: string | null = item.productId ?? null;
    const vendId: string | null = item.vendorId ?? null;
    const customerPricePesewas = parseInt(item.pricePesewas);
    const sellerPricePesewas = Math.round(customerPricePesewas / 1.1);
    const markupPesewas = customerPricePesewas - sellerPricePesewas;

    await db.execute(sql`
      INSERT INTO africart_order_items
        (order_id, product_id, vendor_id, product_name, product_image, qty, price_pesewas)
      VALUES
        (${order.id}::uuid,
         ${prodId}::uuid,
         ${vendId}::uuid,
         ${item.productName ?? item.name ?? "Product"}, ${item.productImage ?? null},
         ${parseInt(item.qty)}, ${customerPricePesewas})
    `);

    await db.execute(sql`
      INSERT INTO africart_commissions
        (order_id, product_id, product_name, qty, seller_price_pesewas, customer_price_pesewas, markup_pesewas)
      VALUES
        (${order.id}::uuid, ${prodId}::uuid,
         ${item.productName ?? item.name ?? "Product"},
         ${parseInt(item.qty)}, ${sellerPricePesewas}, ${customerPricePesewas}, ${markupPesewas})
    `);
  }

  res.status(201).json({ id: order.id, status: order.status });
});

router.get("/africart/orders/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const userId = (req as any).userId;
  const result = await db.execute(sql`
    SELECT o.*, u.full_name AS buyer_name
    FROM africart_orders o JOIN users u ON u.id = o.buyer_id
    WHERE o.id = ${id}::uuid AND o.buyer_id = ${userId}::uuid
    LIMIT 1
  `);
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) { res.status(404).json({ error: "Order not found" }); return; }
  const o = rows[0];
  const itemsResult = await db.execute(sql`
    SELECT oi.*, p.vendor_id, v.business_name AS vendor_name
    FROM africart_order_items oi
    LEFT JOIN africart_products p ON p.id = oi.product_id
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE oi.order_id = ${id}::uuid
  `);
  const itemRows = (itemsResult.rows ?? itemsResult) as any[];
  res.json({
    id: o.id,
    buyerName: o.buyer_name,
    status: o.status,
    totalPesewas: parseInt(o.total_pesewas),
    createdAt: o.created_at,
    deliveryAddress: o.delivery_address,
    deliveryRegion: o.delivery_region,
    deliveryPhone: o.delivery_phone,
    momoPhone: o.momo_phone,
    vendorId: itemRows[0]?.vendor_id ?? null,
    vendorName: itemRows[0]?.vendor_name ?? "",
    items: itemRows.map((i) => ({
      productId: i.product_id,
      name: i.product_name,
      image: i.product_image ?? "",
      qty: parseInt(i.qty),
      pricePesewas: parseInt(i.price_pesewas),
    })),
  });
});

router.patch("/africart/orders/:id/status", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const userId = (req as any).userId;
  const { status } = req.body;
  const valid = ["in_escrow", "shipped", "delivered", "disputed", "complete", "pending"];
  if (!valid.includes(status)) { res.status(400).json({ error: "Invalid status" }); return; }
  await db.execute(sql`
    UPDATE africart_orders SET status=${status}, updated_at=NOW()
    WHERE id=${id}::uuid AND buyer_id=${userId}::uuid
  `);
  res.json({ ok: true, status });
});

// ── Wishlist ──────────────────────────────────────────────────────────────────

router.get("/africart/wishlist", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_wishlists w
    JOIN africart_products p ON p.id = w.product_id
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE w.user_id = ${userId}::uuid AND p.is_deleted = false
    ORDER BY w.created_at DESC
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

router.post("/africart/wishlist/:productId", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  const productId = String(req.params.productId);
  await db.execute(sql`
    INSERT INTO africart_wishlists (user_id, product_id)
    VALUES (${userId}::uuid, ${productId}::uuid)
    ON CONFLICT (user_id, product_id) DO NOTHING
  `);
  res.json({ ok: true });
});

router.delete("/africart/wishlist/:productId", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  const productId = String(req.params.productId);
  await db.execute(sql`DELETE FROM africart_wishlists WHERE user_id=${userId}::uuid AND product_id=${productId}::uuid`);
  res.sendStatus(204);
});

// ── Seller ────────────────────────────────────────────────────────────────────

router.get("/africart/seller/stats", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const products = await db.execute(sql`
    SELECT
      COUNT(*) AS cnt,
      COUNT(*) FILTER (WHERE status='approved') AS approved,
      COUNT(*) FILTER (WHERE status='pending') AS pending,
      COUNT(*) FILTER (WHERE status='rejected') AS rejected
    FROM africart_products WHERE vendor_id=${vendorId}::uuid AND is_deleted=false
  `);
  const earnings = await db.execute(sql`
    SELECT COALESCE(SUM(c.seller_price_pesewas * c.qty), 0) AS seller_revenue,
           COALESCE(SUM(c.markup_pesewas * c.qty), 0) AS platform_markup,
           COUNT(DISTINCT c.order_id) AS order_count
    FROM africart_commissions c
    JOIN africart_order_items i ON i.order_id = c.order_id AND i.product_id = c.product_id
    WHERE i.vendor_id = ${vendorId}::uuid
  `);
  const vendor = await db.execute(sql`SELECT rating_avg FROM vendors WHERE id=${vendorId}::uuid LIMIT 1`);
  const paidOut = await db.execute(sql`
    SELECT COALESCE(SUM(amount_pesewas), 0) AS total_paid
    FROM africart_payout_requests
    WHERE vendor_id = ${vendorId}::uuid AND status = 'approved'
  `);
  const vr = ((vendor.rows ?? vendor) as any[])[0];
  const er = ((earnings.rows ?? earnings) as any[])[0];
  const pr = ((products.rows ?? products) as any[])[0];
  const por = ((paidOut.rows ?? paidOut) as any[])[0];
  const totalRevenuePesewas = parseInt(er?.seller_revenue ?? 0);
  const totalPaidOutPesewas = parseInt(por?.total_paid ?? 0);
  res.json({
    totalRevenuePesewas,
    totalPaidOutPesewas,
    availableBalancePesewas: Math.max(0, totalRevenuePesewas - totalPaidOutPesewas),
    totalOrders: parseInt(er?.order_count ?? 0),
    totalProducts: parseInt(pr?.cnt ?? 0),
    approvedProducts: parseInt(pr?.approved ?? 0),
    pendingProducts: parseInt(pr?.pending ?? 0),
    rejectedProducts: parseInt(pr?.rejected ?? 0),
    monthlyGrowthPercent: 0,
    avgRating: parseFloat(vr?.rating_avg ?? 0).toFixed(1),
    ratingAvg: parseFloat(vr?.rating_avg ?? 0),
  });
});

router.get("/africart/seller/products", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.vendor_id=${vendorId}::uuid AND p.is_deleted=false
    ORDER BY p.created_at DESC
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

router.patch("/africart/seller/orders/:id/status", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const vendorId = (req as any).vendorId;
  const { status } = req.body;
  const valid = ["shipped", "delivered", "cancelled"];
  if (!valid.includes(status)) { res.status(400).json({ error: "Invalid status for vendor" }); return; }
  const check = await db.execute(sql`
    SELECT 1 FROM africart_order_items WHERE order_id=${id}::uuid AND vendor_id=${vendorId}::uuid LIMIT 1
  `);
  if (!((check.rows ?? check) as any[]).length) { res.status(403).json({ error: "Not your order" }); return; }
  await db.execute(sql`UPDATE africart_orders SET status=${status}, updated_at=NOW() WHERE id=${id}::uuid`);
  res.json({ ok: true, status });
});

router.get("/africart/seller/orders", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const result = await db.execute(sql`
    SELECT DISTINCT o.*, u.full_name AS buyer_name
    FROM africart_orders o
    JOIN africart_order_items i ON i.order_id = o.id
    JOIN users u ON u.id = o.buyer_id
    WHERE i.vendor_id = ${vendorId}::uuid
    ORDER BY o.created_at DESC LIMIT 100
  `);
  const rows = (result.rows ?? result) as any[];
  const orders = await Promise.all(rows.map(async (o) => {
    const items = await db.execute(sql`SELECT * FROM africart_order_items WHERE order_id=${o.id}::uuid AND vendor_id=${vendorId}::uuid`);
    return {
      id: o.id,
      buyerName: o.buyer_name,
      deliveryPhone: o.delivery_phone ?? "",
      deliveryAddress: o.delivery_address ?? "",
      deliveryRegion: o.delivery_region ?? "",
      deliveryFullName: o.delivery_full_name ?? o.buyer_name ?? "",
      status: o.status,
      totalPesewas: parseInt(o.total_pesewas),
      deliveryFeePesewas: parseInt(o.delivery_fee_pesewas ?? 0),
      deliveryCommissionPesewas: parseInt(o.delivery_commission_pesewas ?? 0),
      createdAt: o.created_at,
      items: ((items.rows ?? items) as any[]).map((i: any) => ({
        productId: i.product_id,
        name: i.product_name,
        image: i.product_image ?? "",
        qty: parseInt(i.qty),
        pricePesewas: parseInt(i.price_pesewas),
      })),
    };
  }));
  res.json(orders);
});

// ── Admin ─────────────────────────────────────────────────────────────────────

router.get("/africart/admin/stats", requireAdminAuth, async (_req, res): Promise<void> => {
  const [users, vendors, products, orders] = await Promise.all([
    db.execute(sql`SELECT COUNT(*) AS cnt FROM users`),
    db.execute(sql`SELECT COUNT(*) AS cnt FROM vendors`),
    db.execute(sql`SELECT COUNT(*) AS cnt FROM africart_products WHERE is_deleted=false`),
    db.execute(sql`SELECT COUNT(*) AS cnt, COALESCE(SUM(total_pesewas),0) AS revenue FROM africart_orders`),
  ]);
  const [pending, commissions, vendorFees, adRevenue] = await Promise.all([
    db.execute(sql`SELECT COUNT(*) AS cnt FROM africart_products WHERE status='pending' AND is_deleted=false`),
    db.execute(sql`SELECT COALESCE(SUM(markup_pesewas * qty),0) AS total FROM africart_commissions`),
    db.execute(sql`SELECT COUNT(*) AS cnt FROM vendors WHERE onboarding_fee_paid = true`),
    db.execute(sql`SELECT COALESCE(SUM(total_cost_pesewas),0) AS total, COUNT(*) AS cnt FROM africart_ads WHERE status IN ('active','expired') AND is_paid=true`),
  ]);
  const ur = ((users.rows ?? users) as any[])[0];
  const vr = ((vendors.rows ?? vendors) as any[])[0];
  const pr = ((products.rows ?? products) as any[])[0];
  const or = ((orders.rows ?? orders) as any[])[0];
  const per = ((pending.rows ?? pending) as any[])[0];
  const cr = ((commissions.rows ?? commissions) as any[])[0];
  const fr = ((vendorFees.rows ?? vendorFees) as any[])[0];
  const ar = ((adRevenue.rows ?? adRevenue) as any[])[0];
  const vendorFeeRevenuePesewas = parseInt(fr?.cnt ?? 0) * 20000; // GH₵200 per vendor
  const adRevenuePesewas = parseInt(ar?.total ?? 0);
  res.json({
    totalUsers: parseInt(ur?.cnt ?? 0),
    totalVendors: parseInt(vr?.cnt ?? 0),
    totalProducts: parseInt(pr?.cnt ?? 0),
    totalOrders: parseInt(or?.cnt ?? 0),
    totalRevenuePesewas: parseInt(or?.revenue ?? 0) + vendorFeeRevenuePesewas + adRevenuePesewas,
    pendingApprovals: parseInt(per?.cnt ?? 0),
    totalCommissionsPesewas: parseInt(cr?.total ?? 0),
    vendorFeeRevenuePesewas,
    vendorFeeCount: parseInt(fr?.cnt ?? 0),
    adRevenuePesewas,
    adCount: parseInt(ar?.cnt ?? 0),
  });
});

router.get("/africart/admin/products", requireAdminAuth, async (req, res): Promise<void> => {
  const { status } = req.query;
  const statusFilter = status && ["pending","approved","rejected"].includes(String(status))
    ? sql`AND p.status = ${String(status)}`
    : sql``;
  const result = await db.execute(sql`
    SELECT p.*, v.business_name FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.is_deleted = false ${statusFilter}
    ORDER BY p.created_at DESC LIMIT 200
  `);
  res.json(((result.rows ?? result) as any[]).map(rowToProduct));
});

router.patch("/africart/admin/products/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const prodInfo = await db.execute(sql`
    SELECT p.name, v.user_id FROM africart_products p
    JOIN vendors v ON v.id = p.vendor_id WHERE p.id=${id}::uuid LIMIT 1
  `);
  const prod = ((prodInfo.rows ?? prodInfo) as any[])[0];
  await db.execute(sql`UPDATE africart_products SET status='approved', is_approved=true, rejection_reason=null, updated_at=NOW() WHERE id=${id}::uuid`);
  if (prod?.user_id) {
    const msg = `Your product "${prod.name}" has been approved and is now live on the marketplace.`;
    await db.execute(sql`
      INSERT INTO africart_notifications (user_id, type, title, message, data)
      VALUES (${prod.user_id}::uuid, 'product_approved', 'Product Approved!', ${msg}, ${JSON.stringify({ productId: id })}::jsonb)
    `);
  }
  res.json({ ok: true });
});

router.patch("/africart/admin/products/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { reason } = req.body;
  const prodInfo = await db.execute(sql`
    SELECT p.name, v.user_id FROM africart_products p
    JOIN vendors v ON v.id = p.vendor_id WHERE p.id=${id}::uuid LIMIT 1
  `);
  const prod = ((prodInfo.rows ?? prodInfo) as any[])[0];
  await db.execute(sql`UPDATE africart_products SET status='rejected', is_approved=false, rejection_reason=${reason ?? null}, updated_at=NOW() WHERE id=${id}::uuid`);
  if (prod?.user_id) {
    const msg = reason
      ? `Your product "${prod.name}" was rejected. Reason: ${reason}. Please edit and resubmit.`
      : `Your product "${prod.name}" was rejected. Please edit and resubmit it for review.`;
    await db.execute(sql`
      INSERT INTO africart_notifications (user_id, type, title, message, data)
      VALUES (${prod.user_id}::uuid, 'product_rejected', 'Product Rejected', ${msg}, ${JSON.stringify({ productId: id, reason: reason ?? null })}::jsonb)
    `);
  }
  res.json({ ok: true });
});

router.delete("/africart/admin/products/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE africart_products SET is_deleted=true WHERE id=${id}::uuid`);
  res.sendStatus(204);
});

router.get("/africart/admin/orders", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT o.*, u.full_name AS buyer_name
    FROM africart_orders o JOIN users u ON u.id = o.buyer_id
    ORDER BY o.created_at DESC LIMIT 200
  `);
  const rows = (result.rows ?? result) as any[];
  const orders = await Promise.all(rows.map(async (o) => {
    const items = await db.execute(sql`
      SELECT oi.*, p.vendor_id, v.business_name AS vendor_name
      FROM africart_order_items oi
      LEFT JOIN africart_products p ON p.id = oi.product_id
      LEFT JOIN vendors v ON v.id = p.vendor_id
      WHERE oi.order_id=${o.id}::uuid
    `);
    const itemRows = (items.rows ?? items) as any[];
    return {
      id: o.id, buyerName: o.buyer_name, status: o.status,
      totalPesewas: parseInt(o.total_pesewas), createdAt: o.created_at,
      vendorId: itemRows[0]?.vendor_id ?? null,
      vendorName: itemRows[0]?.vendor_name ?? "",
      items: itemRows.map((i: any) => ({
        productId: i.product_id, name: i.product_name, image: i.product_image ?? "",
        qty: parseInt(i.qty), pricePesewas: parseInt(i.price_pesewas),
      })),
    };
  }));
  res.json(orders);
});

router.patch("/africart/admin/orders/:id/status", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { status } = req.body;
  await db.execute(sql`UPDATE africart_orders SET status=${status}, updated_at=NOW() WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

function mapVendorRow(v: any) {
  return {
    id: v.id,
    userId: v.user_id,
    businessName: v.business_name ?? "Unknown Vendor",
    businessType: v.business_type ?? "",
    coverImage: v.cover_image_url ?? "",
    logoUrl: v.logo_url ?? "",
    location: v.location ?? "Ghana",
    isVerified: Boolean(v.is_verified),
    isSuspended: Boolean(v.is_suspended),
    status: v.status ?? "approved",
    verificationLevel: v.verification_level ?? "unverified",
    rejectionReason: v.rejection_reason ?? null,
    suspensionReason: v.suspension_reason ?? null,
    bannedAt: v.banned_at ?? null,
    walletFrozen: Boolean(v.wallet_frozen),
    storeFrozen: Boolean(v.store_frozen),
    disableProductPosting: Boolean(v.disable_product_posting),
    disableStoryPosting: Boolean(v.disable_story_posting),
    disableWithdrawals: Boolean(v.disable_withdrawals),
    ratingAvg: parseFloat(v.rating_avg ?? 0),
    totalReviews: parseInt(v.total_reviews ?? 0),
    totalProducts: parseInt(v.product_count ?? 0),
    totalSales: parseInt(v.total_sales ?? 0),
    ownerName: v.full_name ?? null,
    ownerPhone: v.phone ?? null,
    ownerEmail: v.email ?? null,
    personalName: v.personal_name ?? null,
    idCardUrl: v.id_card_url ?? null,
    passportUrl: v.passport_url ?? null,
    momoReference: v.momo_reference ?? null,
    onboardingFeePaid: Boolean(v.onboarding_fee_paid),
    createdAt: v.created_at,
  };
}

router.get("/africart/admin/vendors", requireAdminAuth, async (req, res): Promise<void> => {
  const search = (req.query.search as string | undefined)?.trim() ?? "";
  const status = req.query.status as string | undefined;
  const verification = req.query.verification as string | undefined;
  const kycStatus = req.query.kycStatus as string | undefined;

  const searchClause = search
    ? sql`AND (v.business_name ILIKE ${"%" + search + "%"} OR u.phone ILIKE ${"%" + search + "%"} OR u.email ILIKE ${"%" + search + "%"} OR v.id::text ILIKE ${"%" + search + "%"})`
    : sql``;
  const statusClause = status && status !== "all"
    ? sql`AND v.status = ${status}`
    : sql``;
  const verificationClause = verification && verification !== "all"
    ? sql`AND v.verification_level = ${verification}`
    : sql``;
  const kycClause = kycStatus && kycStatus !== "all"
    ? sql`AND k.status = ${kycStatus}`
    : sql``;

  const result = await db.execute(sql`
    SELECT v.*, u.full_name, u.phone, u.email,
           (SELECT COUNT(*) FROM africart_products p WHERE p.vendor_id = v.id AND p.is_deleted=false) AS product_count,
           k.status AS kyc_status
    FROM vendors v
    LEFT JOIN users u ON u.id = v.user_id
    LEFT JOIN kyc_verifications k ON k.user_id = v.user_id
    WHERE 1=1 ${searchClause} ${statusClause} ${verificationClause} ${kycClause}
    ORDER BY v.created_at DESC
    LIMIT 500
  `);
  res.json(((result.rows ?? result) as any[]).map((v) => ({
    ...mapVendorRow(v),
    kycStatus: v.kyc_status ?? null,
  })));
});

router.get("/africart/admin/vendors/:id/details", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);

  const [vendorRes, analyticsRes, walletRes, kycRes, messagesRes] = await Promise.all([
    db.execute(sql`
      SELECT v.*, u.full_name, u.phone, u.email, u.fp_id
      FROM vendors v LEFT JOIN users u ON u.id = v.user_id
      WHERE v.id = ${id}::uuid LIMIT 1
    `),
    db.execute(sql`
      SELECT
        (SELECT COUNT(*) FROM africart_products WHERE vendor_id = ${id}::uuid AND is_deleted=false) AS products,
        (SELECT COUNT(DISTINCT o.id) FROM africart_orders o JOIN africart_order_items oi ON oi.order_id = o.id WHERE oi.vendor_id = ${id}::uuid) AS orders,
        (SELECT COALESCE(SUM(oi.price_pesewas * oi.qty), 0) FROM africart_order_items oi WHERE oi.vendor_id = ${id}::uuid) AS revenue_pesewas,
        (SELECT COUNT(DISTINCT o.buyer_id) FROM africart_orders o JOIN africart_order_items oi ON oi.order_id = o.id WHERE oi.vendor_id = ${id}::uuid) AS customers
    `),
    db.execute(sql`
      SELECT w.balance_pesewas FROM wallets w
      JOIN vendors v ON v.user_id = w.user_id
      WHERE v.id = ${id}::uuid LIMIT 1
    `),
    db.execute(sql`
      SELECT k.* FROM kyc_verifications k
      JOIN vendors v ON v.user_id = k.user_id
      WHERE v.id = ${id}::uuid
      ORDER BY k.created_at DESC LIMIT 1
    `),
    db.execute(sql`
      SELECT * FROM vendor_admin_messages WHERE vendor_id = ${id}::uuid ORDER BY created_at DESC LIMIT 50
    `),
  ]);

  const vendor = ((vendorRes.rows ?? vendorRes) as any[])[0];
  if (!vendor) { res.status(404).json({ error: "Vendor not found" }); return; }

  const stats = ((analyticsRes.rows ?? analyticsRes) as any[])[0] ?? {};
  const wallet = ((walletRes.rows ?? walletRes) as any[])[0];
  const kyc = ((kycRes.rows ?? kycRes) as any[])[0] ?? null;
  const messages = (messagesRes.rows ?? messagesRes) as any[];

  res.json({
    ...mapVendorRow(vendor),
    fpId: vendor.fp_id ?? null,
    analytics: {
      products: parseInt(stats.products ?? 0),
      orders: parseInt(stats.orders ?? 0),
      revenuePesewas: parseInt(stats.revenue_pesewas ?? 0),
      customers: parseInt(stats.customers ?? 0),
      walletBalancePesewas: parseInt(wallet?.balance_pesewas ?? 0),
    },
    kyc: kyc ? {
      id: kyc.id,
      status: kyc.status,
      idType: kyc.id_type,
      idNumber: kyc.id_number,
      frontIdUrl: kyc.front_id_url,
      backIdUrl: kyc.back_id_url,
      selfieUrl: kyc.selfie_url,
      rejectionReason: kyc.rejection_reason,
      createdAt: kyc.created_at,
    } : null,
    messages: messages.map((m) => ({
      id: m.id,
      type: m.type,
      subject: m.subject,
      message: m.message,
      createdAt: m.created_at,
    })),
  });
});

router.patch("/africart/admin/vendors/:id/verify", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE vendors SET is_verified=true WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE vendors SET status='approved', is_suspended=false, rejection_reason=null WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { reason } = req.body as { reason?: string };
  await db.execute(sql`UPDATE vendors SET status='rejected', rejection_reason=${reason ?? null} WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/suspend", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { reason } = req.body as { reason?: string };
  await db.execute(sql`UPDATE vendors SET is_suspended=true, status='suspended', suspension_reason=${reason ?? null} WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/unsuspend", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE vendors SET is_suspended=false, status='approved', suspension_reason=null WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/ban", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { reason } = req.body as { reason?: string };
  await db.execute(sql`UPDATE vendors SET status='banned', is_suspended=true, suspension_reason=${reason ?? null}, banned_at=now() WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/unban", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE vendors SET status='approved', is_suspended=false, banned_at=null, suspension_reason=null WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/set-verification", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { level } = req.body as { level: string };
  const validLevels = ["unverified", "verified", "premium_verified"];
  if (!validLevels.includes(level)) { res.status(400).json({ error: "Invalid verification level" }); return; }
  const isVerified = level !== "unverified";
  await db.execute(sql`UPDATE vendors SET verification_level=${level}, is_verified=${isVerified} WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.patch("/africart/admin/vendors/:id/account-control", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { walletFrozen, storeFrozen, disableProductPosting, disableStoryPosting, disableWithdrawals } = req.body as Record<string, boolean>;
  await db.execute(sql`
    UPDATE vendors SET
      wallet_frozen = COALESCE(${walletFrozen ?? null}, wallet_frozen),
      store_frozen = COALESCE(${storeFrozen ?? null}, store_frozen),
      disable_product_posting = COALESCE(${disableProductPosting ?? null}, disable_product_posting),
      disable_story_posting = COALESCE(${disableStoryPosting ?? null}, disable_story_posting),
      disable_withdrawals = COALESCE(${disableWithdrawals ?? null}, disable_withdrawals)
    WHERE id = ${id}::uuid
  `);
  res.json({ ok: true });
});

router.post("/africart/admin/vendors/:id/message", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { type, subject, message } = req.body as { type: string; subject: string; message: string };
  if (!type || !subject || !message) { res.status(400).json({ error: "type, subject, and message are required" }); return; }
  await db.execute(sql`
    INSERT INTO vendor_admin_messages (vendor_id, type, subject, message) VALUES (${id}::uuid, ${type}, ${subject}, ${message})
  `);
  res.json({ ok: true });
});

router.post("/africart/admin/vendors/bulk", requireAdminAuth, async (req, res): Promise<void> => {
  const { ids, action, reason } = req.body as { ids: string[]; action: string; reason?: string };
  if (!Array.isArray(ids) || ids.length === 0) { res.status(400).json({ error: "ids array required" }); return; }

  const updates: Record<string, string> = {
    approve: `status='approved', is_suspended=false`,
    suspend: `is_suspended=true, status='suspended'`,
    ban: `status='banned', is_suspended=true, banned_at=now()`,
    verify: `is_verified=true, verification_level='verified'`,
    unban: `status='approved', is_suspended=false, banned_at=null`,
  };
  if (!updates[action]) { res.status(400).json({ error: "Invalid action" }); return; }

  for (const id of ids) {
    if (action === "approve") await db.execute(sql`UPDATE vendors SET status='approved', is_suspended=false WHERE id=${id}::uuid`);
    else if (action === "suspend") await db.execute(sql`UPDATE vendors SET is_suspended=true, status='suspended', suspension_reason=${reason ?? null} WHERE id=${id}::uuid`);
    else if (action === "ban") await db.execute(sql`UPDATE vendors SET status='banned', is_suspended=true, banned_at=now(), suspension_reason=${reason ?? null} WHERE id=${id}::uuid`);
    else if (action === "verify") await db.execute(sql`UPDATE vendors SET is_verified=true, verification_level='verified' WHERE id=${id}::uuid`);
    else if (action === "unban") await db.execute(sql`UPDATE vendors SET status='approved', is_suspended=false, banned_at=null WHERE id=${id}::uuid`);
  }
  res.json({ ok: true, affected: ids.length });
});

router.get("/africart/admin/onboarding-fees", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT
      v.id, v.business_name, v.personal_name, v.momo_reference,
      v.onboarding_fee_paid, v.onboarding_fee_paid_at, v.status,
      v.created_at,
      u.full_name AS owner_name, u.phone AS owner_phone
    FROM vendors v
    JOIN users u ON u.id = v.user_id
    WHERE v.onboarding_fee_paid = true
    ORDER BY v.onboarding_fee_paid_at DESC NULLS LAST
  `);
  const rows = (result.rows ?? result) as any[];
  const amountPesewas = 20000;
  res.json({
    totalPesewas: rows.length * amountPesewas,
    count: rows.length,
    items: rows.map((r) => ({
      id: r.id,
      businessName: r.business_name,
      personalName: r.personal_name,
      momoReference: r.momo_reference,
      ownerName: r.owner_name,
      ownerPhone: r.owner_phone,
      amountPesewas,
      status: r.status,
      paidAt: r.onboarding_fee_paid_at ?? r.created_at,
    })),
  });
});

router.get("/africart/admin/commissions", requireAdminAuth, async (req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT c.*, o.status AS order_status, u.full_name AS buyer_name
    FROM africart_commissions c
    JOIN africart_orders o ON o.id = c.order_id
    JOIN users u ON u.id = o.buyer_id
    ORDER BY c.created_at DESC LIMIT 200
  `);
  res.json(((result.rows ?? result) as any[]).map((c) => ({
    id: c.id,
    orderId: c.order_id,
    productName: c.product_name,
    qty: parseInt(c.qty),
    sellerPricePesewas: parseInt(c.seller_price_pesewas),
    customerPricePesewas: parseInt(c.customer_price_pesewas),
    markupPesewas: parseInt(c.markup_pesewas),
    orderStatus: c.order_status,
    buyerName: c.buyer_name,
    createdAt: c.created_at,
  })));
});

router.get("/africart/admin/banners", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`SELECT * FROM africart_banners ORDER BY sort_order ASC, created_at DESC`);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((b) => ({
    id: b.id, title: b.title, subtitle: b.subtitle ?? "",
    imageUrl: b.image_url, linkUrl: b.link_url ?? "",
    isActive: b.is_active, sortOrder: b.sort_order, createdAt: b.created_at,
  })));
});

router.post("/africart/admin/banners", requireAdminAuth, async (req, res): Promise<void> => {
  const { title, subtitle, imageUrl, linkUrl, sortOrder } = req.body;
  if (!title || !imageUrl) { res.status(400).json({ error: "title and imageUrl are required" }); return; }
  const result = await db.execute(sql`
    INSERT INTO africart_banners (title, subtitle, image_url, link_url, sort_order)
    VALUES (${title}, ${subtitle ?? null}, ${imageUrl}, ${linkUrl ?? null}, ${parseInt(sortOrder ?? 0)})
    RETURNING *
  `);
  const b = ((result.rows ?? result) as any[])[0];
  res.status(201).json({ id: b.id, title: b.title, imageUrl: b.image_url, isActive: b.is_active });
});

router.patch("/africart/admin/banners/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { isActive } = req.body;
  await db.execute(sql`UPDATE africart_banners SET is_active=${isActive} WHERE id=${id}::uuid`);
  res.json({ ok: true });
});

router.delete("/africart/admin/banners/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`DELETE FROM africart_banners WHERE id=${id}::uuid`);
  res.sendStatus(204);
});

// ── Admin Users ───────────────────────────────────────────────────────────────

router.get("/africart/admin/users", requireAdminAuth, async (req, res): Promise<void> => {
  const search = (req.query.search as string | undefined)?.trim() ?? "";
  const role = req.query.role as string | undefined;

  const searchClause = search
    ? sql`AND (u.full_name ILIKE ${"%" + search + "%"} OR u.phone ILIKE ${"%" + search + "%"})`
    : sql``;
  const roleClause =
    role === "seller" ? sql`AND v.id IS NOT NULL`
    : role === "buyer" ? sql`AND v.id IS NULL`
    : sql``;

  const result = await db.execute(sql`
    SELECT
      u.id,
      u.full_name AS name,
      u.phone,
      u.is_kyc_verified AS verified,
      u.created_at,
      u.is_suspended,
      CASE WHEN v.id IS NOT NULL THEN 'seller' ELSE 'buyer' END AS role,
      COALESCE((SELECT COUNT(*) FROM africart_orders o WHERE o.buyer_id = u.id), 0) AS orders
    FROM users u
    LEFT JOIN vendors v ON v.user_id = u.id
    WHERE 1=1 ${searchClause} ${roleClause}
    ORDER BY u.created_at DESC
    LIMIT 200
  `);

  res.json(((result.rows ?? result) as any[]).map((u) => ({
    id: u.id,
    name: u.name ?? "",
    phone: u.phone ?? "",
    verified: Boolean(u.verified),
    role: u.role,
    orders: parseInt(u.orders ?? 0),
    isSuspended: Boolean(u.is_suspended),
    joined: u.created_at,
  })));
});

// ── Admin Analytics ───────────────────────────────────────────────────────────

router.get("/africart/admin/analytics", requireAdminAuth, async (req, res): Promise<void> => {
  const days = Math.min(Number(req.query.days) || 30, 90);

  const [monthly, categoryRows] = await Promise.all([
    db.execute(sql`
      SELECT
        to_char(date_trunc('day', created_at), 'Mon DD') AS label,
        COALESCE(SUM(total_pesewas), 0)::int AS gmv,
        COUNT(*)::int AS orders
      FROM africart_orders
      WHERE created_at >= NOW() - (${days} || ' days')::interval
      GROUP BY 1, date_trunc('day', created_at)
      ORDER BY date_trunc('day', created_at)
    `),
    db.execute(sql`
      SELECT p.category, COUNT(*) AS cnt
      FROM africart_order_items oi
      JOIN africart_products p ON p.id = oi.product_id
      GROUP BY p.category
      ORDER BY cnt DESC
    `),
  ]);

  const monthlyRows = (monthly.rows ?? monthly) as any[];
  const catRows = (categoryRows.rows ?? categoryRows) as any[];
  const totalCatCnt = catRows.reduce((s: number, r: any) => s + parseInt(r.cnt), 0) || 1;

  res.json({
    daily: monthlyRows.map((r) => ({
      label: r.label,
      gmv: parseInt(r.gmv),
      orders: parseInt(r.orders),
    })),
    categories: catRows.map((r) => ({
      name: r.category ?? "Other",
      value: Math.round((parseInt(r.cnt) / totalCatCnt) * 100),
    })),
  });
});

// ── Seller Notifications ─────────────────────────────────────────────────────

router.get("/africart/seller/notifications", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  const result = await db.execute(sql`
    SELECT * FROM africart_notifications
    WHERE user_id = ${userId}::uuid
    ORDER BY created_at DESC LIMIT 30
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((n) => ({
    id: n.id,
    type: n.type,
    title: n.title,
    message: n.message,
    isRead: n.is_read,
    createdAt: n.created_at,
    data: n.data,
  })));
});

router.patch("/africart/seller/notifications/read", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId;
  await db.execute(sql`UPDATE africart_notifications SET is_read = true WHERE user_id = ${userId}::uuid`);
  res.json({ ok: true });
});

// ── Admin SMS Logs ─────────────────────────────────────────────────────────────

router.get("/africart/admin/sms-logs", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
  const offset = (page - 1) * limit;

  const result = await db.execute(sql`
    SELECT id, phone, message, status, provider, source, created_at
    FROM sms_logs
    WHERE source = 'africart'
    ORDER BY created_at DESC
    LIMIT ${limit} OFFSET ${offset}
  `);

  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((r) => ({
    id: r.id,
    phone: r.phone,
    message: r.message,
    status: r.status,
    provider: r.provider,
    source: r.source,
    createdAt: r.created_at,
  })));
});

// ── Payout Requests ─────────────────────────────────────────────────────────

async function sendPayoutSms(phone: string, message: string): Promise<void> {
  const apiKey = process.env.ARKESEL_API_KEY;
  if (!apiKey) return;
  const intlPhone = "233" + phone.replace(/^0/, "");
  try {
    await fetch(`https://sms.arkesel.com/sms/api?action=send-sms&api_key=${apiKey}&to=${intlPhone}&from=KASUWAA&sms=${encodeURIComponent(message)}`);
  } catch (_) { /* best-effort */ }
}

// Vendor submits a payout request
router.post("/africart/seller/payout-request", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendor = { id: (req as any).vendorId };
  const { amountPesewas, paymentMethod, recipientName, recipientPhone, bankName, bankAccountNumber } = req.body as Record<string, any>;
  const validMethods = ["mtn_momo", "tigo", "vodafone", "bank"];
  if (!amountPesewas || !paymentMethod || !recipientName) {
    res.status(400).json({ error: "amountPesewas, paymentMethod, and recipientName are required" }); return;
  }
  if (!validMethods.includes(paymentMethod)) {
    res.status(400).json({ error: `paymentMethod must be one of: ${validMethods.join(", ")}` }); return;
  }
  if (paymentMethod !== "bank" && !recipientPhone) {
    res.status(400).json({ error: "recipientPhone is required for mobile money" }); return;
  }
  if (paymentMethod === "bank" && (!bankName || !bankAccountNumber)) {
    res.status(400).json({ error: "bankName and bankAccountNumber are required for bank payouts" }); return;
  }
  // Check available balance
  const balanceResult = await db.execute(sql`
    SELECT
      COALESCE((
        SELECT SUM(c.seller_price_pesewas * c.qty)
        FROM africart_commissions c
        JOIN africart_order_items i ON i.order_id = c.order_id AND i.product_id = c.product_id
        WHERE i.vendor_id = ${vendor.id}::uuid
      ), 0) AS earned,
      COALESCE((
        SELECT SUM(amount_pesewas) FROM africart_payout_requests
        WHERE vendor_id = ${vendor.id}::uuid AND status = 'approved'
      ), 0) AS paid_out
  `);
  const bal = ((balanceResult.rows ?? balanceResult as any) as any[])[0];
  const availableBalance = Math.max(0, parseInt(bal?.earned ?? 0) - parseInt(bal?.paid_out ?? 0));
  if (parseInt(amountPesewas) > availableBalance) {
    const ghsAvailable = (availableBalance / 100).toFixed(2);
    res.status(400).json({ error: `Amount exceeds your available balance of GHS ${ghsAvailable}` }); return;
  }
  // Check no pending request already exists
  const existing = await db.execute(sql`
    SELECT id FROM africart_payout_requests
    WHERE vendor_id = ${vendor.id}::uuid AND status = 'pending'
    LIMIT 1
  `);
  if ((existing.rows ?? existing as any).length > 0) {
    res.status(409).json({ error: "You already have a pending payout request. Please wait for it to be processed." }); return;
  }
  const result = await db.execute(sql`
    INSERT INTO africart_payout_requests
      (vendor_id, amount_pesewas, payment_method, recipient_name, recipient_phone, bank_name, bank_account_number)
    VALUES
      (${vendor.id}::uuid, ${parseInt(amountPesewas)}, ${paymentMethod}, ${recipientName},
       ${recipientPhone ?? null}, ${bankName ?? null}, ${bankAccountNumber ?? null})
    RETURNING *
  `);
  const row = (result.rows ?? result as any)[0];
  // Notify admin of new payout request
  const ghsAmount = (parseInt(amountPesewas) / 100).toFixed(2);
  await insertAdminNotification(
    "payout_request",
    "New Payout Request",
    `Vendor requested a payout of GHS ${ghsAmount} via ${paymentMethod.replace(/_/g, " ")}.`,
    { payoutId: row?.id ?? null },
  );
  res.status(201).json(row);
});

// Vendor gets their payout history
router.get("/africart/seller/payout-requests", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendor = { id: (req as any).vendorId };
  const result = await db.execute(sql`
    SELECT * FROM africart_payout_requests
    WHERE vendor_id = ${vendor.id}::uuid
    ORDER BY created_at DESC
  `);
  res.json(result.rows ?? result);
});

// Admin: list all payout requests (with vendor/user info)
router.get("/africart/admin/payout-requests", requireAdminAuth, async (req, res): Promise<void> => {
  const status = (req.query.status as string) ?? "";
  const result = await db.execute(sql`
    SELECT
      pr.*,
      v.business_name AS vendor_name,
      u.full_name AS user_name,
      u.phone AS user_phone
    FROM africart_payout_requests pr
    JOIN vendors v ON v.id = pr.vendor_id
    JOIN users u ON u.id = v.user_id
    ${status ? sql`WHERE pr.status = ${status}` : sql``}
    ORDER BY pr.created_at DESC
  `);
  res.json(result.rows ?? result);
});

// Admin: approve a payout request
router.patch("/africart/admin/payout-requests/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { adminNote } = req.body as { adminNote?: string };
  const result = await db.execute(sql`
    UPDATE africart_payout_requests
    SET status = 'approved', admin_note = ${adminNote ?? null}, processed_at = NOW(), updated_at = NOW()
    WHERE id = ${id}::uuid AND status = 'pending'
    RETURNING *
  `);
  const rows = (result.rows ?? result as any) as any[];
  if (!rows.length) { res.status(404).json({ error: "Request not found or already processed" }); return; }
  const row = rows[0] as any;
  // Fetch vendor user phone for SMS
  const userResult = await db.execute(sql`
    SELECT u.phone, u.full_name FROM users u JOIN vendors v ON v.user_id = u.id WHERE v.id = ${row.vendor_id}::uuid
  `);
  const user = ((userResult.rows ?? userResult as any) as any[])[0] as any;
  if (user?.phone) {
    const ghsAmount = (Number(row.amount_pesewas) / 100).toFixed(2);
    await sendPayoutSms(String(user.phone),
      `Hello ${user.full_name}, your KASUWAA payout of GHS ${ghsAmount} has been APPROVED and is being processed. ${adminNote ? "Note: " + adminNote : ""}`
    );
  }
  res.json({ ok: true, request: row });
});

// Admin: reject a payout request
router.patch("/africart/admin/payout-requests/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { rejectionReason } = req.body as { rejectionReason?: string };
  const result = await db.execute(sql`
    UPDATE africart_payout_requests
    SET status = 'rejected', rejection_reason = ${rejectionReason ?? null}, processed_at = NOW(), updated_at = NOW()
    WHERE id = ${id}::uuid AND status = 'pending'
    RETURNING *
  `);
  const rows = (result.rows ?? result as any) as any[];
  if (!rows.length) { res.status(404).json({ error: "Request not found or already processed" }); return; }
  const row = rows[0] as any;
  const userResult = await db.execute(sql`
    SELECT u.phone, u.full_name FROM users u JOIN vendors v ON v.user_id = u.id WHERE v.id = ${row.vendor_id}::uuid
  `);
  const user = ((userResult.rows ?? userResult as any) as any[])[0] as any;
  if (user?.phone) {
    const ghsAmount = (Number(row.amount_pesewas) / 100).toFixed(2);
    await sendPayoutSms(String(user.phone),
      `Hello ${user.full_name}, your KASUWAA payout request of GHS ${ghsAmount} was not approved. ${rejectionReason ? "Reason: " + rejectionReason : "Please contact support for details."}`
    );
  }
  res.json({ ok: true, request: row });
});

// ── Ads: Seller ───────────────────────────────────────────────────────────────

router.post("/africart/seller/ads", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const { title, description, imageUrl, linkUrl, discountPercent, promoLabel, adType, days, momoPhone } = req.body;
  if (!title?.trim() || !imageUrl?.trim()) {
    res.status(400).json({ error: "Title and image URL are required" }); return;
  }
  const validTypes = ["banner", "popup", "featured"];
  const type = validTypes.includes(adType) ? adType : "banner";
  const numDays = Math.max(1, Math.min(365, parseInt(days ?? 1)));
  const costPerDayMap: Record<string, number> = { banner: 1000, featured: 2500, popup: 5000 };
  const costPerDay = costPerDayMap[type] ?? 1000;
  const totalCost = costPerDay * numDays;

  const vendorResult = await db.execute(sql`SELECT business_name FROM vendors WHERE id=${vendorId}::uuid LIMIT 1`);
  const vendorRow = ((vendorResult.rows ?? vendorResult) as any[])[0];
  const vendorName = vendorRow?.business_name ?? "";

  const result = await db.execute(sql`
    INSERT INTO africart_ads
      (vendor_id, vendor_name, title, description, image_url, link_url, discount_percent,
       promo_label, ad_type, days, cost_per_day_pesewas, total_cost_pesewas, is_paid, momo_phone)
    VALUES
      (${vendorId}::uuid, ${vendorName}, ${title}, ${description ?? null}, ${imageUrl},
       ${linkUrl ?? null}, ${discountPercent ? parseInt(discountPercent) : null},
       ${promoLabel ?? null}, ${type}, ${numDays}, ${costPerDay}, ${totalCost}, false, ${momoPhone ?? null})
    RETURNING *
  `);
  const ad = ((result.rows ?? result) as any[])[0];
  res.status(201).json({ id: ad.id, status: ad.status, totalCostPesewas: totalCost });
});

router.get("/africart/seller/ads", requireAuth, requireVendor, async (req, res): Promise<void> => {
  const vendorId = (req as any).vendorId;
  const result = await db.execute(sql`
    SELECT * FROM africart_ads WHERE vendor_id=${vendorId}::uuid ORDER BY created_at DESC
  `);
  const rows = (result.rows ?? result) as any[];
  res.json(rows.map((r) => ({
    id: r.id,
    title: r.title,
    description: r.description ?? "",
    imageUrl: r.image_url ?? "",
    linkUrl: r.link_url ?? "",
    discountPercent: r.discount_percent ?? null,
    promoLabel: r.promo_label ?? null,
    adType: r.ad_type,
    status: r.status,
    days: r.days,
    costPerDayPesewas: parseInt(r.cost_per_day_pesewas),
    totalCostPesewas: parseInt(r.total_cost_pesewas),
    isPaid: r.is_paid,
    rejectionReason: r.rejection_reason ?? null,
    startDate: r.start_date ?? null,
    endDate: r.end_date ?? null,
    createdAt: r.created_at,
  })));
});

// ── Ads: Admin ────────────────────────────────────────────────────────────────

router.get("/africart/admin/ads", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT a.*, v.business_name AS vendor_business_name
    FROM africart_ads a
    LEFT JOIN vendors v ON v.id = a.vendor_id
    ORDER BY a.created_at DESC
  `);
  const rows = (result.rows ?? result) as any[];
  const totalRevenue = rows
    .filter((r) => r.status === "active" || r.status === "expired")
    .reduce((sum: number, r: any) => sum + parseInt(r.total_cost_pesewas ?? 0), 0);
  res.json({
    ads: rows.map((r) => ({
      id: r.id,
      vendorId: r.vendor_id,
      vendorName: r.vendor_name ?? r.vendor_business_name ?? "",
      title: r.title,
      description: r.description ?? "",
      imageUrl: r.image_url ?? "",
      linkUrl: r.link_url ?? "",
      discountPercent: r.discount_percent ?? null,
      promoLabel: r.promo_label ?? null,
      adType: r.ad_type,
      status: r.status,
      days: r.days,
      costPerDayPesewas: parseInt(r.cost_per_day_pesewas),
      totalCostPesewas: parseInt(r.total_cost_pesewas),
      isPaid: r.is_paid,
      rejectionReason: r.rejection_reason ?? null,
      startDate: r.start_date ?? null,
      endDate: r.end_date ?? null,
      createdAt: r.created_at,
    })),
    totalRevenuePesewas: totalRevenue,
  });
});

router.patch("/africart/admin/ads/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const adResult = await db.execute(sql`SELECT * FROM africart_ads WHERE id=${id}::uuid LIMIT 1`);
  const ad = ((adResult.rows ?? adResult) as any[])[0];
  if (!ad) { res.status(404).json({ error: "Ad not found" }); return; }
  const startDate = new Date();
  const endDate = new Date(startDate.getTime() + (parseInt(ad.days) * 86400000));
  await db.execute(sql`
    UPDATE africart_ads SET status='active', is_paid=true, start_date=${startDate.toISOString()},
    end_date=${endDate.toISOString()}, updated_at=NOW() WHERE id=${id}::uuid
  `);
  res.json({ ok: true, startDate, endDate });
});

router.patch("/africart/admin/ads/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const { reason } = req.body as { reason?: string };
  await db.execute(sql`
    UPDATE africart_ads SET status='rejected', rejection_reason=${reason ?? null}, updated_at=NOW()
    WHERE id=${id}::uuid
  `);
  res.json({ ok: true });
});

router.delete("/africart/admin/ads/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`DELETE FROM africart_ads WHERE id=${id}::uuid`);
  res.sendStatus(204);
});

// ── AI Image Search ────────────────────────────────────────────────────────────

router.post("/africart/image-search", async (req, res): Promise<void> => {
  const { imageBase64, mimeType } = req.body as { imageBase64?: string; mimeType?: string };
  if (!imageBase64 || !mimeType) {
    res.status(400).json({ error: "imageBase64 and mimeType are required" }); return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "AI image search not configured" }); return;
  }

  const genai = new GoogleGenAI({ apiKey });

  // Ask Gemini to identify the product and suggest search keywords
  let searchQuery = "";
  let description = "";
  try {
    const response = await genai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: { mimeType: mimeType as any, data: imageBase64 },
            },
            {
              text: `You are a product search assistant for an African e-commerce marketplace (KASUWAA).
Analyse this image and identify what product or item is shown.
Respond with ONLY a JSON object like this (no markdown, no extra text):
{
  "query": "2-3 word search term that best matches the product (e.g. 'wireless earbuds', 'ankara dress', 'smart watch')",
  "description": "one sentence describing what you see in the image",
  "category": "one of: Electronics, Fashion, Beauty & Personal Care, Groceries, Phones & Gadgets, Home Appliances, Furniture & Interior, Sports & Outdoors, Baby Products, Agriculture, Building Materials, Automobiles, Health & Pharmacy, Books & Education, Industrial Equipment, Pet Supplies, Services, Wholesale Market, Imported Products"
}`,
            },
          ],
        },
      ],
      config: { maxOutputTokens: 256 },
    });

    const raw = response.text ?? "";
    if (!raw.trim()) {
      // Gemini returned nothing — image may not contain a recognisable product
      res.json({ products: [], query: "", description: "Could not identify a product in the image. Try a clearer photo of the item." });
      return;
    }
    // Strip markdown fences and extract the first JSON object found
    const stripped = raw.replace(/```json\n?|```\n?/g, "").trim();
    const jsonMatch = stripped.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      // Gemini returned plain text — try to use it as the query directly
      searchQuery = stripped.slice(0, 60).trim();
      description = stripped.slice(0, 200).trim();
    } else {
      const parsed = JSON.parse(jsonMatch[0]);
      searchQuery = (parsed.query ?? "").toString().trim();
      description = (parsed.description ?? "").toString().trim();
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("Gemini image search failed:", msg);
    // Don't surface internal errors to the user
    res.status(500).json({ error: "Image analysis failed. Please try again with a clearer product photo." }); return;
  }

  if (!searchQuery) {
    res.json({ products: [], query: "", description: "Could not identify a product in the image." }); return;
  }

  // Search DB using the full AI-generated query as a single ILIKE term
  const likeTerm = `%${searchQuery.toLowerCase()}%`;
  const wordTerms = searchQuery.toLowerCase().split(/\s+/).filter(Boolean).map((t) => `%${t}%`);

  // Build OR clauses: full phrase OR any individual word
  const allTerms = [likeTerm, ...wordTerms];
  const conditions = allTerms.map(
    (t) => sql`(p.name ILIKE ${t} OR COALESCE(p.description,'') ILIKE ${t} OR p.category ILIKE ${t})`
  );

  // Combine with OR
  let whereClause = conditions[0];
  for (let i = 1; i < conditions.length; i++) {
    whereClause = sql`${whereClause} OR ${conditions[i]}`;
  }

  const products = await db.execute(sql`
    SELECT p.*, v.business_name
    FROM africart_products p
    LEFT JOIN vendors v ON v.id = p.vendor_id
    WHERE p.is_deleted = false
      AND p.status = 'approved'
      AND p.in_stock = true
      AND (${whereClause})
    ORDER BY
      (CASE WHEN p.name ILIKE ${likeTerm} THEN 3
            WHEN p.category ILIKE ${likeTerm} THEN 2
            ELSE 1 END) DESC,
      p.updated_at DESC
    LIMIT 20
  `);

  const rows = (products.rows ?? products) as any[];
  const mapped = rows.map(rowToProduct);

  res.json({ products: mapped, query: searchQuery, description });
});

// ── Admin notification helper ──────────────────────────────────────────────────
async function insertAdminNotification(
  type: string, title: string, message: string, data: Record<string, unknown> = {},
): Promise<void> {
  try {
    await db.execute(sql`
      INSERT INTO africart_admin_notifications (type, title, message, data)
      VALUES (${type}, ${title}, ${message}, ${JSON.stringify(data)}::jsonb)
    `);
  } catch (err) {
    logger.warn({ err, type }, "admin notification insert failed (non-fatal)");
  }
}

// ── Admin: list notifications ──────────────────────────────────────────────────
router.get("/africart/admin/notifications", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT id, type, title, message, data, is_read, created_at
    FROM africart_admin_notifications
    ORDER BY created_at DESC
    LIMIT 50
  `);
  const rows = (result.rows ?? result) as any[];
  const unreadCount = rows.filter((r: any) => !r.is_read).length;
  res.json({ notifications: rows, unreadCount });
});

// ── Admin: mark all read ───────────────────────────────────────────────────────
router.patch("/africart/admin/notifications/read-all", requireAdminAuth, async (_req, res): Promise<void> => {
  await db.execute(sql`UPDATE africart_admin_notifications SET is_read = true WHERE is_read = false`);
  res.json({ ok: true });
});

// ── Admin: mark one read ───────────────────────────────────────────────────────
router.patch("/africart/admin/notifications/:id/read", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.execute(sql`UPDATE africart_admin_notifications SET is_read = true WHERE id = ${id}::uuid`);
  res.json({ ok: true });
});

// ── Public: track a homepage visit ────────────────────────────────────────────
router.post("/africart/track/visit", async (_req, res): Promise<void> => {
  try {
    await db.execute(sql`
      INSERT INTO africart_site_visits (date, count)
      VALUES (CURRENT_DATE, 1)
      ON CONFLICT (date) DO UPDATE SET count = africart_site_visits.count + 1
    `);
  } catch (_) { /* best-effort */ }
  res.json({ ok: true });
});

// ── Admin: visit stats (last 30 days) ─────────────────────────────────────────
router.get("/africart/admin/visits", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`
    SELECT date::text, count
    FROM africart_site_visits
    ORDER BY date DESC
    LIMIT 30
  `);
  const rows = (result.rows ?? result) as any[];
  const today = rows.find((r: any) => r.date === new Date().toISOString().slice(0, 10));
  const total7d = rows.slice(0, 7).reduce((s: number, r: any) => s + parseInt(r.count ?? 0), 0);
  res.json({ days: rows.reverse(), todayCount: parseInt(today?.count ?? 0), total7d });
});

export default router;
