import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, desc, sql } from "drizzle-orm";
import {
  db,
  walletFundingRequestsTable,
  walletsTable,
  transactionsTable,
  notificationsTable,
  auditLogsTable,
  usersTable,
} from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { emitToUser } from "../lib/socket";

const router: IRouter = Router();

// ── User: submit a wallet-funding-failure support request ───────────────────

const SubmitFundingRequestBody = z.object({
  momoNumber: z.string().min(9),
  transactionReference: z.string().min(3),
  amountPesewas: z.number().int().positive(),
  paymentDate: z.string(), // ISO datetime
  screenshotUrl: z.string().optional(),
  comments: z.string().optional(),
});

router.post("/wallet-funding-requests", requireAuth, async (req, res): Promise<void> => {
  const parsed = SubmitFundingRequestBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [request] = await db
    .insert(walletFundingRequestsTable)
    .values({
      userId: req.userId!,
      momoNumber: parsed.data.momoNumber,
      transactionReference: parsed.data.transactionReference,
      amountPesewas: parsed.data.amountPesewas,
      paymentDate: new Date(parsed.data.paymentDate),
      screenshotUrl: parsed.data.screenshotUrl,
      comments: parsed.data.comments,
    })
    .returning();

  res.status(201).json(request);
});

router.get("/wallet-funding-requests/mine", requireAuth, async (req, res): Promise<void> => {
  const requests = await db
    .select()
    .from(walletFundingRequestsTable)
    .where(eq(walletFundingRequestsTable.userId, req.userId!))
    .orderBy(desc(walletFundingRequestsTable.createdAt));
  res.json(requests);
});

// ── Admin: review queue ──────────────────────────────────────────────────────

router.get("/admin/wallet-funding-requests", requireAdminAuth, async (req, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const rows = await db
    .select({
      id: walletFundingRequestsTable.id,
      userId: walletFundingRequestsTable.userId,
      userPhone: usersTable.phone,
      userFullName: usersTable.fullName,
      momoNumber: walletFundingRequestsTable.momoNumber,
      transactionReference: walletFundingRequestsTable.transactionReference,
      amountPesewas: walletFundingRequestsTable.amountPesewas,
      paymentDate: walletFundingRequestsTable.paymentDate,
      screenshotUrl: walletFundingRequestsTable.screenshotUrl,
      comments: walletFundingRequestsTable.comments,
      status: walletFundingRequestsTable.status,
      adminNotes: walletFundingRequestsTable.adminNotes,
      reviewedAt: walletFundingRequestsTable.reviewedAt,
      createdAt: walletFundingRequestsTable.createdAt,
    })
    .from(walletFundingRequestsTable)
    .innerJoin(usersTable, eq(usersTable.id, walletFundingRequestsTable.userId))
    .where(status ? eq(walletFundingRequestsTable.status, status as "pending" | "approved" | "rejected") : undefined)
    .orderBy(desc(walletFundingRequestsTable.createdAt));
  res.json(rows);
});

const ReviewFundingRequestBody = z.object({
  adminNotes: z.string().optional(),
});

router.patch("/admin/wallet-funding-requests/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = ReviewFundingRequestBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [request] = await db.select().from(walletFundingRequestsTable).where(eq(walletFundingRequestsTable.id, String(req.params.id)));
  if (!request) { res.status(404).json({ error: "Request not found" }); return; }
  if (request.status !== "pending") { res.status(400).json({ error: `Request already ${request.status}` }); return; }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, request.userId));
  if (!wallet) { res.status(404).json({ error: "User wallet not found" }); return; }

  const reference = `WFR-${request.id.slice(0, 8)}`;

  await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${request.amountPesewas}`, updatedAt: new Date() })
      .where(eq(walletsTable.id, wallet.id));

    await trx.insert(transactionsTable).values({
      walletId: wallet.id,
      type: "momo_in",
      amountPesewas: request.amountPesewas,
      feePesewas: 0,
      network: "MTN MoMo",
      reference,
      status: "completed",
      note: `Manually verified wallet funding (ref: ${request.transactionReference})`,
    });

    await trx
      .update(walletFundingRequestsTable)
      .set({
        status: "approved",
        reviewedByAdminId: req.adminId ?? null,
        reviewedAt: new Date(),
        adminNotes: parsed.data.adminNotes ?? null,
      })
      .where(eq(walletFundingRequestsTable.id, request.id));

    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "wallet_funding.approve",
      entityType: "wallet_funding_request",
      entityId: request.id,
      metadata: {
        userId: request.userId,
        amountPesewas: request.amountPesewas,
        transactionReference: request.transactionReference,
        adminNotes: parsed.data.adminNotes ?? null,
      },
    });

    await trx.insert(notificationsTable).values({
      userId: request.userId,
      title: "Wallet funding approved",
      body: `GH₵${(request.amountPesewas / 100).toFixed(2)} has been credited to your wallet after manual verification.`,
      type: "wallet_funding_approved",
      referenceId: request.id,
    });
  });

  emitToUser(request.userId, "balance_updated", { userId: request.userId });
  res.json({ ok: true });
});

router.patch("/admin/wallet-funding-requests/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = ReviewFundingRequestBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [request] = await db.select().from(walletFundingRequestsTable).where(eq(walletFundingRequestsTable.id, String(req.params.id)));
  if (!request) { res.status(404).json({ error: "Request not found" }); return; }
  if (request.status !== "pending") { res.status(400).json({ error: `Request already ${request.status}` }); return; }

  await db.transaction(async (trx) => {
    await trx
      .update(walletFundingRequestsTable)
      .set({
        status: "rejected",
        reviewedByAdminId: req.adminId ?? null,
        reviewedAt: new Date(),
        adminNotes: parsed.data.adminNotes ?? null,
      })
      .where(eq(walletFundingRequestsTable.id, request.id));

    await trx.insert(auditLogsTable).values({
      adminId: req.adminId ?? null,
      action: "wallet_funding.reject",
      entityType: "wallet_funding_request",
      entityId: request.id,
      metadata: {
        userId: request.userId,
        amountPesewas: request.amountPesewas,
        transactionReference: request.transactionReference,
        adminNotes: parsed.data.adminNotes ?? null,
      },
    });

    await trx.insert(notificationsTable).values({
      userId: request.userId,
      title: "Wallet funding request declined",
      body: parsed.data.adminNotes
        ? `We couldn't verify your payment: ${parsed.data.adminNotes}`
        : "We couldn't verify your payment with the provider. Please contact support.",
      type: "wallet_funding_rejected",
      referenceId: request.id,
    });
  });

  res.json({ ok: true });
});

export default router;
