import { Router, type IRouter } from "express";
import { eq, gt, and, sql } from "drizzle-orm";
import {
  db, storiesTable, storyViewsTable, storyReactionsTable,
  storyMutesTable, usersTable,
} from "@workspace/db";
import { CreateStoryBody, DeleteStoryParams, ListStoriesResponse } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { z } from "zod/v4";

const router: IRouter = Router();

const STORY_TTL_MS = 24 * 60 * 60 * 1000;

const ReactBody = z.object({ emoji: z.string().min(1).max(8) });
const ReplyBody = z.object({ text: z.string().min(1).max(1000) });

// ── Helpers ──────────────────────────────────────────────────────────────────

async function enrichStories(stories: any[], viewerId: string) {
  if (!stories.length) return [];

  const ids = stories.map((s: any) => s.id);

  const views = await db
    .select({ storyId: storyViewsTable.storyId })
    .from(storyViewsTable)
    .where(eq(storyViewsTable.viewerId, viewerId));
  const viewedSet = new Set(views.map((v) => v.storyId));

  const reactions = await db
    .select({ storyId: storyReactionsTable.storyId, emoji: storyReactionsTable.emoji })
    .from(storyReactionsTable)
    .where(eq(storyReactionsTable.userId, viewerId));
  const reactionMap = new Map(reactions.map((r) => [r.storyId, r.emoji]));

  return stories.map((s: any) => ({
    ...s,
    viewedByMe: viewedSet.has(s.id),
    myReaction: reactionMap.get(s.id) ?? null,
  }));
}

// ── GET /stories ──────────────────────────────────────────────────────────────

router.get("/stories", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  const now = new Date();

  const mutes = await db
    .select({ mutedUserId: storyMutesTable.mutedUserId })
    .from(storyMutesTable)
    .where(eq(storyMutesTable.userId, userId));
  const mutedIds = mutes.map((m) => m.mutedUserId);

  let query = db
    .select()
    .from(storiesTable)
    .where(gt(storiesTable.expiresAt, now));

  const allStories = await query.orderBy(sql`${storiesTable.createdAt} DESC`);
  const filtered = allStories.filter((s) => !mutedIds.includes(s.userId));

  const enriched = await enrichStories(filtered, userId);
  res.json(enriched);
});

// ── GET /stories/my ──────────────────────────────────────────────────────────

router.get("/stories/my", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  const now = new Date();
  const stories = await db
    .select()
    .from(storiesTable)
    .where(and(eq(storiesTable.userId, userId), gt(storiesTable.expiresAt, now)))
    .orderBy(sql`${storiesTable.createdAt} DESC`);
  const enriched = await enrichStories(stories, userId);
  res.json(enriched);
});

// ── GET /stories/:id ──────────────────────────────────────────────────────────

router.get("/stories/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, id));
  if (!story) { res.status(404).json({ error: "Story not found" }); return; }
  const [enriched] = await enrichStories([story], req.userId!);
  res.json(enriched);
});

// ── POST /stories ─────────────────────────────────────────────────────────────

router.post("/stories", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const userId = req.userId!;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const { mediaUrl, caption, storyType, visibilityType, textColor, textBg } = parsed.data as any;
  const expiresAt = new Date(Date.now() + STORY_TTL_MS);

  const [story] = await db
    .insert(storiesTable)
    .values({
      userId,
      mediaUrl: mediaUrl ?? null,
      caption: caption ?? null,
      storyType: (storyType as "image" | "text" | "video") ?? "text",
      visibilityType: (visibilityType as any) ?? "contacts",
      textColor: textColor ?? null,
      textBg: textBg ?? null,
      userFullName: user.fullName,
      userPhone: user.phone,
      userAvatarUrl: user.avatarUrl ?? null,
      expiresAt,
    })
    .returning();

  // Emit real-time event to all connected clients
  const io = (req as any).app.get("io");
  if (io) {
    io.emit("story:new", {
      storyId: story.id,
      userId: story.userId,
      userFullName: story.userFullName,
    });
  }

  res.status(201).json(story);
});

// ── POST /stories/:id/view ────────────────────────────────────────────────────

router.post("/stories/:id/view", requireAuth, async (req, res): Promise<void> => {
  const storyId = String(req.params.id);
  const viewerId = req.userId!;

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, storyId));
  if (!story) { res.status(404).json({ error: "Story not found" }); return; }

  if (story.userId === viewerId) { res.json({ ok: true }); return; }

  await db
    .insert(storyViewsTable)
    .values({ storyId, viewerId })
    .onConflictDoNothing();

  await db
    .update(storiesTable)
    .set({ viewCount: sql`${storiesTable.viewCount} + 1` })
    .where(eq(storiesTable.id, storyId));

  res.json({ ok: true });
});

// ── GET /stories/:id/views ────────────────────────────────────────────────────

router.get("/stories/:id/views", requireAuth, async (req, res): Promise<void> => {
  const storyId = String(req.params.id);
  const userId = req.userId!;

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, storyId));
  if (!story) { res.status(404).json({ error: "Story not found" }); return; }
  if (story.userId !== userId) { res.status(403).json({ error: "Not your story" }); return; }

  const views = await db
    .select({
      viewerId: storyViewsTable.viewerId,
      viewedAt: storyViewsTable.viewedAt,
      fullName: usersTable.fullName,
      avatarUrl: usersTable.avatarUrl,
      phone: usersTable.phone,
    })
    .from(storyViewsTable)
    .leftJoin(usersTable, eq(storyViewsTable.viewerId, usersTable.id))
    .where(eq(storyViewsTable.storyId, storyId))
    .orderBy(sql`${storyViewsTable.viewedAt} DESC`);

  res.json({ viewCount: story.viewCount, views });
});

// ── POST /stories/:id/react ───────────────────────────────────────────────────

router.post("/stories/:id/react", requireAuth, async (req, res): Promise<void> => {
  const storyId = String(req.params.id);
  const userId = req.userId!;
  const parsed = ReactBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid emoji" }); return; }

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, storyId));
  if (!story) { res.status(404).json({ error: "Story not found" }); return; }

  await db
    .insert(storyReactionsTable)
    .values({ storyId, userId, emoji: parsed.data.emoji })
    .onConflictDoUpdate({
      target: [storyReactionsTable.storyId, storyReactionsTable.userId],
      set: { emoji: parsed.data.emoji },
    });

  res.json({ ok: true, emoji: parsed.data.emoji });
});

// ── DELETE /stories/:id/react ─────────────────────────────────────────────────

router.delete("/stories/:id/react", requireAuth, async (req, res): Promise<void> => {
  const storyId = String(req.params.id);
  const userId = req.userId!;
  await db
    .delete(storyReactionsTable)
    .where(and(eq(storyReactionsTable.storyId, storyId), eq(storyReactionsTable.userId, userId)));
  res.sendStatus(204);
});

// ── POST /stories/:id/reply ───────────────────────────────────────────────────

router.post("/stories/:id/reply", requireAuth, async (req, res): Promise<void> => {
  const storyId = String(req.params.id);
  const userId = req.userId!;
  const parsed = ReplyBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Message required" }); return; }

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.id, storyId));
  if (!story) { res.status(404).json({ error: "Story not found" }); return; }
  if (story.userId === userId) { res.status(400).json({ error: "Cannot reply to own story" }); return; }

  // Emit reply as a direct message via Socket.IO
  const io = (req as any).app.get("io");
  if (io) {
    io.to(`user:${story.userId}`).emit("story:reply", {
      fromUserId: userId,
      storyId,
      text: parsed.data.text,
    });
  }

  res.json({ ok: true });
});

// ── POST /stories/mute/:userId ────────────────────────────────────────────────

router.post("/stories/mute/:userId", requireAuth, async (req, res): Promise<void> => {
  const mutedUserId = String(req.params.userId);
  const userId = req.userId!;
  await db
    .insert(storyMutesTable)
    .values({ userId, mutedUserId })
    .onConflictDoNothing();
  res.json({ ok: true, muted: true });
});

// ── DELETE /stories/mute/:userId ──────────────────────────────────────────────

router.delete("/stories/mute/:userId", requireAuth, async (req, res): Promise<void> => {
  const mutedUserId = String(req.params.userId);
  const userId = req.userId!;
  await db
    .delete(storyMutesTable)
    .where(and(eq(storyMutesTable.userId, userId), eq(storyMutesTable.mutedUserId, mutedUserId)));
  res.json({ ok: true, muted: false });
});

// ── DELETE /stories/:id ───────────────────────────────────────────────────────

router.delete("/stories/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = String(req.params.id);
  const params = DeleteStoryParams.safeParse({ id: raw });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [deleted] = await db
    .delete(storiesTable)
    .where(and(eq(storiesTable.id, params.data.id), eq(storiesTable.userId, req.userId!)))
    .returning();
  if (!deleted) { res.status(404).json({ error: "Story not found" }); return; }
  res.sendStatus(204);
});

export default router;
