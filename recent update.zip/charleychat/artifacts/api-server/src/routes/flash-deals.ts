import { Router, type IRouter } from "express";
import { eq, and, gte } from "drizzle-orm";
import { db, flashDealsTable, productsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/flash-deals", async (_req, res): Promise<void> => {
  try {
    const now = new Date();

    const rows = await db
      .select({
        id: flashDealsTable.id,
        productId: flashDealsTable.productId,
        productName: productsTable.name,
        originalPricePesewas: productsTable.pricePesewas,
        dealPricePesewas: flashDealsTable.dealPricePesewas,
        image: productsTable.images,
        endsAt: flashDealsTable.endsAt,
      })
      .from(flashDealsTable)
      .innerJoin(productsTable, eq(flashDealsTable.productId, productsTable.id))
      .where(
        and(
          eq(flashDealsTable.isActive, true),
          gte(flashDealsTable.endsAt, now)
        )
      );

    const deals = rows.map((r) => {
      const originalPrice = r.originalPricePesewas;
      const dealPrice = r.dealPricePesewas;
      const percentOff = originalPrice > 0
        ? Math.round(((originalPrice - dealPrice) / originalPrice) * 100)
        : 0;
      const images = r.image as string[];
      return {
        id: r.id,
        productId: r.productId,
        productName: r.productName,
        originalPricePesewas: originalPrice,
        dealPricePesewas: dealPrice,
        image: images[0] ?? "",
        endsAt: r.endsAt.toISOString(),
        percentOff,
      };
    });

    res.json(deals);
  } catch (err) {
    // Table may not be seeded yet — return empty list rather than crashing
    res.json([]);
  }
});

export default router;
