import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, and, desc, sql } from "drizzle-orm";
import { db, moviesTable } from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";

const router: IRouter = Router();

// ── User-facing: browse the catalog ──────────────────────────────────────────

router.get("/movies", requireAuth, async (req, res): Promise<void> => {
  const genre = req.query.genre as string | undefined;
  const rows = await db
    .select({
      id: moviesTable.id,
      title: moviesTable.title,
      description: moviesTable.description,
      posterUrl: moviesTable.posterUrl,
      genre: moviesTable.genre,
      releaseYear: moviesTable.releaseYear,
      durationMinutes: moviesTable.durationMinutes,
      rating: moviesTable.rating,
      isPremium: moviesTable.isPremium,
      viewCount: moviesTable.viewCount,
      createdAt: moviesTable.createdAt,
    })
    .from(moviesTable)
    .where(genre ? and(eq(moviesTable.isPublished, true), eq(moviesTable.genre, genre)) : eq(moviesTable.isPublished, true))
    .orderBy(desc(moviesTable.createdAt));
  res.json(rows);
});

router.get("/movies/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, id));
  if (!movie || !movie.isPublished) { res.status(404).json({ error: "Movie not found" }); return; }

  const { videoUrl, ...meta } = movie;
  res.json({ ...meta, videoUrl: movie.isPremium ? null : videoUrl });
});

router.post("/movies/:id/play", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [movie] = await db.select().from(moviesTable).where(eq(moviesTable.id, id));
  if (!movie || !movie.isPublished) { res.status(404).json({ error: "Movie not found" }); return; }

  if (movie.isPremium) {
    const { movieSubscriptionsTable } = await import("@workspace/db");
    const [sub] = await db
      .select()
      .from(movieSubscriptionsTable)
      .where(and(eq(movieSubscriptionsTable.userId, req.userId!), eq(movieSubscriptionsTable.status, "active")))
      .orderBy(sql`${movieSubscriptionsTable.expiresAt} desc`)
      .limit(1);
    if (!sub || sub.expiresAt.getTime() < Date.now()) {
      res.status(403).json({ error: "An active movie subscription is required to play this title.", subscriptionRequired: true });
      return;
    }
  }

  await db.update(moviesTable).set({ viewCount: sql`${moviesTable.viewCount} + 1` }).where(eq(moviesTable.id, id));
  res.json({ videoUrl: movie.videoUrl });
});

// ── Admin: manage the catalog ─────────────────────────────────────────────────

router.get("/admin/movies", requireAdminAuth, async (_req, res): Promise<void> => {
  const rows = await db.select().from(moviesTable).orderBy(desc(moviesTable.createdAt));
  res.json(rows);
});

const UpsertMovieBody = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  posterUrl: z.string().optional(),
  videoUrl: z.string().min(1),
  genre: z.string().optional(),
  releaseYear: z.number().int().optional(),
  durationMinutes: z.number().int().optional(),
  rating: z.number().int().min(0).max(50).optional(),
  isPremium: z.boolean().default(true),
  isPublished: z.boolean().default(true),
});

router.post("/admin/movies", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = UpsertMovieBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [movie] = await db
    .insert(moviesTable)
    .values({ ...parsed.data, uploadedByAdminId: req.adminId ?? null })
    .returning();
  res.status(201).json(movie);
});

router.patch("/admin/movies/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const parsed = UpsertMovieBody.partial().safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [movie] = await db.update(moviesTable).set(parsed.data).where(eq(moviesTable.id, id)).returning();
  if (!movie) { res.status(404).json({ error: "Movie not found" }); return; }
  res.json(movie);
});

router.delete("/admin/movies/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.delete(moviesTable).where(eq(moviesTable.id, id));
  res.json({ ok: true });
});

export default router;
