import { Router, type IRouter } from "express";
import { eq, and, sql, desc } from "drizzle-orm";
import {
  db,
  discussionCategoriesTable,
  discussionsTable,
  discussionRepliesTable,
  usersTable,
} from "@workspace/db";
import {
  CreateDiscussionBody,
  CreateDiscussionReplyBody,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

// ── Helpers ──────────────────────────────────────────────────────────────────

function hotScore(replyCount: number, viewCount: number, createdAt: Date): number {
  const ageHours = (Date.now() - createdAt.getTime()) / (1000 * 60 * 60);
  const score = replyCount * 3 + viewCount;
  return score / Math.pow(ageHours + 2, 1.5);
}

function toSummary(row: {
  discussion: typeof discussionsTable.$inferSelect;
  categoryName: string | null;
  authorName: string | null;
  authorAvatarUrl: string | null;
}) {
  const { discussion, categoryName, authorName, authorAvatarUrl } = row;
  return {
    id: discussion.id,
    authorId: discussion.authorId,
    categoryId: discussion.categoryId,
    categoryName,
    isAnonymous: discussion.isAnonymous,
    title: discussion.title,
    body: discussion.body,
    viewCount: discussion.viewCount,
    replyCount: discussion.replyCount,
    authorName: discussion.isAnonymous ? null : authorName,
    authorAvatarUrl: discussion.isAnonymous ? null : authorAvatarUrl,
    createdAt: discussion.createdAt,
  };
}

// ── GET /discussions/categories ───────────────────────────────────────────────

router.get("/discussions/categories", requireAuth, async (_req, res): Promise<void> => {
  const categories = await db
    .select()
    .from(discussionCategoriesTable)
    .orderBy(discussionCategoriesTable.name);
  res.json(categories);
});

// ── GET /discussions ───────────────────────────────────────────────────────────

router.get("/discussions", requireAuth, async (req, res): Promise<void> => {
  const categoryId = typeof req.query.categoryId === "string" ? req.query.categoryId : undefined;
  const sort = req.query.sort === "new" ? "new" : "hot";

  const conditions = categoryId ? [eq(discussionsTable.categoryId, categoryId)] : [];

  const rows = await db
    .select({
      discussion: discussionsTable,
      categoryName: discussionCategoriesTable.name,
      authorName: usersTable.fullName,
      authorAvatarUrl: usersTable.avatarUrl,
    })
    .from(discussionsTable)
    .leftJoin(discussionCategoriesTable, eq(discussionsTable.categoryId, discussionCategoriesTable.id))
    .leftJoin(usersTable, eq(discussionsTable.authorId, usersTable.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(discussionsTable.createdAt));

  let summaries = rows.map(toSummary);
  if (sort === "hot") {
    summaries = summaries.sort(
      (a, b) =>
        hotScore(b.replyCount, b.viewCount, new Date(b.createdAt)) -
        hotScore(a.replyCount, a.viewCount, new Date(a.createdAt)),
    );
  }

  res.json(summaries);
});

// ── POST /discussions ──────────────────────────────────────────────────────────

router.post("/discussions", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateDiscussionBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const userId = req.userId!;
  const { categoryId, title, body, isAnonymous } = parsed.data;

  const [category] = await db
    .select()
    .from(discussionCategoriesTable)
    .where(eq(discussionCategoriesTable.id, categoryId));
  if (!category) { res.status(400).json({ error: "Invalid category" }); return; }

  const [discussion] = await db
    .insert(discussionsTable)
    .values({
      authorId: userId,
      categoryId,
      title,
      body: body ?? null,
      isAnonymous: isAnonymous ?? true,
    })
    .returning();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));

  res.status(201).json(
    toSummary({
      discussion,
      categoryName: category.name,
      authorName: user?.fullName ?? null,
      authorAvatarUrl: user?.avatarUrl ?? null,
    }),
  );
});

// ── GET /discussions/:id ────────────────────────────────────────────────────────

router.get("/discussions/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);

  const [row] = await db
    .select({
      discussion: discussionsTable,
      categoryName: discussionCategoriesTable.name,
      authorName: usersTable.fullName,
      authorAvatarUrl: usersTable.avatarUrl,
    })
    .from(discussionsTable)
    .leftJoin(discussionCategoriesTable, eq(discussionsTable.categoryId, discussionCategoriesTable.id))
    .leftJoin(usersTable, eq(discussionsTable.authorId, usersTable.id))
    .where(eq(discussionsTable.id, id));

  if (!row) { res.status(404).json({ error: "Discussion not found" }); return; }

  await db
    .update(discussionsTable)
    .set({ viewCount: sql`${discussionsTable.viewCount} + 1` })
    .where(eq(discussionsTable.id, id));

  const replyRows = await db
    .select({
      reply: discussionRepliesTable,
      authorName: usersTable.fullName,
      authorAvatarUrl: usersTable.avatarUrl,
    })
    .from(discussionRepliesTable)
    .leftJoin(usersTable, eq(discussionRepliesTable.authorId, usersTable.id))
    .where(eq(discussionRepliesTable.discussionId, id))
    .orderBy(discussionRepliesTable.createdAt);

  const replies = replyRows.map(({ reply, authorName, authorAvatarUrl }) => ({
    id: reply.id,
    discussionId: reply.discussionId,
    authorId: reply.authorId,
    isAnonymous: reply.isAnonymous,
    body: reply.body,
    likeCount: reply.likeCount,
    authorName: reply.isAnonymous ? null : authorName,
    authorAvatarUrl: reply.isAnonymous ? null : authorAvatarUrl,
    createdAt: reply.createdAt,
  }));

  res.json({
    discussion: toSummary({ ...row, discussion: { ...row.discussion, viewCount: row.discussion.viewCount + 1 } }),
    replies,
  });
});

// ── POST /discussions/:id/replies ────────────────────────────────────────────────

router.post("/discussions/:id/replies", requireAuth, async (req, res): Promise<void> => {
  const discussionId = String(req.params.id);
  const parsed = CreateDiscussionReplyBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const userId = req.userId!;

  const [discussion] = await db.select().from(discussionsTable).where(eq(discussionsTable.id, discussionId));
  if (!discussion) { res.status(404).json({ error: "Discussion not found" }); return; }

  const { body, isAnonymous } = parsed.data;

  const [reply] = await db
    .insert(discussionRepliesTable)
    .values({
      discussionId,
      authorId: userId,
      body,
      isAnonymous: isAnonymous ?? true,
    })
    .returning();

  await db
    .update(discussionsTable)
    .set({ replyCount: sql`${discussionsTable.replyCount} + 1` })
    .where(eq(discussionsTable.id, discussionId));

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));

  res.status(201).json({
    id: reply.id,
    discussionId: reply.discussionId,
    authorId: reply.authorId,
    isAnonymous: reply.isAnonymous,
    body: reply.body,
    likeCount: reply.likeCount,
    authorName: reply.isAnonymous ? null : user?.fullName ?? null,
    authorAvatarUrl: reply.isAnonymous ? null : user?.avatarUrl ?? null,
    createdAt: reply.createdAt,
  });
});

// ── POST /discussions/replies/:replyId/like ──────────────────────────────────────

router.post("/discussions/replies/:replyId/like", requireAuth, async (req, res): Promise<void> => {
  const replyId = String(req.params.replyId);

  const [reply] = await db
    .update(discussionRepliesTable)
    .set({ likeCount: sql`${discussionRepliesTable.likeCount} + 1` })
    .where(eq(discussionRepliesTable.id, replyId))
    .returning();

  if (!reply) { res.status(404).json({ error: "Reply not found" }); return; }

  res.json({ ok: true });
});

export default router;
