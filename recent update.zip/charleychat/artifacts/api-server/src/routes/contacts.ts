import { Router, type IRouter } from "express";
import { eq, and, inArray } from "drizzle-orm";
import { db, usersTable, contactsTable } from "@workspace/db";
import { AddContactBody, RemoveContactParams, ListContactsResponse } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { normalizePhone } from "../lib/phone";

const router: IRouter = Router();

// ── List ───────────────────────────────────────────────────────────────────────

router.get("/contacts", requireAuth, async (req, res): Promise<void> => {
  const rows = await db
    .select({
      id: contactsTable.id,
      ownerId: contactsTable.ownerId,
      contactUserId: contactsTable.contactUserId,
      nickname: contactsTable.nickname,
      isFavorite: contactsTable.isFavorite,
      lastInteraction: contactsTable.lastInteraction,
      createdAt: contactsTable.createdAt,
      contactPhone: usersTable.phone,
      contactName: usersTable.fullName,
      contactAvatar: usersTable.avatarUrl,
    })
    .from(contactsTable)
    .innerJoin(usersTable, eq(contactsTable.contactUserId, usersTable.id))
    .where(eq(contactsTable.ownerId, req.userId!));

  res.json(rows);
});

// ── Batch phone lookup (device contact matching) ───────────────────────────────

router.post("/contacts/lookup", requireAuth, async (req, res): Promise<void> => {
  const phones = req.body?.phones;
  if (!Array.isArray(phones) || phones.length === 0) {
    res.status(400).json({ error: "phones array required" });
    return;
  }

  // Normalise all incoming numbers to 0XXXXXXXXX (same normalisation used everywhere else)
  const normalized = phones.map((p: string) => normalizePhone(String(p)));
  const unique = [...new Set(normalized)];

  if (unique.length === 0) { res.json([]); return; }

  const users = await db
    .select({
      id: usersTable.id,
      phone: usersTable.phone,
      fullName: usersTable.fullName,
      avatar: usersTable.avatarUrl,
      fpId: usersTable.fpId,
    })
    .from(usersTable)
    .where(inArray(usersTable.phone, unique));

  // Return indexed by phone for easy O(1) lookup on client
  const byPhone: Record<string, typeof users[0]> = {};
  for (const u of users) {
    if (u.phone) byPhone[u.phone] = u;
  }

  res.json(byPhone);
});

// ── Add ────────────────────────────────────────────────────────────────────────

router.post("/contacts", requireAuth, async (req, res): Promise<void> => {
  const parsed = AddContactBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { phone: rawPhone, nickname } = parsed.data;
  const phone = normalizePhone(rawPhone);

  const [contactUser] = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
  if (!contactUser) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  if (contactUser.id === req.userId) {
    res.status(400).json({ error: "Cannot add yourself as a contact" });
    return;
  }

  const [contact] = await db
    .insert(contactsTable)
    .values({ ownerId: req.userId!, contactUserId: contactUser.id, nickname: nickname ?? null })
    .onConflictDoNothing()
    .returning();

  res.status(201).json({
    ...contact,
    contactPhone: contactUser.phone,
    contactName: contactUser.fullName,
    contactAvatar: contactUser.avatarUrl,
    isFavorite: false,
  });
});

// ── Toggle favorite ────────────────────────────────────────────────────────────

router.patch("/contacts/:id/favorite", requireAuth, async (req, res): Promise<void> => {
  const id = String(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id);
  const [row] = await db
    .select({ id: contactsTable.id, isFavorite: contactsTable.isFavorite })
    .from(contactsTable)
    .where(and(eq(contactsTable.id, id), eq(contactsTable.ownerId, req.userId!)));

  if (!row) { res.status(404).json({ error: "Contact not found" }); return; }

  const [updated] = await db
    .update(contactsTable)
    .set({ isFavorite: !row.isFavorite })
    .where(eq(contactsTable.id, id))
    .returning();

  res.json(updated);
});

// ── Remove ─────────────────────────────────────────────────────────────────────

router.delete("/contacts/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = RemoveContactParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(contactsTable)
    .where(and(eq(contactsTable.id, params.data.id), eq(contactsTable.ownerId, req.userId!)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Contact not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
