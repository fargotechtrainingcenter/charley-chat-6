import { Router, type IRouter } from "express";
import { eq, and, desc, sql } from "drizzle-orm";
import { z } from "zod/v4";
import {
  db,
  movieSubscriptionsTable,
  walletsTable,
  transactionsTable,
  MOVIE_SUBSCRIPTION_PRICE_PESEWAS,
} from "@workspace/db";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();
const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

async function getActiveMovieSubscription(userId: string) {
  const [sub] = await db
    .select()
    .from(movieSubscriptionsTable)
    .where(and(eq(movieSubscriptionsTable.userId, userId), eq(movieSubscriptionsTable.status, "active")))
    .orderBy(sql`${movieSubscriptionsTable.expiresAt} desc`)
    .limit(1);
  if (!sub) return null;
  if (sub.expiresAt.getTime() < Date.now()) return null;
  return sub;
}

router.get("/movies/subscription", requireAuth, async (req, res): Promise<void> => {
  const sub = await getActiveMovieSubscription(req.userId!);
  if (!sub) {
    res.json({ hasActiveSubscription: false, expiresAt: null, autoRenew: null, pricePesewas: MOVIE_SUBSCRIPTION_PRICE_PESEWAS });
    return;
  }
  res.json({
    hasActiveSubscription: true,
    expiresAt: sub.expiresAt.toISOString(),
    autoRenew: sub.autoRenew,
    pricePesewas: sub.pricePesewas,
  });
});

router.get("/movies/subscription/history", requireAuth, async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(movieSubscriptionsTable)
    .where(eq(movieSubscriptionsTable.userId, req.userId!))
    .orderBy(desc(movieSubscriptionsTable.createdAt));
  res.json(rows);
});

router.post("/movies/subscription/subscribe", requireAuth, async (req, res): Promise<void> => {
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet || wallet.balancePesewas < MOVIE_SUBSCRIPTION_PRICE_PESEWAS) {
    res.status(400).json({ error: "Insufficient wallet balance", pricePesewas: MOVIE_SUBSCRIPTION_PRICE_PESEWAS, needsFunding: true });
    return;
  }

  const existing = await getActiveMovieSubscription(req.userId!);
  const startBase = existing ? existing.expiresAt.getTime() : Date.now();
  const expiresAt = new Date(startBase + THIRTY_DAYS_MS);

  const sub = await db.transaction(async (trx) => {
    if (existing) {
      await trx.update(movieSubscriptionsTable).set({ status: "cancelled", cancelledAt: new Date() }).where(eq(movieSubscriptionsTable.id, existing.id));
    }
    await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${MOVIE_SUBSCRIPTION_PRICE_PESEWAS}` }).where(eq(walletsTable.id, wallet.id));
    await trx.insert(transactionsTable).values({
      walletId: wallet.id,
      type: "bill_payment",
      amountPesewas: MOVIE_SUBSCRIPTION_PRICE_PESEWAS,
      feePesewas: 0,
      reference: `MOVIESUB-${Date.now()}`,
      status: "completed",
      note: "Movie streaming subscription (30 days)",
    });
    const [row] = await trx
      .insert(movieSubscriptionsTable)
      .values({ userId: req.userId!, expiresAt, pricePesewas: MOVIE_SUBSCRIPTION_PRICE_PESEWAS })
      .returning();
    return row;
  });

  res.status(201).json({ expiresAt: sub.expiresAt.toISOString(), pricePesewas: sub.pricePesewas });
});

router.patch("/movies/subscription/auto-renew", requireAuth, async (req, res): Promise<void> => {
  const { autoRenew } = z.object({ autoRenew: z.boolean() }).parse(req.body);
  const sub = await getActiveMovieSubscription(req.userId!);
  if (!sub) { res.status(404).json({ error: "No active subscription" }); return; }
  await db.update(movieSubscriptionsTable).set({ autoRenew }).where(eq(movieSubscriptionsTable.id, sub.id));
  res.json({ ok: true, autoRenew });
});

export default router;
