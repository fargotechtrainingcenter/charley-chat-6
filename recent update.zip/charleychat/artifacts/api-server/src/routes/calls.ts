import { Router, type IRouter } from "express";
import { eq, or, desc, inArray } from "drizzle-orm";
import { db, callsTable, usersTable, notificationsTable } from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { emitToUser } from "../lib/socket";
import { logger } from "../lib/logger";

// agora-token is a CommonJS module — dynamic import avoids ESM interop issues
// eslint-disable-next-line @typescript-eslint/no-require-imports
const { RtcTokenBuilder, RtcRole } = require("agora-token") as {
  RtcTokenBuilder: { buildTokenWithUid: (...args: unknown[]) => string };
  RtcRole: { PUBLISHER: number; SUBSCRIBER: number };
};

const router: IRouter = Router();

const AGORA_APP_ID = (process.env["AGORA_APP_ID"] ?? "").trim();
const AGORA_APP_CERT = (process.env["AGORA_APP_CERTIFICATE"] ?? "").trim();

function generateAgoraToken(channelName: string, uid = 0): string {
  if (!AGORA_APP_ID || !AGORA_APP_CERT) return "";
  const expireTime = Math.floor(Date.now() / 1000) + 3600;
  return RtcTokenBuilder.buildTokenWithUid(AGORA_APP_ID, AGORA_APP_CERT, channelName, uid, RtcRole.PUBLISHER, expireTime, expireTime);
}


router.post("/calls/initiate", requireAuth, async (req, res): Promise<void> => {
  const { receiverId, type } = req.body as { receiverId: string; type: "voice" | "video" };
  if (!receiverId || !type) { res.status(400).json({ error: "receiverId and type are required" }); return; }

  const callerId = req.userId!;

  const receiver = await db.select().from(usersTable).where(eq(usersTable.id, receiverId)).limit(1);
  if (!receiver[0]) { res.status(404).json({ error: "Receiver not found" }); return; }

  const caller = await db.select().from(usersTable).where(eq(usersTable.id, callerId)).limit(1);
  if (!caller[0]) { res.status(404).json({ error: "Caller not found" }); return; }

  const [call] = await db.insert(callsTable).values({
    callerId,
    receiverId,
    type,
    channelName: "",
    status: "initiated",
  }).returning();

  const channelName = call.id;
  await db.update(callsTable).set({ channelName, status: "ringing" }).where(eq(callsTable.id, call.id));

  const callerToken   = generateAgoraToken(channelName, 1);
  const receiverToken = generateAgoraToken(channelName, 2);
  const agoraAppId    = AGORA_APP_ID;

  emitToUser(receiverId, "call:invite", {
    callId: call.id,
    channelName,
    agoraToken: receiverToken,
    agoraAppId,
    callerId,
    callerName: caller[0].fullName,
    callerAvatarUrl: caller[0].avatarUrl ?? null,
    type,
  });

  logger.info({ callId: call.id, callerId, receiverId, type }, "Call initiated");

  res.json({
    callId: call.id,
    channelName,
    agoraToken: callerToken,
    agoraAppId,
    uid: 1,
    receiverName: receiver[0].fullName,
    receiverAvatarUrl: receiver[0].avatarUrl ?? null,
  });
});

router.post("/calls/:id/accept", requireAuth, async (req, res): Promise<void> => {
  const callId = String(req.params["id"]);
  const userId = req.userId!;

  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1);
  if (!call) { res.status(404).json({ error: "Call not found" }); return; }
  if (call.receiverId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const now = new Date();
  await db.update(callsTable).set({ status: "answered", startedAt: now }).where(eq(callsTable.id, callId));

  // Receiver always gets UID=2; caller (UID=1) already has their token from /initiate
  const agoraToken = generateAgoraToken(call.channelName, 2);
  const agoraAppId = AGORA_APP_ID;

  emitToUser(call.callerId, "call:accepted", {
    callId,
    channelName: call.channelName,
    agoraAppId,
  });

  logger.info({ callId, userId }, "Call accepted");
  res.json({ ok: true, callId, channelName: call.channelName, agoraToken, agoraAppId, uid: 2 });
});

router.post("/calls/:id/decline", requireAuth, async (req, res): Promise<void> => {
  const callId = String(req.params["id"]);
  const userId = req.userId!;

  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1);
  if (!call) { res.status(404).json({ error: "Call not found" }); return; }
  if (call.receiverId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  await db.update(callsTable).set({ status: "declined" }).where(eq(callsTable.id, callId));

  emitToUser(call.callerId, "call:declined", { callId });

  logger.info({ callId, userId }, "Call declined");
  res.json({ ok: true });
});

router.post("/calls/:id/cancel", requireAuth, async (req, res): Promise<void> => {
  const callId = String(req.params["id"]);
  const userId = req.userId!;

  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1);
  if (!call) { res.status(404).json({ error: "Call not found" }); return; }
  if (call.callerId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }
  if (call.status !== "ringing") { res.status(400).json({ error: "Call not in ringing state" }); return; }

  await db.update(callsTable).set({ status: "declined", endedAt: new Date() }).where(eq(callsTable.id, callId));

  emitToUser(call.receiverId, "call:cancelled", { callId });

  logger.info({ callId, userId }, "Call cancelled by caller");
  res.json({ ok: true });
});

router.post("/calls/:id/end", requireAuth, async (req, res): Promise<void> => {
  const callId = String(req.params["id"]);
  const userId = req.userId!;

  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1);
  if (!call) { res.status(404).json({ error: "Call not found" }); return; }
  if (call.callerId !== userId && call.receiverId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  const now = new Date();
  let durationSeconds: number | null = null;
  if (call.startedAt) {
    durationSeconds = Math.floor((now.getTime() - call.startedAt.getTime()) / 1000);
  }

  // If still ringing when ended by caller → missed for receiver
  const wasMissed = call.status === "ringing" && call.callerId === userId;
  const finalStatus = call.status === "ringing" ? "missed" : "ended";

  await db.update(callsTable).set({
    status: finalStatus,
    endedAt: now,
    durationSeconds: durationSeconds ?? undefined,
  }).where(eq(callsTable.id, callId));

  const otherId = call.callerId === userId ? call.receiverId : call.callerId;

  if (wasMissed) {
    // Fetch caller name for notification
    const [callerRow] = await db.select({ fullName: usersTable.fullName })
      .from(usersTable).where(eq(usersTable.id, call.callerId)).limit(1);

    const notifTitle = call.type === "video" ? "Missed video call" : "Missed voice call";
    const notifBody  = callerRow ? `${callerRow.fullName} called you` : "You have a missed call";

    await db.insert(notificationsTable).values({
      userId: call.receiverId,
      type: "missed_call",
      title: notifTitle,
      body: notifBody,
      referenceId: callId,
    });

    emitToUser(call.receiverId, "call:missed", {
      callId,
      callerId: call.callerId,
      callerName: callerRow?.fullName ?? "",
      type: call.type,
    });
    emitToUser(call.receiverId, "notification:new", {});
  } else {
    emitToUser(otherId, "call:ended", { callId, durationSeconds });
  }

  logger.info({ callId, userId, durationSeconds, finalStatus }, "Call ended");
  res.json({ ok: true, durationSeconds });
});

router.get("/calls/history", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;

  const rawCalls = await db
    .select({
      id:              callsTable.id,
      type:            callsTable.type,
      status:          callsTable.status,
      durationSeconds: callsTable.durationSeconds,
      createdAt:       callsTable.createdAt,
      callerId:        callsTable.callerId,
      receiverId:      callsTable.receiverId,
    })
    .from(callsTable)
    .where(or(eq(callsTable.callerId, userId), eq(callsTable.receiverId, userId)))
    .orderBy(desc(callsTable.createdAt))
    .limit(100);

  if (rawCalls.length === 0) { res.json([]); return; }

  // Collect unique peer user IDs and batch-fetch names/avatars
  const userIds = [...new Set(rawCalls.flatMap(c => [c.callerId, c.receiverId]))];
  const users = await db
    .select({ id: usersTable.id, fullName: usersTable.fullName, avatarUrl: usersTable.avatarUrl })
    .from(usersTable)
    .where(inArray(usersTable.id, userIds));

  const userMap = Object.fromEntries(users.map(u => [u.id, u]));

  const history = rawCalls.map(c => ({
    ...c,
    callerName:       userMap[c.callerId]?.fullName ?? null,
    callerAvatarUrl:  userMap[c.callerId]?.avatarUrl ?? null,
    receiverName:     userMap[c.receiverId]?.fullName ?? null,
    receiverAvatarUrl: userMap[c.receiverId]?.avatarUrl ?? null,
  }));

  res.json(history);
});

router.delete("/calls/:id", requireAuth, async (req, res): Promise<void> => {
  const callId = String(req.params["id"]);
  const userId = req.userId!;

  const [call] = await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1);
  if (!call) { res.status(404).json({ error: "Call not found" }); return; }
  if (call.callerId !== userId && call.receiverId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  await db.delete(callsTable).where(eq(callsTable.id, callId));

  logger.info({ callId, userId }, "Call history entry deleted");
  res.json({ ok: true });
});

export default router;
