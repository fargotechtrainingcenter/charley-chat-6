import { Router, type IRouter } from "express";
import { eq, desc, and, sql, count } from "drizzle-orm";
import { db, invoicesTable, invoiceItemsTable, walletsTable, transactionsTable } from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { z } from "zod/v4";

const router: IRouter = Router();

const INVOICE_GENERATION_FEE_PESEWAS = 500; // GHS 5.00

const InvoiceItemInput = z.object({
  description: z.string().min(1),
  quantity: z.number().int().positive(),
  unitPricePesewas: z.number().int().positive(),
  sortOrder: z.number().int().optional().default(0),
});

const CreateInvoiceBody = z.object({
  clientName: z.string().min(1),
  clientEmail: z.string().email().optional(),
  clientPhone: z.string().optional(),
  companyName: z.string().optional(),
  companyLogoUrl: z.string().optional(),
  companyAddress: z.string().optional(),
  companyPhone: z.string().optional(),
  companyEmail: z.string().optional(),
  companyWebsite: z.string().optional(),
  issueDate: z.string().min(1),
  dueDate: z.string().min(1),
  taxPercent: z.number().min(0).max(100).optional().default(0),
  discountPercent: z.number().min(0).max(100).optional().default(0),
  notes: z.string().optional(),
  items: z.array(InvoiceItemInput).min(1),
});

function calcTotals(
  items: z.infer<typeof InvoiceItemInput>[],
  taxPercent: number,
  discountPercent: number
) {
  const subtotal = items.reduce((s, i) => s + i.unitPricePesewas * i.quantity, 0);
  const discountAmount = Math.round(subtotal * (discountPercent / 100));
  const taxableAmount = subtotal - discountAmount;
  const taxAmount = Math.round(taxableAmount * (taxPercent / 100));
  const total = taxableAmount + taxAmount;
  return { subtotal, discountAmount, taxAmount, total };
}

// List user's invoices
router.get("/invoices", requireAuth, async (req, res): Promise<void> => {
  const page = parseInt(String(req.query["page"] ?? "1"));
  const limit = parseInt(String(req.query["limit"] ?? "20"));
  const offset = (page - 1) * limit;

  const items = await db.select().from(invoicesTable)
    .where(eq(invoicesTable.userId, req.userId!))
    .orderBy(desc(invoicesTable.createdAt))
    .limit(limit).offset(offset);

  const [countRow] = await db.select({ value: count() }).from(invoicesTable)
    .where(eq(invoicesTable.userId, req.userId!));

  res.json({ items, total: Number(countRow?.value ?? 0), page, limit });
});

// Get single invoice with items
router.get("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params["id"]);
  const [invoice] = await db.select().from(invoicesTable)
    .where(and(eq(invoicesTable.id, id), eq(invoicesTable.userId, req.userId!)));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }

  const invoiceItems = await db.select().from(invoiceItemsTable)
    .where(eq(invoiceItemsTable.invoiceId, id))
    .orderBy(invoiceItemsTable.sortOrder);

  res.json({ ...invoice, items: invoiceItems });
});

// Create invoice (draft)
router.post("/invoices", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateInvoiceBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const data = parsed.data;
  const { subtotal, discountAmount, taxAmount, total } = calcTotals(
    data.items, data.taxPercent ?? 0, data.discountPercent ?? 0
  );

  // Generate invoice number
  const [countRow] = await db.select({ value: count() }).from(invoicesTable)
    .where(eq(invoicesTable.userId, req.userId!));
  const seq = (Number(countRow?.value ?? 0) + 1).toString().padStart(4, "0");
  const invoiceNumber = `INV-${Date.now().toString().slice(-6)}-${seq}`;

  const [invoice] = await db.insert(invoicesTable).values({
    userId: req.userId!,
    invoiceNumber,
    clientName: data.clientName,
    clientEmail: data.clientEmail ?? null,
    clientPhone: data.clientPhone ?? null,
    companyName: data.companyName ?? null,
    companyLogoUrl: data.companyLogoUrl ?? null,
    companyAddress: data.companyAddress ?? null,
    companyPhone: data.companyPhone ?? null,
    companyEmail: data.companyEmail ?? null,
    companyWebsite: data.companyWebsite ?? null,
    issueDate: data.issueDate,
    dueDate: data.dueDate,
    taxPercent: String(data.taxPercent ?? 0),
    discountPercent: String(data.discountPercent ?? 0),
    subtotalPesewas: subtotal,
    taxAmountPesewas: taxAmount,
    discountAmountPesewas: discountAmount,
    totalPesewas: total,
    notes: data.notes ?? null,
    status: "draft",
  }).returning();

  // Insert items
  if (data.items.length > 0) {
    await db.insert(invoiceItemsTable).values(
      data.items.map((item, i) => ({
        invoiceId: invoice!.id,
        description: item.description,
        quantity: item.quantity,
        unitPricePesewas: item.unitPricePesewas,
        totalPesewas: item.unitPricePesewas * item.quantity,
        sortOrder: item.sortOrder ?? i,
      }))
    );
  }

  const items = await db.select().from(invoiceItemsTable).where(eq(invoiceItemsTable.invoiceId, invoice!.id));
  res.status(201).json({ ...invoice, items });
});

// Update invoice (draft only)
router.patch("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params["id"]);
  const [invoice] = await db.select().from(invoicesTable)
    .where(and(eq(invoicesTable.id, id), eq(invoicesTable.userId, req.userId!)));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }
  if (invoice.status !== "draft") { res.status(400).json({ error: "Only drafts can be edited" }); return; }

  const UpdateBody = CreateInvoiceBody.partial();
  const parsed = UpdateBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const data = parsed.data;

  let taxPct = Number(invoice.taxPercent ?? 0);
  let discPct = Number(invoice.discountPercent ?? 0);

  if (data.items && data.items.length > 0) {
    taxPct = Number(data.taxPercent ?? taxPct);
    discPct = Number(data.discountPercent ?? discPct);
    const { subtotal, discountAmount, taxAmount, total } = calcTotals(data.items, taxPct, discPct);
    await db.delete(invoiceItemsTable).where(eq(invoiceItemsTable.invoiceId, id));
    await db.insert(invoiceItemsTable).values(
      data.items.map((item, i) => ({
        invoiceId: id,
        description: item.description,
        quantity: item.quantity,
        unitPricePesewas: item.unitPricePesewas,
        totalPesewas: item.unitPricePesewas * item.quantity,
        sortOrder: item.sortOrder ?? i,
      }))
    );
    await db.update(invoicesTable).set({
      clientName: data.clientName ?? invoice.clientName,
      clientEmail: data.clientEmail ?? invoice.clientEmail,
      clientPhone: data.clientPhone ?? invoice.clientPhone,
      companyName: data.companyName ?? invoice.companyName,
      issueDate: data.issueDate ?? invoice.issueDate,
      dueDate: data.dueDate ?? invoice.dueDate,
      notes: data.notes ?? invoice.notes,
      taxPercent: String(taxPct),
      discountPercent: String(discPct),
      subtotalPesewas: subtotal,
      taxAmountPesewas: taxAmount,
      discountAmountPesewas: discountAmount,
      totalPesewas: total,
    }).where(eq(invoicesTable.id, id));
  } else {
    await db.update(invoicesTable).set({
      ...(data.clientName !== undefined && { clientName: data.clientName }),
      ...(data.clientEmail !== undefined && { clientEmail: data.clientEmail ?? null }),
      ...(data.clientPhone !== undefined && { clientPhone: data.clientPhone ?? null }),
      ...(data.companyName !== undefined && { companyName: data.companyName ?? null }),
      ...(data.issueDate !== undefined && { issueDate: data.issueDate }),
      ...(data.dueDate !== undefined && { dueDate: data.dueDate }),
      ...(data.notes !== undefined && { notes: data.notes ?? null }),
    }).where(eq(invoicesTable.id, id));
  }

  const [updated] = await db.select().from(invoicesTable).where(eq(invoicesTable.id, id));
  const items = await db.select().from(invoiceItemsTable).where(eq(invoiceItemsTable.invoiceId, id));
  res.json({ ...updated, items });
});

// Pay GHS 5 generation fee to unlock PDF
router.post("/invoices/:id/pay-fee", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const id = String(req.params["id"]);
  const [invoice] = await db.select().from(invoicesTable)
    .where(and(eq(invoicesTable.id, id), eq(invoicesTable.userId, req.userId!)));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }
  if (invoice.generationFeePaidAt) { res.json({ message: "Fee already paid", invoice }); return; }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) { res.status(400).json({ error: "No wallet" }); return; }
  if (wallet.balancePesewas < INVOICE_GENERATION_FEE_PESEWAS) {
    res.status(400).json({ error: "Insufficient balance. Need GHS 5.00 to generate PDF." }); return;
  }

  await db.update(walletsTable)
    .set({ balancePesewas: sql`balance_pesewas - ${INVOICE_GENERATION_FEE_PESEWAS}` })
    .where(eq(walletsTable.userId, req.userId!));

  await db.insert(transactionsTable).values({
    walletId: wallet.id,
    type: "p2p_send",
    amountPesewas: INVOICE_GENERATION_FEE_PESEWAS,
    note: `Invoice generation fee: ${invoice.invoiceNumber}`,
    reference: `inv-fee-${id}-${Date.now()}`,
    status: "completed",
  });

  const [updated] = await db.update(invoicesTable)
    .set({ status: "unpaid", generationFeePaidAt: new Date() })
    .where(eq(invoicesTable.id, id))
    .returning();

  res.json({ message: "Fee paid. Invoice is now active.", invoice: updated });
});

// Mark invoice as paid (by invoice creator, e.g. after receiving payment)
router.patch("/invoices/:id/mark-paid", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params["id"]);
  const [invoice] = await db.select().from(invoicesTable)
    .where(and(eq(invoicesTable.id, id), eq(invoicesTable.userId, req.userId!)));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }

  const [updated] = await db.update(invoicesTable)
    .set({ status: "paid" })
    .where(eq(invoicesTable.id, id))
    .returning();
  res.json(updated);
});

// Delete invoice (draft only)
router.delete("/invoices/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params["id"]);
  const [invoice] = await db.select().from(invoicesTable)
    .where(and(eq(invoicesTable.id, id), eq(invoicesTable.userId, req.userId!)));
  if (!invoice) { res.status(404).json({ error: "Invoice not found" }); return; }
  if (invoice.status !== "draft") { res.status(400).json({ error: "Only draft invoices can be deleted" }); return; }

  await db.delete(invoicesTable).where(eq(invoicesTable.id, id));
  res.json({ message: "Deleted" });
});

export default router;
