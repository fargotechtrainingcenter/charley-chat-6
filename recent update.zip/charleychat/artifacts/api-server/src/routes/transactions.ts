import { Router, type IRouter } from "express";
import { eq, desc, count } from "drizzle-orm";
import { db, walletsTable, transactionsTable } from "@workspace/db";
import { ListTransactionsQueryParams, GetTransactionParams, GetTransactionResponse, ListTransactionsResponse } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.get("/transactions", requireAuth, async (req, res): Promise<void> => {
  const query = ListTransactionsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const page = query.data.page ?? 1;
  const limit = query.data.limit ?? 20;
  const offset = (page - 1) * limit;

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.json(ListTransactionsResponse.parse({ items: [], total: 0, page, limit }));
    return;
  }

  const items = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.walletId, wallet.id))
    .orderBy(desc(transactionsTable.createdAt))
    .limit(limit)
    .offset(offset);

  const [countRow] = await db
    .select({ value: count() })
    .from(transactionsTable)
    .where(eq(transactionsTable.walletId, wallet.id));
  const total = Number(countRow?.value ?? 0);

  res.json(ListTransactionsResponse.parse({ items, total, page, limit }));
});

router.get("/transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }

  const [tx] = await db
    .select()
    .from(transactionsTable)
    .where(eq(transactionsTable.id, params.data.id));

  if (!tx || tx.walletId !== wallet.id) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }

  res.json(GetTransactionResponse.parse(tx));
});

export default router;
