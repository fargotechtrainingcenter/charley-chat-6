import { Router, type IRouter } from "express";
import crypto from "crypto";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";
import rateLimit from "express-rate-limit";
import { db, usersTable, sessionsTable, walletsTable, vendorsTable } from "@workspace/db";
import {
  AuthLoginBody,
  AuthRefreshBody,
  AuthLogoutBody,
  AuthLoginResponse,
  AuthRefreshResponse,
} from "@workspace/api-zod";
import { hashPin, verifyPin, signAccessToken, signRefreshToken, verifyRefreshToken, requireAuth } from "../lib/auth";
import { normalizePhone } from "../lib/phone";
import { validateOtp } from "./otp";

const router: IRouter = Router();

// Rate limiters for sensitive auth endpoints
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many login attempts. Please try again in 15 minutes." },
  skipSuccessfulRequests: true,
});

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many registration attempts from this IP. Please try again later." },
});

const pinLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  limit: 8,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many PIN attempts. Please wait 10 minutes." },
  skipSuccessfulRequests: true,
});

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

const REFRESH_TTL_MS = 7 * 24 * 60 * 60 * 1000;

const RegisterBody = z.object({
  phone: z.string().min(9),
  pin: z.string().min(4).max(20),
  fullName: z.string().min(1),
  email: z.string().email().optional(),
  ghanaCardId: z.string().optional(),
  dateOfBirth: z.string().optional(),
  otpCode: z.string().length(6).optional(),
});

router.post("/auth/register", registerLimiter, async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const raw = parsed.data;
  const phone = normalizePhone(raw.phone);
  const { pin, fullName, email, ghanaCardId, dateOfBirth, otpCode } = raw;

  // Validate OTP server-side (required when provided)
  // Pass email too so validateOtp can find the record when OTP was sent via email
  if (otpCode) {
    const otpResult = await validateOtp(phone, otpCode, "register", email);
    if (!otpResult.valid) {
      res.status(400).json({ error: otpResult.error ?? "Invalid or expired OTP" });
      return;
    }
  }

  const [existing] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.phone, phone));
  if (existing) {
    res.status(409).json({ error: "Phone number already registered" });
    return;
  }

  const pinHash = await hashPin(pin);

  // Generate sequential FP-ID
  const maxResult = await db.execute<{ next_num: number }>(sql`
    SELECT COALESCE(MAX(CAST(SUBSTRING(fp_id FROM 4) AS INTEGER)), 0) + 1 AS next_num
    FROM users WHERE fp_id IS NOT NULL
  `);
  const [maxRow] = maxResult.rows;
  const nextNum = maxRow?.next_num ?? 1;
  const fpId = "FP-" + String(nextNum).padStart(6, "0");

  // Generate unique username from fullName
  const baseUsername = fullName.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 20) || "user";
  let username = baseUsername;
  let usernameAttempts = 0;
  while (usernameAttempts < 10) {
    const [existing] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.username, username));
    if (!existing) break;
    username = baseUsername + String(Math.floor(100 + Math.random() * 900));
    usernameAttempts++;
  }

  const [user] = await db
    .insert(usersTable)
    .values({
      phone,
      pinHash,
      fullName,
      fpId,
      username,
      email: email ?? null,
      ghanaCardId: ghanaCardId ?? null,
      dateOfBirth: dateOfBirth ?? null,
    })
    .returning();

  await db.insert(walletsTable).values({ userId: user.id });

  const accessToken = signAccessToken(user.id);
  const refreshToken = signRefreshToken(user.id);
  await db.insert(sessionsTable).values({
    userId: user.id,
    tokenHash: hashToken(refreshToken),
    expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
  });

  res.status(201).json({
    ...AuthLoginResponse.parse({ accessToken, refreshToken, userId: user.id }),
    fpId: user.fpId,
  });
});

router.post("/auth/login", loginLimiter, async (req, res): Promise<void> => {
  const parsed = AuthLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const phone = normalizePhone(parsed.data.phone);
  const { pin } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
  if (!user) {
    res.status(401).json({ error: "Invalid phone or PIN" });
    return;
  }

  if (user.isSuspended) {
    res.status(403).json({ error: "Account suspended. Contact support." });
    return;
  }

  const valid = await verifyPin(pin, user.pinHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid phone or PIN" });
    return;
  }

  const accessToken = signAccessToken(user.id);
  const refreshToken = signRefreshToken(user.id);
  await db.insert(sessionsTable).values({
    userId: user.id,
    tokenHash: hashToken(refreshToken),
    expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
  });

  const [vendorRow] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, user.id));

  res.json({
    ...AuthLoginResponse.parse({ accessToken, refreshToken, userId: user.id }),
    user: {
      id: user.id,
      fullName: user.fullName,
      phone: user.phone,
      fpId: user.fpId,
      isVendor: !!vendorRow,
    },
  });
});

router.post("/auth/refresh", async (req, res): Promise<void> => {
  const parsed = AuthRefreshBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { refreshToken } = parsed.data;

  let payload: { sub: string };
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    res.status(401).json({ error: "Invalid refresh token" });
    return;
  }

  const tokenHash = hashToken(refreshToken);
  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.tokenHash, tokenHash));
  if (!session || session.expiresAt < new Date()) {
    res.status(401).json({ error: "Refresh token expired or revoked" });
    return;
  }

  const newAccessToken = signAccessToken(payload.sub);
  const newRefreshToken = signRefreshToken(payload.sub);
  await db.delete(sessionsTable).where(eq(sessionsTable.tokenHash, tokenHash));
  await db.insert(sessionsTable).values({
    userId: payload.sub,
    tokenHash: hashToken(newRefreshToken),
    expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
  });

  res.json(
    AuthRefreshResponse.parse({
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      userId: payload.sub,
    }),
  );
});

router.post("/auth/reset-pin", pinLimiter, async (req, res): Promise<void> => {
  const { phone: rawPhone, otp, newPin } = req.body ?? {};
  if (!rawPhone || !otp || !newPin) {
    res.status(400).json({ error: "phone, otp, and newPin are required" });
    return;
  }
  const phone = normalizePhone(String(rawPhone));
  const otpResult = await validateOtp(phone, otp, "login_reset");
  if (!otpResult.valid) {
    res.status(400).json({ error: otpResult.error ?? "Invalid or expired OTP" });
    return;
  }
  const [user] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.phone, phone));
  if (!user) {
    res.status(404).json({ error: "Phone number not registered" });
    return;
  }
  const pinHash = await hashPin(String(newPin));
  await db.update(usersTable).set({ pinHash }).where(eq(usersTable.id, user.id));
  res.json({ message: "PIN reset successfully" });
});

router.get("/auth/pin-status", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const [user] = await db.select({ pinHash: usersTable.pinHash }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json({ hasPin: !!user.pinHash });
});

router.post("/auth/create-pin", requireAuth, pinLimiter, async (req, res): Promise<void> => {
  const { pin } = req.body as { pin?: string };
  if (!pin || typeof pin !== "string" || !/^\d{4}$/.test(pin)) {
    res.status(400).json({ error: "PIN must be exactly 4 digits" });
    return;
  }
  const userId = (req as any).userId as string;
  const [user] = await db.select({ pinHash: usersTable.pinHash }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  if (user.pinHash) { res.status(400).json({ error: "PIN already exists. Use change-pin instead." }); return; }
  const newHash = await hashPin(pin);
  await db.update(usersTable).set({ pinHash: newHash }).where(eq(usersTable.id, userId));
  res.json({ ok: true });
});

router.post("/auth/change-pin", requireAuth, pinLimiter, async (req, res): Promise<void> => {
  const { currentPin, newPin } = req.body as { currentPin?: string; newPin?: string };
  if (!currentPin || !newPin || typeof currentPin !== "string" || typeof newPin !== "string") {
    res.status(400).json({ error: "currentPin and newPin are required" });
    return;
  }
  if (!/^\d{4}$/.test(newPin)) {
    res.status(400).json({ error: "New PIN must be exactly 4 digits" });
    return;
  }
  const userId = (req as any).userId as string;
  const [user] = await db.select({ pinHash: usersTable.pinHash }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const valid = await verifyPin(currentPin, user.pinHash);
  if (!valid) { res.status(401).json({ error: "Current PIN is incorrect" }); return; }
  const newHash = await hashPin(newPin);
  await db.update(usersTable).set({ pinHash: newHash }).where(eq(usersTable.id, userId));
  res.json({ ok: true });
});

router.post("/auth/verify-pin", requireAuth, pinLimiter, async (req, res): Promise<void> => {
  const { pin } = req.body as { pin?: string };
  if (!pin || typeof pin !== "string") {
    res.status(400).json({ error: "PIN is required" });
    return;
  }
  const userId = (req as any).userId as string;
  const [user] = await db.select({ pinHash: usersTable.pinHash }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const valid = await verifyPin(pin, user.pinHash);
  if (!valid) {
    res.status(401).json({ error: "Incorrect PIN" });
    return;
  }
  res.json({ ok: true });
});

router.post("/auth/logout", requireAuth, async (req, res): Promise<void> => {
  const parsed = AuthLogoutBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const tokenHash = hashToken(parsed.data.refreshToken);
  await db.delete(sessionsTable).where(eq(sessionsTable.tokenHash, tokenHash));
  res.sendStatus(204);
});

export default router;
