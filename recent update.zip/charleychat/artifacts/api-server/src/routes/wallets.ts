import { Router, type IRouter } from "express";
import { and, eq, gte, sql } from "drizzle-orm";
import { db, usersTable, walletsTable, transactionsTable, notificationsTable } from "@workspace/db";
import {
  GetWalletBalanceResponse,
  DepositFundsBody,
  WithdrawFundsBody,
  SendMoneyBody,
  PayBillBody,
} from "@workspace/api-zod";
import { requireAuth, verifyPin } from "../lib/auth";
import { normalizePhone } from "../lib/phone";
import { emitToUser } from "../lib/socket";
import { calculateTransferFeePesewas, calculateP2PFeePesewas, calculateBillFeePesewas } from "../lib/fees";

const router: IRouter = Router();

async function requireKyc(userId: string): Promise<boolean> {
  const [user] = await db
    .select({ isKycVerified: usersTable.isKycVerified })
    .from(usersTable)
    .where(eq(usersTable.id, userId));
  return user?.isKycVerified === true;
}

router.get("/wallets/fee-preview", requireAuth, async (req, res): Promise<void> => {
  const type = String(req.query.type ?? "");
  const amountPesewas = Number(req.query.amountPesewas ?? 0);
  if (!Number.isFinite(amountPesewas) || amountPesewas <= 0) {
    res.status(400).json({ error: "A valid amountPesewas is required" });
    return;
  }
  let feePesewas: number;
  switch (type) {
    case "deposit":
    case "withdraw":
      feePesewas = calculateTransferFeePesewas(amountPesewas);
      break;
    case "send":
      feePesewas = calculateP2PFeePesewas(amountPesewas);
      break;
    case "bill":
      feePesewas = calculateBillFeePesewas(amountPesewas);
      break;
    default:
      res.status(400).json({ error: "type must be one of: deposit, withdraw, send, bill" });
      return;
  }
  res.json({ amountPesewas, feePesewas, totalPesewas: amountPesewas + feePesewas });
});

router.get("/wallets/me", requireAuth, async (req, res): Promise<void> => {
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  res.json(GetWalletBalanceResponse.parse(wallet));
});

router.post("/wallets/deposit", requireAuth, async (req, res): Promise<void> => {
  if (!(await requireKyc(req.userId!))) {
    res.status(403).json({ error: "KYC verification required before making transactions", kycRequired: true });
    return;
  }
  const parsed = DepositFundsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { amountPesewas, network } = parsed.data;
  const feePesewas = calculateTransferFeePesewas(amountPesewas);

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }

  const txType = network?.toLowerCase().includes("bank")
    ? "bank_in"
    : network?.toLowerCase().includes("visa") || network?.toLowerCase().includes("card")
      ? "visa_in"
      : "momo_in";

  const reference = crypto.randomUUID();
  const [tx] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${amountPesewas}` })
      .where(eq(walletsTable.id, wallet.id));
    return trx
      .insert(transactionsTable)
      .values({
        walletId: wallet.id,
        type: txType,
        amountPesewas,
        // Recorded for accurate revenue reporting. The wallet is still credited
        // with the full requested amount — the fee is charged at the external
        // MoMo/card gateway step (amount + fee collected from the user there),
        // which happens before this endpoint finalizes the wallet credit.
        feePesewas,
        network,
        reference,
        status: "completed",
      })
      .returning();
  });

  res.status(201).json(tx);
});

router.post("/wallets/withdraw", requireAuth, async (req, res): Promise<void> => {
  if (!(await requireKyc(req.userId!))) {
    res.status(403).json({ error: "KYC verification required before making transactions", kycRequired: true });
    return;
  }
  const parsed = WithdrawFundsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { amountPesewas, network, pin } = parsed.data;

  // Verify PIN before touching any funds
  const [userRow] = await db
    .select({ pinHash: usersTable.pinHash })
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!));
  if (!userRow?.pinHash || !(await verifyPin(String(pin), userRow.pinHash))) {
    res.status(401).json({ error: "Incorrect PIN. Please try again." });
    return;
  }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  const feePesewas = calculateTransferFeePesewas(amountPesewas);
  const totalDeductedPesewas = amountPesewas + feePesewas;
  if (wallet.balancePesewas < totalDeductedPesewas) {
    res.status(400).json({ error: "Insufficient funds", feePesewas, totalDeductedPesewas });
    return;
  }

  const txType = network?.toLowerCase().includes("bank") ? "bank_out" : "momo_out";
  const reference = crypto.randomUUID();
  const [tx] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${totalDeductedPesewas}` })
      .where(eq(walletsTable.id, wallet.id));
    return trx
      .insert(transactionsTable)
      .values({
        walletId: wallet.id,
        type: txType,
        amountPesewas,
        feePesewas,
        network,
        reference,
        status: "completed",
      })
      .returning();
  });

  res.status(201).json(tx);
});

router.post("/wallets/send", requireAuth, async (req, res): Promise<void> => {
  if (!(await requireKyc(req.userId!))) {
    res.status(403).json({ error: "KYC verification required before making transactions", kycRequired: true });
    return;
  }
  const parsed = SendMoneyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { toPhone: rawToPhone, amountPesewas, note, pin } = parsed.data;
  const toPhone = normalizePhone(rawToPhone);

  const [sender] = await db
    .select({ id: usersTable.id, phone: usersTable.phone, fullName: usersTable.fullName, pinHash: usersTable.pinHash })
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!));
  if (!sender) {
    res.status(404).json({ error: "Sender not found" });
    return;
  }

  // Verify PIN before any funds move
  if (!sender.pinHash || !(await verifyPin(String(pin), sender.pinHash))) {
    res.status(401).json({ error: "Incorrect PIN. Please try again." });
    return;
  }

  if (sender.phone === toPhone) {
    res.status(400).json({ error: "Cannot send money to yourself" });
    return;
  }

  const [recipient] = await db.select().from(usersTable).where(eq(usersTable.phone, toPhone));
  if (!recipient) {
    res.status(400).json({ error: "Recipient not found" });
    return;
  }

  const [senderWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, sender.id));
  const [recipientWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, recipient.id));

  if (!senderWallet || !recipientWallet) {
    res.status(400).json({ error: "Wallet not found" });
    return;
  }

  // Re-validate balance from DB (never trust frontend)
  const feePesewas = calculateP2PFeePesewas(amountPesewas);
  const totalDeductedPesewas = amountPesewas + feePesewas;
  if (senderWallet.balancePesewas < totalDeductedPesewas) {
    res.status(400).json({ error: "Insufficient funds", feePesewas, totalDeductedPesewas });
    return;
  }

  // Generate CHR-YYYYMMDD-XXXXXX reference
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, "");
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const [{ todayCount }] = await db
    .select({ todayCount: sql<number>`cast(count(*) as int)` })
    .from(transactionsTable)
    .where(and(eq(transactionsTable.type, "p2p_send"), gte(transactionsTable.createdAt, startOfDay)));
  const seq = (todayCount + 1).toString().padStart(6, "0");
  const reference = `CHR-${dateStr}-${seq}`;

  const amountGhs = (amountPesewas / 100).toFixed(2);
  const feeGhs = (feePesewas / 100).toFixed(2);

  await db.transaction(async (trx) => {
    // Debit sender (amount + fee), credit recipient the full requested amount
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${totalDeductedPesewas}`, updatedAt: now })
      .where(eq(walletsTable.id, senderWallet.id));
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${amountPesewas}`, updatedAt: now })
      .where(eq(walletsTable.id, recipientWallet.id));

    // Transaction records for both parties — reference is shared as prefix but
    // the unique constraint requires distinct values, so append -S / -R suffixes.
    const [out] = await trx
      .insert(transactionsTable)
      .values({
        walletId: senderWallet.id,
        type: "p2p_send",
        amountPesewas,
        feePesewas,
        reference: `${reference}-S`,
        status: "completed",
        counterpartyPhone: toPhone,
        note: note ?? null,
      })
      .returning();
    await trx.insert(transactionsTable).values({
      walletId: recipientWallet.id,
      type: "p2p_receive",
      amountPesewas,
      feePesewas: 0,
      reference: `${reference}-R`,
      status: "completed",
      counterpartyPhone: sender.phone,
      note: note ?? null,
    });

    // Notifications for both parties
    await trx.insert(notificationsTable).values({
      userId: recipient.id,
      title: "Money received",
      body: `You received GH₵${amountGhs} from ${sender.fullName}.`,
      type: "p2p_receive",
      referenceId: out.id,
    });
    await trx.insert(notificationsTable).values({
      userId: sender.id,
      title: "Money sent",
      body: feePesewas > 0
        ? `GH₵${amountGhs} sent to ${recipient.fullName} (+ GH₵${feeGhs} fee).`
        : `GH₵${amountGhs} sent successfully to ${recipient.fullName}.`,
      type: "p2p_send",
      referenceId: out.id,
    });
  });

  const newSenderBalancePesewas = senderWallet.balancePesewas - totalDeductedPesewas;

  // Push real-time balance update to both parties instantly
  emitToUser(recipient.id, "balance_updated", { userId: recipient.id });
  emitToUser(sender.id, "balance_updated", { userId: sender.id });

  res.status(201).json({
    reference,
    recipientName: recipient.fullName,
    amountPesewas,
    feePesewas,
    totalDeductedPesewas,
    newBalancePesewas: newSenderBalancePesewas,
  });
});

router.post("/wallets/pay-bill", requireAuth, async (req, res): Promise<void> => {
  if (!(await requireKyc(req.userId!))) {
    res.status(403).json({ error: "KYC verification required before making transactions", kycRequired: true });
    return;
  }
  const parsed = PayBillBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { billerType, billerName, accountNumber, amountPesewas, pin } = parsed.data;

  const [userRow] = await db
    .select({ pinHash: usersTable.pinHash })
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!));
  if (!userRow?.pinHash || !(await verifyPin(String(pin), userRow.pinHash))) {
    res.status(401).json({ error: "Incorrect PIN. Please try again." });
    return;
  }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) {
    res.status(404).json({ error: "Wallet not found" });
    return;
  }
  const feePesewas = calculateBillFeePesewas(amountPesewas);
  const totalDeductedPesewas = amountPesewas + feePesewas;
  if (wallet.balancePesewas < totalDeductedPesewas) {
    res.status(400).json({ error: "Insufficient funds", feePesewas, totalDeductedPesewas });
    return;
  }

  const reference = `BILL-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const [tx] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${totalDeductedPesewas}`, updatedAt: new Date() })
      .where(eq(walletsTable.id, wallet.id));
    return trx
      .insert(transactionsTable)
      .values({
        walletId: wallet.id,
        type: "bill_payment",
        amountPesewas,
        feePesewas,
        reference,
        status: "completed",
        note: `${billerName ?? billerType} bill payment (Acc: ${accountNumber})`,
      })
      .returning();
  });

  emitToUser(req.userId!, "balance_updated", { userId: req.userId! });

  res.status(201).json(tx);
});

export default router;
