import { Router, type IRouter } from "express";
import { eq, sql, and, desc } from "drizzle-orm";
import {
  db,
  reelsTable,
  reelLikesTable,
  reelCommentsTable,
  reelSavesTable,
  reelViewsTable,
  reelFollowsTable,
  reelReportsTable,
  usersTable,
  productsTable,
} from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { z } from "zod/v4";

const router: IRouter = Router();

// ─── Zod schemas ──────────────────────────────────────────────────────────────

const CreateReelBody = z.object({
  videoUrl: z.string().url().optional(),
  thumbnailUrl: z.string().url().optional(),
  coverImageUrl: z.string().url().optional(),
  caption: z.string().max(2200).optional(),
  hashtags: z.array(z.string().max(100)).max(30).optional(),
  location: z.string().max(200).optional(),
  musicInfo: z.string().max(200).optional(),
  durationSeconds: z.number().int().min(0).max(600).optional(),
  isMerchant: z.boolean().optional(),
  taggedProductIds: z.array(z.string().uuid()).optional(),
});

const PostCommentBody = z.object({
  content: z.string().min(1).max(1000),
  parentId: z.string().uuid().optional(),
});

const ReportBody = z.object({
  reason: z.string().min(1).max(200),
  details: z.string().max(1000).optional(),
});

const RecordViewBody = z.object({
  watchedSeconds: z.number().int().min(0).optional(),
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function enrichReels(reels: any[], viewerId: string) {
  if (!reels.length) return [];

  const reelIds = reels.map((r: any) => r.id);

  const [likes, saves, follows] = await Promise.all([
    db.select({ reelId: reelLikesTable.reelId })
      .from(reelLikesTable)
      .where(eq(reelLikesTable.userId, viewerId)),
    db.select({ reelId: reelSavesTable.reelId })
      .from(reelSavesTable)
      .where(eq(reelSavesTable.userId, viewerId)),
    db.select({ followeeId: reelFollowsTable.followeeId })
      .from(reelFollowsTable)
      .where(eq(reelFollowsTable.followerId, viewerId)),
  ]);

  const likedSet = new Set(likes.map((l) => l.reelId));
  const savedSet = new Set(saves.map((s) => s.reelId));
  const followingSet = new Set(follows.map((f) => f.followeeId));

  return reels.map((r: any) => ({
    ...r,
    likedByMe: likedSet.has(r.id),
    savedByMe: savedSet.has(r.id),
    followingCreator: followingSet.has(r.userId),
  }));
}

// ─── GET /reels — public feed ─────────────────────────────────────────────────

router.get("/reels", requireAuth, async (req, res): Promise<void> => {
  const viewerId = req.userId!;
  const page = Math.max(1, parseInt(String(req.query.page ?? "1"), 10));
  const limit = Math.min(20, parseInt(String(req.query.limit ?? "10"), 10));
  const offset = (page - 1) * limit;

  const reels = await db
    .select()
    .from(reelsTable)
    .where(and(eq(reelsTable.isPublished, true), eq(reelsTable.isSuspended, false)))
    .orderBy(desc(reelsTable.createdAt))
    .limit(limit)
    .offset(offset);

  const enriched = await enrichReels(reels, viewerId);
  res.json(enriched);
});

// ─── GET /reels/me — my reels ─────────────────────────────────────────────────

router.get("/reels/me", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  const reels = await db
    .select()
    .from(reelsTable)
    .where(eq(reelsTable.userId, userId))
    .orderBy(desc(reelsTable.createdAt));
  const enriched = await enrichReels(reels, userId);
  res.json(enriched);
});

// ─── GET /reels/analytics — creator analytics ─────────────────────────────────

router.get("/reels/analytics", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;

  const myReels = await db
    .select()
    .from(reelsTable)
    .where(eq(reelsTable.userId, userId));

  const totalViews    = myReels.reduce((s, r) => s + r.viewCount, 0);
  const totalLikes    = myReels.reduce((s, r) => s + r.likeCount, 0);
  const totalComments = myReels.reduce((s, r) => s + r.commentCount, 0);
  const totalShares   = myReels.reduce((s, r) => s + r.shareCount, 0);
  const totalSaves    = myReels.reduce((s, r) => s + r.saveCount, 0);
  const reelCount     = myReels.length;

  const [followRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(reelFollowsTable)
    .where(eq(reelFollowsTable.followeeId, userId));

  res.json({
    totalViews,
    totalLikes,
    totalComments,
    totalShares,
    totalSaves,
    reelCount,
    followers: followRow?.count ?? 0,
    productClicks: 0,
    productPurchases: 0,
  });
});

// ─── GET /reels/saved — saved reels ──────────────────────────────────────────

router.get("/reels/saved", requireAuth, async (req, res): Promise<void> => {
  const userId = req.userId!;
  const saves = await db
    .select({ reelId: reelSavesTable.reelId })
    .from(reelSavesTable)
    .where(eq(reelSavesTable.userId, userId))
    .orderBy(desc(reelSavesTable.createdAt));

  if (!saves.length) { res.json([]); return; }

  const reels: any[] = [];
  for (const { reelId } of saves) {
    const [r] = await db.select().from(reelsTable).where(eq(reelsTable.id, reelId));
    if (r) reels.push(r);
  }
  const enriched = await enrichReels(reels, userId);
  res.json(enriched);
});

// ─── GET /reels/:id ───────────────────────────────────────────────────────────

router.get("/reels/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const [reel] = await db.select().from(reelsTable).where(eq(reelsTable.id, id));
  if (!reel) { res.status(404).json({ error: "Reel not found" }); return; }
  const [enriched] = await enrichReels([reel], req.userId!);
  res.json(enriched);
});

// ─── POST /reels — create reel ────────────────────────────────────────────────

router.post("/reels", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateReelBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const userId = req.userId!;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const {
    videoUrl, thumbnailUrl, coverImageUrl, caption, hashtags,
    location, musicInfo, durationSeconds, isMerchant, taggedProductIds,
  } = parsed.data;

  const [reel] = await db
    .insert(reelsTable)
    .values({
      userId,
      videoUrl: videoUrl ?? null,
      thumbnailUrl: thumbnailUrl ?? null,
      coverImageUrl: coverImageUrl ?? null,
      caption: caption ?? null,
      hashtags: hashtags ?? [],
      location: location ?? null,
      musicInfo: musicInfo ?? null,
      durationSeconds: durationSeconds ?? 0,
      isMerchant: isMerchant ?? false,
      taggedProductIds: taggedProductIds ?? [],
      userFullName: user.fullName,
      userAvatarUrl: user.avatarUrl ?? null,
      userPhone: user.phone,
    })
    .returning();

  res.status(201).json(reel);
});

// ─── DELETE /reels/:id ────────────────────────────────────────────────────────

router.delete("/reels/:id", requireAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  const userId = req.userId!;
  const [reel] = await db.select().from(reelsTable).where(eq(reelsTable.id, id));
  if (!reel) { res.status(404).json({ error: "Reel not found" }); return; }
  if (reel.userId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }
  await db.delete(reelsTable).where(eq(reelsTable.id, id));
  res.json({ ok: true });
});

// ─── POST /reels/:id/like — toggle like ──────────────────────────────────────

router.post("/reels/:id/like", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const userId = req.userId!;

  const [existing] = await db
    .select()
    .from(reelLikesTable)
    .where(and(eq(reelLikesTable.reelId, reelId), eq(reelLikesTable.userId, userId)));

  if (existing) {
    await db.delete(reelLikesTable).where(eq(reelLikesTable.id, existing.id));
    await db.update(reelsTable)
      .set({ likeCount: sql`greatest(0, ${reelsTable.likeCount} - 1)` })
      .where(eq(reelsTable.id, reelId));
    res.json({ liked: false });
  } else {
    await db.insert(reelLikesTable).values({ reelId, userId }).onConflictDoNothing();
    await db.update(reelsTable)
      .set({ likeCount: sql`${reelsTable.likeCount} + 1` })
      .where(eq(reelsTable.id, reelId));
    res.json({ liked: true });
  }
});

// ─── POST /reels/:id/save — toggle save ──────────────────────────────────────

router.post("/reels/:id/save", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const userId = req.userId!;

  const [existing] = await db
    .select()
    .from(reelSavesTable)
    .where(and(eq(reelSavesTable.reelId, reelId), eq(reelSavesTable.userId, userId)));

  if (existing) {
    await db.delete(reelSavesTable).where(eq(reelSavesTable.id, existing.id));
    await db.update(reelsTable)
      .set({ saveCount: sql`greatest(0, ${reelsTable.saveCount} - 1)` })
      .where(eq(reelsTable.id, reelId));
    res.json({ saved: false });
  } else {
    await db.insert(reelSavesTable).values({ reelId, userId }).onConflictDoNothing();
    await db.update(reelsTable)
      .set({ saveCount: sql`${reelsTable.saveCount} + 1` })
      .where(eq(reelsTable.id, reelId));
    res.json({ saved: true });
  }
});

// ─── POST /reels/:id/view ─────────────────────────────────────────────────────

router.post("/reels/:id/view", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const viewerId = req.userId!;
  const parsed = RecordViewBody.safeParse(req.body);

  const [reel] = await db.select().from(reelsTable).where(eq(reelsTable.id, reelId));
  if (!reel) { res.status(404).json({ error: "Reel not found" }); return; }
  if (reel.userId === viewerId) { res.json({ ok: true }); return; }

  await db
    .insert(reelViewsTable)
    .values({ reelId, viewerId, watchedSeconds: parsed.success ? (parsed.data.watchedSeconds ?? 0) : 0 })
    .onConflictDoNothing();

  await db.update(reelsTable)
    .set({ viewCount: sql`${reelsTable.viewCount} + 1` })
    .where(eq(reelsTable.id, reelId));

  res.json({ ok: true });
});

// ─── POST /reels/:id/share — increment share count ───────────────────────────

router.post("/reels/:id/share", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  await db.update(reelsTable)
    .set({ shareCount: sql`${reelsTable.shareCount} + 1` })
    .where(eq(reelsTable.id, reelId));
  res.json({ ok: true });
});

// ─── GET /reels/:id/comments ──────────────────────────────────────────────────

router.get("/reels/:id/comments", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const comments = await db
    .select()
    .from(reelCommentsTable)
    .where(eq(reelCommentsTable.reelId, reelId))
    .orderBy(desc(reelCommentsTable.createdAt));
  res.json(comments);
});

// ─── POST /reels/:id/comments ─────────────────────────────────────────────────

router.post("/reels/:id/comments", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const userId = req.userId!;
  const parsed = PostCommentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [comment] = await db
    .insert(reelCommentsTable)
    .values({
      reelId,
      userId,
      content: parsed.data.content,
      parentId: parsed.data.parentId ?? null,
      userFullName: user.fullName,
      userAvatarUrl: user.avatarUrl ?? null,
    })
    .returning();

  await db.update(reelsTable)
    .set({ commentCount: sql`${reelsTable.commentCount} + 1` })
    .where(eq(reelsTable.id, reelId));

  res.status(201).json(comment);
});

// ─── DELETE /reels/:id/comments/:commentId ───────────────────────────────────

router.delete("/reels/:id/comments/:commentId", requireAuth, async (req, res): Promise<void> => {
  const commentId = String(req.params.commentId);
  const userId = req.userId!;
  const reelId = String(req.params.id);

  const [comment] = await db.select().from(reelCommentsTable).where(eq(reelCommentsTable.id, commentId));
  if (!comment) { res.status(404).json({ error: "Comment not found" }); return; }
  if (comment.userId !== userId) { res.status(403).json({ error: "Forbidden" }); return; }

  await db.delete(reelCommentsTable).where(eq(reelCommentsTable.id, commentId));
  await db.update(reelsTable)
    .set({ commentCount: sql`greatest(0, ${reelsTable.commentCount} - 1)` })
    .where(eq(reelsTable.id, reelId));

  res.json({ ok: true });
});

// ─── POST /reels/:id/report ───────────────────────────────────────────────────

router.post("/reels/:id/report", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const reporterId = req.userId!;
  const parsed = ReportBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  await db.insert(reelReportsTable).values({
    reelId,
    reporterId,
    reason: parsed.data.reason,
    details: parsed.data.details ?? null,
  });

  res.json({ ok: true });
});

// ─── POST /reels/follows/:userId — toggle follow ──────────────────────────────

router.post("/reels/follows/:userId", requireAuth, async (req, res): Promise<void> => {
  const followeeId = String(req.params.userId);
  const followerId = req.userId!;
  if (followerId === followeeId) { res.status(400).json({ error: "Cannot follow yourself" }); return; }

  const [existing] = await db
    .select()
    .from(reelFollowsTable)
    .where(and(eq(reelFollowsTable.followerId, followerId), eq(reelFollowsTable.followeeId, followeeId)));

  if (existing) {
    await db.delete(reelFollowsTable).where(eq(reelFollowsTable.id, existing.id));
    res.json({ following: false });
  } else {
    await db.insert(reelFollowsTable).values({ followerId, followeeId }).onConflictDoNothing();
    res.json({ following: true });
  }
});

// ─── GET /reels/:id/tagged-products ──────────────────────────────────────────

router.get("/reels/:id/tagged-products", requireAuth, async (req, res): Promise<void> => {
  const reelId = String(req.params.id);
  const [reel] = await db.select().from(reelsTable).where(eq(reelsTable.id, reelId));
  if (!reel || !reel.taggedProductIds.length) { res.json([]); return; }

  const products: any[] = [];
  for (const pid of reel.taggedProductIds) {
    const [p] = await db.select().from(productsTable).where(eq(productsTable.id, pid));
    if (p) products.push(p);
  }
  res.json(products);
});

// ─── Admin: GET /admin/reels ──────────────────────────────────────────────────

router.get("/admin/reels", requireAdminAuth, async (req, res): Promise<void> => {
  const reels = await db
    .select()
    .from(reelsTable)
    .orderBy(desc(reelsTable.createdAt))
    .limit(100);
  res.json(reels);
});

// ─── Admin: POST /admin/reels/:id/suspend ─────────────────────────────────────

router.post("/admin/reels/:id/suspend", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.update(reelsTable)
    .set({ isSuspended: true })
    .where(eq(reelsTable.id, id));
  res.json({ ok: true });
});

// ─── Admin: POST /admin/reels/:id/restore ─────────────────────────────────────

router.post("/admin/reels/:id/restore", requireAdminAuth, async (req, res): Promise<void> => {
  const id = String(req.params.id);
  await db.update(reelsTable)
    .set({ isSuspended: false })
    .where(eq(reelsTable.id, id));
  res.json({ ok: true });
});

// ─── Admin: GET /admin/reels/reports ─────────────────────────────────────────

router.get("/admin/reels/reports", requireAdminAuth, async (req, res): Promise<void> => {
  const reports = await db
    .select()
    .from(reelReportsTable)
    .orderBy(desc(reelReportsTable.createdAt))
    .limit(100);
  res.json(reports);
});

export default router;
