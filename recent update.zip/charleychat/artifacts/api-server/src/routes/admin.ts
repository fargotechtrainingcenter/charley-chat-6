import { Router, type IRouter } from "express";
import { eq, desc, ilike, or, sql, and } from "drizzle-orm";
import bcrypt from "bcryptjs";
import {
  db,
  usersTable,
  walletsTable,
  transactionsTable,
  sessionsTable,
  escrowTransactionsTable,
  storiesTable,
  kycVerificationsTable,
  vendorsTable,
  paymentLinksTable,
  notificationsTable,
  adminUsersTable,
  smsLogsTable,
  adminUserNotesTable,
  messagesTable,
} from "@workspace/db";
import {
  AdminLoginBody,
  CreateAdminUserBody,
  AdjustWalletBalanceBody,
  AdminResolveDisputeBody,
  AdminRejectKycBody,
  AdminRejectVendorBody,
  BroadcastNotificationBody,
} from "@workspace/api-zod";
import {
  signAdminToken,
  requireAdminAuth,
  requireSuperAdmin,
} from "../lib/auth";
import { emitToUser } from "../lib/socket";

const router: IRouter = Router();

// ── Auth ─────────────────────────────────────────────────────────────────────

router.post("/admin/auth/login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { email, password } = parsed.data;

  const [admin] = await db
    .select()
    .from(adminUsersTable)
    .where(eq(adminUsersTable.email, email.toLowerCase()));

  if (!admin) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const valid = await bcrypt.compare(password, admin.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const accessToken = signAdminToken(admin.id, admin.role);
  res.json({
    accessToken,
    admin: {
      id: admin.id,
      email: admin.email,
      role: admin.role,
      createdAt: admin.createdAt,
    },
  });
});

router.post("/admin/auth/logout", requireAdminAuth, async (_req, res): Promise<void> => {
  res.sendStatus(204);
});

// ── Stats ─────────────────────────────────────────────────────────────────────

router.get("/admin/stats", requireAdminAuth, async (_req, res): Promise<void> => {
  const [totalUsersRow] = await db.select({ count: sql<number>`count(*)::int` }).from(usersTable);
  const [totalTxRow] = await db.select({ count: sql<number>`count(*)::int` }).from(transactionsTable);
  const [activeEscrowRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(escrowTransactionsTable)
    .where(eq(escrowTransactionsTable.status, "in_escrow"));
  const [pendingKycRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(kycVerificationsTable)
    .where(eq(kycVerificationsTable.status, "pending"));
  const [pendingVendorRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(vendorsTable)
    .where(eq(vendorsTable.isVerified, false));
  const [flaggedRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable)
    .where(eq(usersTable.isFlagged, true));
  const [volumeRow] = await db
    .select({ total: sql<number>`coalesce(sum(amount_pesewas), 0)::int` })
    .from(transactionsTable);
  const [feeRow] = await db
    .select({ total: sql<number>`coalesce(sum(fee_pesewas), 0)::int` })
    .from(transactionsTable);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [newUsersTodayRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable)
    .where(sql`created_at >= ${today}`);
  const [txTodayRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactionsTable)
    .where(sql`created_at >= ${today}`);

  res.json({
    totalUsers: totalUsersRow?.count ?? 0,
    totalWalletVolumePesewas: volumeRow?.total ?? 0,
    totalTransactions: totalTxRow?.count ?? 0,
    activeEscrowCount: activeEscrowRow?.count ?? 0,
    pendingKycCount: pendingKycRow?.count ?? 0,
    pendingVendorCount: pendingVendorRow?.count ?? 0,
    flaggedUserCount: flaggedRow?.count ?? 0,
    totalRevenuePesewas: feeRow?.total ?? 0,
    newUsersToday: newUsersTodayRow?.count ?? 0,
    transactionsToday: txTodayRow?.count ?? 0,
  });
});

// ── Revenue ───────────────────────────────────────────────────────────────────

router.get("/admin/revenue", requireAdminAuth, async (req, res): Promise<void> => {
  const days = Math.min(Number(req.query.days) || 30, 90);
  const rows = await db.execute(sql`
    SELECT
      date_trunc('day', created_at AT TIME ZONE 'UTC')::date::text AS date,
      coalesce(sum(amount_pesewas), 0)::int AS "volumePesewas",
      count(*)::int AS "transactionCount",
      coalesce(sum(fee_pesewas), 0)::int AS "feePesewas"
    FROM transactions
    WHERE created_at >= now() - interval '1 day' * ${days}
    GROUP BY 1
    ORDER BY 1
  `);
  res.json(rows.rows);
});

// ── Users ─────────────────────────────────────────────────────────────────────

router.get("/admin/users", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
  const offset = (page - 1) * limit;
  const search = (req.query.search as string | undefined)?.trim() ?? "";
  const status = req.query.status as string | undefined;

  const whereClause = and(
    search ? or(ilike(usersTable.phone, `%${search}%`), ilike(usersTable.fullName, `%${search}%`)) : undefined,
    status === "suspended" ? eq(usersTable.isSuspended, true) : undefined,
    status === "flagged" ? eq(usersTable.isFlagged, true) : undefined,
  );

  const [totalRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable)
    .where(whereClause);

  const users = await db
    .select()
    .from(usersTable)
    .where(whereClause)
    .orderBy(desc(usersTable.createdAt))
    .limit(limit)
    .offset(offset);

  const enriched = await Promise.all(
    users.map(async (u) => {
      const [wallet] = await db
        .select({ balance: walletsTable.balancePesewas })
        .from(walletsTable)
        .where(eq(walletsTable.userId, u.id));
      const [txCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(transactionsTable)
        .where(eq(transactionsTable.walletId, sql`(select id from wallets where user_id = ${u.id} limit 1)`));
      return {
        id: u.id,
        phone: u.phone,
        fullName: u.fullName,
        avatarUrl: u.avatarUrl,
        isKycVerified: u.isKycVerified,
        isVendor: u.isVendor,
        isSuspended: u.isSuspended,
        isFlagged: u.isFlagged,
        walletBalancePesewas: wallet?.balance ?? 0,
        transactionCount: txCount?.count ?? 0,
        createdAt: u.createdAt,
      };
    }),
  );

  res.json({ items: enriched, total: totalRow?.count ?? 0, page, limit });
});

async function buildUserRecord(userId: string, txCount = 0) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) return null;
  const [wallet] = await db.select({ balance: walletsTable.balancePesewas }).from(walletsTable).where(eq(walletsTable.userId, user.id));
  return {
    id: user.id,
    phone: user.phone,
    fullName: user.fullName,
    email: user.email ?? null,
    ghanaCardId: user.ghanaCardId ?? null,
    avatarUrl: user.avatarUrl ?? null,
    isKycVerified: user.isKycVerified,
    isVendor: user.isVendor,
    isSuspended: user.isSuspended,
    suspendedUntil: user.suspendedUntil ?? null,
    isFlagged: user.isFlagged,
    walletBalancePesewas: wallet?.balance ?? 0,
    transactionCount: txCount,
    createdAt: user.createdAt,
  };
}

router.get("/admin/users/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const [txCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactionsTable)
    .where(eq(transactionsTable.walletId, sql`(select id from wallets where user_id = ${String(req.params.id)} limit 1)`));
  const record = await buildUserRecord(String(req.params.id), txCount?.count ?? 0);
  if (!record) { res.status(404).json({ error: "User not found" }); return; }
  res.json(record);
});

router.patch("/admin/users/:id/suspend", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const [user] = await db.update(usersTable).set({ isSuspended: true, suspendedUntil: null }).where(eq(usersTable.id, String(req.params.id))).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  await db.insert(adminUserNotesTable).values({ userId: user.id, adminId: adminId ?? null, adminEmail: null, noteType: "suspension", note: "Account permanently suspended by admin." });
  res.json(await buildUserRecord(user.id));
});

router.patch("/admin/users/:id/unsuspend", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const [user] = await db.update(usersTable).set({ isSuspended: false, suspendedUntil: null }).where(eq(usersTable.id, String(req.params.id))).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  await db.insert(adminUserNotesTable).values({ userId: user.id, adminId: adminId ?? null, adminEmail: null, noteType: "unsuspend", note: "Account suspension lifted by admin." });
  res.json(await buildUserRecord(user.id));
});

router.patch("/admin/users/:id/hold", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const { days, reason } = req.body as { days: number; reason: string };
  if (!days || days < 1 || days > 365 || !reason) {
    res.status(400).json({ error: "days (1-365) and reason are required" });
    return;
  }
  const until = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  const [user] = await db.update(usersTable).set({ isSuspended: true, suspendedUntil: until }).where(eq(usersTable.id, String(req.params.id))).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  await db.insert(adminUserNotesTable).values({ userId: user.id, adminId: adminId ?? null, adminEmail: null, noteType: "hold", note: `Account held for ${days} day(s) until ${until.toISOString().slice(0, 10)}. Reason: ${reason}` });
  res.json(await buildUserRecord(user.id));
});

router.patch("/admin/users/:id/flag", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const [user] = await db.update(usersTable).set({ isFlagged: true }).where(eq(usersTable.id, String(req.params.id))).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  await db.insert(adminUserNotesTable).values({ userId: user.id, adminId: adminId ?? null, adminEmail: null, noteType: "flag", note: "Account flagged for fraud review." });
  res.json(await buildUserRecord(user.id));
});

router.patch("/admin/users/:id/unflag", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const [user] = await db.update(usersTable).set({ isFlagged: false }).where(eq(usersTable.id, String(req.params.id))).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  await db.insert(adminUserNotesTable).values({ userId: user.id, adminId: adminId ?? null, adminEmail: null, noteType: "unflag", note: "Fraud flag removed from account." });
  res.json(await buildUserRecord(user.id));
});

router.get("/admin/users/:id/notes", requireAdminAuth, async (req, res): Promise<void> => {
  const notes = await db.select().from(adminUserNotesTable).where(eq(adminUserNotesTable.userId, String(req.params.id))).orderBy(desc(adminUserNotesTable.createdAt));
  res.json(notes);
});

router.post("/admin/users/:id/notes", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = (req as any).adminId as string | undefined;
  const { noteType, note } = req.body as { noteType: string; note: string };
  if (!noteType || !note) { res.status(400).json({ error: "noteType and note are required" }); return; }
  const validTypes = ["suspension","hold","flag","warning","violation","info","unsuspend","unflag"];
  if (!validTypes.includes(noteType)) { res.status(400).json({ error: "Invalid noteType" }); return; }
  const [created] = await db.insert(adminUserNotesTable).values({
    userId: String(req.params.id),
    adminId: adminId ?? null,
    adminEmail: null,
    noteType: noteType as "suspension" | "hold" | "flag" | "warning" | "violation" | "info" | "unsuspend" | "unflag",
    note,
  }).returning();
  res.status(201).json(created);
});

// ── Wallets ───────────────────────────────────────────────────────────────────

router.get("/admin/wallets", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
  const offset = (page - 1) * limit;
  const search = (req.query.search as string | undefined)?.trim() ?? "";

  const [totalRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(walletsTable)
    .leftJoin(usersTable, eq(walletsTable.userId, usersTable.id))
    .where(search ? or(ilike(usersTable.phone, `%${search}%`), ilike(usersTable.fullName, `%${search}%`)) : undefined);

  const rows = await db
    .select({
      id: walletsTable.id,
      userId: walletsTable.userId,
      userPhone: usersTable.phone,
      userName: usersTable.fullName,
      balancePesewas: walletsTable.balancePesewas,
      currency: walletsTable.currency,
      updatedAt: walletsTable.updatedAt,
    })
    .from(walletsTable)
    .leftJoin(usersTable, eq(walletsTable.userId, usersTable.id))
    .where(search ? or(ilike(usersTable.phone, `%${search}%`), ilike(usersTable.fullName, `%${search}%`)) : undefined)
    .orderBy(desc(walletsTable.updatedAt))
    .limit(limit)
    .offset(offset);

  res.json({ items: rows, total: totalRow?.count ?? 0, page, limit });
});

router.patch("/admin/wallets/:id/adjust", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = AdjustWalletBalanceBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [wallet] = await db
    .update(walletsTable)
    .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${parsed.data.amountPesewas}` })
    .where(eq(walletsTable.id, String(req.params.id)))
    .returning();

  if (!wallet) { res.status(404).json({ error: "Wallet not found" }); return; }

  const [user] = await db.select({ phone: usersTable.phone, fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, wallet.userId));
  res.json({ id: wallet.id, userId: wallet.userId, userPhone: user?.phone ?? "", userName: user?.fullName ?? "", balancePesewas: wallet.balancePesewas, currency: wallet.currency, updatedAt: wallet.updatedAt });
});

// ── Transactions ──────────────────────────────────────────────────────────────

router.get("/admin/transactions", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
  const offset = (page - 1) * limit;
  const type = req.query.type as string | undefined;
  const status = req.query.status as string | undefined;

  const whereClause = and(
    type ? eq(transactionsTable.type, type as "momo_in" | "momo_out" | "bank_in" | "bank_out" | "visa_in" | "escrow_hold" | "escrow_release" | "p2p_send" | "p2p_receive") : undefined,
    status ? eq(transactionsTable.status, status as "pending" | "completed" | "failed") : undefined,
  );

  const [totalRow] = await db.select({ count: sql<number>`count(*)::int` }).from(transactionsTable).where(whereClause);
  const items = await db.select().from(transactionsTable).where(whereClause).orderBy(desc(transactionsTable.createdAt)).limit(limit).offset(offset);

  res.json({ items, total: totalRow?.count ?? 0, page, limit });
});

// ── Escrow ─────────────────────────────────────────────────────────────────────

router.get("/admin/escrow", requireAdminAuth, async (req, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const items = await db.select().from(escrowTransactionsTable)
    .where(status ? eq(escrowTransactionsTable.status, status as "pending" | "in_escrow" | "pending_release" | "released" | "disputed" | "cancelled") : undefined)
    .orderBy(desc(escrowTransactionsTable.createdAt));
  res.json(items);
});

router.patch("/admin/escrow/:id/resolve", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = AdminResolveDisputeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const newStatus = parsed.data.resolution === "release" ? "released" : "cancelled";
  const [escrow] = await db
    .update(escrowTransactionsTable)
    .set({ status: newStatus })
    .where(eq(escrowTransactionsTable.id, String(req.params.id)))
    .returning();

  if (!escrow) { res.status(404).json({ error: "Escrow not found" }); return; }
  res.json(escrow);
});

// ── Stories ───────────────────────────────────────────────────────────────────

router.get("/admin/stories", requireAdminAuth, async (_req, res): Promise<void> => {
  const items = await db.select().from(storiesTable).orderBy(desc(storiesTable.createdAt));
  res.json(items);
});

router.delete("/admin/stories/:id", requireAdminAuth, async (req, res): Promise<void> => {
  await db.delete(storiesTable).where(eq(storiesTable.id, String(req.params.id)));
  res.sendStatus(204);
});

router.patch("/admin/stories/:id/restrict", requireAdminAuth, async (req, res): Promise<void> => {
  const { isAgeRestricted } = req.body;
  if (typeof isAgeRestricted !== "boolean") {
    res.status(400).json({ error: "isAgeRestricted must be a boolean" });
    return;
  }
  const [story] = await db
    .update(storiesTable)
    .set({ isAgeRestricted })
    .where(eq(storiesTable.id, String(req.params.id)))
    .returning();
  if (!story) {
    res.status(404).json({ error: "Story not found" });
    return;
  }
  res.json(story);
});

// ── KYC ───────────────────────────────────────────────────────────────────────

router.get("/admin/kyc", requireAdminAuth, async (req, res): Promise<void> => {
  const status = req.query.status as string | undefined;
  const items = await db
    .select({
      id: kycVerificationsTable.id,
      userId: kycVerificationsTable.userId,
      status: kycVerificationsTable.status,
      idType: kycVerificationsTable.idType,
      idNumber: kycVerificationsTable.idNumber,
      idFrontUrl: kycVerificationsTable.idFrontUrl,
      idBackUrl: kycVerificationsTable.idBackUrl,
      selfieUrl: kycVerificationsTable.selfieUrl,
      rejectionReason: kycVerificationsTable.rejectionReason,
      reviewedAt: kycVerificationsTable.reviewedAt,
      createdAt: kycVerificationsTable.createdAt,
      userFullName: usersTable.fullName,
      userPhone: usersTable.phone,
      userFpId: usersTable.fpId,
    })
    .from(kycVerificationsTable)
    .leftJoin(usersTable, eq(kycVerificationsTable.userId, usersTable.id))
    .where(status ? eq(kycVerificationsTable.status, status as "pending" | "approved" | "rejected") : undefined)
    .orderBy(desc(kycVerificationsTable.createdAt));
  res.json(items);
});

router.patch("/admin/kyc/:id/approve", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = req.adminId!;
  const [kyc] = await db
    .update(kycVerificationsTable)
    .set({ status: "approved", reviewedAt: new Date(), approvedBy: adminId })
    .where(eq(kycVerificationsTable.id, String(req.params.id)))
    .returning();
  if (!kyc) { res.status(404).json({ error: "KYC not found" }); return; }

  await db.update(usersTable).set({ isKycVerified: true }).where(eq(usersTable.id, kyc.userId));

  // Real-time push: notify the user immediately
  emitToUser(kyc.userId, "kyc_approved", {
    referenceNumber: kyc.referenceNumber,
    message: "Your identity verification has been approved. All wallet features are now active.",
  });

  res.json(kyc);
});

router.patch("/admin/kyc/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = AdminRejectKycBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [kyc] = await db
    .update(kycVerificationsTable)
    .set({ status: "rejected", reviewedAt: new Date(), rejectionReason: parsed.data.reason })
    .where(eq(kycVerificationsTable.id, String(req.params.id)))
    .returning();
  if (!kyc) { res.status(404).json({ error: "KYC not found" }); return; }

  await db.update(usersTable).set({ isKycVerified: false }).where(eq(usersTable.id, kyc.userId));

  // Real-time push: notify the user immediately
  emitToUser(kyc.userId, "kyc_rejected", {
    referenceNumber: kyc.referenceNumber,
    reason: parsed.data.reason,
    message: "Your KYC verification was rejected. Please review the reason and resubmit.",
  });

  res.json(kyc);
});

// ── Vendors ───────────────────────────────────────────────────────────────────

router.get("/admin/vendors", requireAdminAuth, async (req, res): Promise<void> => {
  const verified = req.query.verified as string | undefined;
  const items = await db.select().from(vendorsTable)
    .where(verified === "true" ? eq(vendorsTable.isVerified, true) : verified === "false" ? eq(vendorsTable.isVerified, false) : undefined)
    .orderBy(desc(vendorsTable.createdAt));
  res.json(items);
});

router.patch("/admin/vendors/:id/verify", requireAdminAuth, async (req, res): Promise<void> => {
  const [vendor] = await db
    .update(vendorsTable)
    .set({ isVerified: true })
    .where(eq(vendorsTable.id, String(req.params.id)))
    .returning();
  if (!vendor) { res.status(404).json({ error: "Vendor not found" }); return; }
  await db.update(usersTable).set({ isVendor: true }).where(eq(usersTable.id, vendor.userId));
  res.json(vendor);
});

router.patch("/admin/vendors/:id/reject", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = AdminRejectVendorBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [vendor] = await db
    .update(vendorsTable)
    .set({ isVerified: false })
    .where(eq(vendorsTable.id, String(req.params.id)))
    .returning();
  if (!vendor) { res.status(404).json({ error: "Vendor not found" }); return; }
  res.json(vendor);
});

// ── Payment Links ─────────────────────────────────────────────────────────────

router.get("/admin/payment-links", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 20));
  const offset = (page - 1) * limit;
  const items = await db.select().from(paymentLinksTable).orderBy(desc(paymentLinksTable.createdAt)).limit(limit).offset(offset);
  res.json(items);
});

// ── Notifications ─────────────────────────────────────────────────────────────

router.post("/admin/notifications/broadcast", requireAdminAuth, async (req, res): Promise<void> => {
  const parsed = BroadcastNotificationBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const users = await db.select({ id: usersTable.id }).from(usersTable);
  if (users.length === 0) { res.json({ sent: 0 }); return; }

  const notifs = users.map((u) => ({
    userId: u.id,
    title: parsed.data.title,
    body: parsed.data.body,
    type: "system" as const,
    isRead: false,
  }));

  await db.insert(notificationsTable).values(notifs);
  res.json({ sent: users.length });
});

// ── Sessions ──────────────────────────────────────────────────────────────────

router.get("/admin/sessions", requireAdminAuth, async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: sessionsTable.id,
      userId: sessionsTable.userId,
      userPhone: usersTable.phone,
      createdAt: sessionsTable.createdAt,
      expiresAt: sessionsTable.expiresAt,
    })
    .from(sessionsTable)
    .leftJoin(usersTable, eq(sessionsTable.userId, usersTable.id))
    .where(sql`${sessionsTable.expiresAt} > now()`)
    .orderBy(desc(sessionsTable.createdAt));
  res.json(rows);
});

router.delete("/admin/sessions/:id", requireAdminAuth, async (req, res): Promise<void> => {
  await db.delete(sessionsTable).where(eq(sessionsTable.id, String(req.params.id)));
  res.sendStatus(204);
});

// ── SMS Logs ──────────────────────────────────────────────────────────────────

router.get("/admin/sms-logs", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
  const offset = (page - 1) * limit;
  const items = await db.select().from(smsLogsTable).orderBy(desc(smsLogsTable.createdAt)).limit(limit).offset(offset);
  res.json(items);
});

// ── Admins (super admin only) ─────────────────────────────────────────────────

router.get("/admin/admins", requireAdminAuth, async (_req, res): Promise<void> => {
  const admins = await db
    .select({ id: adminUsersTable.id, email: adminUsersTable.email, role: adminUsersTable.role, createdAt: adminUsersTable.createdAt })
    .from(adminUsersTable)
    .orderBy(adminUsersTable.createdAt);
  res.json(admins);
});

router.post("/admin/admins", requireSuperAdmin, async (req, res): Promise<void> => {
  const parsed = CreateAdminUserBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [existing] = await db
    .select({ id: adminUsersTable.id })
    .from(adminUsersTable)
    .where(eq(adminUsersTable.email, parsed.data.email.toLowerCase()));

  if (existing) { res.status(409).json({ error: "Email already in use" }); return; }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  const [admin] = await db
    .insert(adminUsersTable)
    .values({
      email: parsed.data.email.toLowerCase(),
      passwordHash,
      role: parsed.data.role as "admin" | "super_admin",
    })
    .returning();

  res.status(201).json({ id: admin.id, email: admin.email, role: admin.role, createdAt: admin.createdAt });
});

router.patch("/admin/admins/:id/role", requireSuperAdmin, async (req, res): Promise<void> => {
  const { role } = req.body as { role?: string };
  if (!role || !["admin", "super_admin"].includes(role)) {
    res.status(400).json({ error: "Role must be 'admin' or 'super_admin'" }); return;
  }
  await db.update(adminUsersTable).set({ role: role as "admin" | "super_admin" }).where(eq(adminUsersTable.id, String(req.params.id)));
  res.json({ success: true });
});

router.delete("/admin/admins/:id", requireSuperAdmin, async (req, res): Promise<void> => {
  await db.delete(adminUsersTable).where(eq(adminUsersTable.id, String(req.params.id)));
  res.sendStatus(204);
});

// ── Messages (admin) ──────────────────────────────────────────────────────────

router.get("/admin/messages", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 30));
  const offset = (page - 1) * limit;
  const userId = req.query.userId as string | undefined;

  const whereClause = userId
    ? or(eq(messagesTable.senderId, userId), eq(messagesTable.receiverId, userId))
    : undefined;

  const [totalRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(messagesTable)
    .where(whereClause);

  const items = await db
    .select()
    .from(messagesTable)
    .where(whereClause)
    .orderBy(desc(messagesTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json({ items, total: totalRow?.count ?? 0, page, limit });
});

router.delete("/admin/messages/:id", requireAdminAuth, async (req, res): Promise<void> => {
  await db.delete(messagesTable).where(eq(messagesTable.id, String(req.params.id)));
  res.sendStatus(204);
});

// ── Groups (admin) ────────────────────────────────────────────────────────────

router.get("/admin/groups", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 30));
  const offset = (page - 1) * limit;

  const rows = await db.execute(sql`
    SELECT g.id, g.name, g.description, g.avatar_url AS "avatarUrl",
           g.is_paid AS "isPaid", g.membership_fee_pesewas AS "membershipFeePesewas",
           g.platform_commission_pesewas AS "platformCommissionPesewas",
           g.member_count AS "memberCount", g.is_suspended AS "isSuspended",
           g.created_at AS "createdAt",
           u.full_name AS "ownerName", u.phone AS "ownerPhone"
    FROM groups g
    JOIN users u ON u.id = g.created_by_id
    ORDER BY g.created_at DESC
    LIMIT ${limit} OFFSET ${offset}
  `);

  const countRes = await db.execute(sql`SELECT COUNT(*)::int AS cnt FROM groups`);
  res.json({ items: rows.rows, total: (countRes.rows[0] as any)?.cnt ?? 0, page, limit });
});

router.patch("/admin/groups/:id/suspend", requireAdminAuth, async (req, res): Promise<void> => {
  const { groupsTable } = await import("@workspace/db");
  await db.update(groupsTable).set({ isSuspended: true }).where(eq(groupsTable.id, String(req.params.id)));
  res.json({ message: "Group suspended" });
});

router.patch("/admin/groups/:id/restore", requireAdminAuth, async (req, res): Promise<void> => {
  const { groupsTable } = await import("@workspace/db");
  await db.update(groupsTable).set({ isSuspended: false }).where(eq(groupsTable.id, String(req.params.id)));
  res.json({ message: "Group restored" });
});

router.delete("/admin/groups/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const { groupsTable } = await import("@workspace/db");
  await db.delete(groupsTable).where(eq(groupsTable.id, String(req.params.id)));
  res.sendStatus(204);
});

// ── Platform Settings ─────────────────────────────────────────────────────────

router.get("/admin/settings", requireAdminAuth, async (_req, res): Promise<void> => {
  const result = await db.execute(sql`SELECT * FROM platform_settings WHERE id = 1`);
  const row = (result.rows ?? result)[0] as any;
  if (!row) { res.status(404).json({ error: "Settings not found" }); return; }
  res.json({
    escrowFeePercent: parseFloat(row.escrow_fee_percent),
    paidGroupCommissionPercent: parseFloat(row.paid_group_commission_percent),
    invoiceGenerationFeePesewas: parseInt(row.invoice_generation_fee_pesewas),
    p2pTransferLimitPesewas: parseInt(row.p2p_transfer_limit_pesewas),
    maintenanceMode: row.maintenance_mode,
    registrationEnabled: row.registration_enabled,
    kycRequired: row.kyc_required,
    updatedAt: row.updated_at,
  });
});

router.patch("/admin/settings", requireAdminAuth, async (req, res): Promise<void> => {
  const {
    escrowFeePercent, paidGroupCommissionPercent, invoiceGenerationFeePesewas,
    p2pTransferLimitPesewas, maintenanceMode, registrationEnabled, kycRequired,
  } = req.body as Record<string, unknown>;
  await db.execute(sql`
    UPDATE platform_settings SET
      escrow_fee_percent = COALESCE(${escrowFeePercent ?? null}::numeric, escrow_fee_percent),
      paid_group_commission_percent = COALESCE(${paidGroupCommissionPercent ?? null}::numeric, paid_group_commission_percent),
      invoice_generation_fee_pesewas = COALESCE(${invoiceGenerationFeePesewas ?? null}::int, invoice_generation_fee_pesewas),
      p2p_transfer_limit_pesewas = COALESCE(${p2pTransferLimitPesewas ?? null}::int, p2p_transfer_limit_pesewas),
      maintenance_mode = COALESCE(${maintenanceMode ?? null}::boolean, maintenance_mode),
      registration_enabled = COALESCE(${registrationEnabled ?? null}::boolean, registration_enabled),
      kyc_required = COALESCE(${kycRequired ?? null}::boolean, kyc_required),
      updated_at = NOW()
    WHERE id = 1
  `);
  const result = await db.execute(sql`SELECT * FROM platform_settings WHERE id = 1`);
  const row = (result.rows ?? result)[0] as any;
  res.json({
    escrowFeePercent: parseFloat(row.escrow_fee_percent),
    paidGroupCommissionPercent: parseFloat(row.paid_group_commission_percent),
    invoiceGenerationFeePesewas: parseInt(row.invoice_generation_fee_pesewas),
    p2pTransferLimitPesewas: parseInt(row.p2p_transfer_limit_pesewas),
    maintenanceMode: row.maintenance_mode,
    registrationEnabled: row.registration_enabled,
    kycRequired: row.kyc_required,
    updatedAt: row.updated_at,
  });
});

// ── Invoices (admin) ──────────────────────────────────────────────────────────

router.get("/admin/invoices", requireAdminAuth, async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 30));
  const offset = (page - 1) * limit;

  const rows = await db.execute(sql`
    SELECT i.id, i.invoice_number AS "invoiceNumber", i.client_name AS "clientName",
           i.total_pesewas AS "totalPesewas", i.status, i.is_pdf_generated AS "isPdfGenerated",
           i.generation_fee_paid_at AS "generationFeePaidAt", i.created_at AS "createdAt",
           u.full_name AS "userName", u.phone AS "userPhone"
    FROM invoices i
    JOIN users u ON u.id = i.user_id
    ORDER BY i.created_at DESC
    LIMIT ${limit} OFFSET ${offset}
  `);

  const countRes = await db.execute(sql`SELECT COUNT(*)::int AS cnt FROM invoices`);
  const revenueRes = await db.execute(sql`
    SELECT (
      (SELECT COUNT(*)::int FROM invoices WHERE generation_fee_paid_at IS NOT NULL) *
      COALESCE((SELECT invoice_generation_fee_pesewas FROM platform_settings LIMIT 1), 500)
    ) AS generation_revenue_pesewas
  `);
  const generationRevenuePesewas = (revenueRes.rows[0] as any)?.generation_revenue_pesewas ?? 0;
  res.json({ items: rows.rows, total: (countRes.rows[0] as any)?.cnt ?? 0, page, limit, generationRevenuePesewas });
});

router.delete("/admin/invoices/:id", requireAdminAuth, async (req, res): Promise<void> => {
  const { invoicesTable } = await import("@workspace/db");
  await db.delete(invoicesTable).where(eq(invoicesTable.id, String(req.params.id)));
  res.sendStatus(204);
});

export default router;
