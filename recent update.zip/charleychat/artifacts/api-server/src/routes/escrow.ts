import { Router, type IRouter } from "express";
import { eq, or } from "drizzle-orm";
import crypto from "crypto";
import { db, usersTable, escrowTransactionsTable, walletsTable, transactionsTable, notificationsTable, disputesTable } from "@workspace/db";
import {
  CreateEscrowBody,
  GetEscrowParams,
  GetEscrowResponse,
  ListEscrowResponse,
  ReleaseEscrowParams,
  ReleaseEscrowBody,
  ReleaseEscrowResponse,
  DisputeEscrowParams,
  DisputeEscrowResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { normalizePhone } from "../lib/phone";
import { emitToUser } from "../lib/socket";
import { sendPushToUser } from "./push";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

function generateReleaseCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

router.get("/escrow", requireAuth, async (req, res): Promise<void> => {
  const escrows = await db
    .select()
    .from(escrowTransactionsTable)
    .where(
      or(
        eq(escrowTransactionsTable.buyerId, req.userId!),
        eq(escrowTransactionsTable.sellerId, req.userId!),
      ),
    );
  res.json(ListEscrowResponse.parse(escrows));
});

router.post("/escrow", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const parsed = CreateEscrowBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { sellerPhone: rawSellerPhone, title, description, amountPesewas, dueDate } = parsed.data;
  const sellerPhone = normalizePhone(rawSellerPhone);

  const [seller] = await db.select().from(usersTable).where(eq(usersTable.phone, sellerPhone));
  if (!seller) {
    res.status(400).json({ error: "Seller not found" });
    return;
  }
  if (seller.id === req.userId) {
    res.status(400).json({ error: "Cannot create escrow with yourself" });
    return;
  }
  if (!seller.isKycVerified) {
    res.status(400).json({ error: "The seller must complete KYC verification before they can receive escrow payments." });
    return;
  }

  const [buyerWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!buyerWallet || buyerWallet.balancePesewas < amountPesewas) {
    res.status(400).json({ error: "Insufficient funds" });
    return;
  }

  const releaseCode = generateReleaseCode();
  const reference = crypto.randomUUID();

  const [escrow] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${amountPesewas}` })
      .where(eq(walletsTable.id, buyerWallet.id));
    await trx.insert(transactionsTable).values({
      walletId: buyerWallet.id,
      type: "escrow_hold",
      amountPesewas,
      feePesewas: 0,
      reference,
      status: "completed",
      counterpartyPhone: sellerPhone,
      note: title,
    });
    const [e] = await trx
      .insert(escrowTransactionsTable)
      .values({
        buyerId: req.userId!,
        sellerId: seller.id,
        walletId: buyerWallet.id,
        title,
        description: description ?? "",
        amountPesewas,
        feePesewas: 0,
        status: "in_escrow",
        releaseCode,
        dueDate: dueDate ?? null,
      })
      .returning();
    await trx.insert(notificationsTable).values({
      userId: seller.id,
      title: "New escrow started",
      body: `An escrow of GH₵${(amountPesewas / 100).toFixed(2)} for "${title}" is waiting for delivery.`,
      type: "escrow",
      referenceId: e.id,
    });
    return [e];
  });

  res.status(201).json(escrow);
});

router.get("/escrow/:id", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetEscrowParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [escrow] = await db
    .select()
    .from(escrowTransactionsTable)
    .where(eq(escrowTransactionsTable.id, params.data.id));

  if (!escrow || (escrow.buyerId !== req.userId && escrow.sellerId !== req.userId)) {
    res.status(404).json({ error: "Escrow not found" });
    return;
  }
  res.json(GetEscrowResponse.parse(escrow));
});

router.patch("/escrow/:id/release", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = ReleaseEscrowParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = ReleaseEscrowBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [escrow] = await db
    .select()
    .from(escrowTransactionsTable)
    .where(eq(escrowTransactionsTable.id, params.data.id));

  if (!escrow || escrow.buyerId !== req.userId) {
    res.status(404).json({ error: "Escrow not found" });
    return;
  }
  if (escrow.status !== "in_escrow" && escrow.status !== "pending_release") {
    res.status(400).json({ error: "Escrow cannot be released in its current state" });
    return;
  }
  if (escrow.releaseCode !== body.data.releaseCode) {
    res.status(400).json({ error: "Invalid release code" });
    return;
  }

  const [sellerWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, escrow.sellerId));
  if (!sellerWallet) {
    res.status(400).json({ error: "Seller wallet not found" });
    return;
  }

  const [updated] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} + ${escrow.amountPesewas}` })
      .where(eq(walletsTable.id, sellerWallet.id));
    await trx.insert(transactionsTable).values({
      walletId: sellerWallet.id,
      type: "escrow_release",
      amountPesewas: escrow.amountPesewas,
      feePesewas: 0,
      reference: crypto.randomUUID(),
      status: "completed",
      note: escrow.title,
    });
    const [e] = await trx
      .update(escrowTransactionsTable)
      .set({ status: "released" })
      .where(eq(escrowTransactionsTable.id, escrow.id))
      .returning();
    await trx.insert(notificationsTable).values({
      userId: escrow.sellerId,
      title: "Escrow funds released",
      body: `GH₵${(escrow.amountPesewas / 100).toFixed(2)} for "${escrow.title}" has been released to your wallet.`,
      type: "escrow",
      referenceId: escrow.id,
    });
    return [e];
  });

  res.json(ReleaseEscrowResponse.parse(updated));
});

router.patch("/escrow/:id/dispute", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DisputeEscrowParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [escrow] = await db
    .select()
    .from(escrowTransactionsTable)
    .where(eq(escrowTransactionsTable.id, params.data.id));

  if (!escrow || (escrow.buyerId !== req.userId && escrow.sellerId !== req.userId)) {
    res.status(404).json({ error: "Escrow not found" });
    return;
  }
  if (escrow.status === "released" || escrow.status === "cancelled") {
    res.status(400).json({ error: "Cannot dispute a closed escrow" });
    return;
  }

  const [updated] = await db.transaction(async (trx) => {
    const [e] = await trx
      .update(escrowTransactionsTable)
      .set({ status: "disputed" })
      .where(eq(escrowTransactionsTable.id, escrow.id))
      .returning();

    // Create the dispute record if one doesn't already exist for this escrow
    const [existing] = await trx.select().from(disputesTable).where(eq(disputesTable.escrowId, escrow.id));
    if (!existing) {
      await trx.insert(disputesTable).values({
        escrowId: escrow.id,
        buyerId: escrow.buyerId,
        sellerId: escrow.sellerId,
        raisedByUserId: req.userId!,
      });
    }

    return [e];
  });

  const notifBody = `A dispute was raised for "${escrow.title}". The funds are frozen until support resolves it.`;
  for (const uid of [escrow.buyerId, escrow.sellerId]) {
    await db.insert(notificationsTable).values({
      userId: uid,
      title: "Escrow dispute raised",
      body: notifBody,
      type: "dispute",
      referenceId: escrow.id,
    });
    emitToUser(uid, "escrow_disputed", { escrowId: escrow.id });
    void sendPushToUser(uid, { title: "Escrow dispute raised", body: notifBody, url: `/escrow/${escrow.id}` });
  }

  res.json(DisputeEscrowResponse.parse(updated));
});

export default router;
