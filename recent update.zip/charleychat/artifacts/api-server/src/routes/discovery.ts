import { Router, type IRouter } from "express";
import { eq, and, ne, sql, inArray, notInArray } from "drizzle-orm";
import { z } from "zod/v4";
import { db, usersTable, contactsTable } from "@workspace/db";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

// ── Haversine distance (metres) in SQL ────────────────────────────────────────
// Uses a CTE so PostgreSQL can filter on the computed distance column
function haversineCTE(lat: number, lng: number, myId: string) {
  return sql`
    WITH distances AS (
      SELECT
        u.id,
        u.full_name        AS "fullName",
        u.username,
        u.phone,
        u.avatar_url       AS "avatarUrl",
        u.is_kyc_verified  AS "isKycVerified",
        u.interests,
        u.bio,
        u.nearby_radius    AS "nearbyRadius",
        CASE WHEN u.last_seen_at > NOW() - INTERVAL '5 minutes'
             THEN true ELSE false END AS "isOnline",
        ROUND(
          6371000 * 2 * asin(sqrt(
            power(sin(radians((${lat} - u.latitude) / 2)), 2) +
            cos(radians(u.latitude)) * cos(radians(${lat})) *
            power(sin(radians((${lng} - u.longitude) / 2)), 2)
          ))
        ) AS "distanceMetres"
      FROM users u
      WHERE u.nearby_enabled = true
        AND u.id != ${myId}
        AND u.latitude IS NOT NULL
        AND u.longitude IS NOT NULL
        AND u.is_suspended = false
    )
  `;
}

// ── PUT /api/discovery/location ──────────────────────────────────────────────

const UpdateLocationBody = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  nearbyEnabled: z.boolean().optional(),
});

router.put("/discovery/location", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateLocationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body" });
    return;
  }
  const { latitude, longitude, nearbyEnabled } = parsed.data;
  await db
    .update(usersTable)
    .set({
      latitude,
      longitude,
      nearbyEnabled: nearbyEnabled ?? true,
      lastSeenAt: new Date(),
    })
    .where(eq(usersTable.id, req.userId!));

  res.json({ success: true });
});

// ── GET /api/discovery/nearby ─────────────────────────────────────────────────

router.get("/discovery/nearby", requireAuth, async (req, res): Promise<void> => {
  const radius = Math.min(Number(req.query["radius"] ?? 5000), 50000);
  const filter = req.query["filter"] as string | undefined;
  const page = Math.max(1, Number(req.query["page"] ?? 1));
  const limit = 20;
  const offset = (page - 1) * limit;

  const [me] = await db
    .select({ latitude: usersTable.latitude, longitude: usersTable.longitude })
    .from(usersTable)
    .where(eq(usersTable.id, req.userId!));

  if (!me?.latitude || !me?.longitude) {
    res.status(400).json({ error: "Location not set — call PUT /api/discovery/location first" });
    return;
  }

  const lat = me.latitude;
  const lng = me.longitude;

  const filterClause =
    filter === "online"   ? sql`AND "isOnline" = true`   :
    filter === "verified" ? sql`AND "isKycVerified" = true` :
    sql``;

  const result = await db.execute(sql`
    ${haversineCTE(lat, lng, req.userId!)}
    SELECT * FROM distances
    WHERE "distanceMetres" <= ${radius}
    ${filterClause}
    ORDER BY "distanceMetres" ASC
    LIMIT ${limit} OFFSET ${offset}
  `);

  const countResult = await db.execute(sql`
    ${haversineCTE(lat, lng, req.userId!)}
    SELECT COUNT(*) AS total FROM distances
    WHERE "distanceMetres" <= ${radius}
    ${filterClause}
  `);

  res.json({
    users: result.rows,
    total: Number((countResult.rows[0] as any)?.total ?? 0),
    page,
  });
});

// ── PUT /api/discovery/nearby-toggle ─────────────────────────────────────────

router.put("/discovery/nearby-toggle", requireAuth, async (req, res): Promise<void> => {
  const enabled = req.body?.enabled;
  if (typeof enabled !== "boolean") {
    res.status(400).json({ error: "enabled (boolean) required" });
    return;
  }
  await db
    .update(usersTable)
    .set({ nearbyEnabled: enabled, lastSeenAt: new Date() })
    .where(eq(usersTable.id, req.userId!));
  res.json({ success: true, nearbyEnabled: enabled });
});

// ── GET /api/discovery/suggest ────────────────────────────────────────────────
// People You May Know: contacts-of-contacts + interests overlap, excluding existing contacts

router.get("/discovery/suggest", requireAuth, async (req, res): Promise<void> => {
  const limit = 20;

  // My contact IDs
  const myContacts = await db
    .select({ contactUserId: contactsTable.contactUserId })
    .from(contactsTable)
    .where(eq(contactsTable.ownerId, req.userId!));

  const myContactIds = myContacts.map(c => c.contactUserId);
  const excludeIds = [req.userId!, ...myContactIds];

  if (myContactIds.length > 0) {
    // Find 2nd-degree connections (contacts of my contacts)
    const suggestions = await db.execute(sql`
      SELECT
        u.id,
        u.full_name        AS "fullName",
        u.username,
        u.phone,
        u.avatar_url       AS "avatarUrl",
        u.is_kyc_verified  AS "isKycVerified",
        u.interests,
        u.bio,
        COUNT(DISTINCT c.owner_id) AS "mutualCount"
      FROM users u
      JOIN contacts c ON c.contact_user_id = u.id
      WHERE c.owner_id = ANY(${myContactIds}::uuid[])
        AND u.id != ALL(${excludeIds}::uuid[])
        AND u.is_suspended = false
      GROUP BY u.id, u.full_name, u.username, u.phone, u.avatar_url, u.is_kyc_verified, u.interests, u.bio
      ORDER BY "mutualCount" DESC
      LIMIT ${limit}
    `);

    if ((suggestions.rows ?? []).length > 0) {
      res.json({ users: suggestions.rows });
      return;
    }
  }

  // Fallback: general discover (non-contacts)
  const fallback = await db
    .select({
      id: usersTable.id,
      fullName: usersTable.fullName,
      username: usersTable.username,
      phone: usersTable.phone,
      avatarUrl: usersTable.avatarUrl,
      isKycVerified: usersTable.isKycVerified,
      interests: usersTable.interests,
      bio: usersTable.bio,
    })
    .from(usersTable)
    .where(
      and(
        ...(excludeIds.length > 1
          ? [notInArray(usersTable.id, excludeIds)]
          : [ne(usersTable.id, req.userId!)]),
        eq(usersTable.isSuspended, false),
      ),
    )
    .limit(limit);

  res.json({ users: fallback });
});

// ── PATCH /api/discovery/interests ───────────────────────────────────────────

const UpdateInterestsBody = z.object({
  interests: z.array(z.string().max(50)).max(20),
  bio: z.string().max(200).optional(),
});

router.patch("/discovery/interests", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateInterestsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body" });
    return;
  }
  const updates: Record<string, unknown> = { interests: parsed.data.interests };
  if (parsed.data.bio !== undefined) updates["bio"] = parsed.data.bio;
  await db.update(usersTable).set(updates).where(eq(usersTable.id, req.userId!));
  res.json({ success: true });
});

export default router;
