import { Router, type IRouter } from "express";
import crypto from "crypto";
import { eq, and, gt, isNull, or } from "drizzle-orm";
import { db, otpCodesTable, smsLogsTable, usersTable } from "@workspace/db";
import { z } from "zod";
import { Resend } from "resend";
import rateLimit from "express-rate-limit";
import { normalizePhone } from "../lib/phone";

const router: IRouter = Router();

const otpRequestLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many OTP requests. Please wait 10 minutes." },
});

const otpVerifyLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many OTP verification attempts. Please wait 10 minutes." },
  skipSuccessfulRequests: true,
});

const OTP_TTL_MS = 5 * 60 * 1000;

/**
 * Returns true when OTP simulation mode is active.
 * Simulation is active if:
 *   - OTP_DEV_MODE=true is set explicitly, OR
 *   - No Arkesel API key is configured (no real SMS provider available)
 */
function isDevMode(): boolean {
  if (process.env.OTP_DEV_MODE === "true") return true;
  if (!process.env.ARKESEL_API_KEY) return true;
  return false;
}

/** Map OTP purpose string to the value stored in sms_logs.purpose */
function toLogPurpose(
  purpose: "register" | "login_reset",
): "registration" | "login" | "password_reset" {
  if (purpose === "register") return "registration";
  return "password_reset";
}

const OtpRequestBody = z
  .object({
    phone: z.string().min(9).optional(),
    email: z.string().email().optional(),
    source: z.enum(["fargopay", "africart"]).default("fargopay"),
    purpose: z.enum(["register", "login_reset"]).default("register"),
  })
  .refine((d) => d.phone || d.email, {
    message: "Either phone or email is required",
  });

const OtpVerifyBody = z
  .object({
    phone: z.string().min(9).optional(),
    email: z.string().email().optional(),
    code: z.string().length(6),
    purpose: z.enum(["register", "login_reset"]).default("register"),
  })
  .refine((d) => d.phone || d.email, {
    message: "Either phone or email is required",
  });

function generateOtp(): string {
  return String(Math.floor(100000 + crypto.randomInt(900000))).slice(0, 6);
}

/**
 * Send OTP via SMS.
 * - Dev mode (OTP_DEV_MODE=true or no ARKESEL_API_KEY):
 *     provider = "development", status = "simulated", code logged to console.
 * - Live mode (ARKESEL_API_KEY set):
 *     sends via Arkesel, provider = "arkesel".
 */
async function sendOtpSms(
  phone: string,
  code: string,
  source: "fargopay" | "africart" = "fargopay",
  purpose: "registration" | "login" | "password_reset" = "registration",
): Promise<{ sent: boolean; provider: string; simulated: boolean }> {
  const appName = source === "africart" ? "KASUWAA" : "FargoPay";
  const senderName = source === "africart" ? "KASUWAA" : "FargoPay";
  const message = `Your ${appName} verification code is: ${code}. Valid for 5 minutes. Do not share this code.`;
  const devMode = isDevMode();

  if (devMode) {
    await db.insert(smsLogsTable).values({
      phone,
      message,
      status: "simulated",
      provider: "development",
      purpose,
      source,
    });

    // Log prominently to server console so developers can see it without the dashboard
    console.log(
      "\n" +
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
      "  📱 OTP DEV MODE — SMS Simulated\n" +
      `  Phone:   ${phone}\n` +
      `  Purpose: ${purpose}\n` +
      `  Code:    ${code}\n` +
      `  Source:  ${appName}\n` +
      "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n",
    );

    return { sent: false, provider: "development", simulated: true };
  }

  // ── Live mode: Arkesel ────────────────────────────────────────────────────
  const intlPhone = "233" + phone.replace(/^0/, "");
  const apiKey = process.env.ARKESEL_API_KEY!;

  const [logRow] = await db
    .insert(smsLogsTable)
    .values({ phone, message, status: "pending", provider: "arkesel", purpose, source })
    .returning({ id: smsLogsTable.id });

  const logId = logRow.id;

  try {
    const url = new URL("https://sms.arkesel.com/sms/api");
    url.searchParams.set("action", "send-sms");
    url.searchParams.set("api_key", apiKey);
    url.searchParams.set("to", intlPhone);
    url.searchParams.set("from", senderName);
    url.searchParams.set("sms", message);

    const resp = await fetch(url.toString());
    const data = (await resp.json()) as { code?: string; message?: string };

    if (data.code === "ok") {
      await db.update(smsLogsTable).set({ status: "sent" }).where(eq(smsLogsTable.id, logId));
      return { sent: true, provider: "arkesel", simulated: false };
    } else {
      await db.update(smsLogsTable).set({ status: "failed" }).where(eq(smsLogsTable.id, logId));
      return { sent: false, provider: "arkesel", simulated: false };
    }
  } catch {
    await db.update(smsLogsTable).set({ status: "failed" }).where(eq(smsLogsTable.id, logId));
    return { sent: false, provider: "arkesel", simulated: false };
  }
}

/** Send OTP via Resend email. Falls back to dev-mode log if key not set. */
async function sendOtpEmail(
  email: string,
  code: string,
  source: "fargopay" | "africart" = "fargopay",
): Promise<{ sent: boolean; provider: string }> {
  const appName = source === "africart" ? "KASUWAA" : "FargoPay";
  const apiKey = process.env.RESEND_API_KEY;

  if (!apiKey) {
    return { sent: false, provider: "development" };
  }

  const resend = new Resend(apiKey);
  const fromDomain = source === "africart" ? "kasuwaa.com" : "fargopay.com";
  const fromAddress = `${appName} <noreply@${fromDomain}>`;

  try {
    const { error } = await resend.emails.send({
      from: fromAddress,
      to: [email],
      subject: `Your ${appName} verification code`,
      html: `
        <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px">
          <h2 style="color:#1a1a1a;margin-bottom:8px">${appName} Verification Code</h2>
          <p style="color:#555;margin-bottom:24px">Use the code below to verify your identity. It expires in 5 minutes.</p>
          <div style="background:#f4f4f5;border-radius:8px;padding:24px;text-align:center;letter-spacing:8px;font-size:32px;font-weight:700;color:#1a1a1a">
            ${code}
          </div>
          <p style="color:#888;font-size:13px;margin-top:24px">If you did not request this code, you can safely ignore this email.</p>
        </div>
      `,
      text: `Your ${appName} verification code is: ${code}. Valid for 5 minutes. Do not share this code.`,
    });
    if (error) return { sent: false, provider: "resend" };
    return { sent: true, provider: "resend" };
  } catch {
    return { sent: false, provider: "resend" };
  }
}

router.post("/auth/otp/request", otpRequestLimiter, async (req, res): Promise<void> => {
  const parsed = OtpRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.errors[0]?.message ?? "phone or email required" });
    return;
  }

  const { source, purpose } = parsed.data;
  const rawPhone = parsed.data.phone;
  const rawEmail = parsed.data.email?.toLowerCase().trim();

  const phone = rawPhone ? normalizePhone(rawPhone) : undefined;
  const email = rawEmail;

  // For PIN reset: verify the identifier exists before issuing OTP
  if (purpose === "login_reset") {
    if (phone) {
      const [existing] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.phone, phone));
      if (!existing) {
        res.status(404).json({
          error: "We could not find an account with this phone number. Please check the number or contact support.",
        });
        return;
      }
    } else if (email) {
      const [existing] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.email, email));
      if (!existing) {
        res.status(404).json({
          error: "We could not find an account with this email address. Please check the address or contact support.",
        });
        return;
      }
    }
  }

  // Invalidate any previous unused OTPs for this identifier + purpose
  if (phone) {
    await db
      .update(otpCodesTable)
      .set({ usedAt: new Date() })
      .where(and(eq(otpCodesTable.phone, phone), eq(otpCodesTable.purpose, purpose), isNull(otpCodesTable.usedAt)));
  } else if (email) {
    await db
      .update(otpCodesTable)
      .set({ usedAt: new Date() })
      .where(and(eq(otpCodesTable.email, email), eq(otpCodesTable.purpose, purpose), isNull(otpCodesTable.usedAt)));
  }

  const code = generateOtp();
  const expiresAt = new Date(Date.now() + OTP_TTL_MS);

  await db.insert(otpCodesTable).values({ phone: phone ?? null, email: email ?? null, code, purpose, expiresAt });

  const logPurpose = toLogPurpose(purpose);

  if (phone) {
    try {
      await sendOtpSms(phone, code, source, logPurpose);
    } catch {
      // Don't fail the request if SMS sending throws — code is stored in DB
    }
  } else if (email) {
    try {
      await sendOtpEmail(email, code, source);
    } catch {
      // Don't fail the request if email sending throws
    }
  }

  const channel = phone ? "sms" : "email";
  const devMode = isDevMode();

  req.log.info({ phone, email, purpose, source, channel, devMode }, "OTP generated");

  // Return devCode when:
  //   - OTP_DEV_MODE=true (explicit simulation), OR
  //   - NODE_ENV !== "production" (local development)
  const returnDevCode = devMode || process.env.NODE_ENV !== "production";

  res.json({
    message: "OTP sent",
    channel,
    expiresIn: 300,
    mode: devMode ? "development" : "live",
    ...(returnDevCode ? { devCode: code } : {}),
  });
});

router.post("/auth/otp/verify", otpVerifyLimiter, async (req, res): Promise<void> => {
  const parsed = OtpVerifyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "phone or email, code, and purpose are required" });
    return;
  }

  const phone = parsed.data.phone ? normalizePhone(parsed.data.phone) : undefined;
  const email = parsed.data.email?.toLowerCase().trim();

  const result = await validateOtp(phone ?? null, parsed.data.code, parsed.data.purpose, email);

  if (!result.valid) {
    res.status(400).json({ error: result.error ?? "Invalid or expired OTP" });
    return;
  }
  res.json({ message: "OTP verified" });
});

// Internal-only: validate OTP and mark it as used
export async function validateOtp(
  phone: string | null,
  code: string,
  purpose: "register" | "login_reset" = "register",
  email?: string,
): Promise<{ valid: boolean; error?: string }> {
  const normalizedEmail = email?.toLowerCase().trim();

  const identifierCondition =
    phone && normalizedEmail
      ? or(eq(otpCodesTable.phone, phone), eq(otpCodesTable.email, normalizedEmail))
      : phone
        ? eq(otpCodesTable.phone, phone)
        : normalizedEmail
          ? eq(otpCodesTable.email, normalizedEmail)
          : null;

  if (!identifierCondition) {
    return { valid: false, error: "phone or email required" };
  }

  const [record] = await db
    .select()
    .from(otpCodesTable)
    .where(
      and(
        identifierCondition,
        eq(otpCodesTable.code, code),
        eq(otpCodesTable.purpose, purpose),
        isNull(otpCodesTable.usedAt),
        gt(otpCodesTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  if (!record) return { valid: false, error: "Invalid or expired OTP. Please request a new one." };

  await db.update(otpCodesTable).set({ usedAt: new Date() }).where(eq(otpCodesTable.id, record.id));

  return { valid: true };
}

export default router;
