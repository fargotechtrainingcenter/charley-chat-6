import { Router, type IRouter } from "express";
import { and, asc, desc, eq, ilike, ne, or, sql } from "drizzle-orm";
import { z } from "zod";
import { db, usersTable, kycVerificationsTable } from "@workspace/db";
import { UpdateMeBody, GetMeResponse, UpdateMeResponse, GetUserByPhoneResponse, GetUserByPhoneParams } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { normalizePhone } from "../lib/phone";

const router: IRouter = Router();

router.get("/users/me", requireAuth, async (req, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const [kyc] = await db
    .select({ status: kycVerificationsTable.status, rejectionReason: kycVerificationsTable.rejectionReason })
    .from(kycVerificationsTable)
    .where(eq(kycVerificationsTable.userId, req.userId!))
    .orderBy(desc(kycVerificationsTable.createdAt))
    .limit(1);

  res.json(GetMeResponse.parse({
    ...user,
    kycStatus: kyc?.status ?? null,
    kycRejectionReason: kyc?.rejectionReason ?? null,
  }));
});

router.patch("/users/me", requireAuth, async (req, res): Promise<void> => {
  const body = UpdateMeBody.extend({ email: z.string().email().nullish() }).safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const parsed = body;
  const [user] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, req.userId!)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(UpdateMeResponse.parse(user));
});

const UserSettingsBody = z.object({
  notifPayments:  z.boolean().optional(),
  notifEscrow:    z.boolean().optional(),
  notifMarketing: z.boolean().optional(),
  biometricEnabled: z.boolean().optional(),
});

router.patch("/users/me/settings", requireAuth, async (req, res): Promise<void> => {
  const parsed = UserSettingsBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [user] = await db
    .update(usersTable)
    .set(parsed.data)
    .where(eq(usersTable.id, req.userId!))
    .returning({
      notifPayments:    usersTable.notifPayments,
      notifEscrow:      usersTable.notifEscrow,
      notifMarketing:   usersTable.notifMarketing,
      biometricEnabled: usersTable.biometricEnabled,
    });
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(user);
});

const UpdateUsernameBody = z.object({
  username: z.string().min(3).max(30).regex(/^[a-z0-9_]+$/, "Username may only contain lowercase letters, numbers, and underscores"),
});

router.patch("/users/me/username", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateUsernameBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.errors[0]?.message ?? "Invalid username" }); return; }
  const { username } = parsed.data;
  // Check availability
  const [existing] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.username, username));
  if (existing && existing.id !== req.userId) {
    res.status(409).json({ error: "Username already taken" });
    return;
  }
  const [user] = await db.update(usersTable).set({ username }).where(eq(usersTable.id, req.userId!)).returning({ id: usersTable.id, username: usersTable.username });
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(user);
});

const AvatarBody = z.object({ avatarUrl: z.string().min(1) });

router.post("/users/me/avatar", requireAuth, async (req, res): Promise<void> => {
  const parsed = AvatarBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [user] = await db
    .update(usersTable)
    .set({ avatarUrl: parsed.data.avatarUrl })
    .where(eq(usersTable.id, req.userId!))
    .returning({ id: usersTable.id, avatarUrl: usersTable.avatarUrl });
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(user);
});

const SearchQuery = z.object({ q: z.string().min(2) });

router.get("/users/search", requireAuth, async (req, res): Promise<void> => {
  const parsed = SearchQuery.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: "q must be at least 2 characters" }); return; }
  const q = parsed.data.q.trim();
  const qPhone = normalizePhone(q);
  const users = await db
    .select({
      id: usersTable.id,
      fullName: usersTable.fullName,
      username: usersTable.username,
      phone: usersTable.phone,
      avatarUrl: usersTable.avatarUrl,
      isKycVerified: usersTable.isKycVerified,
    })
    .from(usersTable)
    .where(
      or(
        eq(usersTable.phone, qPhone),
        ilike(usersTable.fullName, `%${q}%`),
        ilike(usersTable.username, `%${q}%`),
      ),
    )
    .limit(15);
  res.json(users.filter((u) => u.id !== req.userId));
});

// ─── Discover: browse all CharLey users ─────────────────────────────────────

const DiscoverQuery = z.object({
  q:     z.string().optional(),
  page:  z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

router.get("/users/discover", requireAuth, async (req, res): Promise<void> => {
  const parsed = DiscoverQuery.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { q, page, limit } = parsed.data;
  const offset = (page - 1) * limit;

  const searchTerm = q?.trim();
  const whereClause = searchTerm && searchTerm.length >= 1
    ? and(
        ne(usersTable.id, req.userId!),
        or(
          ilike(usersTable.fullName, `%${searchTerm}%`),
          ilike(usersTable.username, `%${searchTerm}%`),
        ),
      )
    : ne(usersTable.id, req.userId!);

  const [countRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable)
    .where(whereClause);

  const users = await db
    .select({
      id: usersTable.id,
      fullName: usersTable.fullName,
      username: usersTable.username,
      phone: usersTable.phone,
      avatarUrl: usersTable.avatarUrl,
      isKycVerified: usersTable.isKycVerified,
      fpId: usersTable.fpId,
    })
    .from(usersTable)
    .where(whereClause)
    .orderBy(asc(usersTable.fullName))
    .limit(limit)
    .offset(offset);

  res.json({ users, total: countRow?.count ?? 0, page, limit });
});

router.get("/users/:phone", requireAuth, async (req, res): Promise<void> => {
  const params = GetUserByPhoneParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const phone = normalizePhone(params.data.phone);
  const [user] = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(GetUserByPhoneResponse.parse(user));
});

export default router;
