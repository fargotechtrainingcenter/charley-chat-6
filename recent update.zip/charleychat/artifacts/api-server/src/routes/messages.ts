import { Router, type IRouter } from "express";
import { eq, or, and, asc, sql } from "drizzle-orm";
import { db, messagesTable, usersTable, messageReactionsTable } from "@workspace/db";
import { GetMessagesParams, GetMessagesResponse, SendMessageBody } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";
import { emitToUser } from "../lib/socket";
import { sendPushToUser } from "./push";
import { z } from "zod/v4";

const router: IRouter = Router();

router.get("/conversations", requireAuth, async (req, res): Promise<void> => {
  const myId = req.userId!;

  const rows = await db.execute(sql`
    SELECT
      u.id            AS "userId",
      u.full_name     AS "fullName",
      u.phone,
      u.avatar_url    AS "avatarUrl",
      u.is_kyc_verified AS "isKycVerified",
      u.is_vendor     AS "isVendor",
      lm.content      AS "lastMessage",
      lm.message_type AS "lastMessageType",
      lm.created_at   AS "lastMessageAt",
      lm.sender_id    AS "lastSenderId",
      COALESCE(unread.cnt, 0)::int AS "unreadCount"
    FROM (
      SELECT DISTINCT ON (other_id)
        CASE WHEN sender_id = ${myId}::uuid THEN receiver_id ELSE sender_id END AS other_id,
        id, content, message_type, created_at, sender_id
      FROM messages
      WHERE (sender_id = ${myId}::uuid OR receiver_id = ${myId}::uuid)
        AND deleted_for_everyone = false
      ORDER BY other_id, created_at DESC
    ) lm
    JOIN users u ON u.id = lm.other_id
    LEFT JOIN (
      SELECT sender_id, COUNT(*) AS cnt
      FROM messages
      WHERE receiver_id = ${myId}::uuid AND is_read = false
      GROUP BY sender_id
    ) unread ON unread.sender_id = lm.other_id
    ORDER BY lm.created_at DESC
  `);

  res.json(rows.rows ?? rows);
});

router.get("/messages/:userId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
  const params = GetMessagesParams.safeParse({ userId: raw });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const otherId = params.data.userId;

  const messages = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(eq(messagesTable.senderId, req.userId!), eq(messagesTable.receiverId, otherId)),
        and(eq(messagesTable.senderId, otherId), eq(messagesTable.receiverId, req.userId!)),
      ),
    )
    .orderBy(asc(messagesTable.createdAt));

  await db
    .update(messagesTable)
    .set({ isRead: true })
    .where(and(eq(messagesTable.receiverId, req.userId!), eq(messagesTable.senderId, otherId)));

  // Mark as delivered for sender
  emitToUser(otherId, "messages_read", { byUserId: req.userId! });

  res.json(GetMessagesResponse.parse(messages));
});

router.post("/messages", requireAuth, async (req, res): Promise<void> => {
  const body = { ...req.body, content: req.body.content ?? undefined };
  const parsed = SendMessageBody.safeParse(body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { toUserId, content, messageType, mediaUrl } = parsed.data;

  const [msg] = await db
    .insert(messagesTable)
    .values({
      senderId: req.userId!,
      receiverId: toUserId,
      content: content ?? null,
      messageType: (messageType as typeof messagesTable.$inferInsert["messageType"]) ?? "text",
      mediaUrl: mediaUrl ?? null,
      isRead: false,
      isDelivered: true,
    })
    .returning();

  emitToUser(toUserId, "new_message", msg);

  // Fire-and-forget push notification so the recipient is notified even if
  // the app is backgrounded/closed (socket emit above only reaches an open app).
  void (async () => {
    try {
      const [sender] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, req.userId!));
      const bodyByType: Record<string, string> = {
        text: content ?? "New message",
        voice_note: "🎤 Voice note",
        image: "📷 Photo",
        video: "🎬 Video",
      };
      await sendPushToUser(toUserId, {
        title: sender?.fullName ?? "New message",
        body: bodyByType[msg.messageType] ?? "New message",
        url: `/chat/${req.userId}`,
        tag: `message-${msg.id}`,
      });
    } catch (err) {
      req.log?.warn?.({ err }, "Failed to send push notification for new message");
    }
  })();

  res.status(201).json(msg);
});

// Edit a message (sender only, text messages only)
router.patch("/messages/:id", requireAuth, async (req, res): Promise<void> => {
  const msgId = String(req.params["id"]);
  const myId = req.userId!;

  const [msg] = await db.select().from(messagesTable).where(eq(messagesTable.id, msgId));
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.senderId !== myId) { res.status(403).json({ error: "Not your message" }); return; }
  if (msg.deletedForEveryone || msg.deletedAt) { res.status(400).json({ error: "Cannot edit deleted message" }); return; }

  const schema = z.object({ content: z.string().min(1) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [updated] = await db.update(messagesTable)
    .set({ content: parsed.data.content, isEdited: true, editedAt: new Date() })
    .where(eq(messagesTable.id, msgId))
    .returning();

  emitToUser(msg.receiverId, "message_edited", updated);
  res.json(updated);
});

// Delete message for myself only (soft delete — only hides from my view)
router.delete("/messages/:id", requireAuth, async (req, res): Promise<void> => {
  const msgId = String(req.params["id"]);
  const myId = req.userId!;

  const [msg] = await db.select().from(messagesTable).where(eq(messagesTable.id, msgId));
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.senderId !== myId && msg.receiverId !== myId) {
    res.status(403).json({ error: "Not authorized" }); return;
  }

  const deleteForEveryone = req.query["forEveryone"] === "true";

  if (deleteForEveryone && msg.senderId !== myId) {
    res.status(403).json({ error: "Only sender can delete for everyone" }); return;
  }

  if (deleteForEveryone) {
    const [updated] = await db.update(messagesTable)
      .set({ deletedForEveryone: true, deletedAt: new Date(), content: null })
      .where(eq(messagesTable.id, msgId))
      .returning();
    emitToUser(msg.receiverId, "message_deleted", { id: msgId, forEveryone: true });
    res.json(updated);
  } else {
    const [updated] = await db.update(messagesTable)
      .set({ deletedAt: new Date() })
      .where(eq(messagesTable.id, msgId))
      .returning();
    res.json(updated);
  }
});

// Add/toggle reaction to a message
router.post("/messages/:id/reactions", requireAuth, async (req, res): Promise<void> => {
  const msgId = String(req.params["id"]);
  const myId = req.userId!;

  const schema = z.object({ emoji: z.string().min(1).max(10) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [msg] = await db.select().from(messagesTable).where(eq(messagesTable.id, msgId));
  if (!msg) { res.status(404).json({ error: "Message not found" }); return; }

  // Check if reaction already exists
  const [existing] = await db.select().from(messageReactionsTable)
    .where(and(
      eq(messageReactionsTable.messageId, msgId),
      eq(messageReactionsTable.userId, myId),
      eq(messageReactionsTable.emoji, parsed.data.emoji),
    ));

  if (existing) {
    // Toggle off
    await db.delete(messageReactionsTable).where(eq(messageReactionsTable.id, existing.id));
    const otherId = msg.senderId === myId ? msg.receiverId : msg.senderId;
    emitToUser(otherId, "reaction_removed", { messageId: msgId, emoji: parsed.data.emoji, userId: myId });
    res.json({ removed: true });
  } else {
    const [reaction] = await db.insert(messageReactionsTable).values({
      messageId: msgId,
      userId: myId,
      emoji: parsed.data.emoji,
    }).returning();
    const otherId = msg.senderId === myId ? msg.receiverId : msg.senderId;
    emitToUser(otherId, "reaction_added", { messageId: msgId, emoji: parsed.data.emoji, userId: myId });
    res.status(201).json(reaction);
  }
});

// Get reactions for a message
router.get("/messages/:id/reactions", requireAuth, async (req, res): Promise<void> => {
  const msgId = String(req.params["id"]);
  const reactions = await db.select().from(messageReactionsTable)
    .where(eq(messageReactionsTable.messageId, msgId));
  res.json(reactions);
});

export default router;
