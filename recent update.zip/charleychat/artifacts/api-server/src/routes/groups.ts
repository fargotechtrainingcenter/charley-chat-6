import { Router, type IRouter } from "express";
import { eq, and, desc, sql, count } from "drizzle-orm";
import {
  db,
  groupsTable,
  groupMembersTable,
  groupMessagesTable,
  groupMessageReactionsTable,
  walletsTable,
  transactionsTable,
  notificationsTable,
} from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { emitToGroup } from "../lib/socket";
import { z } from "zod/v4";

const router: IRouter = Router();

const PLATFORM_COMMISSION_RATE = 0.10; // 10%

// List all groups the user is a member of
router.get("/groups", requireAuth, async (req, res): Promise<void> => {
  const myId = req.userId!;
  const rows = await db.execute(sql`
    SELECT
      g.id, g.name, g.description, g.avatar_url AS "avatarUrl",
      g.is_paid AS "isPaid", g.membership_fee_pesewas AS "membershipFeePesewas",
      g.member_count AS "memberCount", g.created_by_id AS "createdById",
      g.created_at AS "createdAt",
      gm.role, gm.status AS "memberStatus",
      lm.content AS "lastMessage", lm.created_at AS "lastMessageAt"
    FROM group_members gm
    JOIN groups g ON g.id = gm.group_id
    LEFT JOIN LATERAL (
      SELECT content, created_at FROM group_messages
      WHERE group_id = g.id AND deleted_at IS NULL
      ORDER BY created_at DESC LIMIT 1
    ) lm ON true
    WHERE gm.user_id = ${myId}::uuid AND gm.status = 'active'
    ORDER BY COALESCE(lm.created_at, g.created_at) DESC
  `);
  res.json(rows.rows ?? rows);
});

// Discover / search public groups
router.get("/groups/discover", requireAuth, async (req, res): Promise<void> => {
  const q = req.query["q"] as string | undefined;
  const rows = await db.execute(sql`
    SELECT g.id, g.name, g.description, g.avatar_url AS "avatarUrl",
           g.is_paid AS "isPaid", g.membership_fee_pesewas AS "membershipFeePesewas",
           g.member_count AS "memberCount", g.created_at AS "createdAt"
    FROM groups g
    WHERE g.is_suspended = false
      ${q ? sql`AND g.name ILIKE ${"%" + q + "%"}` : sql``}
    ORDER BY g.member_count DESC
    LIMIT 30
  `);
  res.json(rows.rows ?? rows);
});

// Get single group detail
router.get("/groups/:id", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, groupId));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }

  const [membership] = await db
    .select()
    .from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));

  res.json({ ...group, membership: membership ?? null });
});

// Create a group
router.post("/groups", requireAuth, async (req, res): Promise<void> => {
  const schema = z.object({
    name: z.string().min(1).max(100),
    description: z.string().optional(),
    avatarUrl: z.string().optional(),
    isPaid: z.boolean().optional().default(false),
    membershipFeePesewas: z.number().int().positive().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { name, description, avatarUrl, isPaid, membershipFeePesewas } = parsed.data;
  if (isPaid && !membershipFeePesewas) {
    res.status(400).json({ error: "Paid groups require a membershipFeePesewas" }); return;
  }

  const commissionPesewas = isPaid && membershipFeePesewas
    ? Math.round(membershipFeePesewas * PLATFORM_COMMISSION_RATE)
    : null;

  const [group] = await db.insert(groupsTable).values({
    name, description: description ?? null, avatarUrl: avatarUrl ?? null,
    createdById: req.userId!,
    isPaid: isPaid ?? false,
    membershipFeePesewas: membershipFeePesewas ?? null,
    platformCommissionPesewas: commissionPesewas,
    memberCount: 1,
  }).returning();

  // Auto-add creator as admin
  await db.insert(groupMembersTable).values({
    groupId: group!.id, userId: req.userId!, role: "admin", status: "active",
  });

  res.status(201).json(group);
});

// Update group info (admin only)
router.patch("/groups/:id", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  const [membership] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (!membership || membership.role !== "admin") {
    res.status(403).json({ error: "Admin only" }); return;
  }

  const schema = z.object({
    name: z.string().min(1).max(100).optional(),
    description: z.string().optional(),
    avatarUrl: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [updated] = await db.update(groupsTable).set(parsed.data).where(eq(groupsTable.id, groupId)).returning();
  res.json(updated);
});

// Join a free group
router.post("/groups/:id/join", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, groupId));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }
  if (group.isSuspended) { res.status(403).json({ error: "Group is suspended" }); return; }
  if (group.isPaid) { res.status(400).json({ error: "Use /groups/:id/pay-join for paid groups" }); return; }

  const [existing] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (existing?.status === "active") { res.json({ message: "Already a member" }); return; }

  await db.insert(groupMembersTable).values({
    groupId, userId: myId, role: "member", status: "active",
  }).onConflictDoUpdate({
    target: [groupMembersTable.groupId, groupMembersTable.userId],
    set: { status: "active" },
  });

  await db.update(groupsTable).set({ memberCount: sql`member_count + 1` }).where(eq(groupsTable.id, groupId));
  res.status(201).json({ message: "Joined successfully" });
});

// Pay to join a paid group
router.post("/groups/:id/pay-join", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, groupId));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }
  if (!group.isPaid || !group.membershipFeePesewas) {
    res.status(400).json({ error: "This is not a paid group" }); return;
  }
  if (group.isSuspended) { res.status(403).json({ error: "Group is suspended" }); return; }

  const [existing] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (existing?.status === "active") { res.json({ message: "Already a member" }); return; }

  // Debit user wallet
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, myId));
  if (!wallet) { res.status(400).json({ error: "No wallet found" }); return; }
  if (wallet.balancePesewas < group.membershipFeePesewas) {
    res.status(400).json({ error: "Insufficient balance" }); return;
  }

  const fee = group.membershipFeePesewas;
  const commission = group.platformCommissionPesewas ?? Math.round(fee * PLATFORM_COMMISSION_RATE);
  const ownerReceives = fee - commission;

  // Debit user
  await db.update(walletsTable)
    .set({ balancePesewas: sql`balance_pesewas - ${fee}` })
    .where(eq(walletsTable.userId, myId));

  await db.insert(transactionsTable).values({
    walletId: wallet.id,
    type: "p2p_send",
    amountPesewas: fee,
    note: `Paid group membership: ${group.name}`,
    reference: `grp-join-${groupId}-${Date.now()}`,
    status: "completed",
  });

  // Credit group owner
  const [ownerWallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, group.createdById));
  if (ownerWallet) {
    await db.update(walletsTable)
      .set({ balancePesewas: sql`balance_pesewas + ${ownerReceives}` })
      .where(eq(walletsTable.userId, group.createdById));
    await db.insert(transactionsTable).values({
      walletId: ownerWallet.id,
      type: "p2p_receive",
      amountPesewas: ownerReceives,
      note: `Group membership fee: ${group.name} (after 10% commission)`,
      reference: `grp-earn-${groupId}-${Date.now()}`,
      status: "completed",
    });
  }

  // Add member
  await db.insert(groupMembersTable).values({
    groupId, userId: myId, role: "member", status: "active",
  }).onConflictDoUpdate({
    target: [groupMembersTable.groupId, groupMembersTable.userId],
    set: { status: "active" },
  });

  await db.update(groupsTable).set({ memberCount: sql`member_count + 1` }).where(eq(groupsTable.id, groupId));

  // Notify group owner
  await db.insert(notificationsTable).values({
    userId: group.createdById,
    title: "New Group Member",
    body: `Someone just paid to join ${group.name}`,
    type: "info",
  });

  res.status(201).json({ message: "Joined paid group successfully", commissionPesewas: commission, ownerReceivesPesewas: ownerReceives });
});

// Leave a group
router.post("/groups/:id/leave", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  await db.update(groupMembersTable)
    .set({ status: "banned" })
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));

  await db.update(groupsTable)
    .set({ memberCount: sql`GREATEST(member_count - 1, 0)` })
    .where(eq(groupsTable.id, groupId));

  res.json({ message: "Left group" });
});

// List members
router.get("/groups/:id/members", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const rows = await db.execute(sql`
    SELECT gm.id, gm.role, gm.status, gm.joined_at AS "joinedAt",
           u.id AS "userId", u.full_name AS "fullName", u.avatar_url AS "avatarUrl", u.phone
    FROM group_members gm
    JOIN users u ON u.id = gm.user_id
    WHERE gm.group_id = ${groupId}::uuid AND gm.status = 'active'
    ORDER BY gm.role DESC, gm.joined_at ASC
  `);
  res.json(rows.rows ?? rows);
});

// Get group messages
router.get("/groups/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  // Must be a member
  const [membership] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (!membership || membership.status !== "active") {
    res.status(403).json({ error: "Not a member" }); return;
  }

  const rows = await db.execute(sql`
    SELECT gm.id, gm.group_id AS "groupId", gm.content, gm.message_type AS "messageType",
           gm.media_url AS "mediaUrl", gm.reply_to_id AS "replyToId",
           gm.is_edited AS "isEdited", gm.edited_at AS "editedAt",
           gm.deleted_at AS "deletedAt", gm.created_at AS "createdAt",
           u.id AS "senderId", u.full_name AS "senderName", u.avatar_url AS "senderAvatar"
    FROM group_messages gm
    JOIN users u ON u.id = gm.sender_id
    WHERE gm.group_id = ${groupId}::uuid
    ORDER BY gm.created_at ASC
    LIMIT 100
  `);
  res.json(rows.rows ?? rows);
});

// Send group message
router.post("/groups/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["id"]);
  const myId = req.userId!;

  const [membership] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (!membership || membership.status !== "active") {
    res.status(403).json({ error: "Not a member" }); return;
  }

  const schema = z.object({
    content: z.string().optional(),
    messageType: z.string().optional().default("text"),
    mediaUrl: z.string().optional(),
    replyToId: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [msg] = await db.insert(groupMessagesTable).values({
    groupId,
    senderId: myId,
    content: parsed.data.content ?? null,
    messageType: parsed.data.messageType ?? "text",
    mediaUrl: parsed.data.mediaUrl ?? null,
    replyToId: parsed.data.replyToId ?? null,
  }).returning();

  emitToGroup(groupId, "new_group_message", { ...msg, senderId: myId });
  res.status(201).json(msg);
});

// Edit group message
router.patch("/groups/:groupId/messages/:msgId", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["groupId"]);
  const msgId = String(req.params["msgId"]);
  const myId = req.userId!;

  const [msg] = await db.select().from(groupMessagesTable).where(eq(groupMessagesTable.id, msgId));
  if (!msg || msg.groupId !== groupId) { res.status(404).json({ error: "Message not found" }); return; }
  if (msg.senderId !== myId) { res.status(403).json({ error: "Not your message" }); return; }

  const schema = z.object({ content: z.string().min(1) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [updated] = await db.update(groupMessagesTable)
    .set({ content: parsed.data.content, isEdited: true, editedAt: new Date() })
    .where(eq(groupMessagesTable.id, msgId))
    .returning();

  emitToGroup(groupId, "group_message_edited", updated);
  res.json(updated);
});

// Delete group message
router.delete("/groups/:groupId/messages/:msgId", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["groupId"]);
  const msgId = String(req.params["msgId"]);
  const myId = req.userId!;

  const [msg] = await db.select().from(groupMessagesTable).where(eq(groupMessagesTable.id, msgId));
  if (!msg || msg.groupId !== groupId) { res.status(404).json({ error: "Message not found" }); return; }

  // Allow sender or group admin to delete
  const [membership] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (msg.senderId !== myId && membership?.role !== "admin") {
    res.status(403).json({ error: "Not authorized" }); return;
  }

  await db.update(groupMessagesTable)
    .set({ deletedAt: new Date() })
    .where(eq(groupMessagesTable.id, msgId));

  emitToGroup(groupId, "group_message_deleted", { id: msgId, groupId });
  res.json({ message: "Deleted" });
});

// React to a group message (toggle: add or remove)
router.post("/groups/:groupId/messages/:msgId/reactions", requireAuth, async (req, res): Promise<void> => {
  const groupId = String(req.params["groupId"]);
  const msgId = String(req.params["msgId"]);
  const myId = req.userId!;

  const schema = z.object({ emoji: z.string().min(1).max(8) });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "emoji required" }); return; }

  // Must be a member
  const [membership] = await db.select().from(groupMembersTable)
    .where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, myId)));
  if (!membership || membership.status !== "active") {
    res.status(403).json({ error: "Not a member" }); return;
  }

  // Toggle: if same emoji exists for user, remove it; otherwise upsert
  const [existing] = await db.select().from(groupMessageReactionsTable)
    .where(and(
      eq(groupMessageReactionsTable.messageId, msgId),
      eq(groupMessageReactionsTable.userId, myId),
      eq(groupMessageReactionsTable.emoji, parsed.data.emoji),
    ));

  if (existing) {
    await db.delete(groupMessageReactionsTable).where(eq(groupMessageReactionsTable.id, existing.id));
    emitToGroup(groupId, "group_reaction_removed", { messageId: msgId, userId: myId, emoji: parsed.data.emoji });
    res.json({ action: "removed" });
  } else {
    await db.insert(groupMessageReactionsTable).values({
      messageId: msgId, userId: myId, emoji: parsed.data.emoji,
    });
    emitToGroup(groupId, "group_reaction_added", { messageId: msgId, userId: myId, emoji: parsed.data.emoji });
    res.json({ action: "added" });
  }
});

// Get reactions for a group message
router.get("/groups/:groupId/messages/:msgId/reactions", requireAuth, async (req, res): Promise<void> => {
  const msgId = String(req.params["msgId"]);
  const myId = req.userId!;

  const rows = await db.execute(sql`
    SELECT emoji, COUNT(*)::int AS count,
           BOOL_OR(user_id = ${myId}::uuid) AS "myReaction"
    FROM group_message_reactions
    WHERE message_id = ${msgId}::uuid
    GROUP BY emoji
    ORDER BY count DESC
  `);
  res.json(rows.rows ?? rows);
});

export default router;
