import { Router } from "express";
import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { logger } from "../lib/logger";
import bcrypt from "bcryptjs";

const router = Router();

const SEED_TOKEN = "KASUWAA_SEED_PROD_2026";

router.post("/internal/seed-kasuwaa", async (req, res): Promise<void> => {
  const auth = req.headers.authorization ?? "";
  if (auth !== `Bearer ${SEED_TOKEN}`) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  const result = await runSeed();
  res.json(result);
});

export async function runSeedIfEmpty(): Promise<void> {
  try {
    // Seed admin account if none exist
    const adminCount = await db.execute(sql`SELECT COUNT(*) AS cnt FROM admin_users`);
    const adminRows = (adminCount.rows ?? adminCount) as any[];
    const admins = parseInt(adminRows[0]?.cnt ?? "0");
    if (admins === 0) {
      logger.info("No admin accounts found — seeding default super admin");
      const hash = await bcrypt.hash("0544366109Jay@", 12);
      await db.execute(sql`
        INSERT INTO admin_users (id, email, password_hash, role, created_at)
        VALUES (gen_random_uuid(), 'africartgh@gmail.com', ${hash}, 'super_admin', NOW())
        ON CONFLICT (email) DO NOTHING
      `);
      logger.info("Default super admin seeded: africartgh@gmail.com");
    }

    // Seed product catalog if empty
    const count = await db.execute(sql`SELECT COUNT(*) AS cnt FROM africart_products WHERE is_deleted = false`);
    const rows = (count.rows ?? count) as any[];
    const cnt = parseInt(rows[0]?.cnt ?? "0");
    if (cnt > 0) {
      logger.info("Seed skipped — africart_products already has data");
      return;
    }
    logger.info("africart_products is empty — running production seed");
    const result = await runSeed();
    logger.info({ result }, "Seed complete");
  } catch (err) {
    logger.error({ err }, "Seed check failed");
  }
}

async function runSeed(): Promise<{ success: boolean; results: string[]; error?: string }> {
  const results: string[] = [];
  try {
    await db.execute(sql`
      INSERT INTO users (id, phone, full_name, pin_hash, is_vendor, is_kyc_verified, is_suspended, is_flagged)
      VALUES
        ('0190a594-1995-4499-9f72-2b539c7cae7a', '0277001122', 'Ama Boateng',
         '$2b$12$vqhmye7iqb3Jho4L4OEnreRR7OCaIIpnMyBQTjVZMfuOavTh9BdiO', false, true, false, false),
        ('66ba122b-fb49-42fe-b76e-6caaf601bb3e', '0244770733', 'ABDUL MALIK NOBLE',
         '$2b$12$YGIJNNh4Z7K2mQxY/VDGo.cV7EWTCOKjjSJqMtVvNflDqsNNwetN6', true, true, false, false),
        ('ad8c566f-642d-4b86-aefc-64c291ae0480', '0244000001', 'Kwame Mensah',
         '$2b$12$Fp7d1eGyGxxkrFxpS/h4oOrDlVVrPV91ly9dzmOn915bZp6oheisO', false, true, false, false)
      ON CONFLICT (id) DO NOTHING
    `);
    results.push("users: ok");

    await db.execute(sql`
      INSERT INTO vendors
        (id, user_id, business_name, business_type, description, logo_url, cover_image_url, location, is_verified, is_suspended, onboarding_fee_paid, status)
      VALUES
        ('3bdb5f9b-60ed-4899-ad83-efc7a8bad244', '0190a594-1995-4499-9f72-2b539c7cae7a',
         'Beauty by Ama', 'Beauty & Wellness',
         'Authentic Ghanaian beauty products made with natural ingredients.',
         'https://picsum.photos/seed/vendor4/100/100', 'https://picsum.photos/seed/vendor4cover/800/300',
         'Tema, Greater Accra', true, false, false, 'approved'),
        ('b5246fe1-9ab8-4fad-abad-e370c9d6935d', '66ba122b-fb49-42fe-b76e-6caaf601bb3e',
         'FARGO TECH TRAINING INSTITUTE', 'Other', null, null, null, null, true, false, false, 'approved'),
        ('e97edb54-0d94-41ac-b60e-b2965fa833c1', 'ad8c566f-642d-4b86-aefc-64c291ae0480',
         'Kantanka Tech Hub', 'Electronics',
         'Ghana-made electronics and innovative tech solutions for the modern African home.',
         'https://picsum.photos/seed/vendor1/100/100', 'https://picsum.photos/seed/vendor1cover/800/300',
         'Accra, Greater Accra', true, false, false, 'approved')
      ON CONFLICT (id) DO NOTHING
    `);
    results.push("vendors: ok");

    await db.execute(sql`
      INSERT INTO africart_products
        (id, vendor_id, name, description, category, seller_price_pesewas, price_pesewas,
         images, in_stock, is_wholesale, moq, status, is_approved, brand, tags, condition)
      VALUES
        ('0b9af8cc-b729-4e00-8ce4-3094b6e5bebb', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Kantanka Smart TV 43"',
         'Ghana-made 43-inch Smart TV with Android OS, built-in Wi-Fi, and crystal-clear 4K display.',
         'Electronics', 168182, 185000,
         ARRAY['https://picsum.photos/seed/tv1/600/400','https://picsum.photos/seed/tv2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('33148111-731a-44dd-be97-407a7b3a990e', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Kantanka Electric Bicycle',
         'Ghana own electric bicycle with 80km range per charge, lightweight aluminum frame.',
         'EV & Bikes', 381818, 420000,
         ARRAY['https://picsum.photos/seed/evbike1/600/400','https://picsum.photos/seed/evbike2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('a6e1010f-ba59-48ee-bd3e-0154d222cdb4', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Samsung Galaxy A54 (Official)',
         'Samsung Galaxy A54 5G with 128GB storage, 50MP camera, and 5000mAh battery. Official warranty.',
         'Electronics', 263636, 290000,
         ARRAY['https://picsum.photos/seed/phone1/600/400','https://picsum.photos/seed/phone2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('b6a8d8f8-263d-4913-acd1-7148699e1f6f', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Kantanka Solar Lantern',
         'Durable solar-powered LED lantern with 8-hour runtime. Made in Ghana, designed for Ghana.',
         'Electronics', 20000, 22000,
         ARRAY['https://picsum.photos/seed/lantern1/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('8d732dc0-a93f-4f8d-9ab6-76cabb3fa5a7', '3bdb5f9b-60ed-4899-ad83-efc7a8bad244',
         'African Black Soap (Premium)',
         'Traditional Ghanaian black soap made from plantain skin ash, cocoa pod, and shea butter.',
         'Beauty', 4091, 4500,
         ARRAY['https://picsum.photos/seed/soap1/600/400','https://picsum.photos/seed/soap2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('96e8738b-1e8b-468f-b737-62858b952df1', '3bdb5f9b-60ed-4899-ad83-efc7a8bad244',
         'Natural Hair Growth Oil',
         'Blend of castor oil, coconut oil, and shea butter infused with Ghanaian herbs.',
         'Beauty', 7727, 8500,
         ARRAY['https://picsum.photos/seed/haircare1/600/400','https://picsum.photos/seed/haircare2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('b1bde827-f758-4f55-a411-b6091d1de0b6', '3bdb5f9b-60ed-4899-ad83-efc7a8bad244',
         'Ghanaian Shea Butter (Bulk 25kg)',
         'Unrefined raw shea butter sourced from Northern Ghana. Cold-pressed, 100% natural.',
         'Wholesale', 77273, 85000,
         ARRAY['https://picsum.photos/seed/shea1/600/400'],
         true, true, 5, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('a8eac828-1677-47f0-9cc2-005135264910', '3bdb5f9b-60ed-4899-ad83-efc7a8bad244',
         'Kente Fabric Roll (6 yards)',
         'Premium hand-woven Ashanti Kente cloth in vibrant royal gold and green. 100% authentic.',
         'Fashion', 38182, 42000,
         ARRAY['https://picsum.photos/seed/kente1/600/400','https://picsum.photos/seed/kente2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('7463f5e0-bf77-4e5b-a0fa-aa79ce008edb', '3bdb5f9b-60ed-4899-ad83-efc7a8bad244',
         'Ankara Print Dress (Women)',
         'Vibrant Ankara wax print wrap dress in assorted patterns. Available in sizes XS-3XL.',
         'Fashion', 10909, 12000,
         ARRAY['https://picsum.photos/seed/dress1/600/400','https://picsum.photos/seed/dress2/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('7db95777-5ed6-4dbf-bf07-e05245d1fa14', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Plantain Chips (Case of 24)',
         'Crispy lightly salted plantain chips from fresh Ghanaian plantains. No artificial preservatives.',
         'Food & Agri', 16364, 18000,
         ARRAY['https://picsum.photos/seed/chips1/600/400'],
         true, true, 10, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('5d7aaf8e-db18-47c8-a7c8-a0080bd71c03', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Tilapia (Fresh, 1kg)',
         'Fresh whole tilapia from Volta Lake farms. Same-day harvest and delivery in Greater Accra.',
         'Food & Agri', 3455, 3800,
         ARRAY['https://picsum.photos/seed/fish1/600/400'],
         true, false, null, 'approved', true, null, ARRAY[]::text[], 'new'),

        ('cffc1252-5948-44d1-8bf6-317a36fa3b75', 'e97edb54-0d94-41ac-b60e-b2965fa833c1',
         'Rice (Bagged, 50kg)',
         'Premium locally grown rice from Northern Ghana. Long-grain, aromatic, great for jollof.',
         'Wholesale', 34545, 38000,
         ARRAY['https://picsum.photos/seed/rice1/600/400'],
         true, true, 3, 'approved', true, null, ARRAY[]::text[], 'new')
      ON CONFLICT (id) DO NOTHING
    `);
    results.push("products: ok");

    return { success: true, results };
  } catch (err: any) {
    return { success: false, error: String(err?.message ?? err), results };
  }
}

export default router;
