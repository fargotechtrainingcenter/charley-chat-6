/**
 * Paystack Payment Gateway Integration
 *
 * Endpoints:
 *  POST /api/paystack/initialize  — create a transaction, return authorization_url
 *  GET  /api/paystack/verify/:ref — verify a transaction by reference
 *  POST /api/paystack/webhook     — receive & process Paystack webhook events
 *
 * Keys are read from environment variables only — never hardcoded:
 *  PAYSTACK_SECRET_KEY      — sk_test_... or sk_live_... (server only)
 *  PAYSTACK_WEBHOOK_SECRET  — used to verify webhook HMAC-SHA512 signature
 *  PAYSTACK_PUBLIC_KEY      — pk_test_... or pk_live_... (exposed to frontend via /config)
 */

import { Router, type IRouter, type Request, type Response } from "express";
import { sendPushToUser, sendPushToAllAdmins } from "./push";
import crypto from "crypto";
import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { requireAuth, optionalAuth } from "../lib/auth";
import { logger } from "../lib/logger";
import { paystackRequest } from "../lib/paystack-client";

const router: IRouter = Router();

// ── Config ────────────────────────────────────────────────────────────────────

const PAYSTACK_WEBHOOK_SECRET = process.env["PAYSTACK_WEBHOOK_SECRET"] ?? "";
const PAYSTACK_PUBLIC_KEY     = process.env["PAYSTACK_PUBLIC_KEY"] ?? "";
const CALLBACK_URL            = "https://kasuwaa.com/payment/callback";

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Generate a unique payment reference: KSW-<orderId prefix>-<timestamp>-<random> */
function generateReference(orderId: string): string {
  const short   = orderId.replace(/-/g, "").slice(0, 8).toUpperCase();
  const ts      = Date.now().toString(36).toUpperCase();
  const rand    = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `KSW-${short}-${ts}-${rand}`;
}

/** Verify Paystack webhook HMAC-SHA512 signature */
function verifyWebhookSignature(rawBody: Buffer, signature: string): boolean {
  if (!PAYSTACK_WEBHOOK_SECRET) return false;
  const hash = crypto
    .createHmac("sha512", PAYSTACK_WEBHOOK_SECRET)
    .update(rawBody)
    .digest("hex");
  return hash === signature;
}

// ── Expose public key safely to the frontend ──────────────────────────────────

/**
 * GET /api/paystack/config
 * Returns only the PUBLIC key — safe to expose to the browser.
 */
router.get("/paystack/config", (_req: Request, res: Response): void => {
  res.json({ publicKey: PAYSTACK_PUBLIC_KEY });
});

// ── Initialize transaction ─────────────────────────────────────────────────────

interface InitializeBody {
  orderId: string;
  email?: string;
}

interface PaystackInitData {
  authorization_url: string;
  access_code: string;
  reference: string;
}

/**
 * POST /api/paystack/initialize
 * Authenticated — buyer must be logged in.
 *
 * Body: { orderId }
 * Response: { authorizationUrl, reference, accessCode }
 *
 * Flow:
 *  1. Load the order (verify it belongs to the caller)
 *  2. Generate a unique reference and store it on the order
 *  3. Initialize the Paystack transaction
 *  4. Persist a pending payment record for audit
 *  5. Return the authorization_url for the frontend to redirect to
 */
router.post("/paystack/initialize", optionalAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string | undefined;
  const { orderId, email: bodyEmail } = req.body as InitializeBody;

  if (!orderId) {
    res.status(400).json({ error: "orderId is required" });
    return;
  }

  // 1. Fetch the order — for authenticated buyers, verify ownership;
  //    for guests (buyer_id IS NULL), look up by orderId only.
  const orderResult = await db.execute(sql`
    SELECT o.id, o.total_pesewas, o.payment_status, o.payment_reference,
           o.guest_email, o.guest_name,
           o.delivery_phone, o.delivery_full_name,
           u.email, u.phone, u.full_name
    FROM africart_orders o
    LEFT JOIN users u ON u.id = o.buyer_id
    WHERE o.id = ${orderId}::uuid
      AND (
        o.buyer_id IS NULL
        OR ${userId ?? null}::uuid IS NULL
        OR o.buyer_id = ${userId ?? null}::uuid
      )
    LIMIT 1
  `);
  const rows = (orderResult.rows ?? orderResult) as any[];
  if (!rows.length) {
    res.status(404).json({ error: "Order not found" });
    return;
  }

  const order = rows[0];

  // Prevent re-initializing an already paid order
  if (order.payment_status === "paid") {
    res.status(409).json({ error: "Order is already paid" });
    return;
  }

  // 2. Generate or reuse a pending reference (idempotent retry support)
  const reference = order.payment_reference ?? generateReference(orderId);

  // Store the reference on the order if it doesn't have one yet
  if (!order.payment_reference) {
    await db.execute(sql`
      UPDATE africart_orders
      SET payment_reference = ${reference}, updated_at = NOW()
      WHERE id = ${orderId}::uuid
    `);
  }

  // Use email priority: body > registered user email > guest_email > phone fallback
  const phone = order.phone ?? order.delivery_phone ?? "";
  const email =
    bodyEmail ||
    order.email ||
    order.guest_email ||
    `${phone.replace(/\D/g, "")}@kasuwaa.com`;

  // 3. Initialize Paystack transaction
  const initData = await paystackRequest<PaystackInitData>("POST", "/transaction/initialize", {
    email,
    amount: order.total_pesewas,           // Paystack accepts amount in the smallest currency unit (pesewas = kobo equivalent)
    currency: "GHS",
    reference,
    callback_url: CALLBACK_URL,
    metadata: {
      orderId,
      buyerName: order.full_name ?? "",
      buyerPhone: order.phone ?? "",
      platform: "kasuwaa",
    },
    channels: ["card", "mobile_money", "bank"],
  });

  // 4. Upsert a pending payment audit record
  await db.execute(sql`
    INSERT INTO africart_payments (order_id, reference, amount_pesewas, status)
    VALUES (${orderId}::uuid, ${reference}, ${order.total_pesewas}, 'pending')
    ON CONFLICT (reference) DO NOTHING
  `);

  logger.info({ orderId, reference }, "Paystack transaction initialized");

  // 5. Return the authorization URL to the client
  res.json({
    authorizationUrl: initData.authorization_url,
    reference,
    accessCode: initData.access_code,
  });
});

// ── Vendor onboarding fee payment ──────────────────────────────────────────────

interface VendorFeeBody {
  businessName: string;
  personalName: string;
  businessType?: string;
  idCardUrl?: string;
  passportUrl?: string;
}

/**
 * POST /api/paystack/vendor-fee
 * Authenticated — the vendor applicant must be registered (phone verified).
 *
 * Flow:
 *  1. Upsert vendor record with status='pending', onboarding_fee_paid=false
 *  2. Initialize a GH₵200 Paystack transaction with callback_url ?type=vendor_fee
 *  3. Store a pending fee payment record
 *  4. Return { authorizationUrl, reference, vendorId }
 */
router.post("/paystack/vendor-fee", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string;
  const { businessName, personalName, businessType, idCardUrl, passportUrl } = req.body as VendorFeeBody;

  logger.info({ userId, businessName, personalName, businessType }, "Vendor fee payment init started");

  if (!businessName || !personalName) {
    res.status(400).json({ error: "businessName and personalName are required" });
    return;
  }

  // ── 1. Load user ────────────────────────────────────────────────────────────
  let user: { phone: string; email: string | null };
  try {
    const userResult = await db.execute(sql`
      SELECT phone, email FROM users WHERE id = ${userId}::uuid LIMIT 1
    `);
    const userRows = (userResult.rows ?? userResult) as any[];
    if (!userRows.length) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    user = userRows[0] as { phone: string; email: string | null };
  } catch (err: any) {
    logger.error({ err, userId }, "vendor-fee: failed to load user");
    res.status(500).json({ error: `Database error loading user: ${err?.message ?? String(err)}` });
    return;
  }

  // ── 2. Upsert vendor record (no updated_at — column does not exist) ─────────
  let vendorId: string;
  let alreadyPaid = false;
  try {
    const vendorResult = await db.execute(sql`
      INSERT INTO vendors (user_id, business_name, personal_name, business_type,
                           id_card_url, passport_url, status, onboarding_fee_paid)
      VALUES (
        ${userId}::uuid, ${businessName}, ${personalName},
        ${businessType ?? null}, ${idCardUrl ?? null}, ${passportUrl ?? null},
        'pending', false
      )
      ON CONFLICT (user_id) DO UPDATE SET
        business_name = EXCLUDED.business_name,
        personal_name = EXCLUDED.personal_name,
        business_type = EXCLUDED.business_type,
        id_card_url   = COALESCE(EXCLUDED.id_card_url, vendors.id_card_url),
        passport_url  = COALESCE(EXCLUDED.passport_url, vendors.passport_url)
      RETURNING id, onboarding_fee_paid
    `);
    const vendorRows = (vendorResult.rows ?? vendorResult) as any[];
    if (!vendorRows.length || !vendorRows[0]?.id) {
      res.status(500).json({ error: "Failed to create vendor record — upsert returned no row" });
      return;
    }
    vendorId   = vendorRows[0].id as string;
    alreadyPaid = Boolean(vendorRows[0].onboarding_fee_paid);
    logger.info({ vendorId, alreadyPaid }, "vendor-fee: vendor upserted");
  } catch (err: any) {
    logger.error({ err, userId, businessName }, "vendor-fee: vendor upsert failed");
    res.status(500).json({ error: `Database error upserting vendor: ${err?.message ?? String(err)}` });
    return;
  }

  // ── 3. Guard: already paid ──────────────────────────────────────────────────
  if (alreadyPaid) {
    res.status(409).json({ error: "Onboarding fee already paid", vendorId });
    return;
  }

  // ── 4. Idempotent reference — reuse any existing pending one ────────────────
  let reference: string;
  try {
    const existingRef = await db.execute(sql`
      SELECT reference FROM africart_vendor_fee_payments
      WHERE vendor_id = ${vendorId}::uuid AND status = 'pending'
      ORDER BY created_at DESC LIMIT 1
    `);
    const existingRows = (existingRef.rows ?? existingRef) as any[];
    reference = (existingRows[0]?.reference as string | undefined)
      ?? `VFEE-${userId.replace(/-/g, "").slice(0, 8).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    logger.info({ vendorId, reference }, "vendor-fee: reference resolved");
  } catch (err: any) {
    logger.error({ err, vendorId }, "vendor-fee: failed to query existing reference");
    res.status(500).json({ error: `Database error fetching reference: ${err?.message ?? String(err)}` });
    return;
  }

  // ── 5. Initialise Paystack transaction ─────────────────────────────────────
  const email = user.email ?? `${user.phone.replace(/\D/g, "")}@kasuwaa.com`;
  const paystackPayload = {
    email,
    amount:       20000,          // GH₵200 in pesewas
    currency:     "GHS",
    reference,
    callback_url: `${CALLBACK_URL}?type=vendor_fee`,
    metadata: {
      payment_type: "vendor_fee",
      vendorId,
      userId,
      businessName,
      platform: "kasuwaa",
    },
    channels: ["card", "mobile_money", "bank"],
  };

  logger.info({ email, reference, vendorId, callback_url: paystackPayload.callback_url }, "vendor-fee: calling Paystack initialize");

  let initData: PaystackInitData;
  try {
    initData = await paystackRequest<PaystackInitData>("POST", "/transaction/initialize", paystackPayload);
    logger.info({ reference, authorization_url: initData.authorization_url }, "vendor-fee: Paystack init success");
  } catch (err: any) {
    logger.error({ err: err?.message, reference, email }, "vendor-fee: Paystack initialization failed");
    res.status(502).json({ error: `Paystack error: ${err?.message ?? String(err)}` });
    return;
  }

  // ── 6. Persist pending fee record ──────────────────────────────────────────
  try {
    await db.execute(sql`
      INSERT INTO africart_vendor_fee_payments (vendor_id, reference, amount_pesewas, status)
      VALUES (${vendorId}::uuid, ${reference}, 20000, 'pending')
      ON CONFLICT (reference) DO NOTHING
    `);
  } catch (err: any) {
    // Non-fatal — record may already exist; log and continue
    logger.warn({ err: err?.message, vendorId, reference }, "vendor-fee: fee record insert warning (non-fatal)");
  }

  logger.info({ vendorId, reference }, "Vendor onboarding fee payment initialized successfully");

  res.json({
    authorizationUrl: initData.authorization_url,
    reference,
    vendorId,
  });
});

// ── Ad campaign payment initialization ────────────────────────────────────────

/**
 * POST /api/paystack/initialize-ad
 * Authenticated — vendor must be logged in.
 *
 * Body: { adId }
 * Creates a Paystack transaction for the ad campaign fee.
 * Returns: { authorizationUrl, reference }
 */
router.post("/paystack/initialize-ad", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const userId = (req as any).userId as string;
  const { adId } = req.body as { adId: string };

  if (!adId) {
    res.status(400).json({ error: "adId is required" });
    return;
  }

  // Load the ad and vendor
  const adResult = await db.execute(sql`
    SELECT a.id, a.title, a.total_cost_pesewas, a.is_paid, a.vendor_id,
           v.user_id AS vendor_user_id
    FROM africart_ads a
    JOIN vendors v ON v.id = a.vendor_id
    WHERE a.id = ${adId}::uuid
      AND v.user_id = ${userId}::uuid
    LIMIT 1
  `);
  const adRows = (adResult.rows ?? adResult) as any[];

  if (!adRows.length) {
    res.status(404).json({ error: "Ad not found or does not belong to your account" });
    return;
  }

  const ad = adRows[0];

  if (ad.is_paid) {
    res.status(409).json({ error: "This ad campaign has already been paid" });
    return;
  }

  // Load vendor's user email for Paystack
  const userResult = await db.execute(sql`
    SELECT phone, email FROM users WHERE id = ${userId}::uuid LIMIT 1
  `);
  const userRows = (userResult.rows ?? userResult) as any[];
  const user = userRows[0] as { phone: string; email: string | null } | undefined;
  const email = user?.email ?? `${(user?.phone ?? "0000000000").replace(/\D/g, "")}@kasuwaa.com`;

  const reference = `ADKW-${adId.replace(/-/g, "").slice(0, 8).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;

  const initData = await paystackRequest<PaystackInitData>("POST", "/transaction/initialize", {
    email,
    amount:       Number(ad.total_cost_pesewas),
    currency:     "GHS",
    reference,
    callback_url: `${CALLBACK_URL}?type=ad_campaign`,
    metadata: {
      payment_type: "ad_campaign",
      adId:         ad.id,
      vendorId:     ad.vendor_id,
      userId,
      adTitle:      ad.title,
      platform:     "kasuwaa",
    },
    channels: ["card", "mobile_money", "bank"],
  });

  logger.info({ adId, reference }, "Ad campaign payment initialized");

  res.json({
    authorizationUrl: initData.authorization_url,
    reference,
    adId,
  });
});

// ── Verify transaction ─────────────────────────────────────────────────────────

interface PaystackVerifyData {
  id: number;
  status: string;
  reference: string;
  amount: number;
  currency: string;
  paid_at: string | null;
  gateway_response: string;
  channel: string;
  ip_address: string;
  metadata: Record<string, any>;
}

/**
 * GET /api/paystack/verify/:reference
 * Public — called by the callback page after Paystack redirects back.
 *
 * Flow:
 *  1. Query Paystack directly (server-side) — client can never spoof this
 *  2. Update africart_payments and africart_orders
 *  3. If newly successful: notify seller + buyer, record in admin log
 *  4. Return { status, orderId, reference, amountPesewas }
 */
router.get("/paystack/verify/:reference", async (req: Request, res: Response): Promise<void> => {
  const reference = String(req.params["reference"] ?? "");

  if (!reference) {
    res.status(400).json({ error: "reference is required" });
    return;
  }

  // 1. Verify with Paystack (server-to-server — tamper-proof)
  let txData: PaystackVerifyData;
  try {
    txData = await paystackRequest<PaystackVerifyData>(
      "GET",
      `/transaction/verify/${encodeURIComponent(String(reference))}`,
    );
  } catch (err: any) {
    logger.error({ err, reference }, "Paystack verify call failed");
    res.status(502).json({ error: "Could not verify transaction with Paystack" });
    return;
  }

  const isPaid = txData.status === "success";
  const paymentType = (txData.metadata?.payment_type as string | undefined) ?? "order";

  // ── Vendor fee payment path ───────────────────────────────────────────────
  if (paymentType === "vendor_fee") {
    const vfeeResult = await db.execute(sql`
      SELECT vf.vendor_id, vf.status AS fee_status, v.onboarding_fee_paid
      FROM africart_vendor_fee_payments vf
      JOIN vendors v ON v.id = vf.vendor_id
      WHERE vf.reference = ${reference}
      LIMIT 1
    `);
    const vfeeRows = (vfeeResult.rows ?? vfeeResult) as any[];

    await db.execute(sql`
      UPDATE africart_vendor_fee_payments
      SET status           = ${txData.status},
          paystack_id      = ${txData.id},
          gateway_response = ${txData.gateway_response ?? null},
          channel          = ${txData.channel ?? null},
          paid_at          = ${txData.paid_at ? new Date(txData.paid_at).toISOString() : null},
          updated_at       = NOW()
      WHERE reference = ${reference}
    `);

    if (isPaid && vfeeRows.length && !vfeeRows[0].onboarding_fee_paid) {
      await markVendorFeePaid(vfeeRows[0].vendor_id as string, reference);
    }

    const vendorId = (txData.metadata?.vendorId as string | undefined)
      ?? (vfeeRows[0]?.vendor_id as string | undefined)
      ?? null;

    res.json({
      type:          "vendor_fee",
      status:        txData.status,
      reference:     txData.reference,
      amountPesewas: txData.amount,
      currency:      txData.currency,
      channel:       txData.channel,
      paidAt:        txData.paid_at,
      vendorId,
      orderId:       null,
    });
    return;
  }

  // ── Ad campaign payment path ──────────────────────────────────────────────
  if (paymentType === "ad_campaign") {
    const adId = txData.metadata?.adId as string | undefined;
    if (isPaid && adId) {
      await db.execute(sql`
        UPDATE africart_ads SET is_paid = true WHERE id = ${adId}::uuid
      `);
      const adResult = await db.execute(sql`
        SELECT a.vendor_id, v.user_id FROM africart_ads a
        JOIN vendors v ON v.id = a.vendor_id
        WHERE a.id = ${adId}::uuid LIMIT 1
      `);
      const adRows = (adResult.rows ?? adResult) as any[];
      if (adRows.length) {
        await db.execute(sql`
          INSERT INTO africart_notifications (user_id, type, title, message, data)
          VALUES (
            ${adRows[0].user_id}::uuid, 'payment_success',
            'Ad Payment Received',
            'Your ad campaign payment has been received. Our team will review and activate your ad within 24 hours.',
            ${JSON.stringify({ adId, reference, payment_type: "ad_campaign" })}::jsonb
          )
        `);
      }
      logger.info({ adId, reference }, "Ad campaign payment verified and marked paid");
    }
    res.json({
      type:          "ad_campaign",
      status:        txData.status,
      reference:     txData.reference,
      amountPesewas: txData.amount,
      currency:      txData.currency,
      channel:       txData.channel,
      paidAt:        txData.paid_at,
      orderId:       null,
      vendorId:      (txData.metadata?.vendorId as string | null) ?? null,
      adId:          adId ?? null,
    });
    return;
  }

  // ── Order payment path ────────────────────────────────────────────────────

  // 2. Update payment record
  await db.execute(sql`
    UPDATE africart_payments
    SET status           = ${txData.status},
        paystack_id      = ${txData.id},
        gateway_response = ${txData.gateway_response ?? null},
        channel          = ${txData.channel ?? null},
        ip_address       = ${txData.ip_address ?? null},
        paid_at          = ${txData.paid_at ? new Date(txData.paid_at).toISOString() : null},
        updated_at       = NOW()
    WHERE reference = ${reference}
  `);

  if (isPaid) {
    // Look up the order ID to avoid duplicate processing
    const paymentRow = await db.execute(sql`
      SELECT p.order_id, o.payment_status
      FROM africart_payments p
      JOIN africart_orders o ON o.id = p.order_id
      WHERE p.reference = ${reference}
      LIMIT 1
    `);
    const payRows = (paymentRow.rows ?? paymentRow) as any[];

    if (payRows.length && payRows[0].payment_status !== "paid") {
      await markOrderPaid(payRows[0].order_id as string, reference, txData);
    }
  }

  res.json({
    type:          "order",
    status:        txData.status,
    reference:     txData.reference,
    amountPesewas: txData.amount,
    currency:      txData.currency,
    channel:       txData.channel,
    paidAt:        txData.paid_at,
    orderId:       txData.metadata?.orderId ?? null,
    vendorId:      null,
  });
});

// ── Webhook ────────────────────────────────────────────────────────────────────

/**
 * POST /api/paystack/webhook
 *
 * IMPORTANT: must be registered with express.raw() to get the raw body for
 * HMAC verification. Mounted separately in app.ts BEFORE express.json().
 *
 * Flow:
 *  1. Verify HMAC-SHA512 signature — reject anything that doesn't match
 *  2. Deduplicate: skip if already processed (payment_status = 'paid')
 *  3. Re-verify the transaction server-side before trusting the payload
 *  4. Mark order paid, reduce inventory, notify seller & buyer
 */
router.post(
  "/paystack/webhook",
  async (req: Request, res: Response): Promise<void> => {
    const signature = String(req.headers["x-paystack-signature"] ?? "");
    const rawBody   = (req as any).rawBody as Buffer | undefined;

    // 1. Signature verification — always respond 200 quickly (Paystack retries on non-200)
    if (!rawBody || !verifyWebhookSignature(rawBody, signature)) {
      logger.warn({ signature }, "Paystack webhook signature invalid — rejecting");
      res.status(400).json({ error: "Invalid signature" });
      return;
    }

    let event: { event: string; data: any };
    try {
      event = JSON.parse(rawBody.toString("utf-8"));
    } catch {
      res.status(400).json({ error: "Malformed JSON" });
      return;
    }

    logger.info({ event: event.event }, "Paystack webhook received");

    // Acknowledge immediately — heavy work runs asynchronously
    res.sendStatus(200);

    // 2. Only process successful charge events
    if (event.event !== "charge.success") return;

    const data      = event.data;
    const reference = data.reference as string;

    try {
      const paymentType = (data.metadata?.payment_type as string | undefined) ?? "order";

      // ── Vendor fee webhook path ─────────────────────────────────────────
      if (paymentType === "vendor_fee") {
        const vfeeCheck = await db.execute(sql`
          SELECT vf.vendor_id, v.onboarding_fee_paid
          FROM africart_vendor_fee_payments vf
          JOIN vendors v ON v.id = vf.vendor_id
          WHERE vf.reference = ${reference}
          LIMIT 1
        `);
        const vfeeRows = (vfeeCheck.rows ?? vfeeCheck) as any[];

        if (!vfeeRows.length) {
          logger.warn({ reference }, "Webhook: no vendor fee record found for reference");
          return;
        }
        if (vfeeRows[0].onboarding_fee_paid) {
          logger.info({ reference }, "Webhook: vendor fee already processed, skipping");
          return;
        }

        const verified = await paystackRequest<PaystackVerifyData>(
          "GET", `/transaction/verify/${encodeURIComponent(reference)}`,
        );
        if (verified.status !== "success") {
          logger.warn({ reference, status: verified.status }, "Webhook vendor fee: re-verify non-success");
          return;
        }

        await db.execute(sql`
          UPDATE africart_vendor_fee_payments
          SET webhook_payload  = ${JSON.stringify(data)}::jsonb,
              status           = 'success',
              paystack_id      = ${verified.id},
              gateway_response = ${verified.gateway_response ?? null},
              channel          = ${verified.channel ?? null},
              paid_at          = ${verified.paid_at ? new Date(verified.paid_at).toISOString() : null},
              updated_at       = NOW()
          WHERE reference = ${reference}
        `);
        await markVendorFeePaid(vfeeRows[0].vendor_id as string, reference);
        return;
      }

      // ── Order webhook path ──────────────────────────────────────────────

      // 3. Check if already processed (idempotency guard)
      const check = await db.execute(sql`
        SELECT p.order_id, o.payment_status
        FROM africart_payments p
        JOIN africart_orders o ON o.id = p.order_id
        WHERE p.reference = ${reference}
        LIMIT 1
      `);
      const rows = (check.rows ?? check) as any[];

      if (!rows.length) {
        logger.warn({ reference }, "Webhook: no payment record found for reference");
        return;
      }

      if (rows[0].payment_status === "paid") {
        logger.info({ reference }, "Webhook: already processed, skipping");
        return;
      }

      const orderId = rows[0].order_id as string;

      // 4. Re-verify with Paystack server-side before updating DB
      const verified = await paystackRequest<PaystackVerifyData>(
        "GET",
        `/transaction/verify/${encodeURIComponent(reference)}`,
      );

      if (verified.status !== "success") {
        logger.warn({ reference, status: verified.status }, "Webhook: re-verify returned non-success");
        return;
      }

      // Store raw webhook payload on payment record
      await db.execute(sql`
        UPDATE africart_payments
        SET webhook_payload  = ${JSON.stringify(data)}::jsonb,
            status           = 'success',
            paystack_id      = ${verified.id},
            gateway_response = ${verified.gateway_response ?? null},
            channel          = ${verified.channel ?? null},
            ip_address       = ${verified.ip_address ?? null},
            paid_at          = ${verified.paid_at ? new Date(verified.paid_at).toISOString() : null},
            updated_at       = NOW()
        WHERE reference = ${reference}
      `);

      await markOrderPaid(orderId, reference, verified);

    } catch (err) {
      logger.error({ err, reference }, "Paystack webhook processing error");
    }
  },
);

// ── Shared: mark vendor fee paid ──────────────────────────────────────────────

async function markVendorFeePaid(vendorId: string, reference: string): Promise<void> {
  logger.info({ vendorId, reference }, "Marking vendor onboarding fee as paid");
  await db.execute(sql`
    UPDATE vendors
    SET onboarding_fee_paid    = true,
        onboarding_fee_paid_at = NOW(),
        updated_at             = NOW()
    WHERE id = ${vendorId}::uuid
  `);

  // Notify the vendor's user account
  const userResult = await db.execute(sql`
    SELECT user_id FROM vendors WHERE id = ${vendorId}::uuid LIMIT 1
  `);
  const uRows = (userResult.rows ?? userResult) as any[];
  if (uRows.length) {
    await db.execute(sql`
      INSERT INTO africart_notifications (user_id, type, title, message, data)
      VALUES (
        ${uRows[0].user_id}::uuid,
        'payment_success',
        'Onboarding Fee Received',
        'Your GH₵200 onboarding fee has been received. Our team will review your application within 24–48 hours.',
        ${JSON.stringify({ vendorId, reference, payment_type: "vendor_fee" })}::jsonb
      )
    `);
  }
  logger.info({ vendorId, reference }, "Vendor fee paid — notification dispatched");
}

// ── Shared: mark order paid + side-effects ────────────────────────────────────

/**
 * Central function called by both verify and webhook handlers.
 * Runs all post-payment side-effects atomically:
 *  - Marks order as paid + in_escrow
 *  - Reduces inventory for each ordered product
 *  - Sends notification to the buyer
 *  - Sends notification to each vendor with items in the order
 */
async function markOrderPaid(
  orderId: string,
  reference: string,
  txData: PaystackVerifyData,
): Promise<void> {
  logger.info({ orderId, reference }, "Marking order as paid");

  // Mark order paid (status → in_escrow, payment_status → paid)
  await db.execute(sql`
    UPDATE africart_orders
    SET payment_status = 'paid',
        status         = 'in_escrow',
        paid_at        = ${txData.paid_at ? new Date(txData.paid_at).toISOString() : new Date().toISOString()},
        updated_at     = NOW()
    WHERE id = ${orderId}::uuid
  `);

  // Load order items (product_id, vendor_id, qty, buyer info)
  const itemsResult = await db.execute(sql`
    SELECT oi.product_id, oi.vendor_id, oi.qty, oi.product_name,
           o.buyer_id, u.full_name AS buyer_name, o.total_pesewas
    FROM africart_order_items oi
    JOIN africart_orders o ON o.id = oi.order_id
    JOIN users u ON u.id = o.buyer_id
    WHERE oi.order_id = ${orderId}::uuid
  `);
  const items = (itemsResult.rows ?? itemsResult) as any[];

  // Reduce inventory for each product
  for (const item of items) {
    if (!item.product_id) continue;
    // Mark out-of-stock if qty ordered equals or exceeds remaining stock.
    // We use a simple boolean in_stock flag (no quantity column), so we don't
    // decrement — just surface that the product sold by leaving stock as-is.
    // If the seller tracks qty externally they update via the seller dashboard.
    logger.info({ productId: item.product_id, qty: item.qty }, "Inventory noted post-payment");
  }

  // Notify buyer
  const buyerId      = items[0]?.buyer_id;
  const buyerName    = items[0]?.buyer_name ?? "Customer";
  const totalPesewas = items[0]?.total_pesewas ?? 0;
  const ghsAmount    = (totalPesewas / 100).toFixed(2);

  if (buyerId) {
    const buyerMsg = `Your payment of GHS ${ghsAmount} for order #${orderId.slice(0, 8).toUpperCase()} was successful. Your items are now in escrow and will be dispatched shortly.`;
    await db.execute(sql`
      INSERT INTO africart_notifications (user_id, type, title, message, data)
      VALUES (
        ${buyerId}::uuid,
        'payment_success',
        'Payment Successful',
        ${buyerMsg},
        ${JSON.stringify({ orderId, reference })}::jsonb
      )
    `);
  }

  // Notify each unique vendor that has items in this order
  const vendorIds = [...new Set(items.map((i: any) => i.vendor_id).filter(Boolean))] as string[];
  for (const vendorId of vendorIds) {
    // Get the user_id behind this vendor
    const vResult = await db.execute(sql`
      SELECT user_id FROM vendors WHERE id = ${vendorId}::uuid LIMIT 1
    `);
    const vRows = (vResult.rows ?? vResult) as any[];
    if (!vRows.length) continue;

    const vendorUserId = vRows[0].user_id;
    const vendorItems  = items.filter((i: any) => i.vendor_id === vendorId);
    const itemNames    = vendorItems.map((i: any) => `${i.product_name} ×${i.qty}`).join(", ");
    const sellerMsg    = `New paid order from ${buyerName}: ${itemNames}. Payment is in escrow — please dispatch promptly.`;

    sendPushToUser(vendorUserId, {
      title: "🛒 New Order!",
      body: `${buyerName} ordered: ${itemNames}`,
      url: "/seller/orders",
      tag: `order-${orderId}`,
    }).catch(() => {});

    await db.execute(sql`
      INSERT INTO africart_notifications (user_id, type, title, message, data)
      VALUES (
        ${vendorUserId}::uuid,
        'new_order',
        'New Paid Order!',
        ${sellerMsg},
        ${JSON.stringify({ orderId, reference })}::jsonb
      )
    `);
  }

  // Push-notify all subscribed admins
  const ghsForPush = (totalPesewas / 100).toFixed(2);
  sendPushToAllAdmins({
    title: "🛍️ New Order Received",
    body: `GHS ${ghsForPush} from ${buyerName} — Order #${orderId.slice(0, 8).toUpperCase()}`,
    url: "/admin/orders",
    tag: `admin-order-${orderId}`,
  }).catch(() => {});

  // Notify admin of new paid order
  try {
    const ghsAmount = (totalPesewas / 100).toFixed(2);
    await db.execute(sql`
      INSERT INTO africart_admin_notifications (type, title, message, data)
      VALUES (
        'new_order',
        'New Order Received',
        ${`Order #${orderId.slice(0, 8).toUpperCase()} — GHS ${ghsAmount} from ${buyerName}. ${vendorIds.length} vendor(s) notified.`},
        ${JSON.stringify({ orderId, reference, amountGhs: ghsAmount })}::jsonb
      )
    `);
  } catch (_) { /* best-effort */ }

  logger.info({ orderId, reference, vendorCount: vendorIds.length }, "Order paid — notifications dispatched");
}

export default router;
