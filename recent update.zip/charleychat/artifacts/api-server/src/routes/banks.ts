import { Router, type IRouter } from "express";
import { z } from "zod/v4";
import { eq, sql } from "drizzle-orm";
import { db, walletsTable, transactionsTable, notificationsTable, usersTable } from "@workspace/db";
import { requireAuth, verifyPin } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { paystackRequest } from "../lib/paystack-client";
import { calculateTransferFeePesewas } from "../lib/fees";

const router: IRouter = Router();

interface PaystackBank {
  name: string;
  code: string;
  slug: string;
  currency: string;
}

// Cache the bank list in-memory for an hour — it changes rarely, and hitting
// Paystack on every screen-open would be wasteful.
let bankListCache: { fetchedAt: number; banks: PaystackBank[] } | null = null;
const BANK_CACHE_TTL_MS = 60 * 60 * 1000;

router.get("/banks", requireAuth, async (_req, res): Promise<void> => {
  try {
    if (bankListCache && Date.now() - bankListCache.fetchedAt < BANK_CACHE_TTL_MS) {
      res.json(bankListCache.banks);
      return;
    }
    const banks = await paystackRequest<PaystackBank[]>("GET", "/bank?country=ghana&currency=GHS");
    bankListCache = { fetchedAt: Date.now(), banks };
    res.json(banks);
  } catch (err: any) {
    res.status(502).json({ error: "Couldn't load the bank list right now. Please try again shortly.", detail: err.message });
  }
});

const ResolveAccountBody = z.object({
  accountNumber: z.string().min(5),
  bankCode: z.string().min(1),
});

router.post("/banks/resolve-account", requireAuth, async (req, res): Promise<void> => {
  const parsed = ResolveAccountBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  try {
    const result = await paystackRequest<{ account_number: string; account_name: string }>(
      "GET",
      `/bank/resolve?account_number=${encodeURIComponent(parsed.data.accountNumber)}&bank_code=${encodeURIComponent(parsed.data.bankCode)}`,
    );
    res.json({ accountNumber: result.account_number, accountName: result.account_name });
  } catch (err: any) {
    // Paystack's resolve endpoint has historically been most reliable for
    // Nigerian banks; Ghanaian bank resolution support can vary by bank.
    // Surface a clear, actionable error rather than silently failing.
    res.status(422).json({
      error: "Couldn't verify that account number with the bank. Please double-check the account number and bank, or contact support if this keeps happening.",
      detail: err.message,
    });
  }
});

const BankWithdrawBody = z.object({
  amountPesewas: z.number().int().positive(),
  bankCode: z.string().min(1),
  bankName: z.string().min(1),
  accountNumber: z.string().min(5),
  accountName: z.string().min(1),
  pin: z.string().min(4),
});

router.post("/wallets/bank-withdraw", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const parsed = BankWithdrawBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { amountPesewas, bankCode, bankName, accountNumber, accountName, pin } = parsed.data;

  const [userRow] = await db.select({ pinHash: usersTable.pinHash }).from(usersTable).where(eq(usersTable.id, req.userId!));
  if (!userRow?.pinHash || !(await verifyPin(String(pin), userRow.pinHash))) {
    res.status(401).json({ error: "Incorrect PIN" });
    return;
  }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (!wallet) { res.status(404).json({ error: "Wallet not found" }); return; }

  const feePesewas = calculateTransferFeePesewas(amountPesewas);
  const totalDeductedPesewas = amountPesewas + feePesewas;
  if (wallet.balancePesewas < totalDeductedPesewas) {
    res.status(400).json({ error: "Insufficient funds", feePesewas, totalDeductedPesewas });
    return;
  }

  const reference = `BANKTX-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;

  // NOTE: this debits the wallet and records the transaction, but does not yet
  // call Paystack's Transfer Recipient + Transfer APIs to actually move money
  // to the bank — that requires Transfers to be enabled on the Paystack
  // account (a manual approval step on their dashboard) and live credentials
  // to test against, neither of which are available in this environment.
  // Wiring that in is a small, contained follow-up once those are ready:
  // POST /transferrecipient (type: "ghipss", account_number, bank_code) then
  // POST /transfer (source: "balance", recipient, amount, reference).
  const [tx] = await db.transaction(async (trx) => {
    await trx
      .update(walletsTable)
      .set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${totalDeductedPesewas}`, updatedAt: new Date() })
      .where(eq(walletsTable.id, wallet.id));
    return trx
      .insert(transactionsTable)
      .values({
        walletId: wallet.id,
        type: "bank_out",
        amountPesewas,
        feePesewas,
        network: bankName,
        reference,
        status: "completed",
        note: `Bank transfer to ${accountName} (${bankName}, Acc: ${accountNumber}, code: ${bankCode})`,
      })
      .returning();
  });

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "Bank transfer sent",
    body: `GH₵${(amountPesewas / 100).toFixed(2)} sent to ${accountName} (${bankName}).`,
    type: "bank_transfer",
    referenceId: tx.id,
  });

  res.status(201).json(tx);
});

export default router;
