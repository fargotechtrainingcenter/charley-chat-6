import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, vendorsTable, usersTable, productsTable, vendorSubscriptionsTable } from "@workspace/db";
import {
  RegisterAsVendorBody,
  UpdateVendorProfileBody,
  GetVendorParams,
} from "@workspace/api-zod";
import { z } from "zod/v4";
import { requireAuth } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { getActiveSubscription, getRemainingListings, subscribeVendor, tierForProductCount } from "../lib/vendor-subscriptions";

const router: IRouter = Router();

function vendorRecord(vendor: typeof vendorsTable.$inferSelect, totalProducts = 0) {
  return {
    id: vendor.id,
    userId: vendor.userId,
    businessName: vendor.businessName,
    businessType: vendor.businessType ?? null,
    description: vendor.description ?? null,
    logoUrl: vendor.logoUrl ?? null,
    coverImageUrl: vendor.coverImageUrl ?? null,
    location: vendor.location ?? null,
    isVerified: vendor.isVerified,
    ratingAvg: vendor.ratingAvg,
    totalReviews: vendor.totalReviews,
    totalProducts,
    createdAt: vendor.createdAt.toISOString(),
  };
}

router.get("/vendors", async (_req, res): Promise<void> => {
  const vendors = await db.select().from(vendorsTable);
  res.json(vendors.map((v) => vendorRecord(v, 0)));
});

router.get("/vendors/me", requireAuth, async (req, res): Promise<void> => {
  const result = await db.execute(
    sql`SELECT id, status, business_name AS "businessName", personal_name AS "personalName", rejection_reason AS "rejectionReason", created_at AS "createdAt"
        FROM vendors WHERE user_id = ${req.userId!}::uuid LIMIT 1`
  );
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) { res.status(404).json({ error: "No vendor account found" }); return; }
  res.json(rows[0]);
});

// ── Marketplace seller subscription ─────────────────────────────────────────

async function findVendorId(userId: string): Promise<string | null> {
  const [v] = await db.select({ id: vendorsTable.id }).from(vendorsTable).where(eq(vendorsTable.userId, userId));
  return v?.id ?? null;
}

router.get("/vendors/me/subscription", requireAuth, async (req, res): Promise<void> => {
  const vendorId = await findVendorId(req.userId!);
  if (!vendorId) { res.status(404).json({ error: "No vendor account found" }); return; }

  const sub = await getActiveSubscription(vendorId);
  const listings = await getRemainingListings(vendorId);

  if (!sub) {
    res.json({ hasActiveSubscription: false, tier: null, productLimit: 0, remainingListings: 0, expiresAt: null });
    return;
  }
  res.json({
    hasActiveSubscription: true,
    tier: sub.tier,
    productLimit: sub.productLimit,
    productsUsed: listings?.used ?? 0,
    remainingListings: listings?.remaining ?? 0,
    expiresAt: sub.expiresAt,
    autoRenew: sub.autoRenew,
    pricePesewas: sub.pricePesewas,
  });
});

const SubscribeBody = z.object({
  tier: z.enum(["basic", "pro"]).optional(),
});

router.post("/vendors/me/subscription", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const vendorId = await findVendorId(req.userId!);
  if (!vendorId) { res.status(404).json({ error: "No vendor account found" }); return; }

  const parsed = SubscribeBody.safeParse(req.body ?? {});
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  // Auto-determine tier from current listing count if not explicitly chosen
  let tier = parsed.data.tier;
  if (!tier) {
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(productsTable).where(eq(productsTable.vendorId, vendorId));
    tier = tierForProductCount(count);
  }

  try {
    const sub = await subscribeVendor(vendorId, req.userId!, tier);
    res.status(201).json(sub);
  } catch (err: any) {
    if (err.code === "INSUFFICIENT_FUNDS") {
      res.status(402).json({
        error: "Insufficient wallet balance for this subscription",
        pricePesewas: err.pricePesewas,
        walletFundingRequired: true,
      });
      return;
    }
    throw err;
  }
});

const AutoRenewBody = z.object({ autoRenew: z.boolean() });

router.patch("/vendors/me/subscription/auto-renew", requireAuth, async (req, res): Promise<void> => {
  const vendorId = await findVendorId(req.userId!);
  if (!vendorId) { res.status(404).json({ error: "No vendor account found" }); return; }
  const parsed = AutoRenewBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const sub = await getActiveSubscription(vendorId);
  if (!sub) { res.status(404).json({ error: "No active subscription" }); return; }

  const { vendorSubscriptionsTable } = await import("@workspace/db");
  await db.update(vendorSubscriptionsTable).set({ autoRenew: parsed.data.autoRenew }).where(eq(vendorSubscriptionsTable.id, sub.id));
  res.json({ ok: true, autoRenew: parsed.data.autoRenew });
});

// ── MoMo push payment (placeholder — swap body for real provider call) ──────
// When you have a Paystack/Hubtel/PawaPay key, replace the body of this
// handler with a real charge-mobile-money API call and return their tx id.
const pendingPayments = new Map<string, { status: "pending" | "success" | "failed"; momoPhone: string }>();

router.post("/vendors/initiate-payment", requireAuth, async (req, res): Promise<void> => {
  const { momoPhone, amountGhc } = req.body as { momoPhone?: string; amountGhc?: number };
  if (!momoPhone || !amountGhc) {
    res.status(400).json({ error: "momoPhone and amountGhc are required" });
    return;
  }
  // Placeholder: generate a transaction id and auto-confirm after 6s
  const transactionId = `KASUWAA-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
  pendingPayments.set(transactionId, { status: "pending", momoPhone });
  // Auto-confirm after 6 seconds (simulates user approving MoMo prompt)
  setTimeout(() => {
    const entry = pendingPayments.get(transactionId);
    if (entry) entry.status = "success";
  }, 6000);
  res.json({ transactionId, message: "MoMo prompt sent" });
});

router.post("/vendors/verify-payment", requireAuth, async (req, res): Promise<void> => {
  const { transactionId } = req.body as { transactionId?: string };
  if (!transactionId) { res.status(400).json({ error: "transactionId required" }); return; }
  const entry = pendingPayments.get(transactionId);
  if (!entry) { res.status(404).json({ error: "Transaction not found" }); return; }
  res.json({ status: entry.status });
  if (entry.status !== "pending") pendingPayments.delete(transactionId);
});

router.post("/vendors", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const parsed = RegisterAsVendorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, req.userId!));

  if (existing) {
    res.status(409).json({ error: "Already registered as a vendor" });
    return;
  }

  const { businessName, businessType, description, logoUrl } = parsed.data;
  const body = parsed.data as typeof parsed.data & {
    personalName?: string;
    idCardUrl?: string;
    passportUrl?: string;
    momoReference?: string;
    momoPhone?: string;
    onboardingFeePaid?: boolean;
  };
  const [vendor] = await db
    .insert(vendorsTable)
    .values({
      userId: req.userId!,
      businessName,
      businessType: businessType ?? null,
      description: description ?? null,
      logoUrl: logoUrl ?? null,
      status: "pending",
      personalName: body.personalName ?? null,
      idCardUrl: body.idCardUrl ?? null,
      passportUrl: body.passportUrl ?? null,
      momoReference: body.momoPhone ?? body.momoReference ?? null,
      onboardingFeePaid: body.onboardingFeePaid ?? false,
    } as any)
    .returning();

  if (body.onboardingFeePaid) {
    await db.execute(sql`UPDATE vendors SET onboarding_fee_paid_at = NOW() WHERE id = ${vendor.id}::uuid`);
  }

  await db.update(usersTable).set({ isVendor: true }).where(eq(usersTable.id, req.userId!));

  // Notify admin of new vendor application
  try {
    await db.execute(sql`
      INSERT INTO africart_admin_notifications (type, title, message, data)
      VALUES (
        'new_vendor',
        'New Vendor Application',
        ${`${body.personalName ?? "A seller"} applied with business "${businessName}" (${businessType ?? "General"}). Documents uploaded for review.`},
        ${JSON.stringify({ vendorId: vendor.id })}::jsonb
      )
    `);
  } catch (_) { /* best-effort */ }

  res.status(201).json(vendorRecord(vendor, 0));
});

router.patch("/vendors/me", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateVendorProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  if (parsed.data.businessName !== undefined) updates.businessName = parsed.data.businessName;
  if (parsed.data.businessType !== undefined) updates.businessType = parsed.data.businessType;
  if (parsed.data.description !== undefined) updates.description = parsed.data.description;
  if (parsed.data.logoUrl !== undefined) updates.logoUrl = parsed.data.logoUrl;

  const [vendor] = await db
    .update(vendorsTable)
    .set(updates)
    .where(eq(vendorsTable.userId, req.userId!))
    .returning();

  if (!vendor) {
    res.status(404).json({ error: "Vendor profile not found" });
    return;
  }

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id));

  res.json(vendorRecord(vendor, count));
});

// ── GET /api/vendors/me/markup ────────────────────────────────────────────────
router.get("/vendors/me/markup", requireAuth, async (req, res): Promise<void> => {
  const result = await db.execute(
    sql`SELECT default_markup_pct AS "defaultMarkupPct" FROM vendors WHERE user_id = ${req.userId!}::uuid LIMIT 1`
  );
  const rows = (result.rows ?? result) as any[];
  if (!rows.length) { res.status(404).json({ error: "No vendor account found" }); return; }
  res.json({ defaultMarkupPct: rows[0].defaultMarkupPct ?? 10 });
});

// ── PUT /api/vendors/me/markup ────────────────────────────────────────────────
router.put("/vendors/me/markup", requireAuth, async (req, res): Promise<void> => {
  const { defaultMarkupPct } = req.body as { defaultMarkupPct?: unknown };
  const pct = Number(defaultMarkupPct);
  if (!Number.isInteger(pct) || pct < 0 || pct > 1000) {
    res.status(400).json({ error: "defaultMarkupPct must be an integer between 0 and 1000" });
    return;
  }
  const updated = await db.execute(
    sql`UPDATE vendors SET default_markup_pct = ${pct} WHERE user_id = ${req.userId!}::uuid RETURNING default_markup_pct AS "defaultMarkupPct"`
  );
  const rows = (updated.rows ?? updated) as any[];
  if (!rows.length) { res.status(404).json({ error: "No vendor account found" }); return; }
  res.json({ defaultMarkupPct: rows[0].defaultMarkupPct });
});

router.get("/vendors/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetVendorParams.safeParse({ id: raw });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, params.data.id));
  if (!vendor) {
    res.status(404).json({ error: "Vendor not found" });
    return;
  }

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendor.id));

  res.json(vendorRecord(vendor, count));
});

export default router;
