import { Router } from "express";
import webpush from "web-push";
import { Expo, type ExpoPushMessage, type ExpoPushToken } from "expo-server-sdk";
import { eq, and, or } from "drizzle-orm";
import { db, pushSubscriptionsTable } from "@workspace/db";
import { requireAuth, requireAdminAuth } from "../lib/auth";
import { logger } from "../lib/logger";

const router = Router();

const VAPID_PUBLIC  = process.env.VAPID_PUBLIC_KEY  ?? "";
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY ?? "";
const VAPID_EMAIL   = process.env.VAPID_EMAIL        ?? "mailto:admin@kasuwaa.com";

if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails(VAPID_EMAIL, VAPID_PUBLIC, VAPID_PRIVATE);
}

const expo = new Expo();

// ── Public VAPID key (for web/PWA push registration) ─────────────────────────

router.get("/push/vapid-key", (_req, res): void => {
  res.json({ publicKey: VAPID_PUBLIC });
});

// ── User subscribe (buyers / vendors) — web/PWA push ─────────────────────────

router.post("/push/subscribe", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const { endpoint, keys } = req.body as {
    endpoint: string;
    keys: { p256dh: string; auth: string };
  };

  if (!endpoint || !keys?.p256dh || !keys?.auth) {
    res.status(400).json({ error: "endpoint and keys required" });
    return;
  }

  await db
    .insert(pushSubscriptionsTable)
    .values({ subscriberType: "user", subscriberId: userId, endpoint, p256dh: keys.p256dh, auth: keys.auth, platform: "web" })
    .onConflictDoUpdate({
      target: [pushSubscriptionsTable.subscriberId, pushSubscriptionsTable.endpoint],
      set: { p256dh: keys.p256dh, auth: keys.auth, updatedAt: new Date() },
    });

  res.json({ ok: true });
});

router.delete("/push/unsubscribe", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const { endpoint } = req.body as { endpoint: string };
  if (!endpoint) { res.status(400).json({ error: "endpoint required" }); return; }
  await db.delete(pushSubscriptionsTable).where(
    and(
      eq(pushSubscriptionsTable.subscriberType, "user"),
      eq(pushSubscriptionsTable.subscriberId, userId),
      eq(pushSubscriptionsTable.endpoint, endpoint),
    ),
  );
  res.json({ ok: true });
});

// ── User subscribe — native mobile push (Expo / Android / iOS) ──────────────

router.post("/push/expo-subscribe", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const { token, platform } = req.body as { token: string; platform?: "ios" | "android" };

  if (!token || !Expo.isExpoPushToken(token)) {
    res.status(400).json({ error: "A valid Expo push token is required" });
    return;
  }

  await db
    .insert(pushSubscriptionsTable)
    .values({ subscriberType: "user", subscriberId: userId, expoPushToken: token, platform: platform ?? "unknown" })
    .onConflictDoUpdate({
      target: [pushSubscriptionsTable.subscriberId, pushSubscriptionsTable.expoPushToken],
      set: { platform: platform ?? "unknown", updatedAt: new Date() },
    });

  res.json({ ok: true });
});

router.delete("/push/expo-unsubscribe", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as any).userId as string;
  const { token } = req.body as { token: string };
  if (!token) { res.status(400).json({ error: "token required" }); return; }
  await db.delete(pushSubscriptionsTable).where(
    and(
      eq(pushSubscriptionsTable.subscriberType, "user"),
      eq(pushSubscriptionsTable.subscriberId, userId),
      eq(pushSubscriptionsTable.expoPushToken, token),
    ),
  );
  res.json({ ok: true });
});

// ── Admin subscribe (web/PWA push only — admin dashboard is web-based) ───────

router.post("/push/admin/subscribe", requireAdminAuth, async (req, res): Promise<void> => {
  const adminId = String((req as any).adminId ?? (req as any).userId ?? "admin");
  const { endpoint, keys } = req.body as {
    endpoint: string;
    keys: { p256dh: string; auth: string };
  };

  if (!endpoint || !keys?.p256dh || !keys?.auth) {
    res.status(400).json({ error: "endpoint and keys required" });
    return;
  }

  await db
    .insert(pushSubscriptionsTable)
    .values({ subscriberType: "admin", subscriberId: adminId, endpoint, p256dh: keys.p256dh, auth: keys.auth, platform: "web" })
    .onConflictDoUpdate({
      target: [pushSubscriptionsTable.subscriberId, pushSubscriptionsTable.endpoint],
      set: { p256dh: keys.p256dh, auth: keys.auth, updatedAt: new Date() },
    });

  res.json({ ok: true });
});

// ── Helpers (used by other routes to actually send notifications) ───────────

export interface PushPayload {
  title: string;
  body: string;
  url?: string;
  tag?: string;
}

async function loadSubscriptions(type: "user" | "admin", id?: string) {
  const where = id
    ? and(eq(pushSubscriptionsTable.subscriberType, type), eq(pushSubscriptionsTable.subscriberId, id))
    : eq(pushSubscriptionsTable.subscriberType, type);
  return db.select().from(pushSubscriptionsTable).where(where);
}

async function sendWebPush(subs: { endpoint: string | null; p256dh: string | null; auth: string | null }[], payload: PushPayload): Promise<void> {
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) return;
  const body = JSON.stringify(payload);
  for (const sub of subs) {
    if (!sub.endpoint || !sub.p256dh || !sub.auth) continue;
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        body,
        { TTL: 3600 },
      );
    } catch (err: any) {
      if (err.statusCode === 410 || err.statusCode === 404) {
        await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.endpoint, sub.endpoint));
      } else {
        logger.warn({ endpoint: sub.endpoint, err: err.message }, "Web push send failed");
      }
    }
  }
}

async function sendExpoPush(subs: { expoPushToken: string | null }[], payload: PushPayload): Promise<void> {
  const tokens = subs.map((s) => s.expoPushToken).filter((t): t is string => !!t && Expo.isExpoPushToken(t));
  if (tokens.length === 0) return;

  const messages: ExpoPushMessage[] = tokens.map((token) => ({
    to: token as ExpoPushToken,
    sound: "default",
    title: payload.title,
    body: payload.body,
    data: { url: payload.url, tag: payload.tag },
  }));

  const chunks = expo.chunkPushNotifications(messages);
  for (const chunk of chunks) {
    try {
      const tickets = await expo.sendPushNotificationsAsync(chunk);
      // Clean up tokens that are no longer valid (app uninstalled, etc.)
      for (let i = 0; i < tickets.length; i++) {
        const ticket = tickets[i];
        if (ticket.status === "error" && ticket.details?.error === "DeviceNotRegistered") {
          const badToken = chunk[i]?.to;
          if (typeof badToken === "string") {
            await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.expoPushToken, badToken));
          }
        }
      }
    } catch (err: any) {
      logger.warn({ err: err.message }, "Expo push send failed");
    }
  }
}

async function sendToSubscriptions(subs: (typeof pushSubscriptionsTable.$inferSelect)[], payload: PushPayload): Promise<void> {
  const webSubs = subs.filter((s) => s.endpoint);
  const expoSubs = subs.filter((s) => s.expoPushToken);
  await Promise.all([sendWebPush(webSubs, payload), sendExpoPush(expoSubs, payload)]);
}

/** Send a push notification to every device (web + native) a user is subscribed on. */
export async function sendPushToUser(userId: string, payload: PushPayload): Promise<void> {
  const subs = await loadSubscriptions("user", userId);
  await sendToSubscriptions(subs, payload);
}

export async function sendPushToAllAdmins(payload: PushPayload): Promise<void> {
  const subs = await loadSubscriptions("admin");
  await sendToSubscriptions(subs, payload);
}

export default router;
