import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, kycVerificationsTable, kycDraftsTable } from "@workspace/db";
import { SubmitKycBody, GetKycStatusResponse } from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

function generateRef(): string {
  const date = new Date();
  const dateStr = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  const seq = String(Math.floor(Math.random() * 999999) + 1).padStart(6, "0");
  return `KYC-${dateStr}-${seq}`;
}

// ── Draft endpoints ────────────────────────────────────────────────────────────

router.get("/kyc/draft", requireAuth, async (req, res): Promise<void> => {
  const [draft] = await db
    .select()
    .from(kycDraftsTable)
    .where(eq(kycDraftsTable.userId, req.userId!));
  if (!draft) { res.status(404).json({ error: "No draft found" }); return; }
  res.json(draft);
});

router.put("/kyc/draft", requireAuth, async (req, res): Promise<void> => {
  const { idType, idNumber, frontImageUrl, backImageUrl, selfieUrl, currentStep } = req.body as {
    idType?: string;
    idNumber?: string;
    frontImageUrl?: string;
    backImageUrl?: string;
    selfieUrl?: string;
    currentStep?: string;
  };

  const [existing] = await db
    .select({ id: kycDraftsTable.id })
    .from(kycDraftsTable)
    .where(eq(kycDraftsTable.userId, req.userId!));

  const now = new Date();

  if (existing) {
    const [draft] = await db
      .update(kycDraftsTable)
      .set({
        ...(idType !== undefined && { idType }),
        ...(idNumber !== undefined && { idNumber }),
        ...(frontImageUrl !== undefined && { frontImageUrl }),
        ...(backImageUrl !== undefined && { backImageUrl }),
        ...(selfieUrl !== undefined && { selfieUrl }),
        ...(currentStep !== undefined && { currentStep }),
        updatedAt: now,
      })
      .where(eq(kycDraftsTable.userId, req.userId!))
      .returning();
    res.json(draft);
  } else {
    const [draft] = await db
      .insert(kycDraftsTable)
      .values({
        userId: req.userId!,
        idType: idType ?? null,
        idNumber: idNumber ?? null,
        frontImageUrl: frontImageUrl ?? null,
        backImageUrl: backImageUrl ?? null,
        selfieUrl: selfieUrl ?? null,
        currentStep: currentStep ?? "id_type",
        updatedAt: now,
      })
      .returning();
    res.status(201).json(draft);
  }
});

router.delete("/kyc/draft", requireAuth, async (req, res): Promise<void> => {
  await db.delete(kycDraftsTable).where(eq(kycDraftsTable.userId, req.userId!));
  res.sendStatus(204);
});

// ── Submit ─────────────────────────────────────────────────────────────────────

router.post("/kyc", requireAuth, async (req, res): Promise<void> => {
  const parsed = SubmitKycBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select({ id: kycVerificationsTable.id, status: kycVerificationsTable.status })
    .from(kycVerificationsTable)
    .where(eq(kycVerificationsTable.userId, req.userId!));

  const { idType, idNumber, idFrontUrl, idBackUrl, selfieUrl } = parsed.data;
  const ref = generateRef();

  if (existing) {
    if (existing.status !== "rejected") {
      res.status(409).json({ error: "KYC already submitted" });
      return;
    }
    const [kyc] = await db
      .update(kycVerificationsTable)
      .set({
        status: "pending",
        referenceNumber: ref,
        idType: idType as "ghana_card" | "passport" | "voter_id",
        idNumber,
        idFrontUrl,
        idBackUrl,
        selfieUrl: selfieUrl ?? null,
        rejectionReason: null,
        reviewedAt: null,
        approvedBy: null,
      })
      .where(eq(kycVerificationsTable.id, existing.id))
      .returning();

    // Clear draft on successful resubmission
    await db.delete(kycDraftsTable).where(eq(kycDraftsTable.userId, req.userId!));
    res.status(200).json(kyc);
    return;
  }

  const [kyc] = await db
    .insert(kycVerificationsTable)
    .values({
      userId: req.userId!,
      referenceNumber: ref,
      status: "pending",
      idType: idType as "ghana_card" | "passport" | "voter_id",
      idNumber,
      idFrontUrl,
      idBackUrl,
      selfieUrl: selfieUrl ?? null,
    })
    .returning();

  // Clear draft on successful submission
  await db.delete(kycDraftsTable).where(eq(kycDraftsTable.userId, req.userId!));

  res.status(201).json(kyc);
});

// ── Status ─────────────────────────────────────────────────────────────────────

router.get("/kyc/me", requireAuth, async (req, res): Promise<void> => {
  const [kyc] = await db
    .select()
    .from(kycVerificationsTable)
    .where(eq(kycVerificationsTable.userId, req.userId!));

  if (!kyc) {
    res.status(404).json({ error: "No KYC submission found" });
    return;
  }
  res.json(GetKycStatusResponse.parse(kyc));
});

export default router;
