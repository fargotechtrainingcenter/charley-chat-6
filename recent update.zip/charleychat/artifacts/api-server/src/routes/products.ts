import { Router, type IRouter } from "express";
import { eq, ilike, and, gte, lte, sql } from "drizzle-orm";
import { db, productsTable, vendorsTable, flashDealsTable } from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { requireKyc } from "../lib/kyc";
import { getRemainingListings } from "../lib/vendor-subscriptions";

const router: IRouter = Router();

function buildProductRecord(
  product: typeof productsTable.$inferSelect & { vendorName: string; flashDealPricePesewas: number | null }
) {
  return {
    id: product.id,
    vendorId: product.vendorId,
    vendorName: product.vendorName,
    name: product.name,
    description: product.description ?? null,
    category: product.category,
    pricePesewas: product.pricePesewas,
    flashDealPricePesewas: product.flashDealPricePesewas,
    images: product.images,
    inStock: product.inStock,
    isWholesale: product.isWholesale,
    moq: product.moq ?? null,
    rating: parseFloat(product.ratingAvg as string),
    reviewCount: product.totalReviews,
    createdAt: product.createdAt.toISOString(),
  };
}

async function getProductsWithJoins(filters: {
  q?: string;
  category?: string;
  vendorId?: string;
  inStock?: boolean;
  wholesale?: boolean;
  minPrice?: number;
  maxPrice?: number;
  limit?: number;
}) {
  const now = new Date();
  const conditions = [];

  if (filters.q) {
    const term = `%${filters.q}%`;
    conditions.push(
      sql`(${ilike(productsTable.name, term)} OR ${ilike(productsTable.description, term)})`
    );
  }
  if (filters.category) {
    conditions.push(eq(productsTable.category, filters.category as typeof productsTable.$inferSelect["category"]));
  }
  if (filters.vendorId) {
    conditions.push(eq(productsTable.vendorId, filters.vendorId));
  }
  if (filters.inStock === true) {
    conditions.push(eq(productsTable.inStock, true));
  }
  if (filters.wholesale === true) {
    conditions.push(eq(productsTable.isWholesale, true));
  }
  if (filters.minPrice !== undefined) {
    conditions.push(gte(productsTable.pricePesewas, filters.minPrice));
  }
  if (filters.maxPrice !== undefined) {
    conditions.push(lte(productsTable.pricePesewas, filters.maxPrice));
  }

  const query = db
    .select({
      id: productsTable.id,
      vendorId: productsTable.vendorId,
      vendorName: vendorsTable.businessName,
      name: productsTable.name,
      description: productsTable.description,
      category: productsTable.category,
      pricePesewas: productsTable.pricePesewas,
      images: productsTable.images,
      inStock: productsTable.inStock,
      isWholesale: productsTable.isWholesale,
      moq: productsTable.moq,
      ratingAvg: productsTable.ratingAvg,
      totalReviews: productsTable.totalReviews,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
      flashDealPricePesewas: sql<number | null>`(
        SELECT fd.deal_price_pesewas FROM flash_deals fd
        WHERE fd.product_id = ${productsTable.id}
          AND fd.is_active = true
          AND fd.ends_at > ${now}
        ORDER BY fd.ends_at ASC
        LIMIT 1
      )`,
    })
    .from(productsTable)
    .innerJoin(vendorsTable, eq(productsTable.vendorId, vendorsTable.id));

  const rows = conditions.length > 0
    ? await query.where(and(...conditions)).limit(filters.limit ?? 100)
    : await query.limit(filters.limit ?? 100);

  return rows.map((r) => buildProductRecord(r as typeof productsTable.$inferSelect & { vendorName: string; flashDealPricePesewas: number | null }));
}

router.get("/products", async (req, res): Promise<void> => {
  const {
    q,
    category,
    vendorId,
    inStock,
    wholesale,
    minPrice,
    maxPrice,
    limit,
  } = req.query as Record<string, string>;

  const products = await getProductsWithJoins({
    q: q?.trim() || undefined,
    category: category || undefined,
    vendorId: vendorId || undefined,
    inStock: inStock === "true" ? true : undefined,
    wholesale: wholesale === "true" ? true : undefined,
    minPrice: minPrice ? parseInt(minPrice) : undefined,
    maxPrice: maxPrice ? parseInt(maxPrice) : undefined,
    limit: limit ? parseInt(limit) : undefined,
  });

  res.json(products);
});

router.get("/products/mine", requireAuth, async (req, res): Promise<void> => {
  const [vendor] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, req.userId!));

  if (!vendor) {
    res.json([]);
    return;
  }

  const products = await getProductsWithJoins({ vendorId: vendor.id });
  res.json(products);
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const productId = String(req.params.id);
  const now = new Date();

  const [row] = await db
    .select({
      id: productsTable.id,
      vendorId: productsTable.vendorId,
      vendorName: vendorsTable.businessName,
      name: productsTable.name,
      description: productsTable.description,
      category: productsTable.category,
      pricePesewas: productsTable.pricePesewas,
      images: productsTable.images,
      inStock: productsTable.inStock,
      isWholesale: productsTable.isWholesale,
      moq: productsTable.moq,
      ratingAvg: productsTable.ratingAvg,
      totalReviews: productsTable.totalReviews,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
      flashDealPricePesewas: sql<number | null>`(
        SELECT fd.deal_price_pesewas FROM flash_deals fd
        WHERE fd.product_id = ${productsTable.id}
          AND fd.is_active = true
          AND fd.ends_at > ${now}
        ORDER BY fd.ends_at ASC
        LIMIT 1
      )`,
    })
    .from(productsTable)
    .innerJoin(vendorsTable, eq(productsTable.vendorId, vendorsTable.id))
    .where(eq(productsTable.id, productId));

  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(buildProductRecord(row as typeof productsTable.$inferSelect & { vendorName: string; flashDealPricePesewas: number | null }));
});

router.post("/products", requireAuth, requireKyc, async (req, res): Promise<void> => {
  const [vendor] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, req.userId!));

  if (!vendor) {
    res.status(403).json({ error: "Must be a registered vendor to create products" });
    return;
  }

  const listings = await getRemainingListings(vendor.id);
  if (!listings) {
    res.status(402).json({
      error: "An active marketplace seller subscription is required to list products.",
      subscriptionRequired: true,
    });
    return;
  }
  if (listings.remaining <= 0) {
    res.status(402).json({
      error: `You've reached your plan's limit of ${listings.limit} listings. Upgrade your subscription to add more products.`,
      subscriptionLimitReached: true,
      productLimit: listings.limit,
    });
    return;
  }

  const { name, description, category, pricePesewas, images, inStock, isWholesale, moq } = req.body;

  if (!name || !category || !pricePesewas || !images) {
    res.status(400).json({ error: "name, category, pricePesewas, and images are required" });
    return;
  }

  const validCategories = ["Electronics", "Fashion", "EV & Bikes", "Wholesale", "Food & Agri", "Beauty"];
  if (!validCategories.includes(category)) {
    res.status(400).json({ error: `category must be one of: ${validCategories.join(", ")}` });
    return;
  }

  const [product] = await db
    .insert(productsTable)
    .values({
      vendorId: vendor.id,
      name,
      description: description ?? null,
      category,
      pricePesewas: parseInt(pricePesewas),
      images: Array.isArray(images) ? images : [images],
      inStock: inStock ?? true,
      isWholesale: isWholesale ?? false,
      moq: moq ? parseInt(moq) : null,
    })
    .returning();

  const productRecord = buildProductRecord({
    ...product,
    vendorName: vendor.id,
    flashDealPricePesewas: null,
  });

  const [vendorRow] = await db
    .select({ businessName: vendorsTable.businessName })
    .from(vendorsTable)
    .where(eq(vendorsTable.id, vendor.id));

  res.status(201).json({ ...productRecord, vendorName: vendorRow?.businessName ?? "" });
});

router.patch("/products/:id", requireAuth, async (req, res): Promise<void> => {
  const productId = String(req.params.id);

  const [vendor] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, req.userId!));

  if (!vendor) {
    res.status(403).json({ error: "Must be a registered vendor" });
    return;
  }

  const [existing] = await db
    .select({ id: productsTable.id, vendorId: productsTable.vendorId })
    .from(productsTable)
    .where(eq(productsTable.id, productId));

  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  if (existing.vendorId !== vendor.id) {
    res.status(403).json({ error: "Not authorized to update this product" });
    return;
  }

  const updates: Record<string, unknown> = {};
  const { name, description, category, pricePesewas, images, inStock, isWholesale, moq } = req.body;

  if (name !== undefined) updates.name = name;
  if (description !== undefined) updates.description = description;
  if (category !== undefined) updates.category = category;
  if (pricePesewas !== undefined) updates.pricePesewas = parseInt(pricePesewas);
  if (images !== undefined) updates.images = Array.isArray(images) ? images : [images];
  if (inStock !== undefined) updates.inStock = inStock;
  if (isWholesale !== undefined) updates.isWholesale = isWholesale;
  if (moq !== undefined) updates.moq = moq ? parseInt(moq) : null;

  const [updated] = await db
    .update(productsTable)
    .set(updates)
    .where(eq(productsTable.id, productId))
    .returning();

  const now = new Date();
  const [flashDeal] = await db
    .select({ dealPricePesewas: flashDealsTable.dealPricePesewas })
    .from(flashDealsTable)
    .where(
      and(
        eq(flashDealsTable.productId, productId),
        eq(flashDealsTable.isActive, true),
        gte(flashDealsTable.endsAt, now)
      )
    );

  const [vendorRow] = await db
    .select({ businessName: vendorsTable.businessName })
    .from(vendorsTable)
    .where(eq(vendorsTable.id, vendor.id));

  res.json(
    buildProductRecord({
      ...updated,
      vendorName: vendorRow?.businessName ?? "",
      flashDealPricePesewas: flashDeal?.dealPricePesewas ?? null,
    })
  );
});

router.delete("/products/:id", requireAuth, async (req, res): Promise<void> => {
  const productId = String(req.params.id);

  const [vendor] = await db
    .select({ id: vendorsTable.id })
    .from(vendorsTable)
    .where(eq(vendorsTable.userId, req.userId!));

  if (!vendor) {
    res.status(403).json({ error: "Must be a registered vendor" });
    return;
  }

  const [existing] = await db
    .select({ id: productsTable.id, vendorId: productsTable.vendorId })
    .from(productsTable)
    .where(eq(productsTable.id, productId));

  if (!existing) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  if (existing.vendorId !== vendor.id) {
    res.status(403).json({ error: "Not authorized to delete this product" });
    return;
  }

  await db.delete(productsTable).where(eq(productsTable.id, productId));
  res.json({ ok: true });
});

export default router;
