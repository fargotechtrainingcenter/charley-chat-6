import { Server } from "socket.io";
import type { Server as HttpServer } from "http";
import jwt from "jsonwebtoken";
import { logger } from "./logger";

let io: Server | null = null;

export function initSocket(httpServer: HttpServer): Server {
  io = new Server(httpServer, {
    cors: { origin: "*" },
    path: "/api/socket.io",
    pingInterval: 25000,
    pingTimeout: 10000,
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth.token as string | undefined;
    if (!token) return next(new Error("unauthorized"));
    const secret = process.env["JWT_SECRET"];
    if (!secret) return next(new Error("server error"));
    try {
      const payload = jwt.verify(token, secret) as { sub: string };
      socket.data.userId = payload.sub;
      next();
    } catch {
      next(new Error("unauthorized"));
    }
  });

  io.on("connection", (socket) => {
    const userId = socket.data.userId as string;
    socket.join(userId);
    logger.info({ userId }, "Socket connected");

    // ── Typing indicators ──────────────────────────────────────────────────
    socket.on("typing", ({ toUserId }: { toUserId: string }) => {
      socket.to(toUserId).emit("typing", { fromUserId: userId });
    });

    socket.on("stop_typing", ({ toUserId }: { toUserId: string }) => {
      socket.to(toUserId).emit("stop_typing", { fromUserId: userId });
    });

    // ── Read receipts ──────────────────────────────────────────────────────
    socket.on("mark_read", ({ fromUserId }: { fromUserId: string }) => {
      socket.to(fromUserId).emit("messages_read", { byUserId: userId });
    });

    // ── Group rooms ────────────────────────────────────────────────────────
    socket.on("join_group", ({ groupId }: { groupId: string }) => {
      socket.join(`group:${groupId}`);
      logger.info({ userId, groupId }, "Joined group room");
    });

    socket.on("leave_group", ({ groupId }: { groupId: string }) => {
      socket.leave(`group:${groupId}`);
    });

    // ── Message acknowledgement ────────────────────────────────────────────
    socket.on("msg_ack", ({ messageId, senderId }: { messageId: string; senderId: string }) => {
      socket.to(senderId).emit("msg_delivered", { messageId, byUserId: userId });
    });

    // ── Heartbeat ──────────────────────────────────────────────────────────
    socket.on("heartbeat", () => {
      socket.emit("heartbeat_ack");
    });

    // ── Call signaling ─────────────────────────────────────────────────────
    // call:busy — called when receiver is already in a call; forwarded to caller
    socket.on("call:busy", ({ callId, callerId }: { callId: string; callerId: string }) => {
      socket.to(callerId).emit("call:busy", { callId });
      logger.info({ callId, userId, callerId }, "Call busy");
    });

    // call:ice_candidate — WebRTC ICE candidate relay (used if/when WebRTC is added)
    socket.on("call:ice_candidate", ({ toUserId, candidate }: { toUserId: string; candidate: unknown }) => {
      socket.to(toUserId).emit("call:ice_candidate", { fromUserId: userId, candidate });
    });

    socket.on("disconnect", (reason) => {
      logger.info({ userId, reason }, "Socket disconnected");
    });
  });

  return io;
}

export function emitToUser(userId: string, event: string, data: unknown): void {
  if (io) io.to(userId).emit(event, data);
}

export function emitToGroup(groupId: string, event: string, data: unknown): void {
  if (io) io.to(`group:${groupId}`).emit(event, data);
}
