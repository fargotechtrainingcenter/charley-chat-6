import { logger } from "./logger";

export const PAYSTACK_SECRET_KEY = process.env["PAYSTACK_SECRET_KEY"] ?? "";
export const PAYSTACK_BASE_URL = "https://api.paystack.co";

if (!PAYSTACK_SECRET_KEY) {
  logger.warn("PAYSTACK_SECRET_KEY is not set — Paystack payments will fail");
}

/** Make an authenticated request to the Paystack REST API. */
export async function paystackRequest<T>(
  method: "GET" | "POST",
  path: string,
  body?: object,
): Promise<T> {
  const res = await fetch(`${PAYSTACK_BASE_URL}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const json = (await res.json()) as { status: boolean; message: string; data: T };

  if (!json.status) {
    throw new Error(`Paystack API error (${path}): ${json.message}`);
  }

  return json.data;
}
