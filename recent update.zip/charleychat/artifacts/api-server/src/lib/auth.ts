import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import type { Request, Response, NextFunction } from "express";
import { logger } from "./logger";

const IS_PROD = process.env.NODE_ENV === "production";

function requireSecret(name: string, fallback: string): string {
  const value = process.env[name];
  if (!value) {
    if (IS_PROD) {
      logger.error(`${name} environment variable is required in production but was not set. Exiting.`);
      process.exit(1);
    }
    logger.warn(`${name} is not set — using insecure dev fallback. Set this env var before going live.`);
    return fallback;
  }
  return value;
}

const JWT_SECRET = requireSecret("JWT_SECRET", "fargopay-dev-secret-change-in-production");
const JWT_REFRESH_SECRET = requireSecret("JWT_REFRESH_SECRET", "fargopay-dev-refresh-secret-change-in-production");
const ADMIN_JWT_SECRET = requireSecret("ADMIN_JWT_SECRET", "fargopay-admin-dev-secret-change-in-production");

declare global {
  namespace Express {
    interface Request {
      userId?: string;
      adminId?: string;
      adminRole?: string;
    }
  }
}

export async function hashPin(pin: string): Promise<string> {
  return bcrypt.hash(pin, 12);
}

export async function verifyPin(pin: string, hash: string): Promise<boolean> {
  return bcrypt.compare(pin, hash);
}

export function signAccessToken(userId: string): string {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: "24h" });
}

export function signRefreshToken(userId: string): string {
  return jwt.sign({ sub: userId }, JWT_REFRESH_SECRET, { expiresIn: "7d" });
}

export function verifyAccessToken(token: string): { sub: string } {
  return jwt.verify(token, JWT_SECRET) as { sub: string };
}

export function verifyRefreshToken(token: string): { sub: string } {
  return jwt.verify(token, JWT_REFRESH_SECRET) as { sub: string };
}

/** Like requireAuth but doesn't reject — sets req.userId if a valid token is present, otherwise continues as guest. */
export function optionalAuth(req: Request, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    try {
      const payload = verifyAccessToken(token);
      req.userId = payload.sub;
    } catch { /* ignore — treat as guest */ }
  }
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing or invalid authorization header" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    const payload = verifyAccessToken(token);
    req.userId = payload.sub;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired access token" });
  }
}

export function signAdminToken(adminId: string, role: string): string {
  return jwt.sign({ sub: adminId, role }, ADMIN_JWT_SECRET, { expiresIn: "8h" });
}

export function verifyAdminToken(token: string): { sub: string; role: string } {
  return jwt.verify(token, ADMIN_JWT_SECRET) as { sub: string; role: string };
}

export function requireAdminAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing or invalid authorization header" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    const payload = verifyAdminToken(token);
    req.adminId = payload.sub;
    req.adminRole = payload.role;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired admin token" });
  }
}

export function requireSuperAdmin(req: Request, res: Response, next: NextFunction): void {
  requireAdminAuth(req, res, () => {
    if (req.adminRole !== "super_admin") {
      res.status(403).json({ error: "Super admin access required" });
      return;
    }
    next();
  });
}
