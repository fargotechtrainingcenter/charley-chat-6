/**
 * AliExpress schema migration
 *
 * Creates the aliexpress_import_jobs table and adds AliExpress columns to
 * africart_products if they don't already exist.  Runs idempotently at server
 * startup so the feature works on any existing DB without a manual step.
 */

import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { logger } from "./logger";

export async function runAliexpressMigration(): Promise<void> {
  try {
    // 1. Add AliExpress columns to africart_products (idempotent via IF NOT EXISTS)
    await db.execute(sql`
      ALTER TABLE africart_products
        ADD COLUMN IF NOT EXISTS aliexpress_product_id    text,
        ADD COLUMN IF NOT EXISTS aliexpress_price_pesewas integer,
        ADD COLUMN IF NOT EXISTS aliexpress_synced_at     timestamptz,
        ADD COLUMN IF NOT EXISTS aliexpress_raw           jsonb
    `);

    // Index on aliexpress_product_id for fast sync lookups
    await db.execute(sql`
      CREATE INDEX IF NOT EXISTS africart_products_aliexpress_product_id_idx
        ON africart_products (aliexpress_product_id)
        WHERE aliexpress_product_id IS NOT NULL
    `);

    // 2. Create aliexpress_import_jobs table (idempotent)
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS aliexpress_import_jobs (
        id                    uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
        vendor_id             uuid        NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
        aliexpress_product_id text        NOT NULL,
        aliexpress_title      text,
        status                text        NOT NULL DEFAULT 'queued'
                                          CHECK (status IN ('queued','importing','done','failed')),
        error                 text,
        africart_product_id   uuid        REFERENCES africart_products(id) ON DELETE SET NULL,
        vendor_price_pesewas  integer,
        created_at            timestamptz NOT NULL DEFAULT now(),
        updated_at            timestamptz NOT NULL DEFAULT now()
      )
    `);

    // Indexes (idempotent)
    await db.execute(sql`
      CREATE INDEX IF NOT EXISTS aliexpress_import_jobs_vendor_id_idx
        ON aliexpress_import_jobs (vendor_id)
    `);
    await db.execute(sql`
      CREATE INDEX IF NOT EXISTS aliexpress_import_jobs_status_idx
        ON aliexpress_import_jobs (status)
    `);
    await db.execute(sql`
      CREATE INDEX IF NOT EXISTS aliexpress_import_jobs_aliexpress_product_id_idx
        ON aliexpress_import_jobs (aliexpress_product_id)
    `);

    logger.info("AliExpress migration: schema up to date");
  } catch (err) {
    logger.error({ err }, "AliExpress migration: failed");
    throw err;
  }
}
