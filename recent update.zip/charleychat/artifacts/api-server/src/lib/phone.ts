/**
 * Normalise any Ghanaian phone number format to 0XXXXXXXXX (10 digits).
 * Handles: +233XXXXXXXXX, 233XXXXXXXXX, XXXXXXXXX (9-digit missing leading 0), 0XXXXXXXXX,
 * and formats with spaces/dashes.
 *
 * This is the single source of truth for phone normalisation. Any route that looks up
 * a user by phone number (contacts, wallets/send, escrow, payment links, users/:phone,
 * discovery, etc.) MUST normalise through this function before querying — phone numbers
 * are always stored in the DB as 0XXXXXXXXX, but users can type +233/233/9-digit formats.
 */
export function normalizePhone(raw: string): string {
  const digits = raw.trim().replace(/\D/g, "");
  if (digits.startsWith("233") && digits.length >= 12) return "0" + digits.slice(3);
  if (digits.startsWith("0") && digits.length === 10) return digits;
  if (digits.length === 9) return "0" + digits;
  return digits;
}
