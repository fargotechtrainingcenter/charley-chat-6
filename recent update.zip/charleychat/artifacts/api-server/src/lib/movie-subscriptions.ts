import { eq, and, lt, gt, isNull, sql } from "drizzle-orm";
import { db, movieSubscriptionsTable, walletsTable, transactionsTable, notificationsTable } from "@workspace/db";
import { logger } from "./logger";
import { sendPushToUser } from "../routes/push";

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
const REMINDER_WINDOW_MS = 3 * 24 * 60 * 60 * 1000; // remind 3 days before expiry

export function startMovieSubscriptionJob(): void {
  const sweep = async () => {
    try {
      // 1. Expiry reminders — active subs expiring within 3 days that haven't been reminded yet
      const soonToExpire = await db
        .select()
        .from(movieSubscriptionsTable)
        .where(
          and(
            eq(movieSubscriptionsTable.status, "active"),
            lt(movieSubscriptionsTable.expiresAt, new Date(Date.now() + REMINDER_WINDOW_MS)),
            gt(movieSubscriptionsTable.expiresAt, new Date()),
            isNull(movieSubscriptionsTable.reminderSentAt),
          ),
        );

      for (const sub of soonToExpire) {
        const body = sub.autoRenew
          ? `Your movie subscription renews automatically in a few days for GH₵${(sub.pricePesewas / 100).toFixed(2)}.`
          : `Your movie subscription expires soon. Renew to keep streaming premium titles.`;
        await db.insert(notificationsTable).values({ userId: sub.userId, title: "Movie subscription expiring soon", body, type: "movie_subscription" });
        await db.update(movieSubscriptionsTable).set({ reminderSentAt: new Date() }).where(eq(movieSubscriptionsTable.id, sub.id));
        void sendPushToUser(sub.userId, { title: "Subscription expiring soon", body });
      }

      // 2. Actually-expired subscriptions — auto-renew or expire
      const expired = await db
        .select()
        .from(movieSubscriptionsTable)
        .where(and(eq(movieSubscriptionsTable.status, "active"), lt(movieSubscriptionsTable.expiresAt, new Date())));

      for (const sub of expired) {
        if (sub.autoRenew) {
          const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, sub.userId));
          if (wallet && wallet.balancePesewas >= sub.pricePesewas) {
            await db.transaction(async (trx) => {
              await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${sub.pricePesewas}` }).where(eq(walletsTable.id, wallet.id));
              await trx.insert(transactionsTable).values({
                walletId: wallet.id,
                type: "bill_payment",
                amountPesewas: sub.pricePesewas,
                feePesewas: 0,
                reference: `MOVIESUB-RENEW-${Date.now()}`,
                status: "completed",
                note: "Movie streaming subscription auto-renewal",
              });
              await trx.update(movieSubscriptionsTable).set({ status: "cancelled", cancelledAt: new Date() }).where(eq(movieSubscriptionsTable.id, sub.id));
              await trx.insert(movieSubscriptionsTable).values({
                userId: sub.userId,
                expiresAt: new Date(Date.now() + THIRTY_DAYS_MS),
                pricePesewas: sub.pricePesewas,
              });
            });
            await db.insert(notificationsTable).values({
              userId: sub.userId,
              title: "Movie subscription renewed",
              body: `Your movie subscription was auto-renewed for another 30 days.`,
              type: "movie_subscription",
            });
            void sendPushToUser(sub.userId, { title: "Subscription renewed", body: "Your movie subscription was auto-renewed." });
            continue;
          }
        }

        await db.update(movieSubscriptionsTable).set({ status: "expired" }).where(eq(movieSubscriptionsTable.id, sub.id));
        await db.insert(notificationsTable).values({
          userId: sub.userId,
          title: "Movie subscription expired",
          body: "Your movie subscription has expired. Resubscribe to keep streaming premium titles.",
          type: "movie_subscription",
        });
        void sendPushToUser(sub.userId, { title: "Subscription expired", body: "Resubscribe to keep streaming." });
      }
    } catch (err) {
      logger.error({ err }, "Movie subscription sweep failed");
    }
  };

  setInterval(sweep, 60 * 60 * 1000); // hourly
  void sweep();
}
