import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import type { Request, Response, NextFunction } from "express";

export async function requireKyc(req: Request, res: Response, next: NextFunction): Promise<void> {
  const userId = req.userId;
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const [user] = await db.select({ isKycVerified: usersTable.isKycVerified }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user?.isKycVerified) {
    res.status(403).json({ error: "KYC verification required", kycRequired: true }); return;
  }
  next();
}
