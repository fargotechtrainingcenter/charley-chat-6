import { eq, and, lt, sql } from "drizzle-orm";
import {
  db,
  vendorsTable,
  vendorSubscriptionsTable,
  VENDOR_SUBSCRIPTION_TIERS,
  productsTable,
  walletsTable,
  transactionsTable,
  notificationsTable,
} from "@workspace/db";
import { logger } from "./logger";
import { sendPushToUser } from "../routes/push";

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export async function getActiveSubscription(vendorId: string) {
  const [sub] = await db
    .select()
    .from(vendorSubscriptionsTable)
    .where(and(eq(vendorSubscriptionsTable.vendorId, vendorId), eq(vendorSubscriptionsTable.status, "active")))
    .orderBy(sql`${vendorSubscriptionsTable.expiresAt} desc`)
    .limit(1);

  if (!sub) return null;
  if (sub.expiresAt.getTime() < Date.now()) return null; // expired but not yet swept by the background job
  return sub;
}

export function tierForProductCount(count: number): keyof typeof VENDOR_SUBSCRIPTION_TIERS {
  return count > VENDOR_SUBSCRIPTION_TIERS.basic.productLimit ? "pro" : "basic";
}

/**
 * Subscribe or renew. If there's a still-active subscription of the same or
 * higher tier, extends from its current expiry rather than losing paid days;
 * otherwise starts a fresh 30-day period from now. Deducts the wallet
 * immediately — caller is responsible for checking balance first if a
 * friendlier error message is wanted before this throws.
 */
export async function subscribeVendor(vendorId: string, userId: string, tier: keyof typeof VENDOR_SUBSCRIPTION_TIERS) {
  const { productLimit, pricePesewas } = VENDOR_SUBSCRIPTION_TIERS[tier];

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, userId));
  if (!wallet || wallet.balancePesewas < pricePesewas) {
    throw Object.assign(new Error("Insufficient wallet balance"), { code: "INSUFFICIENT_FUNDS", pricePesewas });
  }

  const existing = await getActiveSubscription(vendorId);
  const startBase = existing && existing.tier === tier ? existing.expiresAt.getTime() : Date.now();
  const expiresAt = new Date(startBase + THIRTY_DAYS_MS);

  return db.transaction(async (trx) => {
    if (existing) {
      await trx.update(vendorSubscriptionsTable).set({ status: "cancelled", cancelledAt: new Date() }).where(eq(vendorSubscriptionsTable.id, existing.id));
    }
    await trx.update(walletsTable).set({ balancePesewas: sql`${walletsTable.balancePesewas} - ${pricePesewas}` }).where(eq(walletsTable.id, wallet.id));
    await trx.insert(transactionsTable).values({
      walletId: wallet.id,
      type: "bill_payment",
      amountPesewas: pricePesewas,
      feePesewas: 0,
      reference: `VENDORSUB-${Date.now()}`,
      status: "completed",
      note: `Marketplace seller subscription (${tier})`,
    });
    const [sub] = await trx
      .insert(vendorSubscriptionsTable)
      .values({ vendorId, tier, productLimit, pricePesewas, expiresAt })
      .returning();
    return sub;
  });
}

/** How many more listings this vendor can create right now under their active plan. */
export async function getRemainingListings(vendorId: string): Promise<{ limit: number; used: number; remaining: number } | null> {
  const sub = await getActiveSubscription(vendorId);
  if (!sub) return null;
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable)
    .where(eq(productsTable.vendorId, vendorId));
  return { limit: sub.productLimit, used: count, remaining: Math.max(0, sub.productLimit - count) };
}

/**
 * Background job: sweep expired subscriptions every hour. Auto-renews ones
 * with autoRenew=true and sufficient wallet balance; otherwise marks expired
 * and notifies the vendor so they know listings may become hidden/blocked.
 */
export function startVendorSubscriptionRenewalJob(): void {
  const sweep = async () => {
    try {
      const expiring = await db
        .select()
        .from(vendorSubscriptionsTable)
        .where(and(eq(vendorSubscriptionsTable.status, "active"), lt(vendorSubscriptionsTable.expiresAt, new Date())));

      for (const sub of expiring) {
        const [vendor] = await db.select().from(vendorsTable).where(eq(vendorsTable.id, sub.vendorId));
        if (!vendor) continue;

        if (sub.autoRenew) {
          try {
            await subscribeVendor(sub.vendorId, vendor.userId, sub.tier);
            await db.insert(notificationsTable).values({
              userId: vendor.userId,
              title: "Seller subscription renewed",
              body: `Your ${sub.tier} marketplace subscription was auto-renewed for another 30 days.`,
              type: "vendor_subscription",
            });
            void sendPushToUser(vendor.userId, { title: "Subscription renewed", body: "Your marketplace subscription was auto-renewed." });
            continue;
          } catch {
            // Fall through to marking expired — insufficient funds or other error
          }
        }

        await db.update(vendorSubscriptionsTable).set({ status: "expired" }).where(eq(vendorSubscriptionsTable.id, sub.id));
        await db.insert(notificationsTable).values({
          userId: vendor.userId,
          title: "Seller subscription expired",
          body: "Your marketplace subscription has expired. Renew to keep your listings visible and add new products.",
          type: "vendor_subscription",
        });
        void sendPushToUser(vendor.userId, { title: "Subscription expired", body: "Renew your marketplace subscription to keep selling." });
      }
    } catch (err) {
      logger.error({ err }, "Vendor subscription renewal sweep failed");
    }
  };

  setInterval(sweep, 60 * 60 * 1000); // hourly
  void sweep(); // also run once at startup
}
