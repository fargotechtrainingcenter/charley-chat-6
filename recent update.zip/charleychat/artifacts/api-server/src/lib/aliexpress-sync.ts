/**
 * AliExpress background sync worker
 *
 * Queries all africart_products with aliexpress_product_id set,
 * fetches fresh product details, and updates price/stock if changed.
 * Runs every 6 hours on server startup.
 * Errors for individual products do not abort the full run.
 */

import { sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { logger } from "./logger";
import { getProductDetail, AliexpressApiError } from "./aliexpress-client";

export async function syncAliexpressProducts(): Promise<void> {
  const start = Date.now();
  logger.info("AliExpress sync: starting");

  const result = await db.execute(sql`
    SELECT id, aliexpress_product_id, in_stock, aliexpress_price_pesewas
    FROM africart_products
    WHERE aliexpress_product_id IS NOT NULL
      AND is_deleted = false
    ORDER BY aliexpress_synced_at ASC NULLS FIRST
    LIMIT 500
  `);
  const rows = (result.rows ?? result) as any[];

  let checked = 0;
  let updated = 0;
  let failed = 0;

  for (const row of rows) {
    const productId = row.id as string;
    const aliexpressId = row.aliexpress_product_id as string;

    try {
      const detail = await getProductDetail(aliexpressId);

      const newInStock = detail.stock > 0;
      const stockChanged = newInStock !== (row.in_stock as boolean);

      // Compare source price using the structured aliexpress_price_pesewas column (integer)
      const USD_TO_GHS = 15.5;
      const newPricePesewas = Math.round(detail.price * USD_TO_GHS * 100);
      const oldPricePesewas = row.aliexpress_price_pesewas != null
        ? parseInt(row.aliexpress_price_pesewas as string, 10)
        : null;
      const priceChanged =
        oldPricePesewas !== null &&
        Math.abs(newPricePesewas - oldPricePesewas) / (oldPricePesewas || 1) > 0.01;

      const aliexpressRaw = JSON.stringify(detail);

      await db.execute(sql`
        UPDATE africart_products
        SET
          in_stock = ${newInStock},
          aliexpress_price_pesewas = ${newPricePesewas},
          aliexpress_synced_at = NOW(),
          aliexpress_raw = ${aliexpressRaw}::jsonb,
          updated_at = NOW()
        WHERE id = ${productId}::uuid
      `);

      if (stockChanged) {
        logger.info(
          { productId, aliexpressId, inStock: newInStock },
          "AliExpress sync: stock availability changed",
        );
        updated++;
      }
      if (priceChanged) {
        logger.warn(
          {
            productId,
            aliexpressId,
            oldPricePesewas,
            newPricePesewas,
          },
          "AliExpress sync: source price changed — vendor margin may be affected",
        );
        if (!stockChanged) updated++; // count price-only changes once
      }
      checked++;
    } catch (err) {
      failed++;
      const msg = err instanceof AliexpressApiError
        ? `AliexpressApiError code=${err.code}: ${err.message}`
        : String(err).slice(0, 200);
      logger.warn(
        { productId, aliexpressId, err: msg },
        "AliExpress sync: product update failed — skipping",
      );
    }
  }

  logger.info(
    { checked, updated, failed, elapsedMs: Date.now() - start },
    "AliExpress sync: complete",
  );
}

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

export function startAliexpressSyncJob(): void {
  logger.info("AliExpress sync: registering 6-hour background job");
  setInterval(() => {
    syncAliexpressProducts().catch((err) => {
      logger.error({ err }, "AliExpress sync: unhandled error in scheduled run");
    });
  }, SIX_HOURS_MS);
}
