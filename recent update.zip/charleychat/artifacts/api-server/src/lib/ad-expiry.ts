import { and, eq, lt } from "drizzle-orm";
import { db, adsTable } from "@workspace/db";
import { logger } from "./logger";

/** Marks active ads whose duration has elapsed as completed. Runs hourly. */
export function startAdExpirySweepJob(): void {
  const sweep = async () => {
    try {
      await db
        .update(adsTable)
        .set({ status: "completed" })
        .where(and(eq(adsTable.status, "active"), lt(adsTable.endsAt, new Date())));
    } catch (err) {
      logger.error({ err }, "Ad expiry sweep failed");
    }
  };

  setInterval(sweep, 60 * 60 * 1000); // hourly
  void sweep();
}
