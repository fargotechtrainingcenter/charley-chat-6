/**
 * AliExpress Open Platform (Dropship) API client
 *
 * Handles HMAC-MD5 request signing, rate-limit retry, and response normalization.
 * Credentials are read from environment variables only — never exposed to browsers.
 *
 * Reference: https://developers.aliexpress.com/en/doc.htm
 */

import crypto from "crypto";
import { logger } from "./logger";

const APP_KEY = process.env["ALIEXPRESS_APP_KEY"] ?? "";
const APP_SECRET = process.env["ALIEXPRESS_APP_SECRET"] ?? "";
const ACCESS_TOKEN = process.env["ALIEXPRESS_ACCESS_TOKEN"] ?? "";

const BASE_URL = "https://api-sg.aliexpress.com/rest";
const DS_BASE_URL = "https://api-sg.aliexpress.com/sync";

if (!APP_KEY || !APP_SECRET) {
  logger.warn("ALIEXPRESS_APP_KEY or ALIEXPRESS_APP_SECRET not set — AliExpress import will return mock data");
}

// ── Types ─────────────────────────────────────────────────────────────────────

export interface AliexpressProductVariant {
  skuId: string;
  sku: string;
  price: number;
  stock: number;
  attributes: Record<string, string>;
}

export interface AliexpressShippingOption {
  company: string;
  price: number;
  estimatedDays: string;
  trackable: boolean;
}

export interface AliexpressProductDetail {
  productId: string;
  title: string;
  description: string;
  images: string[];
  category: string;
  price: number;
  priceMin: number;
  priceMax: number;
  stock: number;
  variants: AliexpressProductVariant[];
  shippingOptions: AliexpressShippingOption[];
  originCountry: string;
  weight: string;
  evaluation: { rating: number; reviewCount: number };
}

export interface AliexpressSearchResult {
  productId: string;
  title: string;
  image: string;
  price: number;
  priceMin: number;
  priceMax: number;
  stock: number;
  category: string;
  originCountry: string;
}

export interface AliexpressSearchResponse {
  products: AliexpressSearchResult[];
  total: number;
  page: number;
  pageSize: number;
}

// ── Signature ─────────────────────────────────────────────────────────────────

function sign(params: Record<string, string>, secret: string): string {
  const sorted = Object.entries(params)
    .filter(([k]) => k !== "sign")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}${v}`)
    .join("");
  const toSign = `${secret}${sorted}${secret}`;
  return crypto.createHash("md5").update(toSign, "utf8").digest("hex").toUpperCase();
}

// ── HTTP helper with timing log ───────────────────────────────────────────────

async function callApi(
  method: string,
  params: Record<string, string>,
  retries = 2,
): Promise<Record<string, unknown>> {
  const timestamp = String(Date.now());
  const baseParams: Record<string, string> = {
    method,
    app_key: APP_KEY,
    access_token: ACCESS_TOKEN,
    timestamp,
    sign_method: "md5",
    ...params,
  };
  baseParams["sign"] = sign(baseParams, APP_SECRET);

  const url = new URL(DS_BASE_URL);
  Object.entries(baseParams).forEach(([k, v]) => url.searchParams.set(k, v));

  const start = Date.now();
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url.toString(), {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });
      const elapsed = Date.now() - start;
      const body = await res.json() as Record<string, unknown>;

      logger.info(
        { method, statusCode: res.status, elapsedMs: elapsed },
        "AliExpress API call",
      );

      if (!res.ok) {
        const errBody = JSON.stringify(body).slice(0, 200);
        logger.warn({ method, statusCode: res.status, body: errBody }, "AliExpress API non-OK response");
        throw new AliexpressApiError(`HTTP ${res.status}`, res.status, body);
      }

      const errorResponse = body["error_response"] as Record<string, unknown> | undefined;
      if (errorResponse) {
        const code = errorResponse["code"] as number | undefined;
        const msg = errorResponse["msg"] as string | undefined;
        const subMsg = errorResponse["sub_msg"] as string | undefined;

        if (code === 27 || String(msg).toLowerCase().includes("rate") || String(subMsg).toLowerCase().includes("rate")) {
          const waitMs = Math.pow(2, attempt) * 1000;
          logger.warn({ method, attempt, waitMs }, "AliExpress rate limited — retrying");
          await sleep(waitMs);
          continue;
        }
        throw new AliexpressApiError(subMsg ?? msg ?? "AliExpress API error", code ?? 0, errorResponse);
      }

      return body;
    } catch (err) {
      if (err instanceof AliexpressApiError) throw err;
      lastError = err as Error;
      if (attempt < retries) {
        await sleep(Math.pow(2, attempt) * 500);
      }
    }
  }
  throw lastError ?? new AliexpressApiError("Request failed after retries", 0, {});
}

export class AliexpressApiError extends Error {
  constructor(
    message: string,
    public readonly code: number,
    public readonly details: Record<string, unknown>,
  ) {
    super(message);
    this.name = "AliexpressApiError";
  }
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

// ── Mock data (used when credentials are not set) ────────────────────────────

function mockSearchResults(keyword: string, page: number, pageSize: number): AliexpressSearchResponse {
  const results: AliexpressSearchResult[] = Array.from({ length: pageSize }, (_, i) => ({
    productId: `MOCK_${(page - 1) * pageSize + i + 1}`,
    title: `${keyword} Product ${(page - 1) * pageSize + i + 1}`,
    image: `https://picsum.photos/seed/${keyword}-${i}/300/300`,
    price: Math.round((5 + Math.random() * 95) * 100) / 100,
    priceMin: Math.round((3 + Math.random() * 20) * 100) / 100,
    priceMax: Math.round((80 + Math.random() * 120) * 100) / 100,
    stock: Math.floor(Math.random() * 500 + 10),
    category: "Electronics",
    originCountry: "CN",
  }));
  return { products: results, total: 100, page, pageSize };
}

function mockProductDetail(productId: string): AliexpressProductDetail {
  return {
    productId,
    title: `AliExpress Product ${productId}`,
    description: `<p>High quality product imported from AliExpress. This is a detailed description for product ${productId}. Features include durability, modern design, and excellent value for money.</p>`,
    images: Array.from({ length: 4 }, (_, i) => `https://picsum.photos/seed/${productId}-${i}/600/600`),
    category: "Electronics",
    price: 25.99,
    priceMin: 19.99,
    priceMax: 35.99,
    stock: 250,
    variants: [
      { skuId: "sku-1", sku: "RED-S", price: 25.99, stock: 50, attributes: { Color: "Red", Size: "S" } },
      { skuId: "sku-2", sku: "RED-M", price: 25.99, stock: 80, attributes: { Color: "Red", Size: "M" } },
      { skuId: "sku-3", sku: "BLUE-M", price: 27.99, stock: 120, attributes: { Color: "Blue", Size: "M" } },
    ],
    shippingOptions: [
      { company: "AliExpress Standard Shipping", price: 0, estimatedDays: "15-25", trackable: true },
      { company: "DHL", price: 12.99, estimatedDays: "7-10", trackable: true },
    ],
    originCountry: "CN",
    weight: "0.5 kg",
    evaluation: { rating: 4.5, reviewCount: 1240 },
  };
}

// ── Public API methods ────────────────────────────────────────────────────────

export async function searchProducts(
  keyword: string,
  category?: string,
  page = 1,
  pageSize = 20,
): Promise<AliexpressSearchResponse> {
  if (!APP_KEY || !APP_SECRET) {
    logger.info({ keyword, page }, "AliExpress search: using mock data (no credentials)");
    return mockSearchResults(keyword, page, pageSize);
  }

  const params: Record<string, string> = {
    keywords: keyword,
    page_no: String(page),
    page_size: String(Math.min(pageSize, 50)),
    sort: "SALE_PRICE_ASC",
    ship_to_country: "GH",
    target_currency: "USD",
    target_language: "EN",
  };
  if (category) params["category_ids"] = category;

  const body = await callApi("aliexpress.affiliate.product.query", params);
  const resp = (body["aliexpress_affiliate_product_query_response"] as Record<string, unknown> | undefined) ?? {};
  const result = (resp["resp_result"] as Record<string, unknown> | undefined) ?? {};
  const resultObj = (result["result"] as Record<string, unknown> | undefined) ?? {};
  const products = ((resultObj["products"] as Record<string, unknown> | undefined)?.["product"] as any[]) ?? [];

  return {
    products: products.map((p: any) => ({
      productId: String(p["product_id"] ?? p["productId"] ?? ""),
      title: String(p["product_title"] ?? p["title"] ?? ""),
      image: String(p["product_main_image_url"] ?? p["imageUrl"] ?? ""),
      price: parseFloat(p["target_sale_price"] ?? p["sale_price"] ?? 0),
      priceMin: parseFloat(p["min_price"] ?? p["target_sale_price"] ?? 0),
      priceMax: parseFloat(p["max_price"] ?? p["target_sale_price"] ?? 0),
      stock: parseInt(p["quantity"] ?? 999),
      category: String(p["second_level_category_name"] ?? p["first_level_category_name"] ?? ""),
      originCountry: String(p["ship_from_country"] ?? "CN"),
    })),
    total: parseInt(String(resultObj["total_record_count"] ?? 0)),
    page,
    pageSize,
  };
}

export async function getProductDetail(productId: string): Promise<AliexpressProductDetail> {
  if (!APP_KEY || !APP_SECRET) {
    logger.info({ productId }, "AliExpress product detail: using mock data (no credentials)");
    return mockProductDetail(productId);
  }

  const params: Record<string, string> = {
    product_ids: productId,
    target_currency: "USD",
    target_language: "EN",
    ship_to_country: "GH",
    fields: "product_id,product_title,product_description,image_u_r_l_list,product_video_url,sku_price_list,product_price,sale_price,discount,evaluation_info,logistics_info,product_stock,product_price,product_category_id,base_info",
  };

  const body = await callApi("aliexpress.ds.product.get", params);
  const resp = (body["aliexpress_ds_product_get_response"] as Record<string, unknown> | undefined) ?? {};
  const result = (resp["result"] as Record<string, unknown> | undefined) ?? {};

  const baseInfo = (result["ae_item_base_info_dto"] as Record<string, unknown> | undefined) ?? {};
  const skuList = ((result["ae_item_sku_info_dtos"] as Record<string, unknown>)?.["ae_item_sku_info_d_t_o"] as any[]) ?? [];
  const imageList = ((result["ae_multimedia_info_dto"] as Record<string, unknown>)?.["image_urls"] as string ?? "").split(";").filter(Boolean);
  const logisticsWrapper = (result["ae_item_logistics_info_dto"] as Record<string, unknown> | undefined) ?? {};
  const logisticsList = ((logisticsWrapper["ae_delivery_option_d_t_o"] as any[]) ?? []);
  const evaluationInfo = (result["ae_item_properties"] as Record<string, unknown> | undefined) ?? {};

  const variants: AliexpressProductVariant[] = skuList.map((sku: any) => {
    const attrs: Record<string, string> = {};
    const propList = (sku["ae_sku_property_dtos"] as Record<string, unknown>)?.["ae_sku_property_d_t_o"] as any[] ?? [];
    propList.forEach((p: any) => { attrs[p["sku_property_name"]] = p["property_value_definition_name"] ?? p["sku_property_value"]; });
    return {
      skuId: String(sku["sku_id"] ?? ""),
      sku: String(sku["sku_code"] ?? sku["sku_id"] ?? ""),
      price: parseFloat(sku["offer_sale_price"] ?? sku["sku_price"] ?? 0),
      stock: parseInt(sku["sku_available_stock"] ?? 0),
      attributes: attrs,
    };
  });

  const shippingOptions: AliexpressShippingOption[] = logisticsList.map((l: any) => ({
    company: String(l["company"] ?? l["logistics_company"] ?? "Standard"),
    price: parseFloat(l["freight"] ?? l["shipping_fee"] ?? 0),
    estimatedDays: String(l["time"] ?? l["delivery_time_desc"] ?? ""),
    trackable: Boolean(l["is_tracking_info"]),
  }));

  return {
    productId,
    title: String(baseInfo["subject"] ?? result["product_title"] ?? ""),
    description: String((result["ae_item_desc"] as Record<string, unknown>)?.["module_value"] ?? baseInfo["detail"] ?? ""),
    images: imageList.length ? imageList : [String(baseInfo["product_image"] ?? "")].filter(Boolean),
    category: String(baseInfo["category_id"] ?? ""),
    price: parseFloat(String(baseInfo["sale_price"] ?? baseInfo["price"] ?? 0)),
    priceMin: parseFloat(String(baseInfo["min_price"] ?? baseInfo["sale_price"] ?? 0)),
    priceMax: parseFloat(String(baseInfo["max_price"] ?? baseInfo["sale_price"] ?? 0)),
    stock: parseInt(String(baseInfo["total_available_stock"] ?? 0)),
    variants,
    shippingOptions: shippingOptions.length ? shippingOptions : [{ company: "Standard Shipping", price: 0, estimatedDays: "15-25", trackable: true }],
    originCountry: String(baseInfo["product_source_country"] ?? "CN"),
    weight: String((result["package_info_dto"] as any)?.["gross_weight"] ?? ""),
    evaluation: {
      rating: parseFloat(String((result["evaluation_count"] as any)?.["five_star_rate"] ?? 0)) / 20,
      reviewCount: parseInt(String((result["evaluation_count"] as any)?.["evaluation_count"] ?? 0)),
    },
  };
}

export async function getShippingOptions(productId: string, countryCode = "GH"): Promise<AliexpressShippingOption[]> {
  const detail = await getProductDetail(productId);
  return detail.shippingOptions;
}
