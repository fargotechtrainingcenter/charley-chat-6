/**
 * Charley Wallet transaction charges.
 *
 * Tiers (per spec):
 *  - MoMo / bank transfers GH₵50–GH₵1,999.99  → 1%
 *  - MoMo / bank transfers GH₵2,000+          → 2%
 *  - Wallet-to-wallet transfers between Charley users → 0.65%
 *  - Bill payments → 1%
 *
 * Amounts below GH₵50 for MoMo/bank transfers are not covered by an explicit
 * tier in the spec, so they're treated as fee-free (0%) rather than guessing
 * a rate — flag this with product if a small-transfer fee is actually wanted.
 *
 * The fee is always added ON TOP of the amount the sender specifies — the
 * sender is debited (amount + fee), and the recipient/biller/wallet-funding
 * destination always receives the full amount the sender entered, with
 * nothing skimmed off their side. This is what lets the UI show "You pay
 * GH₵X + GH₵Y fee = GH₵Z" before confirmation, and the recipient never has
 * to wonder why they received less than expected.
 */

const PESEWAS_PER_GHS = 100;

function ghsToPesewas(ghs: number): number {
  return Math.round(ghs * PESEWAS_PER_GHS);
}

/** MoMo / bank transfer fee — used for wallet deposit (funding in) and withdrawal (cash out). */
export function calculateTransferFeePesewas(amountPesewas: number): number {
  const tier2000 = ghsToPesewas(2000);
  const tier50 = ghsToPesewas(50);
  if (amountPesewas >= tier2000) return Math.round(amountPesewas * 0.02);
  if (amountPesewas >= tier50) return Math.round(amountPesewas * 0.01);
  return 0;
}

/** Wallet-to-wallet (P2P) transfer fee between two Charley users. */
export function calculateP2PFeePesewas(amountPesewas: number): number {
  return Math.round(amountPesewas * 0.0065);
}

/** Bill payment service charge. */
export function calculateBillFeePesewas(amountPesewas: number): number {
  return Math.round(amountPesewas * 0.01);
}
