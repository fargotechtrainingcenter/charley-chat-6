import { createServer } from "http";
import app from "./app";
import { initSocket } from "./lib/socket";
import { logger } from "./lib/logger";
import { runSeedIfEmpty } from "./routes/seed";
import { startAliexpressSyncJob } from "./lib/aliexpress-sync";
import { runAliexpressMigration } from "./lib/aliexpress-migration";
import { startVendorSubscriptionRenewalJob } from "./lib/vendor-subscriptions";
import { startAdExpirySweepJob } from "./lib/ad-expiry";
import { startMovieSubscriptionJob } from "./lib/movie-subscriptions";

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");

const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);

const httpServer = createServer(app);
initSocket(httpServer);

httpServer.listen(port, () => {
  logger.info({ port }, "Server listening");
  runAliexpressMigration()
    .then(() => {
      startAliexpressSyncJob();
    })
    .catch((err) => logger.error({ err }, "AliExpress migration failed — sync job not started"));
  runSeedIfEmpty().catch((err) => logger.error({ err }, "Startup seed failed"));
  startVendorSubscriptionRenewalJob();
  startAdExpirySweepJob();
  startMovieSubscriptionJob();
});

httpServer.on("error", (err: Error) => {
  logger.error({ err }, "Error listening on port");
  process.exit(1);
});
