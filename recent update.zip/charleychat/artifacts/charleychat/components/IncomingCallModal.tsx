import React, { useEffect, useRef } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, Animated, Modal,
  Vibration, Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export type IncomingCallInfo = {
  callId: string;
  channelName: string;
  agoraToken: string;
  agoraAppId: string;
  callerId: string;
  callerName: string;
  callerAvatarUrl?: string | null;
  type: "voice" | "video";
};

type Props = {
  call: IncomingCallInfo;
  callerColor: string;
  onAccept: () => void;
  onDecline: () => void;
};

const VIBRATION_PATTERN = [0, 400, 200, 400, 200, 400];

export default function IncomingCallModal({ call, callerColor, onAccept, onDecline }: Props) {
  const insets = useSafeAreaInsets();
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(80)).current;

  // Slide in
  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 0,
      useNativeDriver: true,
      damping: 18,
      stiffness: 180,
    }).start();
  }, [slideAnim]);

  // Pulsing ring animation
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 600, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim]);

  // Ringtone vibration (works on both Android & iOS)
  useEffect(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    if (Platform.OS === "android") {
      Vibration.vibrate(VIBRATION_PATTERN, true);
    } else {
      const interval = setInterval(() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      }, 1500);
      return () => clearInterval(interval);
    }
    return () => Vibration.cancel();
  }, []);

  const initials = call.callerName
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const handleAccept = () => {
    Vibration.cancel();
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onAccept();
  };

  const handleDecline = () => {
    Vibration.cancel();
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    onDecline();
  };

  return (
    <Modal transparent animationType="none" visible statusBarTranslucent>
      <View style={styles.overlay}>
        {/* Blurred card */}
        <Animated.View
          style={[
            styles.card,
            { paddingTop: insets.top + 20, transform: [{ translateY: slideAnim }] },
          ]}
        >
          {/* Header */}
          <Text style={styles.incomingLabel}>
            Incoming {call.type === "video" ? "Video" : "Voice"} Call
          </Text>

          {/* Avatar */}
          <View style={styles.avatarWrap}>
            <Animated.View
              style={[
                styles.avatarPulse,
                { backgroundColor: callerColor + "30", transform: [{ scale: pulseAnim }] },
              ]}
            />
            <View style={[styles.avatar, { backgroundColor: callerColor }]}>
              <Text style={styles.avatarText}>{initials}</Text>
            </View>
            <View style={styles.callTypeIcon}>
              <Feather name={call.type === "video" ? "video" : "phone"} size={13} color="#fff" />
            </View>
          </View>

          {/* Name */}
          <Text style={styles.callerName}>{call.callerName}</Text>
          <Text style={styles.callSubtitle}>CharLey Pay</Text>

          {/* Buttons */}
          <View style={styles.btnRow}>
            {/* Decline */}
            <TouchableOpacity style={styles.declineBtn} onPress={handleDecline} activeOpacity={0.85}>
              <Feather name="phone-off" size={28} color="#fff" />
              <Text style={styles.btnLabel}>Decline</Text>
            </TouchableOpacity>

            {/* Accept */}
            <TouchableOpacity style={styles.acceptBtn} onPress={handleAccept} activeOpacity={0.85}>
              <Feather name="phone" size={28} color="#fff" />
              <Text style={styles.btnLabel}>Accept</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "flex-start",
  },
  card: {
    backgroundColor: "#0C1524",
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
    alignItems: "center",
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  incomingLabel: {
    color: "rgba(255,255,255,0.55)",
    fontSize: 13,
    letterSpacing: 0.5,
    marginBottom: 28,
  },
  avatarWrap: {
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
  },
  avatarPulse: {
    position: "absolute",
    width: 130,
    height: 130,
    borderRadius: 65,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "rgba(255,255,255,0.25)",
  },
  avatarText: { color: "#fff", fontSize: 34, fontWeight: "700" },
  callTypeIcon: {
    position: "absolute",
    bottom: 2,
    right: 2,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#0D9488",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#0C1524",
  },
  callerName: { color: "#fff", fontSize: 26, fontWeight: "700", marginBottom: 6 },
  callSubtitle: { color: "rgba(255,255,255,0.4)", fontSize: 13, marginBottom: 40 },
  btnRow: { flexDirection: "row", gap: 48, marginTop: 8 },
  declineBtn: {
    alignItems: "center",
    gap: 10,
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "#EF4444",
    justifyContent: "center",
  },
  acceptBtn: {
    alignItems: "center",
    gap: 10,
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "#22C55E",
    justifyContent: "center",
  },
  btnLabel: { color: "#fff", fontSize: 12, fontWeight: "600", position: "absolute", bottom: -22 },
});
