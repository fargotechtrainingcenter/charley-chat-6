import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useCallback } from "react";
import { Animated, StyleSheet, Text, TouchableOpacity, View, Platform } from "react-native";

import { useColors } from "@/hooks/useColors";
import { useListNotifications } from "@workspace/api-client-react";
import { getListNotificationsQueryKey } from "@workspace/api-client-react";
import { playNotifBellSound } from "@/lib/sounds";

interface Props {
  color?: string;
  size?: number;
}

export function NotificationBell({ color, size = 22 }: Props) {
  const colors = useColors();
  const router = useRouter();
  const bellColor = color ?? colors.text;

  const ringAnim = useRef(new Animated.Value(0)).current;
  const prevUnreadRef = useRef<number | null>(null);

  const { data } = useListNotifications({
    query: {
      queryKey: getListNotificationsQueryKey(),
      refetchInterval: 30000,
    },
  });

  const notifications = Array.isArray(data) ? data : [];
  const unread = notifications.filter((n: any) => !n.isRead).length;

  const startRing = useCallback(() => {
    ringAnim.setValue(0);
    Animated.sequence([
      Animated.timing(ringAnim, { toValue: 1,  duration: 80,  useNativeDriver: true }),
      Animated.timing(ringAnim, { toValue: -1, duration: 80,  useNativeDriver: true }),
      Animated.timing(ringAnim, { toValue: 1,  duration: 80,  useNativeDriver: true }),
      Animated.timing(ringAnim, { toValue: -1, duration: 80,  useNativeDriver: true }),
      Animated.timing(ringAnim, { toValue: 0.5, duration: 60, useNativeDriver: true }),
      Animated.timing(ringAnim, { toValue: 0,  duration: 60,  useNativeDriver: true }),
    ]).start();
  }, [ringAnim]);

  useEffect(() => {
    if (prevUnreadRef.current !== null && unread > prevUnreadRef.current) {
      startRing();
      playNotifBellSound();
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
      }
    }
    prevUnreadRef.current = unread;
  }, [unread, startRing]);

  const rotation = ringAnim.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: ["-20deg", "0deg", "20deg"],
  });

  return (
    <TouchableOpacity
      style={styles.wrapper}
      activeOpacity={0.7}
      onPress={() => router.push("/notifications" as any)}
    >
      <Animated.View style={{ transform: [{ rotate: rotation }] }}>
        <Feather name="bell" size={size} color={bellColor} />
      </Animated.View>
      {unread > 0 && (
        <View style={[styles.badge, { backgroundColor: colors.danger ?? "#EF4444" }]}>
          <Text style={styles.badgeText}>{unread > 99 ? "99+" : unread}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "relative",
    padding: 4,
  },
  badge: {
    position: "absolute",
    top: 0,
    right: 0,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  badgeText: {
    color: "#fff",
    fontSize: 9,
    fontFamily: "Inter_700Bold",
    lineHeight: 11,
  },
});
