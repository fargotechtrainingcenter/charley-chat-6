import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useColors } from "@/hooks/useColors";
import { useListNotifications } from "@workspace/api-client-react";
import { getListNotificationsQueryKey } from "@workspace/api-client-react";

interface Props {
  color?: string;
  size?: number;
}

export function CallHistoryIcon({ color, size = 22 }: Props) {
  const colors = useColors();
  const router = useRouter();
  const iconColor = color ?? colors.text;

  const { data } = useListNotifications({
    query: {
      queryKey: getListNotificationsQueryKey(),
      refetchInterval: 30000,
    },
  });

  const notifications = Array.isArray(data) ? data : [];
  const missedCount = notifications.filter(
    (n: any) => n.type === "missed_call" && !n.isRead
  ).length;

  return (
    <TouchableOpacity
      style={styles.wrapper}
      activeOpacity={0.7}
      onPress={() => router.push("/call-history" as any)}
    >
      <Feather name="phone-call" size={size} color={iconColor} />
      {missedCount > 0 && (
        <View style={[styles.badge, { backgroundColor: "#EF4444" }]}>
          <Text style={styles.badgeText}>{missedCount > 99 ? "99+" : missedCount}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "relative",
    padding: 4,
  },
  badge: {
    position: "absolute",
    top: 0,
    right: 0,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  badgeText: {
    color: "#fff",
    fontSize: 9,
    fontFamily: "Inter_700Bold",
    lineHeight: 11,
  },
});
