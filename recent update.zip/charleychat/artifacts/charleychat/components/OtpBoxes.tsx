import React, { useRef } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

interface OtpColors {
  surface: string;
  primary: string;
  border: string;
  text: string;
}

interface OtpBoxesProps {
  value: string;
  onChange: (v: string) => void;
  colors: OtpColors;
  length?: number;
  autoFocus?: boolean;
}

export default function OtpBoxes({
  value,
  onChange,
  colors,
  length = 6,
  autoFocus = true,
}: OtpBoxesProps) {
  const inputRef = useRef<TextInput>(null);
  const digits = value.padEnd(length, " ").split("");

  return (
    <View style={styles.wrapper}>
      <View style={styles.boxes}>
        {digits.map((d, i) => {
          const isCurrent = value.length === i;
          const isFilled = d.trim().length > 0;
          return (
            <TouchableOpacity
              key={i}
              style={[
                styles.box,
                {
                  backgroundColor: colors.surface,
                  borderColor: isCurrent
                    ? colors.primary
                    : isFilled
                    ? colors.primary + "60"
                    : colors.border,
                  borderWidth: isCurrent ? 2 : 1.5,
                },
              ]}
              onPress={() => inputRef.current?.focus()}
              activeOpacity={0.8}
            >
              <Text
                style={[
                  styles.digit,
                  { color: colors.text, fontFamily: "Inter_700Bold" },
                ]}
              >
                {d.trim()}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <TextInput
        ref={inputRef}
        style={styles.hiddenInput}
        value={value}
        onChangeText={(t) =>
          onChange(t.replace(/\D/g, "").slice(0, length))
        }
        keyboardType="numeric"
        maxLength={length}
        autoFocus={autoFocus}
        caretHidden
        importantForAccessibility="no-hide-descendants"
        accessibilityElementsHidden
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { alignSelf: "stretch" },
  boxes: {
    flexDirection: "row",
    gap: 8,
    justifyContent: "space-between",
    alignSelf: "stretch",
    paddingVertical: 4,
  },
  box: {
    flex: 1,
    maxWidth: 52,
    height: 54,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  digit: { fontSize: 22 },
  hiddenInput: {
    position: "absolute",
    opacity: 0,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    color: "transparent",
  },
});
