import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export type PillTone = "success" | "warning" | "danger" | "neutral" | "indigo" | "gold";

export function Pill({ label, tone = "neutral" }: { label: string; tone?: PillTone }) {
  const colors = useColors();
  const map: Record<PillTone, { bg: string; fg: string }> = {
    success:  { bg: colors.successBg,  fg: colors.success },
    warning:  { bg: colors.warningBg,  fg: colors.warning },
    danger:   { bg: colors.dangerBg,   fg: colors.danger },
    neutral:  { bg: colors.surfaceElevated, fg: colors.textMuted },
    indigo:   { bg: "rgba(0,168,132,0.15)", fg: colors.primary },
    gold:     { bg: colors.goldDim,   fg: colors.gold },
  };
  const c = map[tone];
  return (
    <View style={[styles.pill, { backgroundColor: c.bg }]}>
      <Text style={[styles.pillText, { color: c.fg }]}>{label}</Text>
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: object }) {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>
      {children}
    </View>
  );
}

export function Divider() {
  const colors = useColors();
  return <View style={[styles.divider, { backgroundColor: colors.divider }]} />;
}

export function SectionHeader({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title}</Text>
      {action && onAction && (
        <TouchableOpacity onPress={onAction}>
          <Text style={[styles.sectionAction, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
            {action}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

export function StatTile({
  label,
  value,
  sub,
  subTone = "neutral",
  style,
}: {
  label: string;
  value: string;
  sub?: string;
  subTone?: PillTone;
  style?: object;
}) {
  const colors = useColors();
  return (
    <Card style={[{ flex: 1, alignItems: "flex-start" }, style]}>
      <Text style={[styles.statLabel, { color: colors.textMuted }]}>{label}</Text>
      <Text style={[styles.statValue, { color: colors.text }]}>{value}</Text>
      {sub ? <Pill label={sub} tone={subTone} /> : null}
    </Card>
  );
}

export function EscrowRow({
  title,
  withWho,
  amount,
  status,
  tone,
  color,
  onPress,
}: {
  title: string;
  withWho: string;
  amount: string;
  status: string;
  tone: PillTone;
  color?: string;
  onPress?: () => void;
}) {
  const colors = useColors();
  const initials = withWho
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("");
  return (
    <TouchableOpacity style={styles.escrowRow} onPress={onPress} activeOpacity={onPress ? 0.7 : 1}>
      <View style={[styles.avatarCircle, { backgroundColor: color ?? colors.primary }]}>
        <Text style={[styles.avatarText, { color: "#fff" }]}>{initials}</Text>
      </View>
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={[styles.escrowTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]} numberOfLines={1}>
          {title}
        </Text>
        <Text style={[styles.escrowSub, { color: colors.textMuted }]}>With {withWho}</Text>
      </View>
      <View style={{ alignItems: "flex-end" }}>
        <Text style={[styles.escrowAmount, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{amount}</Text>
        <Pill label={status} tone={tone} />
      </View>
    </TouchableOpacity>
  );
}

// ─── Amount modal used by Wallet ─────────────────────────────────────────────

export function AmountModal({
  visible,
  title,
  subtitle,
  buttonLabel,
  amount,
  onChangeAmount,
  onConfirm,
  onDismiss,
}: {
  visible: boolean;
  title: string;
  subtitle: string;
  buttonLabel: string;
  amount: string;
  onChangeAmount: (v: string) => void;
  onConfirm: () => void;
  onDismiss: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onDismiss}>
      <View style={styles.modalOverlay}>
        <View style={[styles.modalSheet, { backgroundColor: colors.surface, paddingBottom: insets.bottom + 20 }]}>
          <View style={[styles.modalHandle, { backgroundColor: colors.border }]} />
          <Text style={[styles.modalTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title}</Text>
          <Text style={[styles.modalSubtitle, { color: colors.textMuted }]}>{subtitle}</Text>
          <View style={[styles.amountInputWrap, { borderColor: colors.primary, backgroundColor: colors.surfaceElevated }]}>
            <Text style={[styles.currencyPrefix, { color: colors.textMuted }]}>GH₵</Text>
            <TextInput
              style={[styles.amountInput, { color: colors.text }]}
              value={amount}
              onChangeText={onChangeAmount}
              keyboardType="decimal-pad"
              placeholder="0.00"
              placeholderTextColor={colors.textMuted}
              autoFocus
            />
          </View>
          <TouchableOpacity
            style={[styles.modalConfirmBtn, { backgroundColor: colors.primary }]}
            onPress={onConfirm}
            activeOpacity={0.8}
          >
            <Text style={[styles.modalConfirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
              {buttonLabel}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalCancelBtn} onPress={onDismiss}>
            <Text style={[styles.modalCancelText, { color: colors.textMuted }]}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

// ─── Wallet balance card ──────────────────────────────────────────────────────

export function BalanceCard({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  const { balance, addMoney, withdraw } = useApp();
  const [addVisible, setAddVisible] = useState(false);
  const [withdrawVisible, setWithdrawVisible] = useState(false);
  const [amount, setAmount] = useState("");

  const handleAdd = () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) { Alert.alert("Invalid amount", "Enter a valid amount."); return; }
    addMoney(num);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setAmount(""); setAddVisible(false);
  };

  const handleWithdraw = () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) { Alert.alert("Invalid amount", "Enter a valid amount."); return; }
    if (!withdraw(num)) { Alert.alert("Insufficient funds", "Balance too low."); return; }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setAmount(""); setWithdrawVisible(false);
  };

  return (
    <>
      <View style={[styles.balanceCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <View style={styles.balanceCardTop}>
          <View>
            <Text style={[styles.balanceLabel, { color: colors.textMuted }]}>Wallet Balance</Text>
            <Text style={[styles.balanceValue, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
              GH₵ {balance.toLocaleString("en-GH", { minimumFractionDigits: 2 })}
            </Text>
          </View>
          <View style={[styles.virtualCardBadge, { backgroundColor: colors.goldDim }]}>
            <Feather name="credit-card" size={14} color={colors.gold} />
            <Text style={[styles.virtualCardText, { color: colors.gold, fontFamily: "Inter_600SemiBold" }]}>
              {" "}Virtual Card
            </Text>
          </View>
        </View>
        <View style={styles.balanceActionsRow}>
          <TouchableOpacity
            style={[styles.balanceBtn, { backgroundColor: colors.primary }]}
            onPress={() => { setAmount(""); setAddVisible(true); }}
            activeOpacity={0.8}
          >
            <Feather name="plus" size={15} color="#fff" />
            <Text style={[styles.balanceBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}> Add</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.balanceBtn, { backgroundColor: colors.surfaceElevated }]}
            onPress={() => { setAmount(""); setWithdrawVisible(true); }}
            activeOpacity={0.8}
          >
            <Feather name="arrow-up-right" size={15} color={colors.text} />
            <Text style={[styles.balanceBtnText, { color: colors.text, fontFamily: "Inter_700Bold" }]}> Send</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.balanceBtn, { backgroundColor: colors.surfaceElevated }]}
            activeOpacity={0.8}
          >
            <Feather name="arrow-down-left" size={15} color={colors.text} />
            <Text style={[styles.balanceBtnText, { color: colors.text, fontFamily: "Inter_700Bold" }]}> Request</Text>
          </TouchableOpacity>
        </View>
      </View>

      <AmountModal
        visible={addVisible}
        title="Add Money"
        subtitle="Top up your wallet via MTN MoMo"
        buttonLabel="Add Money"
        amount={amount}
        onChangeAmount={setAmount}
        onConfirm={handleAdd}
        onDismiss={() => setAddVisible(false)}
      />
      <AmountModal
        visible={withdrawVisible}
        title="Withdraw Funds"
        subtitle="Transfer to your bank account"
        buttonLabel="Withdraw"
        amount={amount}
        onChangeAmount={setAmount}
        onConfirm={handleWithdraw}
        onDismiss={() => setWithdrawVisible(false)}
      />
    </>
  );
}

const styles = StyleSheet.create({
  pill: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
    alignSelf: "flex-start",
  },
  pillText: { fontSize: 11, fontWeight: "700", fontFamily: "Inter_700Bold" },

  card: {
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
  },

  divider: { height: 1, marginVertical: 2 },

  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
    marginTop: 4,
  },
  sectionTitle: { fontSize: 15, fontWeight: "800" },
  sectionAction: { fontSize: 13, fontWeight: "600" },

  statLabel: { fontSize: 12, marginBottom: 6, fontFamily: "Inter_500Medium" },
  statValue: { fontSize: 20, fontWeight: "800", marginBottom: 8, fontFamily: "Inter_700Bold" },

  escrowRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10 },
  avatarCircle: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center" },
  avatarText: { fontWeight: "700", fontSize: 14, fontFamily: "Inter_700Bold" },
  escrowTitle: { fontSize: 14, fontWeight: "700" },
  escrowSub: { fontSize: 12, marginTop: 1, fontFamily: "Inter_400Regular" },
  escrowAmount: { fontSize: 14, fontWeight: "800", marginBottom: 4 },

  balanceCard: {
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
  },
  balanceCardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 },
  balanceLabel: { fontSize: 12, fontWeight: "600", marginBottom: 4, fontFamily: "Inter_500Medium" },
  balanceValue: { fontSize: 28, fontWeight: "800" },
  virtualCardBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  virtualCardText: { fontSize: 11 },
  balanceActionsRow: { flexDirection: "row", gap: 8 },
  balanceBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    paddingVertical: 10,
  },
  balanceBtnText: { fontSize: 13, fontWeight: "700" },

  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modalSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  modalTitle: { fontSize: 22, fontWeight: "800", marginBottom: 6 },
  modalSubtitle: { fontSize: 14, marginBottom: 20 },
  amountInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1.5,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 20,
  },
  currencyPrefix: { fontSize: 18, fontWeight: "700", marginRight: 8, fontFamily: "Inter_700Bold" },
  amountInput: { flex: 1, fontSize: 24, fontWeight: "700", fontFamily: "Inter_700Bold" },
  modalConfirmBtn: { borderRadius: 14, paddingVertical: 16, alignItems: "center", marginBottom: 10 },
  modalConfirmBtnText: { fontSize: 16, fontWeight: "700" },
  modalCancelBtn: { alignItems: "center", paddingVertical: 10 },
  modalCancelText: { fontSize: 14 },
});
