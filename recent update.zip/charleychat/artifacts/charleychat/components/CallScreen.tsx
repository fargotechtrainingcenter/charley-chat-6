/**
 * CallScreen — Full-screen active call UI for CharLey Chat
 *
 * Agora RTC integration: this component wires up react-native-agora when it's
 * available in the native build. In Expo Go (no native build) the call UI still
 * renders but audio/video transmission requires a custom Expo dev build.
 *
 * To enable native calls:
 *   pnpm --filter @workspace/charleychat add react-native-agora
 *   npx expo prebuild
 *   npx expo run:android  (or run:ios)
 */
import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, Dimensions,
  Animated, Platform, StatusBar, Image,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { width: SW, height: SH } = Dimensions.get("window");

export type ActiveCallInfo = {
  callId: string;
  channelName: string;
  agoraToken: string;
  agoraAppId: string;
  type: "voice" | "video";
  peerName: string;
  peerInitials: string;
  peerColor: string;
  peerAvatarUrl?: string | null;
  isCaller: boolean;
};

type Props = {
  call: ActiveCallInfo;
  onEnd: (callId: string) => void;
};

// ── Try to load Agora engine ──────────────────────────────────────────────────
// This dynamic require safely fails in Expo Go and unlinked builds.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let AgoraRTC: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  AgoraRTC = require("react-native-agora");
} catch {
  AgoraRTC = null;
}

export default function CallScreen({ call, onEnd }: Props) {
  const insets = useSafeAreaInsets();
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(call.type === "video");
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [callStatus, setCallStatus] = useState<"connecting" | "connected" | "reconnecting">("connecting");
  const [durationSecs, setDurationSecs] = useState(0);
  const engineRef = useRef<unknown>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // ── Pulsing ring animation (while connecting) ─────────────────────────────
  useEffect(() => {
    if (callStatus === "connecting") {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.12, duration: 700, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 700, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.stopAnimation();
      pulseAnim.setValue(1);
    }
  }, [callStatus, pulseAnim]);

  // ── Duration timer ────────────────────────────────────────────────────────
  const startTimer = useCallback(() => {
    if (timerRef.current) return;
    timerRef.current = setInterval(() => setDurationSecs((s) => s + 1), 1000);
  }, []);

  // ── Agora engine lifecycle ─────────────────────────────────────────────────
  useEffect(() => {
    if (!AgoraRTC || !call.agoraAppId) {
      // No native Agora — simulate connection after 2 s for UI preview
      const t = setTimeout(() => {
        setCallStatus("connected");
        startTimer();
      }, 2000);
      return () => clearTimeout(t);
    }

    let engine: unknown = null;

    const setup = async () => {
      try {
        engine = AgoraRTC.createAgoraRtcEngine();
        engineRef.current = engine;

        const { RtcSurfaceView, ChannelProfileType, ClientRoleType, AudioProfileType, AudioScenarioType } = AgoraRTC;

        (engine as any).initialize({
          appId: call.agoraAppId,
          channelProfile: ChannelProfileType?.ChannelProfileCommunication ?? 0,
          audioScenario: AudioScenarioType?.AudioScenarioChatRoom ?? 5,
        });

        (engine as any).registerEventHandler({
          onJoinChannelSuccess: () => {
            setCallStatus("connected");
            startTimer();
          },
          onUserJoined: () => {
            setCallStatus("connected");
            startTimer();
          },
          onConnectionStateChanged: (_connection: unknown, state: number) => {
            // 3 = RECONNECTING, 5 = FAILED
            if (state === 3) setCallStatus("reconnecting");
            else if (state === 4) setCallStatus("connected");
          },
          onError: (err: unknown) => console.warn("Agora error:", err),
        });

        if (call.type === "video") {
          (engine as any).enableVideo();
          (engine as any).startPreview();
        } else {
          (engine as any).enableAudio();
          (engine as any).setAudioProfile(
            AudioProfileType?.AudioProfileDefault ?? 0,
            AudioScenarioType?.AudioScenarioChatRoom ?? 5
          );
        }

        (engine as any).setEnableSpeakerphone(isSpeakerOn);

        await (engine as any).joinChannel(
          call.agoraToken || "",
          call.channelName,
          0,
          { clientRoleType: ClientRoleType?.ClientRoleBroadcaster ?? 1 }
        );
      } catch (err) {
        console.warn("Agora init failed:", err);
        setCallStatus("connected");
        startTimer();
      }
    };

    void setup();

    return () => {
      if (engine) {
        try {
          (engine as any).leaveChannel();
          (engine as any).release();
        } catch {}
      }
      if (timerRef.current) clearInterval(timerRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleMute = () => {
    setIsMuted((v) => {
      const next = !v;
      if (engineRef.current) {
        try { (engineRef.current as any).muteLocalAudioStream(next); } catch {}
      }
      Haptics.selectionAsync();
      return next;
    });
  };

  const handleSpeaker = () => {
    setIsSpeakerOn((v) => {
      const next = !v;
      if (engineRef.current) {
        try { (engineRef.current as any).setEnableSpeakerphone(next); } catch {}
      }
      Haptics.selectionAsync();
      return next;
    });
  };

  const handleCameraSwitch = () => {
    setIsFrontCamera((v) => {
      if (engineRef.current) {
        try { (engineRef.current as any).switchCamera(); } catch {}
      }
      Haptics.selectionAsync();
      return !v;
    });
  };

  const handleEnd = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    if (timerRef.current) clearInterval(timerRef.current);
    onEnd(call.callId);
  };

  const fmtDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const statusLabel =
    callStatus === "connecting"
      ? call.type === "video"
        ? "Starting video call…"
        : "Calling…"
      : callStatus === "reconnecting"
      ? "Reconnecting…"
      : fmtDuration(durationSecs);

  const statusColor =
    callStatus === "reconnecting" ? "#F59E0B" : callStatus === "connected" ? "#4ADE80" : "#A1A1AA";

  return (
    <View style={[styles.root, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 24 }]}>
      <StatusBar barStyle="light-content" />

      {/* Background gradient effect */}
      <View style={[styles.bgGradient, { backgroundColor: call.peerColor + "22" }]} />

      {/* ── Top info ───────────────────────────────────────────────────────── */}
      <View style={styles.topInfo}>
        <Text style={styles.callTypeLabel}>
          {call.type === "video" ? "Video Call" : "Voice Call"}{" "}
          {!AgoraRTC && call.type !== undefined && <Text style={{ fontSize: 10, color: "#F59E0B" }}>(demo)</Text>}
        </Text>
        <Text style={[styles.statusLabel, { color: statusColor }]}>{statusLabel}</Text>
      </View>

      {/* ── Avatar ─────────────────────────────────────────────────────────── */}
      <View style={styles.avatarWrap}>
        <Animated.View style={[styles.avatarPulse, { backgroundColor: call.peerColor + "30", transform: [{ scale: pulseAnim }] }]} />
        {call.peerAvatarUrl ? (
          <Image source={{ uri: call.peerAvatarUrl }} style={[styles.avatar, { backgroundColor: call.peerColor }]} />
        ) : (
          <View style={[styles.avatar, { backgroundColor: call.peerColor }]}>
            <Text style={styles.avatarText}>{call.peerInitials}</Text>
          </View>
        )}
        {isMuted && (
          <View style={styles.mutedBadge}>
            <Feather name="mic-off" size={12} color="#fff" />
          </View>
        )}
      </View>

      <Text style={styles.peerName}>{call.peerName}</Text>

      {/* ── Controls ───────────────────────────────────────────────────────── */}
      <View style={styles.controlsRow}>
        {/* Mute */}
        <ControlButton
          icon={isMuted ? "mic-off" : "mic"}
          label={isMuted ? "Unmute" : "Mute"}
          active={isMuted}
          onPress={handleMute}
          activeColor="#EF4444"
        />

        {/* Speaker / Earpiece */}
        <ControlButton
          icon={isSpeakerOn ? "volume-2" : "volume-1"}
          label={isSpeakerOn ? "Speaker" : "Earpiece"}
          active={isSpeakerOn}
          onPress={handleSpeaker}
          activeColor="#0D9488"
        />

        {/* Camera switch (video only) */}
        {call.type === "video" && (
          <ControlButton
            icon="refresh-cw"
            label="Flip"
            active={false}
            onPress={handleCameraSwitch}
          />
        )}
      </View>

      {/* ── End call ─────────────────────────────────────────────────────── */}
      <TouchableOpacity style={styles.endCallBtn} onPress={handleEnd} activeOpacity={0.85}>
        <Feather name="phone-off" size={28} color="#fff" />
      </TouchableOpacity>
      <Text style={styles.endCallLabel}>End</Text>

      {/* ── Agora notice (dev builds only) ───────────────────────────────── */}
      {!AgoraRTC && (
        <View style={styles.noticeBar}>
          <Feather name="info" size={12} color="#F59E0B" style={{ marginRight: 6 }} />
          <Text style={styles.noticeText}>
            Native audio/video requires a custom Expo build with react-native-agora
          </Text>
        </View>
      )}
    </View>
  );
}

function ControlButton({
  icon, label, active, onPress, activeColor = "#0D9488",
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  active: boolean;
  onPress: () => void;
  activeColor?: string;
}) {
  return (
    <TouchableOpacity style={styles.ctrlBtn} onPress={onPress} activeOpacity={0.7}>
      <View style={[
        styles.ctrlBtnCircle,
        { backgroundColor: active ? activeColor + "33" : "rgba(255,255,255,0.12)", borderColor: active ? activeColor : "rgba(255,255,255,0.2)" },
      ]}>
        <Feather name={icon} size={22} color={active ? activeColor : "#fff"} />
      </View>
      <Text style={styles.ctrlLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "#0C1524",
    alignItems: "center",
    zIndex: 9999,
  },
  bgGradient: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
  },
  topInfo: { alignItems: "center", marginBottom: 32, zIndex: 1 },
  callTypeLabel: { color: "rgba(255,255,255,0.5)", fontSize: 13, marginBottom: 6, letterSpacing: 0.5 },
  statusLabel: { fontSize: 16, fontWeight: "600" },
  avatarWrap: { alignItems: "center", justifyContent: "center", marginBottom: 24, zIndex: 1 },
  avatarPulse: {
    position: "absolute",
    width: SW * 0.52,
    height: SW * 0.52,
    borderRadius: SW * 0.26,
  },
  avatar: {
    width: SW * 0.38,
    height: SW * 0.38,
    borderRadius: SW * 0.19,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 3,
    borderColor: "rgba(255,255,255,0.25)",
  },
  avatarText: { color: "#fff", fontSize: SW * 0.13, fontWeight: "700" },
  mutedBadge: {
    position: "absolute",
    bottom: 6,
    right: 6,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#EF4444",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#0C1524",
  },
  peerName: { color: "#fff", fontSize: 28, fontWeight: "700", marginBottom: 48, zIndex: 1 },
  controlsRow: { flexDirection: "row", gap: 28, marginBottom: 56, zIndex: 1 },
  ctrlBtn: { alignItems: "center", gap: 8 },
  ctrlBtnCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1.5,
  },
  ctrlLabel: { color: "rgba(255,255,255,0.65)", fontSize: 12 },
  endCallBtn: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "#EF4444",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
    zIndex: 1,
    shadowColor: "#EF4444",
    shadowOpacity: 0.5,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  endCallLabel: { color: "rgba(255,255,255,0.7)", fontSize: 13, zIndex: 1 },
  noticeBar: {
    position: "absolute",
    bottom: 80,
    left: 16,
    right: 16,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(245, 158, 11, 0.15)",
    borderWidth: 1,
    borderColor: "rgba(245, 158, 11, 0.3)",
    borderRadius: 10,
    padding: 10,
    zIndex: 1,
  },
  noticeText: { color: "#F59E0B", fontSize: 11, flex: 1, lineHeight: 15 },
});
