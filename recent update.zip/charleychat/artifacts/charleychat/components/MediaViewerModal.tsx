import React, { useCallback, useRef, useState } from "react";
import {
  Modal,
  View,
  Text,
  Image,
  Dimensions,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { Video, ResizeMode } from "expo-av";
import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";
import {
  GestureDetector,
  Gesture,
} from "react-native-gesture-handler";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

export interface MediaViewerItem {
  id: string;
  url: string;
  type: "image" | "video";
}

interface MediaViewerModalProps {
  visible: boolean;
  items: MediaViewerItem[];
  initialIndex: number;
  onClose: () => void;
}

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");

export default function MediaViewerModal({ visible, items, initialIndex, onClose }: MediaViewerModalProps) {
  const [activeIndex, setActiveIndex] = useState(initialIndex);
  const scrollRef = useRef<ScrollView>(null);

  const handleMomentumEnd = useCallback((e: any) => {
    const idx = Math.round(e.nativeEvent.contentOffset.x / SCREEN_W);
    setActiveIndex(idx);
  }, []);

  const handleDownload = useCallback(async () => {
    const item = items[activeIndex];
    if (!item) return;
    try {
      const perm = await MediaLibrary.requestPermissionsAsync();
      if (!perm.granted) {
        Alert.alert("Permission needed", "Allow photo library access to save this file.");
        return;
      }
      const ext = item.type === "video" ? "mp4" : "jpg";
      const localPath = `${FileSystem.cacheDirectory}charley-${item.id}.${ext}`;
      const download = await FileSystem.downloadAsync(item.url, localPath);
      await MediaLibrary.saveToLibraryAsync(download.uri);
      Alert.alert("Saved", item.type === "video" ? "Video saved to your gallery." : "Photo saved to your gallery.");
    } catch {
      Alert.alert("Download failed", "Couldn't save this file. Please try again.");
    }
  }, [items, activeIndex]);

  if (!visible) return null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={styles.container}>
        <ScrollView
          ref={scrollRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          contentOffset={{ x: initialIndex * SCREEN_W, y: 0 }}
          onMomentumScrollEnd={handleMomentumEnd}
        >
          {items.map((item) => (
            <View key={item.id} style={{ width: SCREEN_W, height: SCREEN_H, alignItems: "center", justifyContent: "center" }}>
              {item.type === "video" ? (
                <VideoPage url={item.url} />
              ) : (
                <ZoomableImage url={item.url} />
              )}
            </View>
          ))}
        </ScrollView>

        <View style={styles.topBar}>
          <TouchableOpacity onPress={onClose} style={styles.iconBtn} hitSlop={12}>
            <Feather name="x" size={26} color="#fff" />
          </TouchableOpacity>
          {items.length > 1 && (
            <Text style={styles.counter}>{activeIndex + 1} / {items.length}</Text>
          )}
          <TouchableOpacity onPress={handleDownload} style={styles.iconBtn} hitSlop={12}>
            <Feather name="download" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

// ─── Pinch-to-zoom + pan image page ────────────────────────────────────────
function ZoomableImage({ url }: { url: string }) {
  const [loading, setLoading] = useState(true);
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedTranslateX = useSharedValue(0);
  const savedTranslateY = useSharedValue(0);

  const pinchGesture = Gesture.Pinch()
    .onUpdate((e) => {
      scale.value = Math.max(1, Math.min(savedScale.value * e.scale, 5));
    })
    .onEnd(() => {
      savedScale.value = scale.value;
      if (scale.value <= 1) {
        // Snap back to center when zoomed all the way out
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
        savedTranslateX.value = 0;
        savedTranslateY.value = 0;
      }
    });

  const panGesture = Gesture.Pan()
    .onUpdate((e) => {
      if (scale.value <= 1) return; // don't pan when not zoomed — let ScrollView swipe instead
      translateX.value = savedTranslateX.value + e.translationX;
      translateY.value = savedTranslateY.value + e.translationY;
    })
    .onEnd(() => {
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
    });

  const doubleTapGesture = Gesture.Tap()
    .numberOfTaps(2)
    .onEnd(() => {
      const next = scale.value > 1 ? 1 : 2.5;
      scale.value = withSpring(next);
      savedScale.value = next;
      if (next === 1) {
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
        savedTranslateX.value = 0;
        savedTranslateY.value = 0;
      }
    });

  const composedGesture = Gesture.Simultaneous(pinchGesture, panGesture, doubleTapGesture);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ],
  }));

  return (
    <GestureDetector gesture={composedGesture}>
      <Animated.View style={[{ width: SCREEN_W, height: SCREEN_H, alignItems: "center", justifyContent: "center" }, animatedStyle]}>
        {loading && <ActivityIndicator size="large" color="#fff" style={StyleSheet.absoluteFill} />}
        <Image
          source={{ uri: url }}
          style={{ width: SCREEN_W, height: SCREEN_H }}
          resizeMode="contain"
          onLoadEnd={() => setLoading(false)}
        />
      </Animated.View>
    </GestureDetector>
  );
}

// ─── Video page with native controls ───────────────────────────────────────
function VideoPage({ url }: { url: string }) {
  const [loading, setLoading] = useState(true);
  return (
    <View style={{ width: SCREEN_W, height: SCREEN_H, alignItems: "center", justifyContent: "center" }}>
      {loading && <ActivityIndicator size="large" color="#fff" style={StyleSheet.absoluteFill} />}
      <Video
        source={{ uri: url }}
        style={{ width: SCREEN_W, height: SCREEN_H * 0.6 }}
        useNativeControls
        resizeMode={ResizeMode.CONTAIN}
        shouldPlay
        onLoad={() => setLoading(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  topBar: {
    position: "absolute",
    top: Platform.OS === "ios" ? 54 : 30,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0,0,0,0.4)",
    alignItems: "center",
    justifyContent: "center",
  },
  counter: { color: "#fff", fontSize: 14, fontWeight: "600" },
});
