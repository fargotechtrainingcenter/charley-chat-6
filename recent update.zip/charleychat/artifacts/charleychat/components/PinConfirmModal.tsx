import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

interface Props {
  visible: boolean;
  title?: string;
  subtitle?: string;
  onConfirm: (pin: string) => Promise<{ ok: boolean; error?: string }>;
  onCancel: () => void;
}

const PIN_LENGTH = 4;

function NumPad({ onPress, onDelete }: { onPress: (d: string) => void; onDelete: () => void }) {
  const colors = useColors();
  const keys = ["1","2","3","4","5","6","7","8","9","","0","⌫"];
  return (
    <View style={np.grid}>
      {keys.map((k, i) => {
        if (k === "") return <View key={i} style={np.keyEmpty} />;
        const isDelete = k === "⌫";
        return (
          <TouchableOpacity
            key={i}
            style={[np.key, { backgroundColor: colors.surfaceElevated }]}
            onPress={() => isDelete ? onDelete() : onPress(k)}
            activeOpacity={0.55}
          >
            {isDelete
              ? <Feather name="delete" size={20} color={colors.text} />
              : <Text style={[np.keyText, { color: colors.text, fontFamily: "Inter_500Medium" }]}>{k}</Text>
            }
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export function PinConfirmModal({ visible, title = "Enter your PIN", subtitle, onConfirm, onCancel }: Props) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(Dimensions.get("window").height)).current;
  const submittingRef = useRef(false);

  useEffect(() => {
    if (visible) {
      setPin("");
      setError(null);
      setLoading(false);
      submittingRef.current = false;
      Animated.spring(slideAnim, {
        toValue: 0,
        useNativeDriver: true,
        damping: 20,
        stiffness: 180,
      }).start();
    } else {
      Animated.timing(slideAnim, {
        toValue: Dimensions.get("window").height,
        duration: 220,
        useNativeDriver: true,
      }).start();
    }
  }, [visible]);

  const shake = useCallback(() => {
    shakeAnim.setValue(0);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8,   duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8,  duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,   duration: 50, useNativeDriver: true }),
    ]).start();
  }, [shakeAnim]);

  const handleDigit = useCallback((d: string) => {
    if (loading || submittingRef.current) return;
    setError(null);
    setPin(prev => prev.length < PIN_LENGTH ? prev + d : prev);
  }, [loading]);

  const handleDelete = useCallback(() => {
    if (loading || submittingRef.current) return;
    setError(null);
    setPin(prev => prev.slice(0, -1));
  }, [loading]);

  useEffect(() => {
    if (pin.length !== PIN_LENGTH || submittingRef.current) return;
    submittingRef.current = true;
    setLoading(true);
    setError(null);
    onConfirm(pin).then(result => {
      setLoading(false);
      submittingRef.current = false;
      if (!result.ok) {
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        shake();
        setError(result.error ?? "Incorrect PIN. Please try again.");
        setPin("");
      }
    }).catch(() => {
      setLoading(false);
      submittingRef.current = false;
      shake();
      setError("Something went wrong. Please try again.");
      setPin("");
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pin]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={onCancel}
      statusBarTranslucent
    >
      <View style={styles.backdrop}>
        <TouchableOpacity style={StyleSheet.absoluteFill} activeOpacity={1} onPress={loading ? undefined : onCancel} />
        <Animated.View
          style={[
            styles.sheet,
            {
              backgroundColor: colors.surface,
              paddingBottom: Math.max(insets.bottom, 20),
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          {/* Handle bar */}
          <View style={[styles.handle, { backgroundColor: colors.border }]} />

          {/* Lock icon */}
          <View style={[styles.iconWrap, { backgroundColor: colors.primary + "18" }]}>
            <Feather name="lock" size={26} color={colors.primary} />
          </View>

          <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title}</Text>
          {subtitle ? (
            <Text style={[styles.subtitle, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{subtitle}</Text>
          ) : null}

          {/* Dot indicators */}
          <Animated.View style={[styles.dotsRow, { transform: [{ translateX: shakeAnim }] }]}>
            {Array.from({ length: PIN_LENGTH }).map((_, i) => (
              <View
                key={i}
                style={[
                  styles.dot,
                  {
                    backgroundColor: i < pin.length
                      ? (error ? "#EF4444" : colors.primary)
                      : colors.surfaceElevated,
                    borderWidth: 2,
                    borderColor: i < pin.length
                      ? (error ? "#EF4444" : colors.primary)
                      : (i === pin.length ? colors.primary : colors.border),
                    transform: [{ scale: i < pin.length ? 1.1 : 1 }],
                  },
                ]}
              />
            ))}
          </Animated.View>

          {error ? (
            <Text style={[styles.errorText, { fontFamily: "Inter_500Medium" }]}>{error}</Text>
          ) : loading ? (
            <Text style={[styles.hintText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Verifying…</Text>
          ) : (
            <Text style={[styles.hintText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              {pin.length < PIN_LENGTH ? `Enter ${PIN_LENGTH}-digit PIN` : " "}
            </Text>
          )}

          <NumPad onPress={handleDigit} onDelete={handleDelete} />

          <TouchableOpacity onPress={onCancel} style={styles.cancelBtn} disabled={loading} activeOpacity={0.7}>
            <Text style={[styles.cancelText, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Cancel</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </Modal>
  );
}

const np = StyleSheet.create({
  grid:     { flexDirection: "row", flexWrap: "wrap", width: 252, justifyContent: "center", gap: 10, marginTop: 4 },
  key:      { width: 72, height: 56, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  keyEmpty: { width: 72, height: 56 },
  keyText:  { fontSize: 24 },
});

const styles = StyleSheet.create({
  backdrop:  { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  sheet:     { width: "100%", borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 12, paddingHorizontal: 24, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.25, shadowRadius: 24, elevation: 24 },
  handle:    { width: 40, height: 4, borderRadius: 2, marginBottom: 20 },
  iconWrap:  { width: 60, height: 60, borderRadius: 30, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  title:     { fontSize: 18, marginBottom: 4, textAlign: "center" },
  subtitle:  { fontSize: 13, textAlign: "center", marginBottom: 12, lineHeight: 18, maxWidth: 280, color: "#888" },
  dotsRow:   { flexDirection: "row", gap: 20, marginVertical: 20 },
  dot:       { width: 18, height: 18, borderRadius: 9 } as any,
  errorText: { color: "#EF4444", fontSize: 13, marginBottom: 4, textAlign: "center", height: 18 },
  hintText:  { fontSize: 12, marginBottom: 4, textAlign: "center", height: 18 },
  cancelBtn: { marginTop: 16, paddingVertical: 10, paddingHorizontal: 32 },
  cancelText: { fontSize: 15 },
});
