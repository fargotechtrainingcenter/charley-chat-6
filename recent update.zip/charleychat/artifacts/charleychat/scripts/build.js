const { execSync } = require("child_process");
const path = require("path");

const projectRoot = path.resolve(__dirname, "..");
const basePath = process.env.BASE_PATH || "/mobile";

console.log(`Building CharLey Chat web app (basePath: ${basePath})...`);

execSync("pnpm exec expo export --platform web", {
  cwd: projectRoot,
  stdio: "inherit",
  env: {
    ...process.env,
    EXPO_BASE_URL: basePath,
  },
});

console.log("Web build complete! Files in dist/");
