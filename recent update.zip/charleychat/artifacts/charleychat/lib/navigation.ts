import type { Router } from "expo-router";

/**
 * Like router.back(), but falls back to the app's home tab when there's no
 * screen to go back to (e.g. the screen was opened directly via a deep link
 * or a push-notification tap, rather than pushed from within the app).
 *
 * Plain `router.back()` silently does nothing in that situation, which is
 * exactly why back buttons could feel "inconsistent" — sometimes they work
 * (when there's navigation history) and sometimes they appear to do nothing
 * at all (when there isn't).
 */
export function safeGoBack(router: Router, fallback: string = "/(tabs)") {
  if (router.canGoBack()) {
    router.back();
  } else {
    router.replace(fallback as any);
  }
}
