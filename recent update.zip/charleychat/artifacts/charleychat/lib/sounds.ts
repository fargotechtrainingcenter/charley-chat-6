import { Audio } from "expo-av";
import AsyncStorage from "@react-native-async-storage/async-storage";

/**
 * Cross-platform chat/notification sounds.
 *
 * On native (iOS/Android) these play real bundled WAV files via expo-av.
 * On web, expo-av's web backend uses an HTMLAudioElement under the hood, which
 * works the same way — so a single code path now covers all platforms
 * (previously this only worked on web, via synthesized Web Audio oscillator
 * tones, and native builds got no sound at all).
 */

export const SOUND_SETTING_KEY = "charley_sounds_enabled";

let soundsEnabled = true;
let settingLoaded = false;

async function ensureSettingLoaded() {
  if (settingLoaded) return;
  settingLoaded = true;
  try {
    const stored = await AsyncStorage.getItem(SOUND_SETTING_KEY);
    if (stored !== null) soundsEnabled = stored === "true";
  } catch {
    // default to enabled if storage read fails
  }
}
void ensureSettingLoaded();

export function areSoundsEnabled(): boolean {
  return soundsEnabled;
}

export async function setSoundsEnabled(enabled: boolean): Promise<void> {
  soundsEnabled = enabled;
  settingLoaded = true;
  try {
    await AsyncStorage.setItem(SOUND_SETTING_KEY, String(enabled));
  } catch {
    // best-effort persistence; in-memory flag above still applies for this session
  }
}

const soundAssets = {
  received: require("../assets/sounds/message-received.wav"),
  sent: require("../assets/sounds/message-sent.wav"),
  delivered: require("../assets/sounds/message-delivered.wav"),
  seen: require("../assets/sounds/message-seen.wav"),
  payment: require("../assets/sounds/payment.wav"),
  bell: require("../assets/sounds/notif-bell.wav"),
} as const;

type SoundKey = keyof typeof soundAssets;

// Cache loaded Sound objects so repeated plays don't reload the asset every time.
const soundCache: Partial<Record<SoundKey, Audio.Sound>> = {};

async function playSound(key: SoundKey) {
  if (!soundsEnabled) return;
  try {
    let sound = soundCache[key];
    if (!sound) {
      const created = await Audio.Sound.createAsync(soundAssets[key], { shouldPlay: false });
      sound = created.sound;
      soundCache[key] = sound;
    }
    // Restart from the beginning in case it's still finishing a previous play
    await sound.setPositionAsync(0);
    await sound.playAsync();
  } catch (err) {
    if (__DEV__) console.warn(`Failed to play "${key}" sound:`, err);
  }
}

/** Money received / wallet credited. */
export function playPaymentSound() {
  void playSound("payment");
}

/** New chat message received from someone else. */
export function playMessageSound() {
  void playSound("received");
}

/** Your own message finished sending successfully. */
export function playMessageSentSound() {
  void playSound("sent");
}

/** Your message was delivered to the recipient's device. */
export function playMessageDeliveredSound() {
  void playSound("delivered");
}

/** Your message was seen/read by the recipient. */
export function playMessageSeenSound() {
  void playSound("seen");
}

/** General notification bell sound (for the bell icon animation). */
export function playNotifBellSound() {
  void playSound("bell");
}
