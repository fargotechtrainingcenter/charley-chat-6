/**
 * Resolves the API origin (scheme + host) from an EXPO_PUBLIC_DOMAIN value.
 *
 * Real deployments (Replit, production) always use https. But for local
 * development/testing — e.g. running the api-server on localhost and
 * opening the app in Chrome via `expo start --web` — there's no TLS
 * certificate, so https:// would fail outright. This picks the right
 * scheme automatically based on the host.
 */
export function apiOrigin(domain: string): string {
  const isLocal = /^(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/.test(domain);
  return `${isLocal ? "http" : "https"}://${domain}`;
}

/** Same as apiOrigin, but for websocket URLs (Socket.IO connects via ws/wss). */
export function socketOrigin(domain: string): string {
  return apiOrigin(domain);
}
