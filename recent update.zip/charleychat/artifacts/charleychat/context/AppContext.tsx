import AsyncStorage from "@react-native-async-storage/async-storage";
import { Audio } from "expo-av";
import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import { Platform } from "react-native";
import { router } from "expo-router";
import { playPaymentSound, playMessageSound, playMessageSentSound, playMessageDeliveredSound, playMessageSeenSound } from "@/lib/sounds";
import { apiOrigin, socketOrigin } from "@/lib/api-base";
import type { IncomingCallInfo } from "@/components/IncomingCallModal";
import type { ActiveCallInfo } from "@/components/CallScreen";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  setAuthTokenGetter,
  useAuthLogin,
  useAuthLogout,
  useAuthRegister,
  useCreateEscrow,
  useCreatePaymentLink,
  useCreateStory,
  useDeleteStory,
  useDepositFunds,
  useGetMe,
  useGetWalletBalance,
  useListContacts,
  useListEscrow,
  useListMyStories,
  useListPaymentLinks,
  useListStories,
  useListTransactions,
  useAddContact,
  useMuteUserStories,
  usePayPaymentLink,
  useConfirmPayLinkDelivery,
  useDisputePayLink as useDisputePayLinkAPI,
  useReactToStory,
  useReleaseEscrow,
  useRemoveStoryReaction,
  useReplyToStory,
  useRequestUploadUrl,
  useSendMoney,
  usePayBill,
  useUnmuteUserStories,
  useViewStory,
  useWithdrawFunds,
  useListConversations,
  useSendMessage as useSendMessageAPI,
  useUpdateMySettings,
  useUpdateMyAvatar,
  getMessages as getMessagesAPI,
  getGetMeQueryKey,
  getGetWalletBalanceQueryKey,
  getListTransactionsQueryKey,
  getListEscrowQueryKey,
  getListContactsQueryKey,
  getListPaymentLinksQueryKey,
  getListStoriesQueryKey,
  getListMyStoriesQueryKey,
  getListConversationsQueryKey,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";
import { io as socketIO } from "socket.io-client";

// ── Type exports ──────────────────────────────────────────────────────────────

export interface Transaction {
  id: string;
  title: string;
  sub: string;
  amount: string;
  amountRaw: number;
  type: "credit" | "debit";
  icon: string;
  date: string;
}

export interface Escrow {
  id: string;
  title: string;
  withWho: string;
  amount: string;
  amountRaw: number;
  status: "In Escrow" | "Completed" | "Pending Release" | "Disputed";
  tone: "indigo" | "success" | "warning" | "danger";
  date: string;
  direction: "sent" | "received";
}

export interface Conversation {
  id: string;
  name: string;
  initials: string;
  color: string;
  lastMessage: string;
  time: string;
  unread: number;
  type: "chat" | "group" | "business";
  verified?: boolean;
  phone?: string;
  paymentAmount?: string;
  paymentStatus?: "locked" | "delivered" | "awaiting";
}

export interface Message {
  id: string;
  from: "me" | "them";
  type:
    | "text"
    | "money_request"
    | "payment_sent"
    | "escrow_deal"
    | "image"
    | "video"
    | "location"
    | "voice_note";
  text?: string;
  amount?: number;
  amountStr?: string;
  note?: string;
  requestStatus?: "pending" | "paid" | "declined" | "expired";
  disputeStatus?: "flagged" | "disputed";
  disputeReason?: string;
  escrowTitle?: string;
  escrowStatus?: "pending" | "funded" | "released";
  mediaUrl?: string;
  mediaLabel?: string;
  locationName?: string;
  locationCoords?: string;
  time: string;
  /** true while the message is queued offline waiting to be delivered */
  queued?: boolean;
  /** Lifecycle status for messages sent by "me": sending -> sent -> delivered -> seen */
  status?: "sending" | "sent" | "delivered" | "seen";
  /** 0–1 upload progress, shown while a video/large media file is uploading */
  uploadProgress?: number;
}

export interface Dispute {
  id: string;
  convId: string;
  msgId: string;
  convName: string;
  type: "flag" | "dispute";
  reason: string;
  description: string;
  amountStr?: string;
  date: string;
  status: "open" | "under_review" | "resolved";
}

export interface Listing {
  id: string;
  title: string;
  price: string;
  priceRaw: number;
  seller: string;
  sellerVerified: boolean;
  category: string;
  description: string;
  status: "available" | "sold" | "reserved";
  color: string;
}

export interface UserProfile {
  userId: string;
  name: string;
  phone: string;
  email: string;
  ghanaCardId: string;
  verified: boolean;
  fpId: string;
  kycStatus: "pending" | "approved" | "rejected" | null;
  kycRejectionReason: string | null;
  createdAt: string;
}

export interface RegisterData {
  name: string;
  phone: string;
  pin: string;
  otpCode?: string;
  email?: string;
  password?: string;
  ghanaCardId?: string;
  dob?: string;
}

export interface PayLink {
  id: string;
  code: string;
  title: string;
  description: string;
  amount: number;
  amountStr: string;
  delivery?: string;
  status: "active" | "in_escrow" | "completed" | "cancelled" | "disputed";
  buyerName?: string;
  buyerPhone?: string;
  network?: string;
  createdAt: string;
  disputeReason?: string;
}

export interface Story {
  id: string;
  name: string;
  initials: string;
  color: string;
  convId: string | null;
  product: string;
  price: string;
  priceRaw: number;
  category: string;
  caption: string;
  // Real API fields
  userId: string;
  mediaUrl: string | null;
  storyType: "image" | "text" | "video";
  textColor: string | null;
  textBg: string | null;
  viewCount: number;
  myReaction: string | null;
  viewedByMe: boolean;
  visibilityType: string;
  createdAt: string;
  expiresAt: string;
  userFullName: string;
  userPhone: string;
  userAvatarUrl: string | null;
}

export interface StoryGroup {
  userId: string;
  userName: string;
  userInitials: string;
  userColor: string;
  userPhone: string;
  userAvatarUrl: string | null;
  isMe: boolean;
  hasUnviewed: boolean;
  stories: Story[];
}

export interface CreateStoryData {
  storyType: "image" | "text" | "video";
  mediaUri?: string;
  mediaName?: string;
  mediaSize?: number;
  mediaContentType?: string;
  caption?: string;
  textColor?: string;
  textBg?: string;
  visibilityType?: string;
}

interface AppContextType {
  balance: number;
  transactions: Transaction[];
  escrows: Escrow[];
  conversations: Conversation[];
  messages: Record<string, Message[]>;
  listings: Listing[];
  disputes: Dispute[];
  payLinks: PayLink[];
  notifications: number;
  profilePicture: string | null;
  stories: Story[];
  storyGroups: StoryGroup[];
  myStories: Story[];
  notifPayments: boolean;
  notifEscrow: boolean;
  notifMarketing: boolean;
  biometricEnabled: boolean;
  addMoney: (amount: number) => void;
  withdraw: (amount: number) => boolean;
  createEscrow: (escrow: Omit<Escrow, "id" | "date">) => void;
  releaseEscrow: (id: string) => void;
  sendMessage: (convId: string, text: string) => void;
  loadMessages: (userId: string) => Promise<void>;
  requestMoney: (convId: string, amount: number, note: string) => void;
  payRequest: (convId: string, msgId: string, amount: number) => boolean;
  declineRequest: (convId: string, msgId: string) => void;
  openDispute: (
    convId: string,
    msgId: string,
    type: "flag" | "dispute",
    reason: string,
    description: string,
    amountStr?: string
  ) => void;
  createChatEscrow: (convId: string, amount: number, title: string) => void;
  sendMediaMessage: (
    convId: string,
    type: "image" | "video" | "location" | "voice_note",
    label: string
  ) => void;
  sendImageMessage: (convId: string, localUri: string, contentType?: string) => Promise<void>;
  sendVideoMessage: (convId: string, localUri: string, contentType?: string) => Promise<void>;
  sendMoneyInChat: (convId: string, amount: number, note: string, recipientPhone: string, pin?: string) => Promise<{ success: boolean; error?: string }>;
  setProfilePicture: (uri: string | null) => void;
  updateSettings: (s: Partial<{ notifPayments: boolean; notifEscrow: boolean; notifMarketing: boolean; biometricEnabled: boolean }>) => void;
  updateAvatar: (url: string) => void;
  addContact: (name: string, phone: string) => Promise<string | null>;
  sendMobileMoney: (
    amount: number,
    phone: string,
    network: string,
    note?: string,
    totalCharged?: number,
    pin?: string
  ) => Promise<{ reference: string; recipientName: string; newBalancePesewas: number }>;
  payBill: (
    billerType: string,
    billerName: string,
    accountNumber: string,
    amount: number,
    pin: string
  ) => Promise<{ reference: string; newBalancePesewas: number }>;
  createPayLink: (
    title: string,
    description: string,
    amount: number,
    delivery?: string
  ) => string;
  payPayLink: (code: string, buyerPhone: string, network: string) => boolean;
  confirmPayLinkDelivery: (code: string) => void;
  disputePayLink: (code: string, reason: string) => void;
  viewStory: (storyId: string) => Promise<void>;
  reactToStory: (storyId: string, emoji: string) => Promise<void>;
  removeStoryReaction: (storyId: string) => Promise<void>;
  deleteStory: (storyId: string) => Promise<void>;
  muteUser: (userId: string) => Promise<void>;
  unmuteUser: (userId: string) => Promise<void>;
  replyToStory: (storyId: string, text: string) => Promise<void>;
  createStory: (data: CreateStoryData) => Promise<void>;
  authUserId: string | null;
  isAuthenticated: boolean;
  authLoading: boolean;
  currentUser: UserProfile | null;
  verifyPin: (pin: string) => Promise<boolean>;
  login: (phone: string, pin: string) => Promise<boolean>;
  register: (data: RegisterData) => Promise<{ fpId: string }>;
  logout: () => void;
  /** 'connected' | 'reconnecting' | 'disconnected' */
  socketStatus: "connected" | "reconnecting" | "disconnected";
  /** Increments each time the socket successfully reconnects after a drop */
  reconnectCount: number;
  /** Join a group socket room (call on group chat open, auto-rejoins after reconnect) */
  joinGroupRoom: (groupId: string) => void;
  /** Leave a group socket room (call on group chat close) */
  leaveGroupRoom: (groupId: string) => void;
  // ── Calls ──────────────────────────────────────────────────────────────────
  incomingCall: IncomingCallInfo | null;
  activeCall: ActiveCallInfo | null;
  outgoingCallPending: boolean;
  startCall: (convId: string, type: "voice" | "video") => Promise<void>;
  acceptCall: () => Promise<void>;
  rejectCall: () => Promise<void>;
  endCall: () => Promise<void>;
  // ── Voice notes ────────────────────────────────────────────────────────────
  startVoiceRecording: () => Promise<boolean>;
  /** Stop recording and return URI + duration for preview. Does NOT send. */
  stopVoiceRecording: () => Promise<{ uri: string; durLabel: string } | null>;
  /** Upload and send a previously stopped voice note. */
  sendVoiceNote: (convId: string, uri: string, durLabel: string) => Promise<void>;
  cancelVoiceRecording: () => void;
}

// ── Storage keys ──────────────────────────────────────────────────────────────

const ACCESS_TOKEN_KEY = "@fp_access";
const REFRESH_TOKEN_KEY = "@fp_refresh";
const USER_ID_KEY = "@fp_userid";

// Module-level token reference for the auth getter (sync access required)
let _currentToken: string | null = null;

// ── Helpers ───────────────────────────────────────────────────────────────────

const AVATAR_COLORS = [
  "#12D9A0", "#F59E0B", "#EC4899", "#10B981", "#3B82F6",
  "#F97316", "#00A884", "#9C59B3", "#C8932A", "#E74C3C",
];

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function nowTime(): string {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function fmtDate(d: Date | string | null | undefined): string {
  if (!d) return "";
  const date = d instanceof Date ? d : new Date(d as string);
  if (isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

function genCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function txTitle(type: string): string {
  const map: Record<string, string> = {
    momo_in: "Mobile Money In",
    momo_out: "Mobile Money Out",
    bank_in: "Bank Deposit",
    bank_out: "Bank Withdrawal",
    visa_in: "Card Deposit",
    escrow_hold: "Escrow Locked",
    escrow_release: "Escrow Released",
    p2p_send: "Money Sent",
    p2p_receive: "Money Received",
  };
  return map[type] ?? "Transaction";
}

function txSub(type: string, network?: string | null, phone?: string | null): string {
  const parts: string[] = [];
  if (network) parts.push(network);
  if (phone) parts.push(phone);
  if (parts.length === 0) parts.push(txTitle(type));
  return parts.join(" · ");
}

function txIcon(type: string): string {
  const map: Record<string, string> = {
    momo_in: "plus-circle",
    momo_out: "smartphone",
    bank_in: "plus-circle",
    bank_out: "arrow-up-circle",
    visa_in: "credit-card",
    escrow_hold: "lock",
    escrow_release: "unlock",
    p2p_send: "send",
    p2p_receive: "download",
  };
  return map[type] ?? "circle";
}

function mapEscrowStatus(
  s: string
): "In Escrow" | "Completed" | "Pending Release" | "Disputed" {
  if (s === "in_escrow") return "In Escrow";
  if (s === "released") return "Completed";
  if (s === "pending_release") return "Pending Release";
  if (s === "disputed") return "Disputed";
  if (s === "pending") return "In Escrow";
  if (s === "cancelled") return "Completed";
  return "In Escrow";
}

function mapEscrowTone(
  s: string
): "indigo" | "success" | "warning" | "danger" {
  if (s === "in_escrow" || s === "pending") return "indigo";
  if (s === "released") return "success";
  if (s === "pending_release") return "warning";
  if (s === "disputed") return "danger";
  if (s === "cancelled") return "success";
  return "indigo";
}

function mapPayLinkStatus(
  s: string
): "active" | "in_escrow" | "completed" | "cancelled" | "disputed" {
  const valid = ["active", "in_escrow", "completed", "cancelled", "disputed"];
  return (valid.includes(s) ? s : "active") as PayLink["status"];
}

// ── Deprecated static export (kept for backward compat) ──────────────────────
export const STORIES_DATA: Story[] = [];

// ── Context ───────────────────────────────────────────────────────────────────

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [authUserId, setAuthUserId] = useState<string | null>(null);

  // Raw escrow data ref — needed to look up releaseCode without re-render
  const escrowRawRef = useRef<any[]>([]);

  // Messages: local state, populated from API + socket
  const [messages, setMessages] = useState<Record<string, Message[]>>({});

  // Socket.IO ref
  const socketRef = useRef<ReturnType<typeof socketIO> | null>(null);

  // ── Connection reliability refs/state ─────────────────────────────────────
  const [socketStatus, setSocketStatus] = useState<"connected" | "reconnecting" | "disconnected">("disconnected");
  /** Increments each time socket reconnects after a drop (not on first connect) */
  const [reconnectCount, setReconnectCount] = useState(0);
  /** Group rooms to auto-rejoin after reconnect */
  const activeGroupRoomsRef = useRef<Set<string>>(new Set());
  /** Messages that failed HTTP delivery and are waiting to be retried on reconnect */
  type QueuedMsg = { convId: string; text: string; optimisticId: string };
  const offlineQueueRef = useRef<QueuedMsg[]>([]);
  /** Stable ref to the send mutation so the socket event handler can call it */
  const sendMessageMutRef = useRef<typeof sendMessageMut | null>(null);
  /** Stable ref to loadMessages so reconnect handler can reload conversations */
  const loadMessagesRef = useRef<((userId: string) => Promise<void>) | null>(null);
  /** Whether the socket has ever connected (distinguishes initial vs. re-connect) */
  const hasEverConnectedRef = useRef(false);

  // ── Call state ────────────────────────────────────────────────────────────
  const [incomingCall, setIncomingCall] = useState<IncomingCallInfo | null>(null);
  const [activeCall, setActiveCall] = useState<ActiveCallInfo | null>(null);
  const [outgoingCallPending, setOutgoingCallPending] = useState(false);
  /** Stores initiate-response data while waiting for the callee to accept */
  const pendingOutgoingCallRef = useRef<{
    callId: string; channelName: string; agoraToken: string; agoraAppId: string;
    type: "voice" | "video"; peerName: string; peerInitials: string;
    peerColor: string; peerAvatarUrl?: string | null;
  } | null>(null);

  // ── Voice recording ref ───────────────────────────────────────────────────
  const voiceRecordingRef = useRef<Audio.Recording | null>(null);

  // Optimistic override for settings toggles — clears once server refetch completes
  const [settingsOverride, setSettingsOverride] = useState<{
    notifPayments?: boolean;
    notifEscrow?: boolean;
    notifMarketing?: boolean;
    biometricEnabled?: boolean;
  } | null>(null);

  // ── Token refresh helper ──────────────────────────────────────────────────

  function jwtExpiresAt(token: string): number | null {
    try {
      const part = token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
      const padded = part + "=".repeat((4 - (part.length % 4)) % 4);
      const json = decodeURIComponent(
        atob(padded)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
      const payload = JSON.parse(json) as { exp?: number };
      return typeof payload.exp === "number" ? payload.exp * 1000 : null;
    } catch {
      return null;
    }
  }

  async function refreshAccessToken(): Promise<string | null> {
    const rToken = await AsyncStorage.getItem(REFRESH_TOKEN_KEY).catch(() => null);
    if (!rToken) {
      _currentToken = null;
      setIsAuthenticated(false);
      setAuthUserId(null);
      AsyncStorage.multiRemove([ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY, USER_ID_KEY]).catch(() => {});
      return null;
    }
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain) return null;
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken: rToken }),
      });
      if (!res.ok) {
        _currentToken = null;
        setIsAuthenticated(false);
        setAuthUserId(null);
        AsyncStorage.multiRemove([ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY, USER_ID_KEY]).catch(() => {});
        return null;
      }
      const data = await res.json() as { accessToken: string; refreshToken: string };
      _currentToken = data.accessToken;
      await AsyncStorage.multiSet([
        [ACCESS_TOKEN_KEY, data.accessToken],
        [REFRESH_TOKEN_KEY, data.refreshToken],
      ]).catch(() => {});
      return data.accessToken;
    } catch {
      return null;
    }
  }

  // ── Bootstrap: load saved token from AsyncStorage ─────────────────────────
  useEffect(() => {
    // Async getter — proactively refreshes when token is within 2 min of expiry
    setAuthTokenGetter(async () => {
      if (!_currentToken) return null;
      const exp = jwtExpiresAt(_currentToken);
      if (exp !== null && Date.now() > exp - 2 * 60 * 1000) {
        const refreshed = await refreshAccessToken();
        return refreshed ?? _currentToken;
      }
      return _currentToken;
    });

    AsyncStorage.multiGet([ACCESS_TOKEN_KEY, USER_ID_KEY])
      .then(([[, access], [, userId]]) => {
        if (access) {
          _currentToken = access;
          setAuthUserId(userId);
          setIsAuthenticated(true);
        }
        setAuthLoading(false);
      })
      .catch(() => setAuthLoading(false));

    return () => {
      setAuthTokenGetter(null);
    };
  }, []);

  // ── Socket.IO connection ───────────────────────────────────────────────────

  useEffect(() => {
    if (!isAuthenticated || !_currentToken) return;
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain) return;

    const s = socketIO(socketOrigin(domain), {
      path: "/api/socket.io",
      transports: ["websocket"],
      auth: { token: _currentToken },
      // Reconnection with true exponential backoff + jitter
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 30000,
      randomizationFactor: 0.5,
    });
    socketRef.current = s;

    // ── Connection lifecycle ─────────────────────────────────────────────

    s.on("connect", () => {
      setSocketStatus("connected");

      if (hasEverConnectedRef.current) {
        // This is a RE-connect after a drop
        setReconnectCount((c) => c + 1);

        // Rejoin every group room the user was in before the drop
        for (const groupId of activeGroupRoomsRef.current) {
          s.emit("join_group", { groupId });
        }

        // Flush queued messages that failed while offline
        const queue = [...offlineQueueRef.current];
        offlineQueueRef.current = [];
        for (const { convId, text, optimisticId } of queue) {
          const mut = sendMessageMutRef.current;
          if (!mut) continue;
          mut.mutate(
            { data: { toUserId: convId, content: text, messageType: "text" } },
            {
              onSuccess: (result: any) => {
                setMessages((prev) => {
                  const msgs = prev[convId] ?? [];
                  const idx = msgs.findIndex((m) => m.id === optimisticId);
                  if (idx === -1) return prev;
                  const updated = [...msgs];
                  updated[idx] = { ...updated[idx], id: result.id, queued: false, status: "sent" };
                  return { ...prev, [convId]: updated };
                });
                queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
              },
              onError: () => {
                // Still failing — put back in queue
                offlineQueueRef.current.push({ convId, text, optimisticId });
              },
            }
          );
        }

        // Refetch balance/transactions to catch any missed real-time events
        queryClient.refetchQueries({ queryKey: getGetWalletBalanceQueryKey() });
        queryClient.refetchQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      }

      hasEverConnectedRef.current = true;
    });

    s.on("disconnect", () => {
      setSocketStatus("reconnecting");
    });

    s.on("connect_error", () => {
      setSocketStatus("reconnecting");
    });

    // ── App-level heartbeat (on top of engine.io ping/pong) ──────────────
    // If we stop getting heartbeat_ack the socket-io reconnection will kick in
    // via the disconnect event anyway, but this gives an early warning.
    const heartbeatInterval = setInterval(() => {
      if (s.connected) s.emit("heartbeat");
    }, 30_000);

    s.on("heartbeat_ack", () => {
      // Connection is alive — no action needed; disconnect event handles failure
    });

    // ── App events ───────────────────────────────────────────────────────

    s.on("story:new", () => {
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListMyStoriesQueryKey() });
    });

    s.on("balance_updated", () => {
      playPaymentSound();
      queryClient.refetchQueries({ queryKey: getGetWalletBalanceQueryKey() });
      queryClient.refetchQueries({ queryKey: getListTransactionsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
    });

    s.on("kyc_approved", () => {
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    });

    s.on("kyc_rejected", () => {
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
    });

    s.on("new_message", (msg: any) => {
      const senderId = msg.senderId as string;
      setMessages((prev) => {
        const existing = prev[senderId] ?? [];
        if (existing.find((m) => m.id === msg.id)) return prev;
        const msgType = (msg.messageType ?? "text") as Message["type"];
        const isMedia = msgType === "image" || msgType === "video";
        const isPayment = msgType === "payment_sent";

        let mappedFields: Partial<Message> = {};
        if (isPayment) {
          try {
            const pay = JSON.parse(msg.content ?? "{}");
            mappedFields = { amountStr: pay.amountStr ?? "", note: pay.note ?? undefined };
          } catch {
            mappedFields = { amountStr: msg.content ?? "" };
          }
          queryClient.invalidateQueries({ queryKey: getGetWalletBalanceQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
        }

        const mapped: Message = {
          id: msg.id,
          from: "them",
          type: msgType,
          text: isMedia || isPayment ? undefined : (msg.content ?? ""),
          mediaUrl: msg.mediaUrl ?? undefined,
          time: new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          ...mappedFields,
        };
        return { ...prev, [senderId]: [...existing, mapped] };
      });

      // Acknowledge delivery back to the sender
      s.emit("msg_ack", { messageId: msg.id, senderId: msg.senderId });

      playMessageSound();
      queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
    });

    // Recipient's device confirmed receipt of a message we sent
    s.on("msg_delivered", ({ messageId, byUserId }: { messageId: string; byUserId: string }) => {
      setMessages((prev) => {
        const msgs = prev[byUserId];
        if (!msgs) return prev;
        const idx = msgs.findIndex((m) => m.id === messageId);
        // Don't downgrade a message that's already been marked "seen"
        if (idx === -1 || msgs[idx].status === "seen") return prev;
        const updated = [...msgs];
        updated[idx] = { ...updated[idx], status: "delivered" };
        return { ...prev, [byUserId]: updated };
      });
      playMessageDeliveredSound();
    });

    // Recipient opened the conversation and read our messages
    s.on("messages_read", ({ byUserId }: { byUserId: string }) => {
      let didUpdate = false;
      setMessages((prev) => {
        const msgs = prev[byUserId];
        if (!msgs) return prev;
        const updated = msgs.map((m) => {
          if (m.from === "me" && m.status !== "seen") {
            didUpdate = true;
            return { ...m, status: "seen" as const };
          }
          return m;
        });
        return { ...prev, [byUserId]: updated };
      });
      if (didUpdate) playMessageSeenSound();
    });

    // ── Call signaling events ─────────────────────────────────────────────
    s.on("call:invite", (data: IncomingCallInfo) => {
      setIncomingCall(data);
    });

    s.on("call:accepted", (data: { callId: string; channelName: string; agoraToken: string; agoraAppId: string }) => {
      const pending = pendingOutgoingCallRef.current;
      if (!pending || pending.callId !== data.callId) return;
      pendingOutgoingCallRef.current = null;
      setOutgoingCallPending(false);
      setActiveCall({
        callId: data.callId,
        channelName: pending.channelName,
        agoraToken: pending.agoraToken,
        agoraAppId: pending.agoraAppId || data.agoraAppId,
        type: pending.type,
        peerName: pending.peerName,
        peerInitials: pending.peerInitials,
        peerColor: pending.peerColor,
        peerAvatarUrl: pending.peerAvatarUrl,
        isCaller: true,
      });
    });

    s.on("call:declined", () => {
      pendingOutgoingCallRef.current = null;
      setOutgoingCallPending(false);
    });

    s.on("call:busy", () => {
      pendingOutgoingCallRef.current = null;
      setOutgoingCallPending(false);
    });

    s.on("call:ended", () => {
      setActiveCall(null);
      setIncomingCall(null);
    });

    return () => {
      clearInterval(heartbeatInterval);
      s.disconnect();
      socketRef.current = null;
      setSocketStatus("disconnected");
    };
  }, [isAuthenticated, queryClient]);

  // ── Native push notification registration (Expo Push / Android + iOS) ──────
  // Registers this device for push so the user is notified of new messages,
  // reels/story activity, escrow updates etc. even when the app is backgrounded
  // or fully closed. Web push (PWA) is handled separately via the service worker.

  useEffect(() => {
    if (!isAuthenticated || !_currentToken) return;
    if (Platform.OS === "web") return; // web/PWA push uses a different flow
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain) return;

    let cancelled = false;

    (async () => {
      if (!Device.isDevice) return; // push tokens aren't available on simulators/emulators

      const permCheck = (await Notifications.getPermissionsAsync()) as { status: string };
      let finalStatus = permCheck.status;
      if (finalStatus !== "granted") {
        const permRequest = (await Notifications.requestPermissionsAsync()) as { status: string };
        finalStatus = permRequest.status;
      }
      if (finalStatus !== "granted" || cancelled) return;

      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("default", {
          name: "default",
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: "#1E1C4D",
        });
      }

      try {
        const tokenResponse = await Notifications.getExpoPushTokenAsync({
          projectId: "a4e7c0d4-7f9e-43f9-bed6-c427a4323732",
        });
        if (cancelled) return;

        await fetch(`${apiOrigin(domain)}/api/push/expo-subscribe`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${_currentToken}`,
          },
          body: JSON.stringify({ token: tokenResponse.data, platform: Platform.OS }),
        });
      } catch (err) {
        console.warn("Failed to register for push notifications:", err);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isAuthenticated]);

  // Show notifications as banners even while the app is in the foreground
  useEffect(() => {
    if (Platform.OS === "web") return;
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowBanner: true,
        shouldShowList: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
      }),
    });
  }, []);

  // Tapping a notification opens the relevant screen (chat, story, reel, etc.)
  useEffect(() => {
    if (Platform.OS === "web") return;
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const url = response.notification.request.content.data?.url as string | undefined;
      if (url) {
        router.push(url as any);
      }
    });
    return () => subscription.remove();
  }, []);

  // ── API queries ───────────────────────────────────────────────────────────

  const meQuery = useGetMe({
    query: { enabled: isAuthenticated, queryKey: getGetMeQueryKey() },
  });
  const walletQuery = useGetWalletBalance({
    query: { enabled: isAuthenticated, queryKey: getGetWalletBalanceQueryKey() },
  });
  const txQuery = useListTransactions(undefined, {
    query: { enabled: isAuthenticated, queryKey: getListTransactionsQueryKey() },
  });
  const escrowQuery = useListEscrow({
    query: { enabled: isAuthenticated, queryKey: getListEscrowQueryKey() },
  });
  const storiesQuery = useListStories({
    query: { enabled: isAuthenticated, queryKey: getListStoriesQueryKey() },
  });
  const contactsQuery = useListContacts({
    query: { enabled: isAuthenticated, queryKey: getListContactsQueryKey() },
  });
  const payLinksQuery = useListPaymentLinks({
    query: { enabled: isAuthenticated, queryKey: getListPaymentLinksQueryKey() },
  });
  const listConversationsQuery = useListConversations({
    query: { enabled: isAuthenticated, queryKey: getListConversationsQueryKey() },
  });

  // ── Mutations ─────────────────────────────────────────────────────────────

  const loginMut = useAuthLogin();
  const registerMut = useAuthRegister();
  const logoutMut = useAuthLogout();
  const depositMut = useDepositFunds();
  const withdrawMut = useWithdrawFunds();
  const sendMoneyMut = useSendMoney();
  const payBillMut = usePayBill();
  const createEscrowMut = useCreateEscrow();
  const releaseEscrowMut = useReleaseEscrow();
  const addContactMut = useAddContact();
  const createPayLinkMut = useCreatePaymentLink();
  const payPayLinkMut = usePayPaymentLink();
  const confirmPayLinkMut = useConfirmPayLinkDelivery();
  const disputePayLinkMut = useDisputePayLinkAPI();
  const sendMessageMut = useSendMessageAPI();
  // Keep a stable ref so the socket connect handler can flush the offline queue
  // without needing sendMessageMut in its dependency array.
  useEffect(() => { sendMessageMutRef.current = sendMessageMut; }, [sendMessageMut]);
  const updateSettingsMut = useUpdateMySettings();
  const updateAvatarMut = useUpdateMyAvatar();
  const createStoryMut = useCreateStory();
  const deleteStoryMut = useDeleteStory();
  const viewStoryMut = useViewStory();
  const reactToStoryMut = useReactToStory();
  const removeStoryReactionMut = useRemoveStoryReaction();
  const replyToStoryMut = useReplyToStory();
  const muteUserStoriesMut = useMuteUserStories();
  const unmuteUserStoriesMut = useUnmuteUserStories();
  const requestUploadUrlMut = useRequestUploadUrl();

  // ── Invalidation helpers ──────────────────────────────────────────────────

  const invalidateWallet = useCallback(() => {
    // Invalidate + force-refetch immediately (invalidate alone doesn't refetch on React Native)
    queryClient.refetchQueries({ queryKey: getGetWalletBalanceQueryKey() });
    queryClient.refetchQueries({ queryKey: getListTransactionsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
  }, [queryClient]);

  const invalidateEscrow = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: getListEscrowQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetWalletBalanceQueryKey() });
  }, [queryClient]);

  // ── Auth actions ──────────────────────────────────────────────────────────

  const login = useCallback(
    async (phone: string, pin: string): Promise<boolean> => {
      try {
        const result = await loginMut.mutateAsync({ data: { phone, pin } });
        _currentToken = (result as any).accessToken;
        await AsyncStorage.multiSet([
          [ACCESS_TOKEN_KEY, (result as any).accessToken],
          [REFRESH_TOKEN_KEY, (result as any).refreshToken],
          [USER_ID_KEY, (result as any).userId],
        ]);
        setIsAuthenticated(true);
        setAuthUserId((result as any).userId);
        return true;
      } catch {
        return false;
      }
    },
    [loginMut]
  );

  const register = useCallback(
    async (data: RegisterData): Promise<{ fpId: string }> => {
      const result = await registerMut.mutateAsync({
        data: {
          phone: data.phone,
          pin: data.pin,
          fullName: data.name,
          email: data.email || undefined,
          ghanaCardId: data.ghanaCardId || undefined,
          dateOfBirth: data.dob || undefined,
          otpCode: data.otpCode || undefined,
        },
      });
      _currentToken = (result as any).accessToken;
      await AsyncStorage.multiSet([
        [ACCESS_TOKEN_KEY, (result as any).accessToken],
        [REFRESH_TOKEN_KEY, (result as any).refreshToken],
        [USER_ID_KEY, (result as any).userId],
      ]);
      setIsAuthenticated(true);
      setAuthUserId((result as any).userId);
      return { fpId: (result as any).fpId ?? "" };
    },
    [registerMut]
  );

  const logout = useCallback(() => {
    AsyncStorage.getItem(REFRESH_TOKEN_KEY)
      .then((rToken) => {
        if (rToken) logoutMut.mutate({ data: { refreshToken: rToken } });
      })
      .catch(() => {});
    _currentToken = null;
    AsyncStorage.multiRemove([ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY, USER_ID_KEY]).catch(
      () => {}
    );
    queryClient.clear();
    setIsAuthenticated(false);
    setAuthUserId(null);
  }, [logoutMut, queryClient]);

  // ── Derived data ──────────────────────────────────────────────────────────

  const balance = ((walletQuery.data as any)?.balancePesewas ?? 0) / 100;

  const transactions: Transaction[] = useMemo(() => {
    const items = (txQuery.data as any)?.items ?? [];
    return items.map((t: any) => {
      const amtGhs = t.amountPesewas / 100;
      const isCredit = [
        "momo_in",
        "bank_in",
        "visa_in",
        "p2p_receive",
        "escrow_release",
      ].includes(t.type);
      return {
        id: t.id,
        title: txTitle(t.type),
        sub: t.note ?? txSub(t.type, t.network, t.counterpartyPhone),
        amount: isCredit
          ? `+ GH₵ ${amtGhs.toFixed(2)}`
          : `- GH₵ ${amtGhs.toFixed(2)}`,
        amountRaw: isCredit ? amtGhs : -amtGhs,
        type: (isCredit ? "credit" : "debit") as "credit" | "debit",
        icon: txIcon(t.type),
        date: fmtDate(t.createdAt),
      };
    });
  }, [txQuery.data]);

  const escrows: Escrow[] = useMemo(() => {
    const items: any[] = (escrowQuery.data as any[]) ?? [];
    escrowRawRef.current = items;
    return items.map((e: any) => {
      const amtGhs = e.amountPesewas / 100;
      const isBuyer = e.buyerId === authUserId;
      return {
        id: e.id,
        title: e.title,
        withWho: isBuyer
          ? e.sellerId?.slice(0, 8) ?? "Seller"
          : e.buyerId?.slice(0, 8) ?? "Buyer",
        amount: `GH₵ ${amtGhs.toLocaleString()}`,
        amountRaw: amtGhs,
        status: mapEscrowStatus(e.status),
        tone: mapEscrowTone(e.status),
        date: fmtDate(e.createdAt),
        direction: (isBuyer ? "sent" : "received") as "sent" | "received",
      };
    });
  }, [escrowQuery.data, authUserId]);

  const currentUser: UserProfile | null = useMemo(() => {
    const u = meQuery.data as any;
    if (!u) return null;
    return {
      userId: u.id ?? authUserId ?? "",
      name: u.fullName ?? u.name ?? "",
      phone: u.phone ?? "",
      email: u.email ?? "",
      ghanaCardId: u.ghanaCardId ?? "",
      verified: u.isKycVerified ?? false,
      fpId: u.fpId ?? "",
      kycStatus: u.kycStatus ?? null,
      kycRejectionReason: u.kycRejectionReason ?? null,
      createdAt: fmtDate(u.createdAt),
    };
  }, [meQuery.data, authUserId]);

  const stories: Story[] = useMemo(() => {
    const items: any[] = (storiesQuery.data as any[]) ?? [];
    return items.map((s: any, i: number) => {
      const fullName = s.userFullName ?? s.userId?.slice(0, 8) ?? "User";
      const words = fullName.trim().split(/\s+/);
      const initials = words.length >= 2
        ? (words[0][0] + words[words.length - 1][0]).toUpperCase()
        : fullName.slice(0, 2).toUpperCase();
      return {
        id: s.id,
        userId: s.userId ?? "",
        name: fullName,
        initials,
        color: AVATAR_COLORS[i % AVATAR_COLORS.length],
        convId: null,
        product: s.caption?.split(" ").slice(0, 4).join(" ") ?? "Status",
        price: "GH₵ 0",
        priceRaw: 0,
        category: s.storyType === "text" ? "Text" : s.storyType === "video" ? "Video" : "Photo",
        caption: s.caption ?? "",
        mediaUrl: s.mediaUrl ?? null,
        storyType: (s.storyType ?? "text") as "image" | "text" | "video",
        textColor: s.textColor ?? null,
        textBg: s.textBg ?? null,
        viewCount: s.viewCount ?? 0,
        myReaction: s.myReaction ?? null,
        viewedByMe: s.viewedByMe ?? false,
        visibilityType: s.visibilityType ?? "contacts",
        createdAt: s.createdAt ?? new Date().toISOString(),
        expiresAt: s.expiresAt ?? new Date().toISOString(),
        userFullName: fullName,
        userPhone: s.userPhone ?? "",
        userAvatarUrl: s.userAvatarUrl ?? null,
      };
    });
  }, [storiesQuery.data]);

  const storyGroups: StoryGroup[] = useMemo(() => {
    const groupMap = new Map<string, Story[]>();
    stories.forEach((s) => {
      if (!groupMap.has(s.userId)) groupMap.set(s.userId, []);
      groupMap.get(s.userId)!.push(s);
    });
    const groups: StoryGroup[] = [];
    groupMap.forEach((storyList, userId) => {
      const first = storyList[0];
      groups.push({
        userId,
        userName: first.userFullName,
        userInitials: first.initials,
        userColor: first.color,
        userPhone: first.userPhone,
        userAvatarUrl: first.userAvatarUrl,
        isMe: userId === authUserId,
        hasUnviewed: storyList.some((s) => !s.viewedByMe),
        stories: storyList,
      });
    });
    groups.sort((a, b) => {
      if (a.isMe && !b.isMe) return -1;
      if (!a.isMe && b.isMe) return 1;
      return 0;
    });
    return groups;
  }, [stories, authUserId]);

  const myStories: Story[] = useMemo(
    () => stories.filter((s) => s.userId === authUserId),
    [stories, authUserId]
  );

  const notifPayments    = settingsOverride?.notifPayments    ?? (meQuery.data as any)?.notifPayments    ?? true;
  const notifEscrow      = settingsOverride?.notifEscrow      ?? (meQuery.data as any)?.notifEscrow      ?? true;
  const notifMarketing   = settingsOverride?.notifMarketing   ?? (meQuery.data as any)?.notifMarketing   ?? false;
  const biometricEnabled = settingsOverride?.biometricEnabled ?? (meQuery.data as any)?.biometricEnabled ?? false;

  const conversations: Conversation[] = useMemo(() => {
    const convItems: any[] = (listConversationsQuery.data as any[]) ?? [];
    const contactItems: any[] = (contactsQuery.data as any[]) ?? [];

    const convUserIds = new Set(convItems.map((c: any) => c.userId));

    const convMapped = convItems.map((c: any, i: number) => ({
      id: c.userId,
      name: c.fullName,
      initials: (c.fullName as string).slice(0, 2).toUpperCase(),
      color: AVATAR_COLORS[i % AVATAR_COLORS.length],
      lastMessage: c.lastMessage ?? "",
      time: c.lastMessageAt
        ? new Date(c.lastMessageAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        : "",
      unread: c.unreadCount ?? 0,
      type: (c.isVendor ? "business" : "chat") as "chat" | "business",
      verified: c.isKycVerified ?? false,
      phone: c.phone ?? undefined,
    }));

    // Contacts that don't already have a conversation appear at the end
    const contactMapped = contactItems
      .filter((c: any) => c.contactUserId && !convUserIds.has(c.contactUserId))
      .map((c: any, i: number) => ({
        id: c.contactUserId,
        name: c.nickname ?? c.contactName ?? c.contactPhone ?? "Contact",
        initials: (c.nickname ?? c.contactName ?? c.contactPhone ?? "?")
          .slice(0, 2)
          .toUpperCase(),
        color: AVATAR_COLORS[(convMapped.length + i) % AVATAR_COLORS.length],
        lastMessage: "",
        time: "",
        unread: 0,
        type: "chat" as const,
        phone: c.contactPhone ?? undefined,
      }));

    return [...convMapped, ...contactMapped];
  }, [listConversationsQuery.data, contactsQuery.data]);

  const payLinks: PayLink[] = useMemo(() => {
    const items: any[] = (payLinksQuery.data as any[]) ?? [];
    return items.map((p: any) => ({
      id: p.id,
      code: p.code,
      title: p.title,
      description: p.description ?? "",
      amount: (p.amountPesewas ?? 0) / 100,
      amountStr: `GH₵ ${((p.amountPesewas ?? 0) / 100).toLocaleString()}`,
      delivery: p.delivery ?? undefined,
      status: mapPayLinkStatus(p.status),
      buyerName: p.buyerName ?? undefined,
      buyerPhone: p.buyerPhone ?? undefined,
      network: p.network ?? undefined,
      createdAt: fmtDate(p.createdAt),
      disputeReason: p.disputeReason ?? undefined,
    }));
  }, [payLinksQuery.data]);

  // ── Financial actions ─────────────────────────────────────────────────────

  const addMoney = useCallback(
    (amount: number) => {
      depositMut.mutate(
        { data: { amountPesewas: Math.round(amount * 100), network: "MTN" } },
        { onSuccess: invalidateWallet }
      );
    },
    [depositMut, invalidateWallet]
  );

  const withdraw = useCallback(
    (amount: number): boolean => {
      if (amount > balance) return false;
      withdrawMut.mutate(
        {
          // PIN gate not yet wired into this legacy path — server will reject with 401
          data: {
            amountPesewas: Math.round(amount * 100),
            network: "bank",
            accountNumber: "default",
          } as any,
        },
        { onSuccess: invalidateWallet }
      );
      return true;
    },
    [balance, withdrawMut, invalidateWallet]
  );

  const createEscrow = useCallback(
    (escrow: Omit<Escrow, "id" | "date">) => {
      createEscrowMut.mutate(
        {
          data: {
            sellerPhone: escrow.withWho,
            title: escrow.title,
            description: escrow.title,
            amountPesewas: Math.round(escrow.amountRaw * 100),
          },
        },
        { onSuccess: invalidateEscrow }
      );
    },
    [createEscrowMut, invalidateEscrow]
  );

  const releaseEscrow = useCallback(
    (id: string) => {
      // Look up the releaseCode from the raw escrow data we cached in a ref
      const raw = escrowRawRef.current;
      const found = raw.find((e: any) => e.id === id);
      const releaseCode: string = found?.releaseCode ?? "";
      releaseEscrowMut.mutate(
        { id, data: { releaseCode } },
        { onSuccess: invalidateEscrow }
      );
    },
    [releaseEscrowMut, invalidateEscrow]
  );

  const sendMobileMoney = useCallback(
    async (
      amount: number,
      phone: string,
      _network: string,
      note?: string,
      totalCharged?: number,
      pin?: string
    ): Promise<{ reference: string; recipientName: string; newBalancePesewas: number }> => {
      const deduct = totalCharged ?? amount;
      if (deduct > balance) throw new Error("Insufficient funds");
      const result = await sendMoneyMut.mutateAsync({
        data: {
          toPhone: phone,
          amountPesewas: Math.round(amount * 100),
          note: note ?? undefined,
          pin: pin ?? "",
        } as any,
      });
      const res = result as unknown as { reference: string; recipientName: string; newBalancePesewas: number };
      // Instantly apply the authoritative new balance from the server response
      queryClient.setQueryData(getGetWalletBalanceQueryKey(), (old: any) => ({
        ...(old ?? {}),
        balancePesewas: res.newBalancePesewas,
      }));
      invalidateWallet();
      return res;
    },
    [balance, sendMoneyMut, invalidateWallet, queryClient]
  );

  const payBill = useCallback(
    async (
      billerType: string,
      billerName: string,
      accountNumber: string,
      amount: number,
      pin: string
    ): Promise<{ reference: string; newBalancePesewas: number }> => {
      const amountPesewas = Math.round(amount * 100);
      if (amount > balance) throw new Error("Insufficient funds");
      const result = await payBillMut.mutateAsync({
        data: {
          billerType,
          billerName,
          accountNumber,
          amountPesewas,
          pin,
        } as any,
      });
      const res = result as unknown as { id: string; reference: string; amountPesewas: number };
      const newBalancePesewas = Math.round(balance * 100) - res.amountPesewas;
      queryClient.setQueryData(getGetWalletBalanceQueryKey(), (old: any) => ({
        ...(old ?? {}),
        balancePesewas: newBalancePesewas,
      }));
      invalidateWallet();
      queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
      return { reference: res.reference, newBalancePesewas };
    },
    [balance, payBillMut, invalidateWallet, queryClient]
  );

  const verifyPin = useCallback(async (pin: string): Promise<boolean> => {
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain || !_currentToken) return false;
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/auth/verify-pin`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${_currentToken}` },
        body: JSON.stringify({ pin }),
      });
      return res.ok;
    } catch {
      return false;
    }
  }, []);

  const createPayLink = useCallback(
    (
      title: string,
      description: string,
      amount: number,
      delivery?: string
    ): string => {
      genCode(); // generate a local code (the real code comes from API response)
      createPayLinkMut.mutate(
        { data: { title, description, amountPesewas: Math.round(amount * 100), isFixedAmount: true } },
        {
          onSuccess: () =>
            queryClient.invalidateQueries({
              queryKey: getListPaymentLinksQueryKey(),
            }),
        }
      );
      return genCode();
    },
    [createPayLinkMut, queryClient]
  );

  const payPayLink = useCallback(
    (code: string, buyerPhone: string, network: string): boolean => {
      const link = payLinks.find((p) => p.code === code);
      const amountPesewas = link ? Math.round(link.amount * 100) : 1;
      payPayLinkMut.mutate(
        { code, data: { buyerPhone, network, amountPesewas } },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({
              queryKey: getListPaymentLinksQueryKey(),
            });
            invalidateWallet();
          },
        }
      );
      return true;
    },
    [payPayLinkMut, queryClient, invalidateWallet]
  );

  const addContact = useCallback(
    async (name: string, phone: string): Promise<string | null> => {
      try {
        const result = await addContactMut.mutateAsync({ data: { phone, nickname: name } });
        queryClient.invalidateQueries({ queryKey: getListContactsQueryKey() });
        return (result as any).contactUserId ?? null;
      } catch {
        return null;
      }
    },
    [addContactMut, queryClient]
  );

  // ── Messaging ─────────────────────────────────────────────────────────────

  const loadMessages = useCallback(async (userId: string): Promise<void> => {
    if (!_currentToken) return;
    try {
      const data = await getMessagesAPI(userId);
      const mapped: Message[] = (data as any[]).map((m: any) => {
        const msgType = (m.messageType ?? "text") as Message["type"];
        const isMedia = msgType === "image" || msgType === "video";
        const isPayment = msgType === "payment_sent";

        let extra: Partial<Message> = {};
        if (isPayment) {
          try {
            const pay = JSON.parse(m.content ?? "{}");
            extra = { amountStr: pay.amountStr ?? "", note: pay.note ?? undefined };
          } catch {
            extra = { amountStr: m.content ?? "" };
          }
        }

        const isMe = m.senderId === authUserId;
        return {
          id: m.id,
          from: (isMe ? "me" : "them") as "me" | "them",
          type: msgType,
          text: isMedia || isPayment ? undefined : (m.content ?? ""),
          mediaUrl: m.mediaUrl ?? undefined,
          time: new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          status: isMe ? (m.isRead ? "seen" : m.isDelivered ? "delivered" : "sent") : undefined,
          ...extra,
        };
      });
      const dbIds = new Set(mapped.map((m) => m.id));
      setMessages((prev) => {
        const inFlight = (prev[userId] ?? []).filter((m) => !dbIds.has(m.id));
        return { ...prev, [userId]: [...mapped, ...inFlight] };
      });
    } catch { /* silently ignore network failures */ }
  }, [authUserId]);

  const sendMessage = useCallback((convId: string, text: string) => {
    const optimisticId = uid();
    const msg: Message = { id: optimisticId, from: "me", type: "text", text, time: nowTime(), status: "sending" };
    setMessages((prev) => ({
      ...prev,
      [convId]: [...(prev[convId] ?? []), msg],
    }));
    sendMessageMut.mutate(
      { data: { toUserId: convId, content: text, messageType: "text" } },
      {
        onSuccess: (result: any) => {
          setMessages((prev) => {
            const msgs = prev[convId] ?? [];
            const idx = msgs.findIndex((m) => m.id === optimisticId);
            if (idx === -1) return prev;
            const updated = [...msgs];
            updated[idx] = { ...updated[idx], id: result.id, queued: false, status: "sent" };
            return { ...prev, [convId]: updated };
          });
          playMessageSentSound();
          queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        },
        onError: () => {
          // Network was down — mark message as queued and add to retry queue.
          // The socket reconnect handler will flush this queue automatically.
          setMessages((prev) => {
            const msgs = prev[convId] ?? [];
            return {
              ...prev,
              [convId]: msgs.map((m) =>
                m.id === optimisticId ? { ...m, queued: true } : m
              ),
            };
          });
          offlineQueueRef.current.push({ convId, text, optimisticId });
        },
      }
    );
  }, [sendMessageMut, queryClient]);

  const requestMoney = useCallback(
    (convId: string, amount: number, note: string) => {
      const amountStr = `GH₵ ${amount.toLocaleString()}`;
      const optimisticId = uid();
      const msg: Message = {
        id: optimisticId,
        from: "me",
        type: "money_request",
        amount,
        amountStr,
        note,
        requestStatus: "pending",
        time: nowTime(),
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), msg],
      }));
      sendMessageMut.mutate(
        { data: { toUserId: convId, messageType: "payment_request", content: note || `Payment request for ${amountStr}` } },
        {
          onSuccess: (result: any) => {
            setMessages((prev) => {
              const msgs = prev[convId] ?? [];
              const idx = msgs.findIndex((m) => m.id === optimisticId);
              if (idx === -1) return prev;
              const updated = [...msgs];
              updated[idx] = { ...updated[idx], id: result.id };
              return { ...prev, [convId]: updated };
            });
            queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
          },
        }
      );
    },
    [sendMessageMut, queryClient]
  );

  const payRequest = useCallback(
    (convId: string, msgId: string, amount: number): boolean => {
      const conv = conversations.find((c) => c.id === convId);
      if (!conv?.phone) return false;
      setMessages((prev) => ({
        ...prev,
        [convId]: (prev[convId] ?? []).map((m) =>
          m.id === msgId ? { ...m, requestStatus: "paid" as const } : m
        ),
      }));
      sendMoneyMut.mutate(
        // PIN gate not yet wired into payRequest path — server rejects with 401 if called without PIN
        { data: { toPhone: conv.phone, amountPesewas: Math.round(amount * 100) } as any },
        {
          onSuccess: () => {
            invalidateWallet();
            queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
          },
          onError: () => {
            setMessages((prev) => ({
              ...prev,
              [convId]: (prev[convId] ?? []).map((m) =>
                m.id === msgId ? { ...m, requestStatus: "pending" as const } : m
              ),
            }));
          },
        }
      );
      return true;
    },
    [conversations, sendMoneyMut, invalidateWallet, queryClient]
  );

  const declineRequest = useCallback(
    (convId: string, msgId: string) => {
      setMessages((prev) => ({
        ...prev,
        [convId]: (prev[convId] ?? []).map((m) =>
          m.id === msgId ? { ...m, requestStatus: "declined" as const } : m
        ),
      }));
    },
    []
  );

  const openDispute = useCallback(
    (
      convId: string,
      _msgId: string,
      type: "flag" | "dispute",
      reason: string,
      description: string,
      _amountStr?: string
    ) => {
      const label = type === "dispute" ? "Dispute" : "Flag";
      const content = `⚠️ ${label}: ${reason}${description ? ` — ${description}` : ""}`;
      sendMessageMut.mutate({
        data: { toUserId: convId, messageType: "text", content },
      });
    },
    [sendMessageMut]
  );

  const createChatEscrow = useCallback(
    (convId: string, amount: number, title: string) => {
      const amountStr = `GH₵ ${amount.toLocaleString()}`;
      const optimisticId = uid();
      const msg: Message = {
        id: optimisticId,
        from: "me",
        type: "escrow_deal",
        escrowTitle: title,
        amountStr,
        amount,
        escrowStatus: "pending",
        time: nowTime(),
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), msg],
      }));
      sendMessageMut.mutate(
        { data: { toUserId: convId, messageType: "text", content: `🔒 Secure Deal: ${title} — ${amountStr}` } },
        {
          onSuccess: (result: any) => {
            setMessages((prev) => {
              const msgs = prev[convId] ?? [];
              const idx = msgs.findIndex((m) => m.id === optimisticId);
              if (idx === -1) return prev;
              const updated = [...msgs];
              updated[idx] = { ...updated[idx], id: result.id };
              return { ...prev, [convId]: updated };
            });
            queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
          },
        }
      );
    },
    [sendMessageMut, queryClient]
  );

  const sendMediaMessage = useCallback(
    (
      convId: string,
      type: "image" | "video" | "location" | "voice_note",
      label: string
    ) => {
      const optimisticId = uid();
      const msg: Message = {
        id: optimisticId,
        from: "me",
        type,
        mediaLabel: label,
        time: nowTime(),
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), msg],
      }));
      const apiType = type === "voice_note" ? "voice_note" : type === "location" ? "text" : type;
      const content = type === "voice_note" ? `🎤 Voice note (${label})` : type === "location" ? `📍 ${label}` : label;
      sendMessageMut.mutate(
        { data: { toUserId: convId, messageType: apiType as "text" | "voice_note" | "image" | "payment_request", content } },
        {
          onSuccess: (result: any) => {
            setMessages((prev) => {
              const msgs = prev[convId] ?? [];
              const idx = msgs.findIndex((m) => m.id === optimisticId);
              if (idx === -1) return prev;
              const updated = [...msgs];
              updated[idx] = { ...updated[idx], id: result.id };
              return { ...prev, [convId]: updated };
            });
            queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
          },
        }
      );
    },
    [sendMessageMut, queryClient]
  );

  const sendImageMessage = useCallback(
    async (convId: string, localUri: string, contentType: string = "image/jpeg"): Promise<void> => {
      const domain = process.env["EXPO_PUBLIC_DOMAIN"];
      const optimisticId = uid();
      const optimistic: Message = {
        id: optimisticId,
        from: "me",
        type: "image",
        mediaUrl: localUri,
        time: nowTime(),
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), optimistic],
      }));
      try {
        const ext = localUri.split(".").pop()?.split("?")[0] ?? "jpg";
        const uploadRes = await requestUploadUrlMut.mutateAsync({
          data: { name: `chat-${Date.now()}.${ext}`, size: 1, contentType },
        });
        const { uploadURL, objectPath } = uploadRes as any;
        const blob = await (await fetch(localUri)).blob();
        await fetch(uploadURL as string, {
          method: "PUT",
          body: blob,
          headers: { "Content-Type": contentType },
        });
        const objectKey = (objectPath as string).split("/").pop();
        const mediaUrl = domain
          ? `${apiOrigin(domain)}/api/storage/objects/uploads/${objectKey}`
          : localUri;
        const result = await sendMessageMut.mutateAsync({
          data: { toUserId: convId, messageType: "image", mediaUrl },
        });
        setMessages((prev) => {
          const msgs = prev[convId] ?? [];
          const idx = msgs.findIndex((m) => m.id === optimisticId);
          if (idx === -1) return prev;
          const updated = [...msgs];
          updated[idx] = { ...updated[idx], id: (result as any).id, mediaUrl };
          return { ...prev, [convId]: updated };
        });
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      } catch {
        setMessages((prev) => ({
          ...prev,
          [convId]: (prev[convId] ?? []).filter((m) => m.id !== optimisticId),
        }));
      }
    },
    [requestUploadUrlMut, sendMessageMut, queryClient]
  );

  const sendVideoMessage = useCallback(
    async (convId: string, localUri: string, contentType: string = "video/mp4"): Promise<void> => {
      const domain = process.env["EXPO_PUBLIC_DOMAIN"];
      const optimisticId = uid();
      const optimistic: Message = {
        id: optimisticId,
        from: "me",
        type: "video",
        mediaUrl: localUri,
        time: nowTime(),
        uploadProgress: 0,
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), optimistic],
      }));
      try {
        const ext = localUri.split(".").pop()?.split("?")[0] ?? "mp4";
        const uploadRes = await requestUploadUrlMut.mutateAsync({
          data: { name: `chat-video-${Date.now()}.${ext}`, size: 1, contentType },
        });
        const { uploadURL, objectPath } = uploadRes as any;
        const blob = await (await fetch(localUri)).blob();

        // Use XHR (not fetch) so we get real upload progress for the indicator.
        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.open("PUT", uploadURL as string);
          xhr.setRequestHeader("Content-Type", contentType);
          xhr.upload.onprogress = (event) => {
            if (!event.lengthComputable) return;
            const progress = event.loaded / event.total;
            setMessages((prev) => {
              const msgs = prev[convId] ?? [];
              const idx = msgs.findIndex((m) => m.id === optimisticId);
              if (idx === -1) return prev;
              const updated = [...msgs];
              updated[idx] = { ...updated[idx], uploadProgress: progress };
              return { ...prev, [convId]: updated };
            });
          };
          xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`Upload failed: ${xhr.status}`)));
          xhr.onerror = () => reject(new Error("Upload network error"));
          xhr.send(blob);
        });

        const objectKey = (objectPath as string).split("/").pop();
        const mediaUrl = domain
          ? `${apiOrigin(domain)}/api/storage/objects/uploads/${objectKey}`
          : localUri;
        const result = await sendMessageMut.mutateAsync({
          data: { toUserId: convId, messageType: "video", mediaUrl },
        });
        setMessages((prev) => {
          const msgs = prev[convId] ?? [];
          const idx = msgs.findIndex((m) => m.id === optimisticId);
          if (idx === -1) return prev;
          const updated = [...msgs];
          updated[idx] = { ...updated[idx], id: (result as any).id, mediaUrl, uploadProgress: undefined };
          return { ...prev, [convId]: updated };
        });
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
      } catch {
        setMessages((prev) => ({
          ...prev,
          [convId]: (prev[convId] ?? []).filter((m) => m.id !== optimisticId),
        }));
      }
    },
    [requestUploadUrlMut, sendMessageMut, queryClient]
  );

  const sendMoneyInChat = useCallback(
    async (
      convId: string,
      amount: number,
      note: string,
      recipientPhone: string,
      pin?: string
    ): Promise<{ success: boolean; error?: string }> => {
      if (amount > balance) return { success: false, error: "Insufficient balance" };
      const amountStr = `GH₵ ${amount.toLocaleString()}`;
      const optimisticId = uid();
      const msg: Message = {
        id: optimisticId,
        from: "me",
        type: "payment_sent",
        amount,
        amountStr,
        note,
        time: nowTime(),
      };
      setMessages((prev) => ({
        ...prev,
        [convId]: [...(prev[convId] ?? []), msg],
      }));
      try {
        const sendResult = await sendMoneyMut.mutateAsync({
          data: { toPhone: recipientPhone, amountPesewas: Math.round(amount * 100), note, pin: pin ?? "" },
        });
        // Instantly write the server-confirmed new balance into the cache
        const newBal = (sendResult as any)?.newBalancePesewas;
        if (typeof newBal === "number") {
          queryClient.setQueryData(getGetWalletBalanceQueryKey(), (old: any) => ({
            ...(old ?? {}),
            balancePesewas: newBal,
          }));
        }
        const result = await sendMessageMut.mutateAsync({
          data: {
            toUserId: convId,
            messageType: "payment_sent" as any,
            content: JSON.stringify({ amountStr, note: note || undefined, amountPesewas: Math.round(amount * 100) }),
          },
        });
        setMessages((prev) => {
          const msgs = prev[convId] ?? [];
          const idx = msgs.findIndex((m) => m.id === optimisticId);
          if (idx === -1) return prev;
          const updated = [...msgs];
          updated[idx] = { ...updated[idx], id: (result as any).id };
          return { ...prev, [convId]: updated };
        });
        invalidateWallet();
        queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
        return { success: true };
      } catch (err: any) {
        setMessages((prev) => ({
          ...prev,
          [convId]: (prev[convId] ?? []).filter((m) => m.id !== optimisticId),
        }));
        const msg = err?.message ?? "";
        if (msg.includes("Insufficient")) return { success: false, error: "Insufficient balance" };
        if (msg.includes("KYC")) return { success: false, error: "KYC verification required" };
        if (msg.includes("not found")) return { success: false, error: "Recipient not found" };
        return { success: false, error: "Transfer failed. Please try again." };
      }
    },
    [balance, sendMoneyMut, sendMessageMut, invalidateWallet, queryClient]
  );

  const setProfilePicture = useCallback(async (uri: string | null) => {
    if (!uri) return;
    try {
      const uploadInfo = await requestUploadUrlMut.mutateAsync({
        data: { name: `avatar-${Date.now()}.jpg`, size: 1, contentType: "image/jpeg" },
      });
      const { uploadURL, objectPath } = uploadInfo as any;
      const blob = await (await fetch(uri)).blob();
      await fetch(uploadURL as string, { method: "PUT", headers: { "Content-Type": "image/jpeg" }, body: blob });
      const objectKey = (objectPath as string).split("/").pop();
      const domain = process.env["EXPO_PUBLIC_DOMAIN"] ?? "";
      const avatarUrl = domain
        ? `${apiOrigin(domain)}/api/storage/objects/uploads/${objectKey}`
        : uri;
      updateAvatarMut.mutate(
        { data: { avatarUrl } },
        { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() }) }
      );
    } catch {
      // silent — user sees no change if upload fails
    }
  }, [requestUploadUrlMut, updateAvatarMut, queryClient]);

  const updateSettings = useCallback(
    (s: Partial<{ notifPayments: boolean; notifEscrow: boolean; notifMarketing: boolean; biometricEnabled: boolean }>) => {
      setSettingsOverride((prev) => ({ ...prev, ...s }));
      updateSettingsMut.mutate(
        { data: s },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
            setSettingsOverride(null);
          },
          onError: () => setSettingsOverride(null),
        }
      );
    },
    [updateSettingsMut, queryClient]
  );

  const updateAvatar = useCallback(
    (url: string) => {
      updateAvatarMut.mutate(
        { data: { avatarUrl: url } },
        { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() }) }
      );
    },
    [updateAvatarMut, queryClient]
  );

  const confirmPayLinkDelivery = useCallback(
    (code: string) => {
      confirmPayLinkMut.mutate({ code });
    },
    [confirmPayLinkMut]
  );

  const disputePayLink = useCallback(
    (code: string, reason: string) => {
      disputePayLinkMut.mutate({ code, data: { reason } });
    },
    [disputePayLinkMut]
  );

  // ── Story actions ─────────────────────────────────────────────────────────

  const viewStory = useCallback(
    async (storyId: string) => {
      await viewStoryMut.mutateAsync({ id: storyId });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
    },
    [viewStoryMut, queryClient]
  );

  const reactToStory = useCallback(
    async (storyId: string, emoji: string) => {
      await reactToStoryMut.mutateAsync({ id: storyId, data: { emoji } });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
    },
    [reactToStoryMut, queryClient]
  );

  const removeStoryReaction = useCallback(
    async (storyId: string) => {
      await removeStoryReactionMut.mutateAsync({ id: storyId });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
    },
    [removeStoryReactionMut, queryClient]
  );

  const deleteStory = useCallback(
    async (storyId: string) => {
      await deleteStoryMut.mutateAsync({ id: storyId });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListMyStoriesQueryKey() });
    },
    [deleteStoryMut, queryClient]
  );

  const muteUser = useCallback(
    async (userId: string) => {
      await muteUserStoriesMut.mutateAsync({ userId });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
    },
    [muteUserStoriesMut, queryClient]
  );

  const unmuteUser = useCallback(
    async (userId: string) => {
      await unmuteUserStoriesMut.mutateAsync({ userId });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
    },
    [unmuteUserStoriesMut, queryClient]
  );

  const replyToStory = useCallback(
    async (storyId: string, text: string) => {
      await replyToStoryMut.mutateAsync({ id: storyId, data: { text } });
    },
    [replyToStoryMut]
  );

  const createStory = useCallback(
    async (data: CreateStoryData) => {
      let mediaUrl: string | undefined;
      if (data.mediaUri && data.mediaName && data.mediaSize && data.mediaContentType) {
        const uploadResult = await requestUploadUrlMut.mutateAsync({
          data: { name: data.mediaName, size: data.mediaSize, contentType: data.mediaContentType },
        });
        const { uploadURL, objectPath } = uploadResult as any;
        const fileRes = await fetch(data.mediaUri);
        const blob = await fileRes.blob();
        await fetch(uploadURL, {
          method: "PUT",
          body: blob,
          headers: { "Content-Type": data.mediaContentType },
        });
        mediaUrl = objectPath;
      }
      await createStoryMut.mutateAsync({
        data: {
          storyType: data.storyType,
          mediaUrl: mediaUrl ?? null,
          caption: data.caption ?? null,
          textColor: data.textColor ?? null,
          textBg: data.textBg ?? null,
          visibilityType: (data.visibilityType as any) ?? "contacts",
        },
      });
      queryClient.invalidateQueries({ queryKey: getListStoriesQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListMyStoriesQueryKey() });
    },
    [requestUploadUrlMut, createStoryMut, queryClient]
  );

  // ── Socket room management ────────────────────────────────────────────────

  const joinGroupRoom = useCallback((groupId: string) => {
    activeGroupRoomsRef.current.add(groupId);
    if (socketRef.current?.connected) {
      socketRef.current.emit("join_group", { groupId });
    }
  }, []);

  const leaveGroupRoom = useCallback((groupId: string) => {
    activeGroupRoomsRef.current.delete(groupId);
    if (socketRef.current?.connected) {
      socketRef.current.emit("leave_group", { groupId });
    }
  }, []);

  // ── Call functions ────────────────────────────────────────────────────────

  const startCall = useCallback(async (convId: string, type: "voice" | "video") => {
    if (outgoingCallPending || activeCall) return;
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain || !_currentToken) return;

    setOutgoingCallPending(true);
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/calls/initiate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${_currentToken}`,
        },
        body: JSON.stringify({ receiverId: convId, type }),
      });
      if (!res.ok) { setOutgoingCallPending(false); return; }
      const data = await res.json() as {
        callId: string; channelName: string; agoraToken: string; agoraAppId: string;
        receiverName: string; receiverAvatarUrl?: string | null;
      };

      const initials = data.receiverName
        .split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase();
      const colorIndex = data.callId.charCodeAt(0) % AVATAR_COLORS.length;
      const peerColor = AVATAR_COLORS[colorIndex];

      const callInfo = {
        callId: data.callId,
        channelName: data.channelName,
        agoraToken: data.agoraToken,
        agoraAppId: data.agoraAppId,
        type,
        peerName: data.receiverName,
        peerInitials: initials,
        peerColor,
        peerAvatarUrl: data.receiverAvatarUrl ?? null,
      };
      pendingOutgoingCallRef.current = callInfo;
      // Show CallScreen immediately in "connecting" state
      setActiveCall({ ...callInfo, isCaller: true });
      setOutgoingCallPending(false);
    } catch {
      setOutgoingCallPending(false);
    }
  }, [outgoingCallPending, activeCall]);

  const acceptCall = useCallback(async () => {
    if (!incomingCall) return;
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!domain || !_currentToken) return;

    const callSnap = incomingCall;
    setIncomingCall(null);
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/calls/${callSnap.callId}/accept`, {
        method: "POST",
        headers: { Authorization: `Bearer ${_currentToken}` },
      });
      if (!res.ok) return;
      const data = await res.json() as { channelName: string; agoraToken: string; agoraAppId: string };

      const initials = callSnap.callerName
        .split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase();
      const colorIndex = callSnap.callId.charCodeAt(0) % AVATAR_COLORS.length;

      setActiveCall({
        callId: callSnap.callId,
        channelName: data.channelName,
        agoraToken: data.agoraToken,
        agoraAppId: data.agoraAppId,
        type: callSnap.type,
        peerName: callSnap.callerName,
        peerInitials: initials,
        peerColor: AVATAR_COLORS[colorIndex],
        peerAvatarUrl: callSnap.callerAvatarUrl ?? null,
        isCaller: false,
      });
    } catch {
      setIncomingCall(callSnap);
    }
  }, [incomingCall]);

  const rejectCall = useCallback(async () => {
    if (!incomingCall) return;
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    const callId = incomingCall.callId;
    setIncomingCall(null);
    if (!domain || !_currentToken) return;
    fetch(`${apiOrigin(domain)}/api/calls/${callId}/decline`, {
      method: "POST",
      headers: { Authorization: `Bearer ${_currentToken}` },
    }).catch(() => {});
  }, [incomingCall]);

  const endCall = useCallback(async () => {
    const callId = activeCall?.callId ?? pendingOutgoingCallRef.current?.callId;
    setActiveCall(null);
    setOutgoingCallPending(false);
    pendingOutgoingCallRef.current = null;
    const domain = process.env["EXPO_PUBLIC_DOMAIN"];
    if (!callId || !domain || !_currentToken) return;
    fetch(`${apiOrigin(domain)}/api/calls/${callId}/end`, {
      method: "POST",
      headers: { Authorization: `Bearer ${_currentToken}` },
    }).catch(() => {});
  }, [activeCall]);

  // ── Voice note recording ──────────────────────────────────────────────────

  const startVoiceRecording = useCallback(async (): Promise<boolean> => {
    try {
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== "granted") return false;
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );
      voiceRecordingRef.current = recording;
      return true;
    } catch {
      return false;
    }
  }, []);

  const cancelVoiceRecording = useCallback(() => {
    if (!voiceRecordingRef.current) return;
    voiceRecordingRef.current.stopAndUnloadAsync().catch(() => {});
    voiceRecordingRef.current = null;
    Audio.setAudioModeAsync({ allowsRecordingIOS: false }).catch(() => {});
  }, []);

  const stopVoiceRecording = useCallback(async (): Promise<{ uri: string; durLabel: string } | null> => {
    if (!voiceRecordingRef.current) return null;
    const recording = voiceRecordingRef.current;
    voiceRecordingRef.current = null;

    try {
      await recording.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });

      const uri = recording.getURI();
      if (!uri) return null;

      const statusObj = await recording.getStatusAsync();
      const durMs = (statusObj as any).durationMillis ?? 0;
      const durSecs = Math.round(durMs / 1000);
      const durLabel = `${Math.floor(durSecs / 60)}:${(durSecs % 60).toString().padStart(2, "0")}`;

      return { uri, durLabel };
    } catch {
      return null;
    }
  }, []);

  const sendVoiceNote = useCallback(async (convId: string, uri: string, durLabel: string) => {
    const optimisticId = uid();
    setMessages((prev) => ({
      ...prev,
      [convId]: [...(prev[convId] ?? []), {
        id: optimisticId, from: "me" as const, type: "voice_note" as const,
        mediaUrl: uri, mediaLabel: durLabel, time: nowTime(),
      }],
    }));

    try {
      const domain = process.env["EXPO_PUBLIC_DOMAIN"];
      const uploadRes = await requestUploadUrlMut.mutateAsync({
        data: { name: `vn-${Date.now()}.m4a`, size: 1, contentType: "audio/m4a" },
      });
      const { uploadURL, objectPath } = uploadRes as any;
      const blob = await (await fetch(uri)).blob();
      await fetch(uploadURL as string, {
        method: "PUT", body: blob,
        headers: { "Content-Type": "audio/m4a" },
      });
      const objectKey = (objectPath as string).split("/").pop();
      const mediaUrl = domain
        ? `${apiOrigin(domain)}/api/storage/objects/uploads/${objectKey}`
        : uri;

      const result = await sendMessageMut.mutateAsync({
        data: { toUserId: convId, messageType: "voice_note", mediaUrl, content: durLabel },
      });

      setMessages((prev) => {
        const msgs = prev[convId] ?? [];
        const idx = msgs.findIndex((m) => m.id === optimisticId);
        if (idx === -1) return prev;
        const updated = [...msgs];
        updated[idx] = { ...updated[idx], id: (result as any).id, mediaUrl };
        return { ...prev, [convId]: updated };
      });

      queryClient.invalidateQueries({ queryKey: getListConversationsQueryKey() });
    } catch {
      setMessages((prev) => ({
        ...prev,
        [convId]: (prev[convId] ?? []).filter((m) => m.id !== optimisticId),
      }));
    }
  }, [requestUploadUrlMut, sendMessageMut, queryClient]);

  // ── Provider ──────────────────────────────────────────────────────────────

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        authLoading,
        currentUser,
        login,
        register,
        logout,
        balance,
        transactions,
        escrows,
        conversations,
        messages,
        listings: [],
        disputes: [],
        payLinks,
        notifications: 0,
        profilePicture: (meQuery.data as any)?.avatarUrl ?? null,
        stories,
        storyGroups,
        myStories,
        notifPayments,
        notifEscrow,
        notifMarketing,
        biometricEnabled,
        addMoney,
        withdraw,
        createEscrow,
        releaseEscrow,
        sendMessage,
        loadMessages,
        requestMoney,
        payRequest,
        declineRequest,
        openDispute,
        createChatEscrow,
        sendMediaMessage,
        sendImageMessage,
        sendVideoMessage,
        sendMoneyInChat,
        setProfilePicture,
        updateSettings,
        updateAvatar,
        addContact,
        verifyPin,
        sendMobileMoney,
        payBill,
        createPayLink,
        payPayLink,
        confirmPayLinkDelivery,
        disputePayLink,
        viewStory,
        reactToStory,
        removeStoryReaction,
        deleteStory,
        muteUser,
        unmuteUser,
        replyToStory,
        createStory,
        authUserId,
        socketStatus,
        reconnectCount,
        joinGroupRoom,
        leaveGroupRoom,
        incomingCall,
        activeCall,
        outgoingCallPending,
        startCall,
        acceptCall,
        rejectCall,
        endCall,
        startVoiceRecording,
        stopVoiceRecording,
        sendVoiceNote,
        cancelVoiceRecording,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
