export type FeeType = "charley" | "mtn" | "telecel" | "airteltigo" | "bank" | "phone" | "email";

// ─── Rate constants (editable without code changes in a real admin dashboard) ─

const FARGOPAY_RATE  = 0.005;  // 0.5% service fee on all transfers
const FARGOPAY_MIN   = 0.50;   // GH₵0.50 minimum

const HUBTEL_MOBILE  = { rate: 0.008, fixed: 0.50 };  // 0.8% + GH₵0.50
const HUBTEL_BANK    = { rate: 0.005, fixed: 2.00 };   // 0.5% + GH₵2.00
const NETWORK_RATE   = 0.0075; // 0.75% mobile network surcharge
const BANK_RATE      = 0.002;  // 0.2% bank processing
const BANK_FIXED     = 5.00;   // GH₵5.00 bank fixed charge

// ─── Tier discount system ────────────────────────────────────────────────────

export interface Tier {
  name: string;
  label: string;
  discount: number;
  minAmount: number;
}

export const TIERS: Tier[] = [
  { name: "Tier 4", label: "−50%", discount: 0.50, minAmount: 20000 },
  { name: "Tier 3", label: "−25%", discount: 0.25, minAmount: 5000  },
  { name: "Tier 2", label: "−10%", discount: 0.10, minAmount: 1000  },
  { name: "Standard", label: "",   discount: 0,    minAmount: 0     },
];

function getTier(amount: number): Tier {
  return TIERS.find((t) => amount >= t.minAmount) ?? TIERS[TIERS.length - 1];
}

// ─── Fee breakdown type ──────────────────────────────────────────────────────

export interface FeeBreakdown {
  transactionAmount: number;
  fargoPayFee: number;
  hubtelFee: number;
  networkFee: number;
  bankFee: number;
  totalFees: number;
  totalCharged: number;
  recipientReceives: number;
  tier: Tier;
}

function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

// ─── Main calculation ────────────────────────────────────────────────────────

export function calculateFee(type: FeeType, amount: number): FeeBreakdown {
  const tier = getTier(amount);

  const rawFargoFee = Math.max(amount * FARGOPAY_RATE, FARGOPAY_MIN);
  const fargoPayFee = r2(rawFargoFee * (1 - tier.discount));

  let hubtelFee  = 0;
  let networkFee = 0;
  let bankFee    = 0;

  switch (type) {
    case "mtn":
    case "telecel":
    case "airteltigo":
    case "phone":
      hubtelFee  = r2(amount * HUBTEL_MOBILE.rate + HUBTEL_MOBILE.fixed);
      networkFee = r2(amount * NETWORK_RATE);
      break;
    case "bank":
      hubtelFee = r2(amount * HUBTEL_BANK.rate + HUBTEL_BANK.fixed);
      bankFee   = r2(amount * BANK_RATE + BANK_FIXED);
      break;
    case "charley":
    case "email":
    default:
      break;
  }

  const totalFees   = r2(fargoPayFee + hubtelFee + networkFee + bankFee);
  const totalCharged = r2(amount + totalFees);

  return {
    transactionAmount: amount,
    fargoPayFee,
    hubtelFee,
    networkFee,
    bankFee,
    totalFees,
    totalCharged,
    recipientReceives: amount,
    tier,
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function fmtFee(n: number): string {
  return `GH₵ ${n.toFixed(2)}`;
}
