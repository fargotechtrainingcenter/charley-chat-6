/**
 * Production server for CharLey Chat web app.
 * Serves the Expo web export (dist/) as a single-page application.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");

const DIST_ROOT = path.resolve(__dirname, "..", "dist");
const basePath = (process.env.BASE_PATH || "/mobile").replace(/\/+$/, "");
const port = parseInt(process.env.PORT || "3000", 10);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js":   "application/javascript; charset=utf-8",
  ".mjs":  "application/javascript; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif":  "image/gif",
  ".svg":  "image/svg+xml",
  ".ico":  "image/x-icon",
  ".woff": "font/woff",
  ".woff2":"font/woff2",
  ".ttf":  "font/ttf",
  ".otf":  "font/otf",
  ".webp": "image/webp",
  ".map":  "application/json",
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url || "/", `http://localhost`);
  let pathname = url.pathname;

  // Healthcheck endpoint
  if (pathname === basePath + "/status" || pathname === "/status") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  // Strip the base path prefix
  if (basePath && pathname.startsWith(basePath)) {
    pathname = pathname.slice(basePath.length) || "/";
  }
  if (!pathname.startsWith("/")) pathname = "/" + pathname;

  // Try exact file
  const safePath = path.normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, "");
  let filePath = path.join(DIST_ROOT, safePath);

  if (fs.existsSync(filePath) && !fs.statSync(filePath).isDirectory()) {
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME[ext] || "application/octet-stream";
    const isAsset = ext !== ".html";
    res.writeHead(200, {
      "content-type": contentType,
      "cache-control": isAsset ? "public, max-age=31536000, immutable" : "no-cache",
    });
    res.end(fs.readFileSync(filePath));
    return;
  }

  // SPA fallback — serve index.html for all unmatched routes
  const indexPath = path.join(DIST_ROOT, "index.html");
  if (fs.existsSync(indexPath)) {
    res.writeHead(200, {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-cache",
    });
    res.end(fs.readFileSync(indexPath));
    return;
  }

  res.writeHead(503, { "content-type": "text/plain" });
  res.end("App not built yet. Run the build step first.");
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Serving CharLey Chat web app on port ${port} (basePath: ${basePath})`);
});
