import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useMemo, useState } from "react";
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  CONTINUE_WATCHING,
  NEW_RELEASES,
  POPULAR_ON_STREAM,
  StreamTitle,
  TOP_PICKS,
} from "@/constants/streamData";
import { useColors } from "@/hooks/useColors";

const TABS = ["Movies", "TV Shows", "Downloaded"] as const;
type Tab = (typeof TABS)[number];

const MY_LIST: StreamTitle[] = [
  ...TOP_PICKS.slice(0, 2),
  ...POPULAR_ON_STREAM.slice(0, 2),
  ...NEW_RELEASES.slice(0, 1),
  ...CONTINUE_WATCHING.filter((t) => t.kind === "show"),
];

function ListRow({ item, onPress }: { item: StreamTitle; onPress: () => void }) {
  const colors = useColors();
  return (
    <TouchableOpacity style={s.row} onPress={onPress} activeOpacity={0.75}>
      <View style={s.thumb}>
        <LinearGradient colors={item.gradient} style={StyleSheet.absoluteFill} />
        <Feather name="film" size={16} color="rgba(255,255,255,0.55)" />
      </View>
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={[s.rowTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]} numberOfLines={1}>
          {item.title}
        </Text>
        <Text style={[s.rowSub, { color: colors.textMuted }]} numberOfLines={1}>
          {item.year} · {item.seasonInfo ?? item.duration}
        </Text>
      </View>
      <Feather name="more-vertical" size={18} color={colors.textMuted} />
    </TouchableOpacity>
  );
}

export default function MyListScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<Tab>("Movies");

  const data = useMemo(() => {
    if (tab === "Movies") return MY_LIST.filter((t) => t.kind === "movie");
    if (tab === "TV Shows") return MY_LIST.filter((t) => t.kind === "show");
    return MY_LIST.slice(0, 2);
  }, [tab]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={[s.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)}>
          <Feather name="arrow-left" size={20} color={colors.text} />
        </TouchableOpacity>
        <Text style={[s.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>My List</Text>
        <TouchableOpacity>
          <Text style={{ color: colors.primary, fontSize: 13, fontFamily: "Inter_600SemiBold" }}>Edit</Text>
        </TouchableOpacity>
      </View>

      <View style={s.tabRow}>
        {TABS.map((t) => {
          const active = t === tab;
          return (
            <TouchableOpacity
              key={t}
              onPress={() => setTab(t)}
              style={[
                s.tabChip,
                { backgroundColor: active ? colors.primary : colors.surfaceElevated, borderColor: active ? colors.primary : colors.border },
              ]}
            >
              <Text style={[s.tabChipText, { color: active ? "#04241D" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                {t}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {data.length === 0 ? (
        <View style={s.empty}>
          <Feather name="bookmark" size={48} color={colors.textMuted} />
          <Text style={[s.emptyTitle, { color: colors.text }]}>Nothing here yet</Text>
          <Text style={[s.emptySub, { color: colors.textMuted }]}>
            Titles you save will show up in this tab.
          </Text>
        </View>
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: insets.bottom + 24 }}
          renderItem={({ item }) => (
            <ListRow item={item} onPress={() => router.push(`/movie/${item.id}`)} />
          )}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 14,
  },
  headerTitle: { fontSize: 17 },

  tabRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16, marginBottom: 16 },
  tabChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  tabChipText: { fontSize: 12.5 },

  row: { flexDirection: "row", alignItems: "center", paddingVertical: 10 },
  thumb: {
    width: 56,
    height: 72,
    borderRadius: 10,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
  rowTitle: { fontSize: 14.5 },
  rowSub: { fontSize: 12, marginTop: 2, fontFamily: "Inter_400Regular" },

  empty: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32 },
  emptyTitle: { fontSize: 16, fontWeight: "700", marginTop: 14, fontFamily: "Inter_700Bold" },
  emptySub: { fontSize: 13, textAlign: "center", marginTop: 6, fontFamily: "Inter_400Regular" },
});
