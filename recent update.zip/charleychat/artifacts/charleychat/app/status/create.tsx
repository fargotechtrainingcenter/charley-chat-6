import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const TEXT_BG_OPTIONS = [
  { bg: "#075E54", color: "#ffffff" },
  { bg: "#128C7E", color: "#ffffff" },
  { bg: "#C8932A", color: "#ffffff" },
  { bg: "#E53E3E", color: "#ffffff" },
  { bg: "#6B46C1", color: "#ffffff" },
  { bg: "#2B6CB0", color: "#ffffff" },
  { bg: "#1A202C", color: "#ffffff" },
  { bg: "#D69E2E", color: "#1A202C" },
  { bg: "#F7FAFC", color: "#1A202C" },
];

const VISIBILITY_OPTIONS = [
  { value: "contacts", label: "My Contacts", icon: "users" as const },
  { value: "everyone", label: "Everyone", icon: "globe" as const },
  { value: "contacts_except", label: "Contacts Except…", icon: "user-x" as const },
  { value: "only_share", label: "Only Share With…", icon: "user-check" as const },
];

type ScreenMode = "pick" | "media" | "text";

export default function StatusCreateScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { createStory } = useApp();

  const [mode, setMode] = useState<ScreenMode>("pick");
  const [mediaUri, setMediaUri] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<"image" | "video">("image");
  const [mediaName, setMediaName] = useState("status.jpg");
  const [mediaSize, setMediaSize] = useState(0);
  const [mediaMime, setMediaMime] = useState("image/jpeg");
  const [caption, setCaption] = useState("");
  const [textContent, setTextContent] = useState("");
  const [selectedBg, setSelectedBg] = useState(TEXT_BG_OPTIONS[0]);
  const [visibility, setVisibility] = useState("contacts");
  const [posting, setPosting] = useState(false);

  const topPad = Platform.OS === "web" ? 16 : insets.top;
  const botPad = Platform.OS === "web" ? 20 : insets.bottom;

  const requestMediaPermission = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission needed", "Allow CharLey to access your photos and videos to post a status.");
      return false;
    }
    return true;
  };

  const requestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Camera access needed", "Allow CharLey to use your camera to take a status photo.");
      return false;
    }
    return true;
  };

  const openGallery = async () => {
    if (!(await requestMediaPermission())) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images", "videos"],
      allowsEditing: true,
      quality: 0.85,
      videoMaxDuration: 30,
    });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      setMediaUri(asset.uri);
      setMediaType(asset.type === "video" ? "video" : "image");
      setMediaName(asset.fileName ?? (asset.type === "video" ? "status.mp4" : "status.jpg"));
      setMediaSize(asset.fileSize ?? 200000);
      setMediaMime(asset.mimeType ?? (asset.type === "video" ? "video/mp4" : "image/jpeg"));
      setMode("media");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const openCamera = async () => {
    if (!(await requestCameraPermission())) return;
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      quality: 0.85,
    });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      setMediaUri(asset.uri);
      setMediaType("image");
      setMediaName("photo.jpg");
      setMediaSize(asset.fileSize ?? 150000);
      setMediaMime("image/jpeg");
      setMode("media");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const openVideoCamera = async () => {
    if (!(await requestCameraPermission())) return;
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["videos"],
      videoMaxDuration: 30,
    });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      setMediaUri(asset.uri);
      setMediaType("video");
      setMediaName("video.mp4");
      setMediaSize(asset.fileSize ?? 1000000);
      setMediaMime("video/mp4");
      setMode("media");
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handlePost = async () => {
    if (mode === "text" && !textContent.trim()) {
      Alert.alert("Add text", "Type something for your status first.");
      return;
    }
    if (mode === "media" && !mediaUri) return;

    setPosting(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await createStory({
        storyType: mode === "text" ? "text" : mediaType,
        mediaUri: mediaUri ?? undefined,
        mediaName: mediaUri ? mediaName : undefined,
        mediaSize: mediaUri ? mediaSize : undefined,
        mediaContentType: mediaUri ? mediaMime : undefined,
        caption: mode === "text" ? textContent : caption || undefined,
        textColor: mode === "text" ? selectedBg.color : undefined,
        textBg: mode === "text" ? selectedBg.bg : undefined,
        visibilityType: visibility,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      safeGoBack(router);
    } catch (e: any) {
      Alert.alert("Failed to post", e?.message ?? "Something went wrong. Please try again.");
    } finally {
      setPosting(false);
    }
  };

  // ── Mode: pick ────────────────────────────────────────────────────────────

  if (mode === "pick") {
    return (
      <View style={[styles.root, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.iconBtn} activeOpacity={0.7}>
            <Feather name="x" size={22} color={colors.text} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: colors.text }]}>New Status</Text>
          <View style={styles.iconBtn} />
        </View>

        <ScrollView contentContainerStyle={[styles.pickScroll, { paddingBottom: botPad + 32 }]} showsVerticalScrollIndicator={false}>
          <Text style={[styles.pickHint, { color: colors.textMuted }]}>
            Share a photo, video, or text — disappears in 24 hours
          </Text>

          {[
            { icon: "image" as const, color: colors.primary, bg: colors.primary + "20", title: "Photo from Gallery", sub: "Pick a photo or video from your library", onPress: openGallery },
            { icon: "camera" as const, color: "#C8932A", bg: "#C8932A20", title: "Take a Photo", sub: "Open your camera and capture a new photo", onPress: openCamera },
            { icon: "video" as const, color: "#E53E3E", bg: "#E53E3E20", title: "Record a Video", sub: "Record a short video — up to 30 seconds", onPress: openVideoCamera },
            { icon: "type" as const, color: "#6B46C1", bg: "#6B46C120", title: "Text Status", sub: "Share a message on a coloured background", onPress: () => setMode("text") },
          ].map((item) => (
            <TouchableOpacity
              key={item.title}
              style={[styles.pickCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}
              onPress={() => { item.onPress(); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
              activeOpacity={0.8}
            >
              <View style={[styles.pickIcon, { backgroundColor: item.bg }]}>
                <Feather name={item.icon} size={26} color={item.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.pickTitle, { color: colors.text }]}>{item.title}</Text>
                <Text style={[styles.pickSub, { color: colors.textMuted }]}>{item.sub}</Text>
              </View>
              <Feather name="chevron-right" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    );
  }

  // ── Mode: text ────────────────────────────────────────────────────────────

  if (mode === "text") {
    return (
      <KeyboardAvoidingView
        style={[styles.root, { backgroundColor: selectedBg.bg }]}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={[styles.textHeader, { paddingTop: topPad + 8 }]}>
          <TouchableOpacity onPress={() => setMode("pick")} style={styles.iconBtn} activeOpacity={0.7}>
            <Feather name="arrow-left" size={22} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.postBtn, { backgroundColor: "#fff", opacity: posting ? 0.6 : 1 }]}
            onPress={handlePost} disabled={posting} activeOpacity={0.8}
          >
            {posting
              ? <ActivityIndicator size="small" color={selectedBg.bg} />
              : <><Feather name="send" size={13} color={selectedBg.bg} /><Text style={[styles.postBtnLabel, { color: selectedBg.bg }]}>  Post</Text></>
            }
          </TouchableOpacity>
        </View>

        <TextInput
          style={[styles.textInput, { color: selectedBg.color }]}
          placeholder="Type a status…"
          placeholderTextColor={selectedBg.color + "80"}
          value={textContent}
          onChangeText={setTextContent}
          multiline
          textAlignVertical="center"
          autoFocus
        />

        <View style={{ paddingBottom: 10 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 10, paddingVertical: 12 }}>
            {TEXT_BG_OPTIONS.map((opt) => (
              <TouchableOpacity
                key={opt.bg}
                style={[styles.bgSwatch, { backgroundColor: opt.bg, borderWidth: selectedBg.bg === opt.bg ? 3 : 1.5, borderColor: selectedBg.bg === opt.bg ? "#fff" : "rgba(255,255,255,0.3)" }]}
                onPress={() => { setSelectedBg(opt); Haptics.selectionAsync(); }}
                activeOpacity={0.8}
              />
            ))}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 8, paddingBottom: botPad + 16 }}>
            {VISIBILITY_OPTIONS.map((v) => (
              <TouchableOpacity
                key={v.value}
                style={[styles.visChip, {
                  backgroundColor: visibility === v.value ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.1)",
                  borderWidth: 1,
                  borderColor: visibility === v.value ? "#fff" : "transparent",
                }]}
                onPress={() => { setVisibility(v.value); Haptics.selectionAsync(); }}
                activeOpacity={0.8}
              >
                <Feather name={v.icon} size={12} color="#fff" />
                <Text style={styles.visChipText}>{v.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    );
  }

  // ── Mode: media preview ───────────────────────────────────────────────────

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: "#0a0a0a" }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={[styles.mediaHeader, { paddingTop: topPad + 8 }]}>
        <TouchableOpacity onPress={() => setMode("pick")} style={styles.iconBtn} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.mediaHeaderTitle}>{mediaType === "video" ? "Video Status" : "Photo Status"}</Text>
        <TouchableOpacity
          style={[styles.postBtn, { backgroundColor: colors.primary, opacity: posting ? 0.6 : 1 }]}
          onPress={handlePost} disabled={posting} activeOpacity={0.8}
        >
          {posting
            ? <ActivityIndicator size="small" color="#fff" />
            : <><Feather name="send" size={13} color="#fff" /><Text style={styles.postBtnLabelWhite}>  Post</Text></>
          }
        </TouchableOpacity>
      </View>

      <View style={styles.mediaPreview}>
        {mediaUri && <Image source={{ uri: mediaUri }} style={styles.mediaImg} resizeMode="contain" />}
        {mediaType === "video" && (
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            <View style={styles.playOverlay}>
              <Feather name="play-circle" size={60} color="rgba(255,255,255,0.75)" />
            </View>
          </View>
        )}
      </View>

      <View style={[styles.captionArea, { paddingBottom: botPad + 8 }]}>
        <TextInput
          style={styles.captionInput}
          placeholder="Add a caption…"
          placeholderTextColor="rgba(255,255,255,0.4)"
          value={caption}
          onChangeText={setCaption}
          multiline
          maxLength={200}
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: 8, paddingTop: 8 }}>
          {VISIBILITY_OPTIONS.map((v) => (
            <TouchableOpacity
              key={v.value}
              style={[styles.visChip, {
                backgroundColor: visibility === v.value ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.07)",
                borderWidth: 1,
                borderColor: visibility === v.value ? "rgba(255,255,255,0.6)" : "transparent",
              }]}
              onPress={() => { setVisibility(v.value); Haptics.selectionAsync(); }}
              activeOpacity={0.8}
            >
              <Feather name={v.icon} size={12} color="rgba(255,255,255,0.75)" />
              <Text style={styles.visChipTextDim}>{v.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 14, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  iconBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 17, fontWeight: "700", fontFamily: "Inter_700Bold" },

  pickScroll: { padding: 20, gap: 14 },
  pickHint: { fontSize: 13, textAlign: "center", marginBottom: 4, lineHeight: 20 },
  pickCard: {
    flexDirection: "row", alignItems: "center", gap: 14,
    borderRadius: 16, borderWidth: 1, padding: 16,
  },
  pickIcon: { width: 50, height: 50, borderRadius: 25, alignItems: "center", justifyContent: "center" },
  pickTitle: { fontSize: 15, fontWeight: "600", fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  pickSub: { fontSize: 13, lineHeight: 18 },

  textHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 14, paddingBottom: 12,
  },
  textInput: {
    flex: 1, fontSize: 28, fontWeight: "700", fontFamily: "Inter_700Bold",
    textAlign: "center", paddingHorizontal: 24, lineHeight: 38,
  },
  bgSwatch: { width: 36, height: 36, borderRadius: 18 },

  mediaHeader: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 14, paddingBottom: 12,
  },
  mediaHeaderTitle: { color: "#fff", fontSize: 16, fontWeight: "700", fontFamily: "Inter_700Bold" },
  mediaPreview: { flex: 1, alignItems: "center", justifyContent: "center" },
  mediaImg: { width: "100%", height: "100%" },
  playOverlay: { flex: 1, alignItems: "center", justifyContent: "center" },

  captionArea: { paddingHorizontal: 16, paddingTop: 12, backgroundColor: "rgba(0,0,0,0.55)" },
  captionInput: {
    color: "#fff", fontSize: 15, minHeight: 44, paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: "rgba(255,255,255,0.2)",
  },

  visChip: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20,
  },
  visChipText: { color: "#fff", fontSize: 12, fontWeight: "600" },
  visChipTextDim: { color: "rgba(255,255,255,0.8)", fontSize: 12, fontWeight: "600" },

  postBtn: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 16, paddingVertical: 9, borderRadius: 20,
  },
  postBtnLabel: { fontSize: 14, fontWeight: "700", fontFamily: "Inter_700Bold" },
  postBtnLabelWhite: { color: "#fff", fontSize: 14, fontWeight: "700", fontFamily: "Inter_700Bold" },
});
