import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import OtpBoxes from "@/components/OtpBoxes";
import { apiOrigin } from "@/lib/api-base";

type Step = "phone" | "otp" | "newPin";

const API_BASE = process.env.EXPO_PUBLIC_DOMAIN ? apiOrigin(process.env.EXPO_PUBLIC_DOMAIN) : "";

async function requestOtp(phone: string): Promise<{ ok: boolean; devCode?: string; error?: string }> {
  try {
    const res = await fetch(`${API_BASE}/api/auth/otp/request`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone, purpose: "login_reset" }),
    });
    const data = await res.json();
    if (!res.ok) return { ok: false, error: data.error ?? "Failed to send OTP" };
    return { ok: true, devCode: data.devCode };
  } catch {
    return { ok: false, error: "Network error. Please try again." };
  }
}

async function resetPin(phone: string, otp: string, newPin: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch(`${API_BASE}/api/auth/reset-pin`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone, otp, newPin }),
    });
    const data = await res.json();
    if (!res.ok) return { ok: false, error: data.error ?? "Failed to reset PIN" };
    return { ok: true };
  } catch {
    return { ok: false, error: "Network error. Please try again." };
  }
}

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("");
  const [phoneNormalized, setPhoneNormalized] = useState("");
  const [otp, setOtp] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [devCode, setDevCode] = useState<string | undefined>();
  const [done, setDone] = useState(false);

  const confirmRef = useRef<TextInput>(null);

  const inputStyle = [
    styles.input,
    { backgroundColor: colors.surface, borderColor: colors.border, color: colors.text },
  ];

  async function handlePhoneSubmit() {
    setError("");
    const normalized = phone.trim().replace(/\s/g, "").replace(/^\+233/, "0").replace(/^233(\d{9})$/, "0$1");
    if (normalized.length < 9) {
      setError("Enter a valid phone number.");
      return;
    }
    setLoading(true);
    const result = await requestOtp(normalized);
    setLoading(false);
    if (!result.ok) {
      setError(result.error ?? "Failed to send OTP.");
      return;
    }
    setPhoneNormalized(normalized);
    setDevCode(result.devCode);
    setStep("otp");
  }

  async function handleOtpSubmit() {
    setError("");
    if (otp.trim().length !== 6) {
      setError("Enter the 6-digit code.");
      return;
    }
    setStep("newPin");
  }

  async function handlePinSubmit() {
    setError("");
    if (newPin.length < 4) {
      setError("PIN must be at least 4 digits.");
      return;
    }
    if (newPin !== confirmPin) {
      setError("PINs do not match.");
      return;
    }
    setLoading(true);
    const result = await resetPin(phoneNormalized, otp.trim(), newPin);
    setLoading(false);
    if (!result.ok) {
      setError(result.error ?? "Something went wrong.");
      return;
    }
    setDone(true);
  }

  async function handleResend() {
    setError("");
    setLoading(true);
    const result = await requestOtp(phoneNormalized);
    setLoading(false);
    if (!result.ok) {
      setError(result.error ?? "Failed to resend OTP.");
    } else {
      setDevCode(result.devCode);
      setOtp("");
    }
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  if (done) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background }]}>
        <View style={[styles.inner, { paddingTop: topPad + 32, paddingBottom: Math.max(insets.bottom, 16) }]}>
          <View style={[styles.successCircle, { backgroundColor: colors.primary + "18" }]}>
            <Feather name="check-circle" size={48} color={colors.primary} />
          </View>
          <Text style={[styles.successTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>PIN Reset!</Text>
          <Text style={[styles.successSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            Your PIN has been updated successfully. You can now sign in with your new PIN.
          </Text>
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: colors.primary, marginTop: 24 }]}
            onPress={() => router.replace("/login")}
            activeOpacity={0.85}
          >
            <Text style={[styles.btnText, { fontFamily: "Inter_700Bold" }]}>Back to Sign In</Text>
            <Feather name="log-in" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={[styles.inner, { paddingTop: topPad + 12, paddingBottom: Math.max(insets.bottom, 16) + 8 }]}>

        {/* Back */}
        <TouchableOpacity
          style={[styles.backBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => {
            if (step === "phone") safeGoBack(router);
            else if (step === "otp") setStep("phone");
            else setStep("otp");
            setError("");
          }}
        >
          <Feather name="arrow-left" size={20} color={colors.text} />
        </TouchableOpacity>

        {/* Progress dots */}
        <View style={styles.progressRow}>
          {(["phone", "otp", "newPin"] as Step[]).map((s, i) => (
            <View
              key={s}
              style={[
                styles.dot,
                {
                  backgroundColor:
                    s === step ? colors.primary : (["phone", "otp", "newPin"].indexOf(step) > i ? colors.primary + "55" : colors.border),
                  width: s === step ? 20 : 8,
                },
              ]}
            />
          ))}
        </View>

        {/* Heading */}
        <View style={styles.headingBlock}>
          <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
            {step === "phone" && "Forgot PIN?"}
            {step === "otp" && "Verify Your Number"}
            {step === "newPin" && "Set New PIN"}
          </Text>
          <Text style={[styles.subtitle, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            {step === "phone" && "Enter your registered phone number and we'll send you a verification code."}
            {step === "otp" && `Enter the 6-digit code sent to +233 ${phone.replace(/^0/, "")}.`}
            {step === "newPin" && "Choose a new 4–6 digit PIN you'll use to sign in."}
          </Text>
        </View>

        {/* Step 1: Phone */}
        {step === "phone" && (
          <View style={styles.form}>
            <View style={styles.inputWrap}>
              <View style={[styles.flagPill, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.flagText, { color: colors.text }]}>🇬🇭 +233</Text>
              </View>
              <TextInput
                style={[inputStyle, { paddingLeft: 90 }]}
                value={phone}
                onChangeText={(t) => { setPhone(t); setError(""); }}
                placeholder="0244 567 890"
                placeholderTextColor={colors.textMuted}
                keyboardType="phone-pad"
                autoFocus
                returnKeyType="done"
                onSubmitEditing={handlePhoneSubmit}
              />
            </View>

            {error ? <ErrorBox error={error} colors={colors} /> : null}

            <TouchableOpacity
              style={[styles.btn, { backgroundColor: loading ? colors.primary + "88" : colors.primary }]}
              onPress={handlePhoneSubmit}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Text style={[styles.btnText, { fontFamily: "Inter_700Bold" }]}>Send Code</Text>
                  <Feather name="send" size={17} color="#fff" />
                </>
              )}
            </TouchableOpacity>
          </View>
        )}

        {/* Step 2: OTP */}
        {step === "otp" && (
          <View style={styles.form}>
            <OtpBoxes
              value={otp}
              onChange={(t) => { setOtp(t); setError(""); }}
              colors={colors}
            />

            {devCode && (
              <View style={[styles.devBanner, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "44" }]}>
                <Feather name="code" size={13} color={colors.primary} />
                <Text style={[styles.devText, { color: colors.primary, fontFamily: "Inter_500Medium" }]}>
                  Dev code: <Text style={{ fontFamily: "Inter_700Bold" }}>{devCode}</Text>
                </Text>
              </View>
            )}

            {error ? <ErrorBox error={error} colors={colors} /> : null}

            <TouchableOpacity
              style={[styles.btn, { backgroundColor: loading ? colors.primary + "88" : colors.primary }]}
              onPress={handleOtpSubmit}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Text style={[styles.btnText, { fontFamily: "Inter_700Bold" }]}>Verify Code</Text>
                  <Feather name="check" size={17} color="#fff" />
                </>
              )}
            </TouchableOpacity>

            <TouchableOpacity style={styles.resendRow} onPress={handleResend} disabled={loading}>
              <Text style={[styles.resendText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                Didn't receive it?{" "}
              </Text>
              <Text style={[styles.resendLink, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Resend</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Step 3: New PIN */}
        {step === "newPin" && (
          <View style={styles.form}>
            <View style={styles.inputWrap}>
              <TextInput
                style={inputStyle}
                value={newPin}
                onChangeText={(t) => { setNewPin(t.replace(/\D/g, "").slice(0, 6)); setError(""); }}
                placeholder="New PIN (4–6 digits)"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                maxLength={6}
                secureTextEntry={!showPin}
                autoFocus
                returnKeyType="next"
                onSubmitEditing={() => confirmRef.current?.focus()}
              />
              <TouchableOpacity style={styles.eyeBtn} onPress={() => setShowPin((v) => !v)}>
                <Feather name={showPin ? "eye-off" : "eye"} size={18} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <View style={styles.inputWrap}>
              <TextInput
                ref={confirmRef}
                style={inputStyle}
                value={confirmPin}
                onChangeText={(t) => { setConfirmPin(t.replace(/\D/g, "").slice(0, 6)); setError(""); }}
                placeholder="Confirm PIN"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                maxLength={6}
                secureTextEntry={!showPin}
                returnKeyType="done"
                onSubmitEditing={handlePinSubmit}
              />
            </View>

            {error ? <ErrorBox error={error} colors={colors} /> : null}

            <TouchableOpacity
              style={[styles.btn, { backgroundColor: loading ? colors.primary + "88" : colors.primary }]}
              onPress={handlePinSubmit}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Text style={[styles.btnText, { fontFamily: "Inter_700Bold" }]}>Reset PIN</Text>
                  <Feather name="lock" size={17} color="#fff" />
                </>
              )}
            </TouchableOpacity>
          </View>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

function ErrorBox({ error, colors }: { error: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[styles.errorBox, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
      <Feather name="alert-circle" size={13} color={colors.danger} />
      <Text style={[styles.errorText, { color: colors.danger, fontFamily: "Inter_400Regular" }]}> {error}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, overflow: "hidden" },
  inner: { flex: 1, paddingHorizontal: 24, gap: 18 },
  backBtn: {
    width: 38, height: 38, borderRadius: 11, borderWidth: 1,
    alignItems: "center", justifyContent: "center",
  },
  progressRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  dot: { height: 8, borderRadius: 4 },
  headingBlock: { gap: 6 },
  title: { fontSize: 26, letterSpacing: -0.5 },
  subtitle: { fontSize: 14, lineHeight: 21 },
  form: { gap: 12 },
  inputWrap: { position: "relative" },
  flagPill: {
    position: "absolute", left: 0, top: 0, bottom: 0, zIndex: 1,
    justifyContent: "center", paddingHorizontal: 10,
    borderTopLeftRadius: 12, borderBottomLeftRadius: 12, borderRightWidth: 1,
  },
  flagText: { fontSize: 12 },
  input: {
    height: 48, borderRadius: 12, borderWidth: 1,
    paddingHorizontal: 14, fontSize: 15,
  },
  eyeBtn: {
    position: "absolute", right: 12, top: 0, bottom: 0, justifyContent: "center",
  },
  devBanner: {
    flexDirection: "row", alignItems: "center", gap: 6,
    borderRadius: 10, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8,
  },
  devText: { fontSize: 13 },
  errorBox: {
    flexDirection: "row", alignItems: "center",
    borderRadius: 10, borderWidth: 1, padding: 10,
  },
  errorText: { fontSize: 12, flex: 1 },
  btn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    borderRadius: 14, paddingVertical: 14, gap: 8,
  },
  btnText: { color: "#fff", fontSize: 15 },
  resendRow: { flexDirection: "row", alignItems: "center", justifyContent: "center" },
  resendText: { fontSize: 13 },
  resendLink: { fontSize: 13 },
  successCircle: {
    width: 96, height: 96, borderRadius: 48,
    alignItems: "center", justifyContent: "center", alignSelf: "center",
  },
  successTitle: { fontSize: 26, letterSpacing: -0.5, textAlign: "center" },
  successSub: { fontSize: 14, lineHeight: 21, textAlign: "center" },
});
