import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { customFetch } from "@workspace/api-client-react";

// ─── Types ────────────────────────────────────────────────────────────────────
interface Group {
  id: string;
  name: string;
  description?: string;
  isPaid: boolean;
  membershipFeePesewas?: number;
  memberCount: number;
  ownerId: string;
  ownerName?: string;
  isMember?: boolean;
  avatarColor?: string;
  createdAt: string;
}

const AVATAR_COLORS = [
  "#12D9A0", "#F59E0B", "#EC4899", "#10B981", "#3B82F6",
  "#F97316", "#00A884",
];

function groupColor(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) & 0xffff;
  return AVATAR_COLORS[h % AVATAR_COLORS.length]!;
}

function initials(name: string) {
  return name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

// ─── Screen ───────────────────────────────────────────────────────────────────
export default function GroupsScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isAuthenticated, authUserId, balance } = useApp();

  const [myGroups, setMyGroups] = useState<Group[]>([]);
  const [discover, setDiscover] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"mine" | "discover">("mine");
  const [showCreate, setShowCreate] = useState(false);

  // ── Create form state ──────────────────────────────────────────────────────
  const [createName, setCreateName] = useState("");
  const [createDesc, setCreateDesc] = useState("");
  const [createPaid, setCreatePaid] = useState(false);
  const [createFee, setCreateFee] = useState("");
  const [creating, setCreating] = useState(false);

  // ── Join modal ─────────────────────────────────────────────────────────────
  const [joinTarget, setJoinTarget] = useState<Group | null>(null);
  const [joining, setJoining] = useState(false);

  // ─── Load data ───────────────────────────────────────────────────────────────
  const loadGroups = useCallback(async () => {
    if (!isAuthenticated) return;
    setLoading(true);
    try {
      const [mine, all] = await Promise.all([
        customFetch<Group[]>("/api/groups"),
        customFetch<Group[]>("/api/groups/discover"),
      ]);
      setMyGroups(mine as Group[]);
      const mineIds = new Set((mine as Group[]).map((g) => g.id));
      setDiscover((all as Group[]).filter((g) => !mineIds.has(g.id)));
    } catch (e) {
      // silently ignore
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => { loadGroups(); }, [loadGroups]);

  // ─── Create group ────────────────────────────────────────────────────────────
  const handleCreate = async () => {
    if (!createName.trim()) { Alert.alert("Name required", "Please enter a group name."); return; }
    if (createPaid && (!createFee || parseFloat(createFee) <= 0)) {
      Alert.alert("Fee required", "Enter a valid membership fee for paid groups.");
      return;
    }
    setCreating(true);
    try {
      const body: any = {
        name: createName.trim(),
        description: createDesc.trim() || undefined,
        isPaid: createPaid,
      };
      if (createPaid) body.membershipFeePesewas = Math.round(parseFloat(createFee) * 100);
      const created = await customFetch<Group>("/api/groups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      setShowCreate(false);
      setCreateName(""); setCreateDesc(""); setCreatePaid(false); setCreateFee("");
      await loadGroups();
      router.push(`/groups/${(created as Group).id}` as never);
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not create group.");
    } finally {
      setCreating(false);
    }
  };

  // ─── Join group ───────────────────────────────────────────────────────────
  const handleJoin = async (group: Group) => {
    if (group.isPaid) { setJoinTarget(group); return; }
    setJoining(true);
    try {
      await customFetch(`/api/groups/${group.id}/join`, { method: "POST" });
      await loadGroups();
      router.push(`/groups/${group.id}` as never);
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not join group.");
    } finally {
      setJoining(false);
    }
  };

  const handlePaidJoin = async () => {
    if (!joinTarget) return;
    const fee = (joinTarget.membershipFeePesewas ?? 0);
    if ((balance ?? 0) < fee) {
      Alert.alert("Insufficient balance", "Top up your wallet to join this group.");
      setJoinTarget(null);
      return;
    }
    setJoining(true);
    try {
      await customFetch(`/api/groups/${joinTarget.id}/pay-join`, { method: "POST" });
      setJoinTarget(null);
      await loadGroups();
      router.push(`/groups/${joinTarget.id}` as never);
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not join group.");
    } finally {
      setJoining(false);
    }
  };

  // ─── Leave group ──────────────────────────────────────────────────────────
  const handleLeave = (group: Group) => {
    Alert.alert("Leave Group", `Leave "${group.name}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Leave", style: "destructive",
        onPress: async () => {
          try {
            await customFetch(`/api/groups/${group.id}/leave`, { method: "POST" });
            loadGroups();
          } catch (e: any) {
            Alert.alert("Error", e?.message ?? "Could not leave group.");
          }
        },
      },
    ]);
  };

  // ─── Render group card ────────────────────────────────────────────────────
  const renderGroup = ({ item, isMine }: { item: Group; isMine: boolean }) => {
    const color = groupColor(item.id);
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
        activeOpacity={0.8}
        onPress={() => {
          if (isMine) router.push(`/groups/${item.id}` as never);
          else handleJoin(item);
        }}
        onLongPress={() => isMine && handleLeave(item)}
      >
        <View style={[styles.avatar, { backgroundColor: color }]}>
          <Text style={styles.avatarText}>{initials(item.name)}</Text>
        </View>
        <View style={styles.cardBody}>
          <View style={styles.cardRow}>
            <Text style={[styles.cardName, { color: colors.text }]} numberOfLines={1}>{item.name}</Text>
            {item.isPaid && (
              <View style={[styles.paidBadge, { backgroundColor: "#F59E0B22" }]}>
                <Feather name="lock" size={10} color="#F59E0B" />
                <Text style={styles.paidText}>{fmtGHS(item.membershipFeePesewas)}</Text>
              </View>
            )}
          </View>
          {item.description ? (
            <Text style={[styles.cardDesc, { color: colors.textMuted }]} numberOfLines={1}>{item.description}</Text>
          ) : null}
          <Text style={[styles.cardMeta, { color: colors.textMuted }]}>
            {item.memberCount} {item.memberCount === 1 ? "member" : "members"}
          </Text>
        </View>
        <Feather name={isMine ? "chevron-right" : "plus-circle"} size={18} color={isMine ? colors.textMuted : colors.primary} />
      </TouchableOpacity>
    );
  };

  const list = activeTab === "mine" ? myGroups : discover;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Groups</Text>
        <TouchableOpacity onPress={() => setShowCreate(true)} style={styles.addBtn}>
          <Feather name="plus" size={22} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={[styles.tabs, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        {(["mine", "discover"] as const).map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && { borderBottomColor: colors.primary, borderBottomWidth: 2 }]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, { color: activeTab === tab ? colors.primary : colors.textMuted }]}>
              {tab === "mine" ? "My Groups" : "Discover"}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List */}
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} size="large" /></View>
      ) : list.length === 0 ? (
        <View style={styles.center}>
          <Feather name="users" size={48} color={colors.textMuted} />
          <Text style={[styles.emptyText, { color: colors.textMuted }]}>
            {activeTab === "mine" ? "No groups yet.\nCreate or join one!" : "No new groups to discover."}
          </Text>
          {activeTab === "mine" && (
            <TouchableOpacity style={[styles.createBtn, { backgroundColor: colors.primary }]} onPress={() => setShowCreate(true)}>
              <Text style={styles.createBtnText}>Create Group</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <FlatList
          data={list}
          keyExtractor={(g) => g.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => renderGroup({ item, isMine: activeTab === "mine" })}
        />
      )}

      {/* Create Group Modal */}
      <Modal visible={showCreate} animationType="slide" transparent>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.modalOverlay}>
          <View style={[styles.sheet, { backgroundColor: colors.surface }]}>
            <View style={styles.sheetHandle} />
            <Text style={[styles.sheetTitle, { color: colors.text }]}>New Group</Text>

            <Text style={[styles.label, { color: colors.textMuted }]}>Group Name *</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
              value={createName} onChangeText={setCreateName}
              placeholder="e.g. Family Savings" placeholderTextColor={colors.textMuted}
              maxLength={50}
            />

            <Text style={[styles.label, { color: colors.textMuted }]}>Description</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border, height: 72, textAlignVertical: "top" }]}
              value={createDesc} onChangeText={setCreateDesc}
              placeholder="What's this group about?" placeholderTextColor={colors.textMuted}
              multiline maxLength={200}
            />

            {/* Paid toggle */}
            <TouchableOpacity
              style={[styles.toggle, { backgroundColor: colors.background, borderColor: colors.border }]}
              onPress={() => setCreatePaid((p) => !p)}
            >
              <View>
                <Text style={[styles.toggleLabel, { color: colors.text }]}>Paid Group</Text>
                <Text style={[styles.toggleSub, { color: colors.textMuted }]}>Charge members a fee to join</Text>
              </View>
              <View style={[styles.toggleDot, { backgroundColor: createPaid ? colors.primary : colors.border }]}>
                {createPaid && <View style={styles.toggleInner} />}
              </View>
            </TouchableOpacity>

            {createPaid && (
              <>
                <Text style={[styles.label, { color: colors.textMuted }]}>Membership Fee (GHS)</Text>
                <TextInput
                  style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                  value={createFee} onChangeText={setCreateFee}
                  keyboardType="decimal-pad" placeholder="e.g. 10.00"
                  placeholderTextColor={colors.textMuted}
                />
                <Text style={[styles.feeNote, { color: colors.textMuted }]}>
                  Platform takes 10% commission. You receive GHS {createFee ? ((parseFloat(createFee) || 0) * 0.9).toFixed(2) : "0.00"} per member.
                </Text>
              </>
            )}

            <View style={styles.sheetActions}>
              <TouchableOpacity
                style={[styles.btn, styles.btnCancel, { borderColor: colors.border }]}
                onPress={() => { setShowCreate(false); setCreateName(""); setCreateDesc(""); setCreatePaid(false); setCreateFee(""); }}
              >
                <Text style={[styles.btnText, { color: colors.textMuted }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.btn, { backgroundColor: colors.primary }]}
                onPress={handleCreate} disabled={creating}
              >
                {creating ? <ActivityIndicator color="#fff" size="small" /> : <Text style={[styles.btnText, { color: "#fff" }]}>Create</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Paid Join Modal */}
      <Modal visible={!!joinTarget} animationType="fade" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.sheet, { backgroundColor: colors.surface }]}>
            <View style={styles.sheetHandle} />
            <View style={[styles.paidIcon, { backgroundColor: "#F59E0B22" }]}>
              <Feather name="lock" size={28} color="#F59E0B" />
            </View>
            <Text style={[styles.sheetTitle, { color: colors.text }]}>{joinTarget?.name}</Text>
            <Text style={[styles.paidDesc, { color: colors.textMuted }]}>
              This is a paid group. A one-time membership fee will be deducted from your wallet.
            </Text>
            <View style={[styles.feeCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <Text style={[styles.feeLabel, { color: colors.textMuted }]}>Membership Fee</Text>
              <Text style={[styles.feeValue, { color: colors.text }]}>{fmtGHS(joinTarget?.membershipFeePesewas)}</Text>
            </View>
            <View style={[styles.feeCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <Text style={[styles.feeLabel, { color: colors.textMuted }]}>Your Balance</Text>
              <Text style={[styles.feeValue, { color: (balance ?? 0) >= (joinTarget?.membershipFeePesewas ?? 0) ? "#10B981" : "#EF4444" }]}>
                {fmtGHS(balance)}
              </Text>
            </View>
            <View style={styles.sheetActions}>
              <TouchableOpacity
                style={[styles.btn, styles.btnCancel, { borderColor: colors.border }]}
                onPress={() => setJoinTarget(null)}
              >
                <Text style={[styles.btnText, { color: colors.textMuted }]}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.btn, { backgroundColor: "#F59E0B" }]}
                onPress={handlePaidJoin} disabled={joining}
              >
                {joining ? <ActivityIndicator color="#fff" size="small" /> : <Text style={[styles.btnText, { color: "#fff" }]}>Pay & Join</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function fmtGHS(p?: number | null) {
  if (!p) return "GH₵ 0.00";
  return `GH₵ ${(p / 100).toFixed(2)}`;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn: { padding: 4, marginRight: 8 },
  title: { flex: 1, fontSize: 20, fontFamily: "Inter_700Bold" },
  addBtn: { padding: 4 },
  tabs: { flexDirection: "row", borderBottomWidth: 1 },
  tab: { flex: 1, alignItems: "center", paddingVertical: 12 },
  tabText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32 },
  emptyText: { textAlign: "center", marginTop: 16, fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 22 },
  createBtn: { marginTop: 20, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  createBtnText: { color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 15 },
  listContent: { padding: 16, gap: 10 },
  card: { flexDirection: "row", alignItems: "center", borderRadius: 14, padding: 14, borderWidth: 1 },
  avatar: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
  cardBody: { flex: 1, marginHorizontal: 12 },
  cardRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  cardName: { fontSize: 15, fontFamily: "Inter_600SemiBold", flex: 1 },
  cardDesc: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 2 },
  cardMeta: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  paidBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 8 },
  paidText: { fontSize: 11, fontFamily: "Inter_600SemiBold", color: "#F59E0B" },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 36 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: "#ffffff33", alignSelf: "center", marginBottom: 16 },
  sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", marginBottom: 16, textAlign: "center" },
  label: { fontSize: 12, fontFamily: "Inter_500Medium", marginBottom: 6, marginTop: 12, textTransform: "uppercase", letterSpacing: 0.5 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, fontFamily: "Inter_400Regular" },
  toggle: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderRadius: 12, padding: 14, marginTop: 14 },
  toggleLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  toggleSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  toggleDot: { width: 40, height: 24, borderRadius: 12, alignItems: "flex-end", justifyContent: "center", paddingRight: 3 },
  toggleInner: { width: 18, height: 18, borderRadius: 9, backgroundColor: "#fff" },
  feeNote: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 6 },
  sheetActions: { flexDirection: "row", gap: 10, marginTop: 20 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  btnCancel: { borderWidth: 1 },
  btnText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  paidIcon: { width: 60, height: 60, borderRadius: 20, alignItems: "center", justifyContent: "center", alignSelf: "center", marginBottom: 12 },
  paidDesc: { textAlign: "center", fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 20, marginBottom: 16 },
  feeCard: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 8 },
  feeLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  feeValue: { fontSize: 16, fontFamily: "Inter_700Bold" },
});
