import { Feather } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActionSheetIOS,
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { customFetch } from "@workspace/api-client-react";
import { apiOrigin } from "@/lib/api-base";

// ─── Types ────────────────────────────────────────────────────────────────────
interface GroupMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string | null;
  messageType: string;
  mediaUrl?: string | null;
  createdAt: string;
  isEdited?: boolean;
  reactions?: { emoji: string; count: number; myReaction?: boolean }[];
}

interface GroupDetail {
  id: string;
  name: string;
  description?: string;
  isPaid: boolean;
  memberCount: number;
  ownerId: string;
  isMember: boolean;
}

const REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🔥"];

// ─── Upload helper ────────────────────────────────────────────────────────────
async function uploadMedia(
  localUri: string,
  fileName: string,
  contentType: string,
  fileSize: number = 1
): Promise<string> {
  const domain = process.env["EXPO_PUBLIC_DOMAIN"];
  const uploadRes = await customFetch<{ uploadURL: string; objectPath: string }>(
    "/api/storage/uploads/request-url",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: fileName, size: Math.max(1, fileSize), contentType }),
    }
  );
  const { uploadURL, objectPath } = uploadRes as { uploadURL: string; objectPath: string };

  const blob = await (await fetch(localUri)).blob();
  await fetch(uploadURL, {
    method: "PUT",
    body: blob,
    headers: { "Content-Type": contentType },
  });

  const objectKey = objectPath.split("/").pop();
  return domain
    ? `${apiOrigin(domain)}/api/storage/objects/uploads/${objectKey}`
    : localUri;
}

// ─── Media Bubble ─────────────────────────────────────────────────────────────
function MediaBubble({ msg, colors }: { msg: GroupMessage; colors: ReturnType<typeof useColors> }) {
  const type = msg.messageType;

  if (type === "image" && msg.mediaUrl) {
    return (
      <Image
        source={{ uri: msg.mediaUrl }}
        style={styles.mediaBubbleImage}
        resizeMode="cover"
      />
    );
  }

  if (type === "video" && msg.mediaUrl) {
    return (
      <View style={[styles.mediaBubbleVideo, { backgroundColor: colors.surface }]}>
        <Feather name="play-circle" size={40} color="#fff" />
        <Text style={styles.mediaLabel}>Video</Text>
      </View>
    );
  }

  if (type === "file" && msg.mediaUrl) {
    const parts = msg.mediaUrl.split("/");
    const rawName = decodeURIComponent(parts[parts.length - 1] ?? "File");
    const displayName = rawName.replace(/^\d+-/, "");
    return (
      <View style={[styles.mediaBubbleFile, { backgroundColor: colors.surface }]}>
        <Feather name="file" size={22} color={colors.primary} />
        <Text style={[styles.mediaFileName, { color: colors.text }]} numberOfLines={2}>
          {displayName}
        </Text>
        <Feather name="download" size={18} color={colors.textMuted} />
      </View>
    );
  }

  return null;
}

// ─── Screen ───────────────────────────────────────────────────────────────────
export default function GroupChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { authUserId } = useApp();

  const [group, setGroup] = useState<GroupDetail | null>(null);
  const [messages, setMessages] = useState<GroupMessage[]>([]);
  const [loadingGroup, setLoadingGroup] = useState(true);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [reactionTarget, setReactionTarget] = useState<string | null>(null);

  const flatRef = useRef<FlatList>(null);

  // ─── Load group + messages ────────────────────────────────────────────────
  const loadData = useCallback(async () => {
    if (!id) return;
    try {
      const [g, msgs] = await Promise.all([
        customFetch<GroupDetail>(`/api/groups/${id}`),
        customFetch<GroupMessage[]>(`/api/groups/${id}/messages`),
      ]);
      setGroup(g as GroupDetail);
      const arr = Array.isArray(msgs) ? (msgs as GroupMessage[]) : [];
      setMessages(arr);
    } catch {
      // silent
    } finally {
      setLoadingGroup(false);
    }
  }, [id]);

  useEffect(() => { loadData(); }, [loadData]);

  // ─── Send text message ────────────────────────────────────────────────────
  const handleSend = async () => {
    const content = text.trim();
    if (!content || sending) return;
    setSending(true);
    setText("");
    const optimisticId = `opt-${Date.now()}`;
    const optimistic: GroupMessage = {
      id: optimisticId, senderId: authUserId ?? "", senderName: "You",
      content, messageType: "text", createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 50);
    try {
      const sent = await customFetch<GroupMessage>(`/api/groups/${id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content, messageType: "text" }),
      });
      setMessages((prev) => prev.map((m) => m.id === optimisticId ? (sent as GroupMessage) : m));
    } catch {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticId));
      setText(content);
    } finally {
      setSending(false);
    }
  };

  // ─── Send media message ───────────────────────────────────────────────────
  const sendMedia = async (
    localUri: string,
    fileName: string,
    contentType: string,
    messageType: "image" | "video" | "file",
    fileSize: number = 1
  ) => {
    if (sending) return;
    setSending(true);
    setUploadProgress("Uploading…");

    const optimisticId = `opt-${Date.now()}`;
    const optimistic: GroupMessage = {
      id: optimisticId, senderId: authUserId ?? "", senderName: "You",
      content: null, messageType, mediaUrl: localUri,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 50);

    try {
      const mediaUrl = await uploadMedia(localUri, fileName, contentType, fileSize);
      setUploadProgress("Sending…");
      const sent = await customFetch<GroupMessage>(`/api/groups/${id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageType, mediaUrl }),
      });
      setMessages((prev) => prev.map((m) => m.id === optimisticId ? (sent as GroupMessage) : m));
    } catch (e: unknown) {
      setMessages((prev) => prev.filter((m) => m.id !== optimisticId));
      Alert.alert("Upload failed", "Could not send media. Please try again.");
    } finally {
      setSending(false);
      setUploadProgress(null);
    }
  };

  // ─── Attachment picker ─────────────────────────────────────────────────────
  const openAttachMenu = () => {
    const options = ["Photo from Gallery", "Video from Gallery", "Send File", "Cancel"];
    const handlers = [pickImage, pickVideo, pickFile];

    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        { options, cancelButtonIndex: 3, tintColor: colors.primary },
        (idx) => { if (idx < 3) handlers[idx]?.(); }
      );
    } else {
      Alert.alert("Send Media", "Choose an option", [
        { text: "📷 Photo from Gallery", onPress: pickImage },
        { text: "🎬 Video from Gallery", onPress: pickVideo },
        { text: "📎 Send File", onPress: pickFile },
        { text: "Cancel", style: "cancel" },
      ]);
    }
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission required", "Gallery access is needed to send photos.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      quality: 0.85,
    });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const ext = asset.uri.split(".").pop()?.split("?")[0] ?? "jpg";
    await sendMedia(asset.uri, `img-${Date.now()}.${ext}`, "image/jpeg", "image", asset.fileSize ?? 1);
  };

  const pickVideo = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission required", "Gallery access is needed to send videos.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "videos",
      videoMaxDuration: 120,
    });
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const ext = asset.uri.split(".").pop()?.split("?")[0] ?? "mp4";
    await sendMedia(asset.uri, `vid-${Date.now()}.${ext}`, "video/mp4", "video", asset.fileSize ?? 1);
  };

  const pickFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "*/*",
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];
      const uri = asset.uri;
      const name = asset.name ?? `file-${Date.now()}`;
      const mimeType = asset.mimeType ?? "application/octet-stream";
      await sendMedia(uri, name, mimeType, "file", asset.size ?? 1);
    } catch {
      Alert.alert("Error", "Could not open file picker.");
    }
  };

  // ─── Delete message ────────────────────────────────────────────────────────
  const handleDelete = (msgId: string, senderId: string) => {
    if (senderId !== authUserId) return;
    Alert.alert("Delete Message", "Delete this message?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete", style: "destructive",
        onPress: async () => {
          try {
            await customFetch(`/api/groups/${id}/messages/${msgId}`, { method: "DELETE" });
            setMessages((prev) => prev.filter((m) => m.id !== msgId));
          } catch {
            Alert.alert("Error", "Could not delete message.");
          }
        },
      },
    ]);
  };

  // ─── React to message ──────────────────────────────────────────────────────
  const handleReact = async (msgId: string, emoji: string) => {
    setReactionTarget(null);
    try {
      await customFetch(`/api/groups/${id}/messages/${msgId}/reactions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ emoji }),
      });
      loadData();
    } catch { /* silent */ }
  };

  // ─── Helpers ──────────────────────────────────────────────────────────────
  function fmtTime(iso: string) {
    return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function senderColor(sid: string) {
    const palette = ["#12D9A0", "#F59E0B", "#EC4899", "#10B981", "#3B82F6", "#F97316"];
    let h = 0;
    for (let i = 0; i < sid.length; i++) h = (h * 31 + sid.charCodeAt(i)) & 0xff;
    return palette[h % palette.length]!;
  }

  // ─── Render message ────────────────────────────────────────────────────────
  const renderMsg = ({ item }: { item: GroupMessage }) => {
    const isMe = item.senderId === authUserId;
    const color = senderColor(item.senderId);
    const isMedia = item.messageType !== "text";

    return (
      <TouchableOpacity
        activeOpacity={0.85}
        onLongPress={() => {
          if (isMe) {
            Alert.alert("Message Options", undefined, [
              { text: "Delete", style: "destructive", onPress: () => handleDelete(item.id, item.senderId) },
              { text: "React", onPress: () => setReactionTarget(item.id) },
              { text: "Cancel", style: "cancel" },
            ]);
          } else {
            setReactionTarget(item.id);
          }
        }}
        style={[styles.msgRow, isMe && styles.msgRowMe]}
      >
        {!isMe && (
          <View style={[styles.msgAvatar, { backgroundColor: color }]}>
            <Text style={styles.msgAvatarText}>{(item.senderName ?? "?")[0]?.toUpperCase()}</Text>
          </View>
        )}
        <View style={[
          styles.bubble,
          isMe
            ? { backgroundColor: colors.primary }
            : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 },
          isMedia && styles.bubbleMedia,
        ]}>
          {!isMe && <Text style={[styles.senderName, { color }]}>{item.senderName}</Text>}

          {isMedia && <MediaBubble msg={item} colors={colors} />}

          {item.content ? (
            <Text style={[styles.bubbleText, { color: isMe ? "#fff" : colors.text }]}>
              {item.content}
            </Text>
          ) : null}

          {/* Reactions row */}
          {item.reactions && item.reactions.length > 0 && (
            <View style={styles.reactionsRow}>
              {item.reactions.map((r) => (
                <TouchableOpacity
                  key={r.emoji}
                  style={[styles.reactionChip, r.myReaction && { backgroundColor: colors.primary + "33" }]}
                  onPress={() => handleReact(item.id, r.emoji)}
                >
                  <Text style={styles.reactionChipText}>{r.emoji} {r.count}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <View style={styles.bubbleMeta}>
            {item.isEdited && (
              <Text style={[styles.editedTag, { color: isMe ? "#ffffff88" : colors.textMuted }]}>edited</Text>
            )}
            <Text style={[styles.bubbleTime, { color: isMe ? "#ffffff88" : colors.textMuted }]}>
              {fmtTime(item.createdAt)}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  // ─── Reaction picker overlay ───────────────────────────────────────────────
  const ReactionPicker = () => {
    if (!reactionTarget) return null;
    return (
      <TouchableOpacity style={styles.reactionOverlay} activeOpacity={1} onPress={() => setReactionTarget(null)}>
        <View style={[styles.reactionPicker, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {REACTIONS.map((emoji) => (
            <TouchableOpacity key={emoji} onPress={() => handleReact(reactionTarget, emoji)} style={styles.reactionBtn}>
              <Text style={styles.reactionEmoji}>{emoji}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </TouchableOpacity>
    );
  };

  if (loadingGroup) {
    return (
      <View style={[styles.root, styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={[styles.headerName, { color: colors.text }]} numberOfLines={1}>{group?.name ?? "Group"}</Text>
          <Text style={[styles.headerSub, { color: colors.textMuted }]}>{group?.memberCount ?? 0} members</Text>
        </View>
        <TouchableOpacity style={styles.headerAction}>
          <Feather name="info" size={20} color={colors.textMuted} />
        </TouchableOpacity>
      </View>

      {/* Upload progress banner */}
      {uploadProgress && (
        <View style={[styles.uploadBanner, { backgroundColor: colors.primary }]}>
          <ActivityIndicator size="small" color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.uploadBannerText}>{uploadProgress}</Text>
        </View>
      )}

      {/* Messages */}
      <FlatList
        ref={flatRef}
        data={messages}
        keyExtractor={(m) => m.id}
        renderItem={renderMsg}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.listContent, { paddingBottom: insets.bottom + 88 }]}
        onContentSizeChange={() => flatRef.current?.scrollToEnd({ animated: false })}
        ListEmptyComponent={
          <View style={styles.center}>
            <Text style={[styles.emptyText, { color: colors.textMuted }]}>No messages yet. Say hello! 👋</Text>
          </View>
        }
      />

      {/* Input bar */}
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <View style={[styles.inputBar, {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          paddingBottom: insets.bottom + 8,
        }]}>
          {/* Attach button */}
          <TouchableOpacity
            style={[styles.attachBtn, { backgroundColor: colors.background, borderColor: colors.border }]}
            onPress={openAttachMenu}
            disabled={sending}
          >
            <Feather name="paperclip" size={19} color={sending ? colors.textMuted : colors.primary} />
          </TouchableOpacity>

          <TextInput
            style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
            value={text}
            onChangeText={setText}
            placeholder="Message…"
            placeholderTextColor={colors.textMuted}
            multiline
            returnKeyType="send"
            onSubmitEditing={handleSend}
          />

          <TouchableOpacity
            style={[styles.sendBtn, { backgroundColor: text.trim() ? colors.primary : colors.border }]}
            onPress={handleSend}
            disabled={!text.trim() || sending}
          >
            {sending && !uploadProgress
              ? <ActivityIndicator color="#fff" size="small" />
              : <Feather name="send" size={18} color="#fff" />}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      <ReactionPicker />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn: { padding: 4, marginRight: 8 },
  headerInfo: { flex: 1 },
  headerName: { fontSize: 17, fontFamily: "Inter_700Bold" },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 1 },
  headerAction: { padding: 4 },
  uploadBanner: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 6, paddingHorizontal: 16 },
  uploadBannerText: { color: "#fff", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  listContent: { padding: 16, gap: 8 },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  msgRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  msgRowMe: { flexDirection: "row-reverse" },
  msgAvatar: { width: 28, height: 28, borderRadius: 10, alignItems: "center", justifyContent: "center", marginBottom: 4 },
  msgAvatarText: { color: "#fff", fontSize: 11, fontFamily: "Inter_700Bold" },
  bubble: { maxWidth: "75%", borderRadius: 16, padding: 10 },
  bubbleMedia: { padding: 6 },
  senderName: { fontSize: 11, fontFamily: "Inter_600SemiBold", marginBottom: 3 },
  bubbleText: { fontSize: 15, fontFamily: "Inter_400Regular", lineHeight: 21, marginTop: 4 },
  bubbleMeta: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", marginTop: 4, gap: 4 },
  editedTag: { fontSize: 10, fontFamily: "Inter_400Regular" },
  bubbleTime: { fontSize: 10, fontFamily: "Inter_400Regular" },
  reactionsRow: { flexDirection: "row", flexWrap: "wrap", gap: 4, marginTop: 4 },
  reactionChip: { flexDirection: "row", alignItems: "center", borderRadius: 10, paddingHorizontal: 7, paddingVertical: 2, backgroundColor: "#ffffff18" },
  reactionChipText: { fontSize: 12 },
  // Media bubbles
  mediaBubbleImage: { width: 200, height: 200, borderRadius: 12 },
  mediaBubbleVideo: { width: 200, height: 140, borderRadius: 12, alignItems: "center", justifyContent: "center", gap: 6 },
  mediaLabel: { color: "#fff", fontSize: 13, fontFamily: "Inter_600SemiBold" },
  mediaBubbleFile: { flexDirection: "row", alignItems: "center", gap: 8, padding: 10, borderRadius: 12, minWidth: 160, maxWidth: 220 },
  mediaFileName: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular" },
  // Input
  inputBar: { flexDirection: "row", alignItems: "flex-end", padding: 10, gap: 8, borderTopWidth: 1 },
  attachBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", borderWidth: 1 },
  input: { flex: 1, borderWidth: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15, fontFamily: "Inter_400Regular", maxHeight: 120 },
  sendBtn: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  // Reaction picker
  reactionOverlay: { ...StyleSheet.absoluteFillObject, zIndex: 100 },
  reactionPicker: { position: "absolute", bottom: 80, alignSelf: "center", left: 40, right: 40, flexDirection: "row", justifyContent: "space-around", borderRadius: 20, padding: 8, borderWidth: 1 },
  reactionBtn: { padding: 6 },
  reactionEmoji: { fontSize: 24 },
});
