import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BalanceCard, Card, Divider, SectionHeader } from "@/components/FargoComponents";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const MOMO_PROVIDERS = [
  { name: "MTN MoMo",     icon: "smartphone" as const, color: "#F5C200" },
  { name: "Telecel Cash", icon: "smartphone" as const, color: "#D32F2F" },
  { name: "AirtelTigo",   icon: "smartphone" as const, color: "#FF6900" },
];

const TXN_ICON_MAP: Record<string, keyof typeof Feather.glyphMap> = {
  lock: "lock",
  "plus-circle": "plus-circle",
  "arrow-up-circle": "arrow-up-circle",
  unlock: "unlock",
};

export default function WalletScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { transactions } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 8 }]}>
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Wallet</Text>
        <TouchableOpacity
          style={[styles.historyBtn, { backgroundColor: colors.surfaceElevated }]}
          onPress={() => router.push("/settings" as any)}
          activeOpacity={0.75}
        >
          <Feather name="settings" size={16} color={colors.textMuted} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <BalanceCard />

        <SectionHeader title="Mobile Money" />
        <Card style={{ paddingVertical: 4 }}>
          {MOMO_PROVIDERS.map((m, i) => (
            <View key={m.name}>
              <View style={styles.momoRow}>
                <View style={[styles.momoIconWrap, { backgroundColor: m.color + "22" }]}>
                  <Feather name={m.icon} size={18} color={m.color} />
                </View>
                <Text style={[styles.momoName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                  {m.name}
                </Text>
                <TouchableOpacity style={[styles.connectBtn, { borderColor: colors.border }]}>
                  <Text style={[styles.connectBtnText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                    Link
                  </Text>
                </TouchableOpacity>
              </View>
              {i < MOMO_PROVIDERS.length - 1 && <Divider />}
            </View>
          ))}
        </Card>

        <SectionHeader title="Recent Transactions" action="See All" />
        <Card style={{ paddingVertical: 4 }}>
          {transactions.map((t, i) => (
            <View key={t.id}>
              <View style={styles.txnRow}>
                <View
                  style={[
                    styles.txnIcon,
                    { backgroundColor: t.type === "credit" ? colors.successBg : colors.surfaceElevated },
                  ]}
                >
                  <Feather
                    name={TXN_ICON_MAP[t.icon] ?? "circle"}
                    size={16}
                    color={t.type === "credit" ? colors.success : colors.textMuted}
                  />
                </View>
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <Text style={[styles.txnTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                    {t.title}
                  </Text>
                  <Text style={[styles.txnSub, { color: colors.textMuted }]}>
                    {t.sub} · {t.date}
                  </Text>
                </View>
                <Text
                  style={[
                    styles.txnAmount,
                    { color: t.type === "credit" ? colors.success : colors.danger, fontFamily: "Inter_700Bold" },
                  ]}
                >
                  {t.amount}
                </Text>
              </View>
              {i < transactions.length - 1 && <Divider />}
            </View>
          ))}
        </Card>

        {/* Bank card banner */}
        <TouchableOpacity
          style={[styles.bankBanner, { backgroundColor: colors.surface, borderColor: colors.border }]}
          activeOpacity={0.8}
        >
          <View style={[styles.bankIcon, { backgroundColor: colors.goldDim }]}>
            <Feather name="credit-card" size={20} color={colors.gold} />
          </View>
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={[styles.bankTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
              Link a Bank Account
            </Text>
            <Text style={[styles.bankSub, { color: colors.textMuted }]}>Instant withdrawals</Text>
          </View>
          <Feather name="chevron-right" size={18} color={colors.textMuted} />
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  screenTitle: { fontSize: 22, fontWeight: "800" },
  historyBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  scroll: { paddingHorizontal: 14, paddingTop: 16, paddingBottom: 100 },

  momoRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12, gap: 12 },
  momoIconWrap: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  momoName: { flex: 1, fontSize: 14 },
  connectedBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  connectedText: { fontSize: 11, fontWeight: "600" },
  connectBtn: { borderWidth: 1, borderRadius: 10, paddingVertical: 6, paddingHorizontal: 14 },
  connectBtnText: { fontSize: 12 },

  txnRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  txnIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  txnTitle: { fontSize: 14 },
  txnSub: { fontSize: 12, marginTop: 2 },
  txnAmount: { fontSize: 14, fontWeight: "800" },

  bankBanner: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
  },
  bankIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  bankTitle: { fontSize: 14 },
  bankSub: { fontSize: 12, marginTop: 2 },
});
