import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import { Video, ResizeMode } from "expo-av";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { LinearGradient } from "expo-linear-gradient";
import React, {
  useCallback, useEffect, useRef, useState,
} from "react";
import {
  ActivityIndicator, Alert, Animated, Dimensions, FlatList,
  KeyboardAvoidingView, Modal, Platform, ScrollView,
  StyleSheet, Text, TextInput, TouchableOpacity, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import {
  useListReels, useListMyReels, useListSavedReels, useGetReelAnalytics,
  useToggleReelLike, useToggleReelSave, usePostReelComment, useListReelComments,
  useToggleReelFollow, useCreateReel, useRecordReelView, useShareReel, useReportReel,
  useDeleteReel,
} from "@workspace/api-client-react";
import type { ReelRecord, ReelCommentRecord } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

const { width: SW, height: SH } = Dimensions.get("window");
const CARD_H = SH;

type FeedTab = "feed" | "my" | "saved" | "analytics";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmtCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 60)  return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24)  return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

// ─── Video player ─────────────────────────────────────────────────────────────
// Web: uses native <video> element. Native: real expo-av playback (was previously
// a static thumbnail + non-functional play button — videos never actually played).

function VideoPlayer({ videoUrl, thumbnailUrl, isActive }: {
  videoUrl?: string | null;
  thumbnailUrl?: string | null;
  isActive: boolean;
}) {
  const colors = useColors();
  const [muted, setMuted] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    const player = videoRef.current;
    if (!player) return;
    if (isActive) {
      player.playAsync().catch(() => {});
    } else {
      player.pauseAsync().catch(() => {});
      player.setPositionAsync(0).catch(() => {});
    }
  }, [isActive]);

  if (Platform.OS === "web" && videoUrl) {
    return (React.createElement as any)("video", {
      src: videoUrl,
      poster: thumbnailUrl ?? undefined,
      autoPlay: isActive,
      loop: true,
      muted: true,
      playsInline: true,
      style: {
        position: "absolute", inset: 0,
        width: "100%", height: "100%",
        objectFit: "cover", display: "block",
      },
    });
  }

  if (!videoUrl) {
    return (
      <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.background }]}>
        {thumbnailUrl ? (
          <Image source={{ uri: thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <LinearGradient colors={["#0B2A3D", "#070C14", "#0C1524"]} style={StyleSheet.absoluteFill} />
        )}
        <View style={s.playOverlay}>
          <View style={s.playCircle}>
            <Feather name="play" size={28} color="#fff" />
          </View>
        </View>
      </View>
    );
  }

  return (
    <TouchableOpacity
      activeOpacity={1}
      style={StyleSheet.absoluteFill}
      onPress={() => setMuted((m) => !m)}
    >
      {!isLoaded && (
        thumbnailUrl ? (
          <Image source={{ uri: thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <LinearGradient colors={["#0B2A3D", "#070C14", "#0C1524"]} style={StyleSheet.absoluteFill} />
        )
      )}
      <Video
        ref={videoRef}
        source={{ uri: videoUrl }}
        style={StyleSheet.absoluteFill}
        resizeMode={ResizeMode.COVER}
        isLooping
        isMuted={muted}
        shouldPlay={isActive}
        onLoad={() => setIsLoaded(true)}
      />
      {muted && (
        <View style={s.muteBadge}>
          <Feather name="volume-x" size={14} color="#fff" />
        </View>
      )}
    </TouchableOpacity>
  );
}

// ─── Bounce-animated engagement button ────────────────────────────────────────

function EngageBtn({ icon, count, active, activeColor, onPress }: {
  icon: keyof typeof Feather.glyphMap;
  count?: number;
  active?: boolean;
  activeColor?: string;
  onPress: () => void;
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const press = () => {
    Animated.sequence([
      Animated.spring(scale, { toValue: 1.38, useNativeDriver: true, speed: 50 }),
      Animated.spring(scale, { toValue: 1,    useNativeDriver: true, speed: 50 }),
    ]).start();
    onPress();
  };
  return (
    <TouchableOpacity style={s.engageBtn} onPress={press} activeOpacity={0.75}>
      <Animated.View style={{ transform: [{ scale }] }}>
        <Feather name={icon} size={28} color={active ? (activeColor ?? "#12D9A0") : "#fff"} />
      </Animated.View>
      {count !== undefined && (
        <Text style={s.engageCount}>{fmtCount(count)}</Text>
      )}
    </TouchableOpacity>
  );
}

// ─── Comments sheet ───────────────────────────────────────────────────────────

function CommentsSheet({ visible, reelId, onClose }: {
  visible: boolean; reelId: string; onClose: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [text, setText] = useState("");

  const { data: comments, refetch } = useListReelComments(reelId);
  const postMut = usePostReelComment({
    mutation: { onSuccess: () => { setText(""); refetch(); } },
  });

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1 }}>
        <TouchableOpacity style={{ flex: 1 }} onPress={onClose} activeOpacity={1} />
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined}>
          <View style={[s.commentsPanel, { backgroundColor: colors.surface }]}>
            <View style={[s.handle, { backgroundColor: colors.border }]} />
            <Text style={[s.commentsTitle, { color: colors.text }]}>Comments</Text>

            <FlatList
              data={(comments ?? []) as ReelCommentRecord[]}
              keyExtractor={(c) => c.id}
              showsVerticalScrollIndicator={false}
              style={{ maxHeight: SH * 0.42 }}
              ListEmptyComponent={
                <Text style={[s.emptyText, { color: colors.textMuted }]}>No comments yet. Be first!</Text>
              }
              renderItem={({ item }) => (
                <View style={[s.commentRow, { borderBottomColor: colors.border }]}>
                  <View style={[s.commentAvatar, { backgroundColor: colors.primary + "33" }]}>
                    {item.userAvatarUrl
                      ? <Image source={{ uri: item.userAvatarUrl }} style={s.commentAvatarImg} />
                      : <Text style={[s.commentInitial, { color: colors.primary }]}>{(item.userFullName ?? "U")[0]}</Text>
                    }
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[s.commentName, { color: colors.text }]}>{item.userFullName ?? "User"}</Text>
                    <Text style={[s.commentContent, { color: colors.text }]}>{item.content}</Text>
                    <Text style={[s.commentTime, { color: colors.textMuted }]}>{timeAgo(item.createdAt)}</Text>
                  </View>
                </View>
              )}
            />

            <View style={[s.commentInputRow, { borderTopColor: colors.border, paddingBottom: Math.max(insets.bottom, 16) }]}>
              <TextInput
                style={[s.commentBox, { backgroundColor: colors.surfaceElevated, color: colors.text }]}
                placeholder="Add a comment…"
                placeholderTextColor={colors.textMuted}
                value={text}
                onChangeText={setText}
                multiline
                maxLength={1000}
              />
              <TouchableOpacity
                style={[s.sendBtn, { backgroundColor: colors.primary, opacity: text.trim() ? 1 : 0.4 }]}
                onPress={() => {
                  if (!text.trim()) return;
                  postMut.mutate({ id: reelId, data: { content: text.trim() } });
                }}
                disabled={!text.trim() || postMut.isPending}
              >
                <Feather name="send" size={16} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}

// ─── Report sheet ─────────────────────────────────────────────────────────────

const REPORT_REASONS = [
  "Spam or misleading", "Hate speech", "Violence or gore",
  "Misinformation", "Scam or fraud", "Inappropriate content", "Other",
];

function ReportSheet({ visible, reelId, onClose }: {
  visible: boolean; reelId: string; onClose: () => void;
}) {
  const colors = useColors();
  const reportMut = useReportReel({
    mutation: {
      onSuccess: () => { onClose(); Alert.alert("Reported", "Thanks for keeping CharLey safe."); },
    },
  });
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.7)" }}>
        <TouchableOpacity style={{ flex: 1 }} onPress={onClose} activeOpacity={1} />
        <View style={[s.reportSheet, { backgroundColor: colors.surface }]}>
          <View style={[s.handle, { backgroundColor: colors.border }]} />
          <Text style={[s.sheetTitle, { color: colors.text, marginBottom: 8 }]}>Report Reel</Text>
          {REPORT_REASONS.map((r) => (
            <TouchableOpacity
              key={r}
              style={[s.reportRow, { borderBottomColor: colors.border }]}
              onPress={() => reportMut.mutate({ id: reelId, data: { reason: r } })}
            >
              <Text style={[s.reportReason, { color: colors.text }]}>{r}</Text>
              <Feather name="chevron-right" size={16} color={colors.textMuted} />
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </Modal>
  );
}

// ─── Create reel sheet ────────────────────────────────────────────────────────

function CreateReelSheet({ visible, onClose, onCreated }: {
  visible: boolean; onClose: () => void; onCreated: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<"pick" | "details" | "uploading" | "done">("pick");
  const [mediaUri, setMediaUri] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [hashtags, setHashtags] = useState("");
  const [location, setLocation] = useState("");
  const [isMerchant, setIsMerchant] = useState(false);

  const createMut = useCreateReel({
    mutation: {
      onSuccess: () => { setStep("done"); setTimeout(() => { doClose(); onCreated(); }, 1500); },
      onError:   () => { Alert.alert("Error", "Failed to post. Try again."); setStep("details"); },
    },
  });

  const doClose = () => {
    setStep("pick"); setMediaUri(null);
    setCaption(""); setHashtags(""); setLocation(""); setIsMerchant(false);
    onClose();
  };

  const pickMedia = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) { Alert.alert("Permission needed", "Allow media access to upload a reel."); return; }
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["videos", "images"],
      allowsEditing: true,
      quality: 0.85,
    });
    if (!res.canceled && res.assets[0]) {
      setMediaUri(res.assets[0].uri);
      setStep("details");
    }
  };

  const handlePost = () => {
    setStep("uploading");
    const tags = hashtags.split(/[\s,#]+/).filter(Boolean).map((t) => t.toLowerCase());
    createMut.mutate({
      data: {
        caption: caption || undefined,
        hashtags: tags,
        location: location || undefined,
        isMerchant,
        thumbnailUrl: mediaUri ?? undefined,
        videoUrl:     mediaUri ?? undefined,
      },
    });
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={doClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.75)" }}>
        <TouchableOpacity style={{ flex: 0.12 }} onPress={doClose} activeOpacity={1} />
        <View style={[s.createSheet, { backgroundColor: colors.surface, paddingBottom: Math.max(insets.bottom + 16, 24) }]}>
          <View style={[s.handle, { backgroundColor: colors.border }]} />

          {step === "pick" && (
            <>
              <Text style={[s.sheetTitle, { color: colors.text }]}>Create Reel</Text>
              <Text style={[s.sheetSub, { color: colors.textMuted }]}>Share a moment with your community</Text>
              <TouchableOpacity
                style={[s.pickBtn, { backgroundColor: colors.primary }]}
                onPress={pickMedia}
                activeOpacity={0.85}
              >
                <Feather name="video" size={22} color="#fff" />
                <Text style={s.pickBtnText}>Pick from Library</Text>
              </TouchableOpacity>
            </>
          )}

          {step === "details" && (
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <Text style={[s.sheetTitle, { color: colors.text }]}>Add Details</Text>
              {mediaUri && (
                <View style={s.previewBox}>
                  <Image source={{ uri: mediaUri }} style={{ width: "100%", height: "100%" }} contentFit="cover" />
                  <View style={[s.previewBadge, { backgroundColor: colors.primary }]}>
                    <Feather name="play-circle" size={12} color="#fff" />
                    <Text style={s.previewBadgeText}>Selected</Text>
                  </View>
                </View>
              )}
              <Text style={[s.fieldLabel, { color: colors.textMuted }]}>CAPTION</Text>
              <TextInput
                style={[s.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="Write a caption…" placeholderTextColor={colors.textMuted}
                value={caption} onChangeText={setCaption} multiline maxLength={2200}
              />
              <Text style={[s.fieldLabel, { color: colors.textMuted }]}>HASHTAGS</Text>
              <TextInput
                style={[s.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="#ghana #fintech #savings" placeholderTextColor={colors.textMuted}
                value={hashtags} onChangeText={setHashtags}
              />
              <Text style={[s.fieldLabel, { color: colors.textMuted }]}>LOCATION</Text>
              <TextInput
                style={[s.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="Accra, Ghana" placeholderTextColor={colors.textMuted}
                value={location} onChangeText={setLocation}
              />
              <TouchableOpacity
                style={s.merchantToggleRow}
                onPress={() => setIsMerchant((p) => !p)}
                activeOpacity={0.8}
              >
                <View style={{ flex: 1 }}>
                  <Text style={[s.toggleLabel, { color: colors.text }]}>Merchant Reel</Text>
                  <Text style={[s.toggleSub, { color: colors.textMuted }]}>Tag products from your catalog</Text>
                </View>
                <View style={[s.pill, { backgroundColor: isMerchant ? colors.primary : colors.surfaceElevated }]}>
                  <View style={[s.pillThumb, { left: isMerchant ? 22 : 2 }]} />
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.postBtn, { backgroundColor: colors.primary, marginTop: 20, marginBottom: 8 }]}
                onPress={handlePost}
                activeOpacity={0.85}
              >
                <Feather name="upload-cloud" size={18} color="#fff" />
                <Text style={s.postBtnText}>Post Reel</Text>
              </TouchableOpacity>
            </ScrollView>
          )}

          {step === "uploading" && (
            <View style={s.centeredState}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[s.centeredStateText, { color: colors.textMuted }]}>Posting your reel…</Text>
            </View>
          )}

          {step === "done" && (
            <View style={s.centeredState}>
              <Feather name="check-circle" size={52} color="#4ADE80" />
              <Text style={[s.centeredStateText, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Reel Posted! 🎉</Text>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}

// ─── Analytics panel ──────────────────────────────────────────────────────────

function AnalyticsPanel() {
  const colors = useColors();
  const { data, isLoading } = useGetReelAnalytics();

  if (isLoading) return (
    <View style={[s.centered, { backgroundColor: colors.background }]}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  const stats = [
    { icon: "eye" as const,            label: "Views",     value: data?.totalViews    ?? 0 },
    { icon: "heart" as const,          label: "Likes",     value: data?.totalLikes    ?? 0 },
    { icon: "message-circle" as const, label: "Comments",  value: data?.totalComments ?? 0 },
    { icon: "share-2" as const,        label: "Shares",    value: data?.totalShares   ?? 0 },
    { icon: "bookmark" as const,       label: "Saves",     value: data?.totalSaves    ?? 0 },
    { icon: "users" as const,          label: "Followers", value: data?.followers     ?? 0 },
    { icon: "film" as const,           label: "Reels",     value: data?.reelCount     ?? 0 },
  ];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={s.analyticsContent}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[s.analyticsTitle, { color: colors.text }]}>Creator Analytics</Text>
      <Text style={[s.analyticsSub, { color: colors.textMuted }]}>Your overall reel performance</Text>
      <View style={s.statsGrid}>
        {stats.map((stat) => (
          <View key={stat.label} style={[s.statCard, { backgroundColor: colors.surface }]}>
            <View style={[s.statIcon, { backgroundColor: colors.primary + "22" }]}>
              <Feather name={stat.icon} size={20} color={colors.primary} />
            </View>
            <Text style={[s.statValue, { color: colors.text }]}>{fmtCount(stat.value)}</Text>
            <Text style={[s.statLabel, { color: colors.textMuted }]}>{stat.label}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

// ─── My Reels grid ────────────────────────────────────────────────────────────

function MyReelsGrid() {
  const colors = useColors();
  const { data, isLoading, refetch } = useListMyReels();
  const deleteMut = useDeleteReel({ mutation: { onSuccess: () => refetch() } });

  const handleDelete = (id: string) =>
    Alert.alert("Delete Reel", "Permanently delete this reel?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => deleteMut.mutate({ id }) },
    ]);

  if (isLoading) return (
    <View style={[s.centered, { backgroundColor: colors.background }]}>
      <ActivityIndicator color={colors.primary} />
    </View>
  );

  if (!data?.length) return (
    <View style={[s.emptyState, { backgroundColor: colors.background }]}>
      <Feather name="film" size={52} color={colors.textMuted} />
      <Text style={[s.emptyTitle, { color: colors.text }]}>No Reels Yet</Text>
      <Text style={[s.emptySub, { color: colors.textMuted }]}>Tap + Create to post your first reel</Text>
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={s.thumbGrid} showsVerticalScrollIndicator={false}>
      {data.map((reel) => (
        <TouchableOpacity
          key={reel.id}
          style={[s.thumbCard, { backgroundColor: colors.surfaceElevated }]}
          onLongPress={() => handleDelete(reel.id)}
          activeOpacity={0.8}
        >
          {reel.thumbnailUrl
            ? <Image source={{ uri: reel.thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
            : <LinearGradient colors={["#0B2A3D", "#070C14"]} style={StyleSheet.absoluteFill} />
          }
          <LinearGradient
            colors={["transparent", "rgba(0,0,0,0.75)"]}
            style={[StyleSheet.absoluteFill, { justifyContent: "flex-end", padding: 6 }]}
          >
            <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
              <Feather name="eye" size={10} color="#fff" />
              <Text style={{ color: "#fff", fontSize: 10 }}>{fmtCount(reel.viewCount)}</Text>
            </View>
          </LinearGradient>
          <View style={s.thumbPlay}>
            <Feather name="play" size={12} color="#fff" />
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

// ─── Saved grid ───────────────────────────────────────────────────────────────

function SavedGrid() {
  const colors = useColors();
  const { data, isLoading } = useListSavedReels();

  if (isLoading) return (
    <View style={[s.centered, { backgroundColor: colors.background }]}>
      <ActivityIndicator color={colors.primary} />
    </View>
  );

  if (!data?.length) return (
    <View style={[s.emptyState, { backgroundColor: colors.background }]}>
      <Feather name="bookmark" size={52} color={colors.textMuted} />
      <Text style={[s.emptyTitle, { color: colors.text }]}>No Saved Reels</Text>
      <Text style={[s.emptySub, { color: colors.textMuted }]}>Bookmark reels to watch later</Text>
    </View>
  );

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={s.thumbGrid} showsVerticalScrollIndicator={false}>
      {data.map((reel) => (
        <View key={reel.id} style={[s.thumbCard, { backgroundColor: colors.surfaceElevated }]}>
          {reel.thumbnailUrl
            ? <Image source={{ uri: reel.thumbnailUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
            : <LinearGradient colors={["#0B2A3D", "#070C14"]} style={StyleSheet.absoluteFill} />
          }
          <LinearGradient
            colors={["transparent", "rgba(0,0,0,0.75)"]}
            style={[StyleSheet.absoluteFill, { justifyContent: "flex-end", padding: 6 }]}
          >
            <Text style={{ color: "#fff", fontSize: 10 }} numberOfLines={1}>{reel.caption ?? ""}</Text>
          </LinearGradient>
        </View>
      ))}
    </ScrollView>
  );
}

// ─── Full-screen reel card ────────────────────────────────────────────────────

function ReelCard({ reel, isActive, onComments, onReport, onLike, onSave, onFollow, onShare }: {
  reel: ReelRecord;
  isActive: boolean;
  onComments: (id: string) => void;
  onReport:   (id: string) => void;
  onLike:     (id: string) => void;
  onSave:     (id: string) => void;
  onFollow:   (id: string, userId: string) => void;
  onShare:    (id: string) => void;
}) {
  const colors = useColors();
  const viewMut = useRecordReelView();

  useEffect(() => {
    if (!isActive) return;
    const t = setTimeout(() => viewMut.mutate({ id: reel.id }), 1200);
    return () => clearTimeout(t);
  }, [isActive, reel.id]);

  const initials = (reel.userFullName ?? reel.userPhone ?? "?")[0].toUpperCase();

  return (
    <View style={[s.card, { width: SW, height: CARD_H }]}>
      <VideoPlayer videoUrl={reel.videoUrl} thumbnailUrl={reel.thumbnailUrl ?? reel.coverImageUrl} isActive={isActive} />

      <LinearGradient colors={["rgba(0,0,0,0.55)", "transparent"]} style={s.topFade} pointerEvents="none" />
      <LinearGradient colors={["transparent", "rgba(0,0,0,0.9)"]} style={s.bottomFade} pointerEvents="none" />

      {/* Right engagement rail */}
      <View style={s.rail}>
        <EngageBtn icon="heart"           count={reel.likeCount}    active={reel.likedByMe}      activeColor="#F472B6"
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onLike(reel.id); }} />
        <EngageBtn icon="message-circle"  count={reel.commentCount}
          onPress={() => { Haptics.selectionAsync(); onComments(reel.id); }} />
        <EngageBtn icon="bookmark"        count={reel.saveCount}    active={reel.savedByMe}      activeColor="#F59E0B"
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onSave(reel.id); }} />
        <EngageBtn icon="share-2"         count={reel.shareCount}
          onPress={() => { Haptics.selectionAsync(); onShare(reel.id); }} />
        <EngageBtn icon="more-horizontal"
          onPress={() => { Haptics.selectionAsync(); onReport(reel.id); }} />
      </View>

      {/* Bottom creator + meta */}
      <View style={s.bottomMeta}>
        <View style={s.creatorRow}>
          <View style={[s.creatorAvatar, { backgroundColor: colors.primary + "44" }]}>
            {reel.userAvatarUrl
              ? <Image source={{ uri: reel.userAvatarUrl }} style={s.creatorAvatarImg} />
              : <Text style={s.creatorInitial}>{initials}</Text>
            }
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.creatorName} numberOfLines={1}>{reel.userFullName ?? reel.userPhone ?? "Unknown"}</Text>
            <Text style={s.creatorTime}>{timeAgo(reel.createdAt)}</Text>
          </View>
          {reel.userId && (
            <TouchableOpacity
              style={[
                s.followBtn,
                reel.followingCreator
                  ? { backgroundColor: "transparent", borderWidth: 1, borderColor: "rgba(255,255,255,0.4)" }
                  : { backgroundColor: colors.primary },
              ]}
              onPress={() => { Haptics.selectionAsync(); onFollow(reel.id, reel.userId!); }}
            >
              <Text style={s.followBtnLabel}>{reel.followingCreator ? "Following" : "Follow"}</Text>
            </TouchableOpacity>
          )}
        </View>

        {reel.caption    ? <Text style={s.caption}  numberOfLines={3}>{reel.caption}</Text> : null}
        {reel.hashtags?.length
          ? <Text style={[s.hashtags, { color: colors.primary }]} numberOfLines={1}>{reel.hashtags.map((h) => `#${h}`).join(" ")}</Text>
          : null
        }
        {reel.musicInfo  ? (
          <View style={s.infoRow}>
            <Feather name="music" size={11} color="rgba(255,255,255,0.65)" />
            <Text style={s.infoText}>{reel.musicInfo}</Text>
          </View>
        ) : null}
        {reel.location   ? (
          <View style={s.infoRow}>
            <Feather name="map-pin" size={11} color="rgba(255,255,255,0.55)" />
            <Text style={s.infoText}>{reel.location}</Text>
          </View>
        ) : null}
        {reel.isMerchant && (
          <View style={[s.merchantBadge, { backgroundColor: "#F59E0B22", borderColor: "#F59E0B44" }]}>
            <Feather name="shopping-bag" size={11} color="#F59E0B" />
            <Text style={[s.merchantBadgeText, { color: "#F59E0B" }]}>Merchant · Tap to shop</Text>
          </View>
        )}
      </View>
    </View>
  );
}

// ─── Feed (vertical paged FlatList) ──────────────────────────────────────────

function ReelsFeed() {
  const colors = useColors();
  const [activeIdx, setActiveIdx] = useState(0);
  const [commentsId, setCommentsId] = useState<string | null>(null);
  const [reportId,   setReportId]   = useState<string | null>(null);

  const { data, isLoading, refetch } = useListReels({ page: 1, limit: 20 });
  const likeMut   = useToggleReelLike();
  const saveMut   = useToggleReelSave();
  const followMut = useToggleReelFollow();
  const shareMut  = useShareReel();

  const reels: ReelRecord[] = (data as ReelRecord[] | undefined) ?? [];

  const onViewable = useCallback(({ viewableItems }: any) => {
    if (viewableItems.length > 0) setActiveIdx(viewableItems[0].index ?? 0);
  }, []);

  if (isLoading) return (
    <View style={[s.centered, { backgroundColor: colors.background }]}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );

  if (!reels.length) return (
    <View style={[s.emptyState, { backgroundColor: colors.background }]}>
      <LinearGradient colors={["#0B2A3D", "#070C14"]} style={StyleSheet.absoluteFill} />
      <Feather name="play-circle" size={68} color={colors.primary} />
      <Text style={[s.emptyTitle, { color: colors.text, marginTop: 16 }]}>No Reels Yet</Text>
      <Text style={[s.emptySub, { color: colors.textMuted, textAlign: "center", paddingHorizontal: 32 }]}>
        Be the first to share a moment with the CharLey community.
      </Text>
    </View>
  );

  return (
    <>
      <FlatList
        data={reels}
        keyExtractor={(r) => r.id}
        pagingEnabled
        snapToInterval={CARD_H}
        snapToAlignment="start"
        decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={onViewable}
        viewabilityConfig={{ viewAreaCoveragePercentThreshold: 60 }}
        onRefresh={refetch}
        refreshing={false}
        renderItem={({ item, index }) => (
          <ReelCard
            reel={item}
            isActive={index === activeIdx}
            onComments={setCommentsId}
            onReport={setReportId}
            onLike={(id) => likeMut.mutate({ id })}
            onSave={(id) => saveMut.mutate({ id })}
            onFollow={(_id, userId) => followMut.mutate({ userId })}
            onShare={(id) => shareMut.mutate({ id })}
          />
        )}
      />
      {commentsId && <CommentsSheet visible reelId={commentsId} onClose={() => setCommentsId(null)} />}
      {reportId   && <ReportSheet   visible reelId={reportId}   onClose={() => setReportId(null)}   />}
    </>
  );
}

// ─── Root screen ──────────────────────────────────────────────────────────────

export default function MarketScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [tab, setTab]           = useState<FeedTab>("feed");
  const [showCreate, setCreate] = useState(false);
  const { refetch: refetchFeed } = useListReels({ page: 1, limit: 20 });

  const TABS: { key: FeedTab; label: string }[] = [
    { key: "feed",      label: "Feed"      },
    { key: "my",        label: "My Reels"  },
    { key: "saved",     label: "Saved"     },
    { key: "analytics", label: "Analytics" },
  ];

  return (
    <View style={[s.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[s.header, { paddingTop: insets.top + 6 }]}>
        <Text style={[s.headerTitle, { color: colors.text }]}>Reels</Text>
        <View style={s.headerRight}>
          <TouchableOpacity style={s.iconBtn} activeOpacity={0.7}>
            <Feather name="search" size={20} color={colors.text} />
          </TouchableOpacity>
          <TouchableOpacity
            style={[s.createBtn, { backgroundColor: colors.primary }]}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setCreate(true); }}
            activeOpacity={0.85}
          >
            <Feather name="plus" size={16} color="#fff" />
            <Text style={s.createBtnText}>Create</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Sub-tabs (hidden on feed — overlay used instead) */}
      {tab !== "feed" && (
        <View style={[s.tabBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          {TABS.map((t) => (
            <TouchableOpacity
              key={t.key}
              style={[s.tabItem, tab === t.key && { borderBottomWidth: 2, borderBottomColor: colors.primary }]}
              onPress={() => setTab(t.key)}
            >
              <Text style={[s.tabLabel, { color: tab === t.key ? colors.primary : colors.textMuted }]}>
                {t.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <View style={{ flex: 1 }}>
        {tab === "feed" && (
          <View style={StyleSheet.absoluteFill}>
            <ReelsFeed />
            {/* Floating tab pills over the feed */}
            <View style={s.feedTabsOverlay}>
              {TABS.map((t) => (
                <TouchableOpacity key={t.key} style={s.feedTabPill} onPress={() => setTab(t.key)}>
                  <Text style={[s.feedTabText, tab === t.key ? s.feedTabActive : s.feedTabInactive]}>
                    {t.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
        {tab === "my"        && <MyReelsGrid />}
        {tab === "saved"     && <SavedGrid />}
        {tab === "analytics" && <AnalyticsPanel />}
      </View>

      <CreateReelSheet
        visible={showCreate}
        onClose={() => setCreate(false)}
        onCreated={() => refetchFeed()}
      />
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  screen: { flex: 1 },

  // Header
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 8, zIndex: 20,
  },
  headerTitle: { fontSize: 24, fontFamily: "Inter_700Bold", letterSpacing: -0.5 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 10 },
  iconBtn: { padding: 6 },
  createBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
  },
  createBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },

  // Tab bar (non-feed tabs)
  tabBar: { flexDirection: "row", borderBottomWidth: 1, zIndex: 10 },
  tabItem: { flex: 1, alignItems: "center", paddingVertical: 10 },
  tabLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },

  // Feed overlay tabs
  feedTabsOverlay: {
    position: "absolute", top: 0, left: 0, right: 0,
    flexDirection: "row", paddingHorizontal: 12, paddingVertical: 8,
    zIndex: 30, gap: 4,
  },
  feedTabPill: { paddingHorizontal: 4, paddingVertical: 6 },
  feedTabText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  feedTabActive: { color: "#fff" },
  feedTabInactive: { color: "rgba(255,255,255,0.45)" },

  // Reel card
  card: { overflow: "hidden", backgroundColor: "#070C14" },
  topFade: { position: "absolute", top: 0, left: 0, right: 0, height: 130, zIndex: 5 },
  bottomFade: { position: "absolute", bottom: 0, left: 0, right: 0, height: 300, zIndex: 5 },

  // Play overlay
  playOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: "center", alignItems: "center", zIndex: 3 },
  playCircle: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "center", alignItems: "center",
    borderWidth: 2, borderColor: "rgba(255,255,255,0.4)",
  },
  muteBadge: {
    position: "absolute", top: 16, right: 16, zIndex: 4,
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center", alignItems: "center",
  },

  // Engagement rail
  rail: { position: "absolute", right: 12, bottom: 200, zIndex: 20, gap: 4 },
  engageBtn: { alignItems: "center", paddingVertical: 8 },
  engageCount: {
    color: "#fff", fontSize: 12, fontFamily: "Inter_600SemiBold",
    textAlign: "center", marginTop: 2,
    textShadowColor: "rgba(0,0,0,0.9)", textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3,
  },

  // Bottom meta
  bottomMeta: { position: "absolute", left: 0, right: 74, bottom: 90, paddingHorizontal: 16, zIndex: 20 },
  creatorRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 8 },
  creatorAvatar: {
    width: 42, height: 42, borderRadius: 21,
    justifyContent: "center", alignItems: "center", overflow: "hidden",
  },
  creatorAvatarImg: { width: 42, height: 42, borderRadius: 21 },
  creatorInitial: { color: "#fff", fontSize: 17, fontFamily: "Inter_700Bold" },
  creatorName: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  creatorTime: { color: "rgba(255,255,255,0.55)", fontSize: 11 },
  followBtn: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16 },
  followBtnLabel: { color: "#fff", fontSize: 13, fontFamily: "Inter_600SemiBold" },

  caption: {
    color: "#fff", fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 20, marginBottom: 4,
    textShadowColor: "rgba(0,0,0,0.6)", textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 2,
  },
  hashtags: { fontSize: 13, fontFamily: "Inter_500Medium", marginBottom: 4 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 3 },
  infoText: { color: "rgba(255,255,255,0.6)", fontSize: 12 },
  merchantBadge: {
    alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: 10, borderWidth: 1, marginTop: 6,
  },
  merchantBadgeText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },

  // Comments
  commentsPanel: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 8, paddingHorizontal: 16 },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 12, marginTop: 4 },
  commentsTitle: { fontSize: 17, fontFamily: "Inter_700Bold", textAlign: "center", marginBottom: 12 },
  commentRow: { flexDirection: "row", gap: 10, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  commentAvatar: {
    width: 34, height: 34, borderRadius: 17,
    justifyContent: "center", alignItems: "center", overflow: "hidden",
  },
  commentAvatarImg: { width: 34, height: 34, borderRadius: 17 },
  commentInitial: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  commentName: { fontSize: 13, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  commentContent: { fontSize: 13, lineHeight: 18 },
  commentTime: { fontSize: 11, marginTop: 3 },
  commentInputRow: {
    flexDirection: "row", gap: 10, alignItems: "flex-end",
    paddingTop: 12, borderTopWidth: 1,
  },
  commentBox: { flex: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, maxHeight: 100 },
  sendBtn: { width: 40, height: 40, borderRadius: 20, justifyContent: "center", alignItems: "center" },
  emptyText: { textAlign: "center", padding: 24, fontSize: 14 },

  // Report
  reportSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingTop: 8, paddingHorizontal: 20, paddingBottom: 40 },
  reportRow: {
    flexDirection: "row", justifyContent: "space-between", alignItems: "center",
    paddingVertical: 16, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  reportReason: { fontSize: 15 },

  // Create sheet
  createSheet: {
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    paddingTop: 8, paddingHorizontal: 20, maxHeight: SH * 0.9,
  },
  sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", marginBottom: 4 },
  sheetSub: { fontSize: 14, marginBottom: 20 },
  pickBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 10, paddingVertical: 18, borderRadius: 16, marginTop: 8,
  },
  pickBtnText: { color: "#fff", fontSize: 16, fontFamily: "Inter_600SemiBold" },
  previewBox: { width: "100%", height: 160, borderRadius: 14, overflow: "hidden", marginBottom: 16, position: "relative" },
  previewBadge: {
    position: "absolute", bottom: 8, left: 8,
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
  },
  previewBadgeText: { color: "#fff", fontSize: 11 },
  fieldLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 0.8, marginBottom: 6, marginTop: 14 },
  fieldInput: { borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, borderWidth: 1 },
  merchantToggleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 18 },
  toggleLabel: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  toggleSub: { fontSize: 12, marginTop: 2 },
  pill: { width: 48, height: 28, borderRadius: 14, position: "relative" },
  pillThumb: { position: "absolute", top: 4, width: 20, height: 20, borderRadius: 10, backgroundColor: "#fff" },
  postBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 10, paddingVertical: 16, borderRadius: 16,
  },
  postBtnText: { color: "#fff", fontSize: 16, fontFamily: "Inter_600SemiBold" },
  centeredState: { alignItems: "center", justifyContent: "center", paddingVertical: 52, gap: 16 },
  centeredStateText: { fontSize: 16 },

  // Analytics
  analyticsContent: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 60 },
  analyticsTitle: { fontSize: 22, fontFamily: "Inter_700Bold", marginBottom: 4 },
  analyticsSub: { fontSize: 13, marginBottom: 20 },
  statsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  statCard: { width: (SW - 44) / 2, borderRadius: 16, padding: 16 },
  statIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: "center", alignItems: "center", marginBottom: 10 },
  statValue: { fontSize: 28, fontFamily: "Inter_700Bold" },
  statLabel: { fontSize: 13, marginTop: 2 },

  // Grids
  thumbGrid: { flexDirection: "row", flexWrap: "wrap", gap: 2, padding: 2, paddingBottom: 120 },
  thumbCard: { width: (SW - 8) / 3, height: ((SW - 8) / 3) * 1.4, borderRadius: 4, overflow: "hidden" },
  thumbPlay: {
    position: "absolute", top: 6, right: 6,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center", alignItems: "center",
  },

  // Shared empty/centered
  centered: { flex: 1, justifyContent: "center", alignItems: "center" },
  emptyState: { flex: 1, justifyContent: "center", alignItems: "center", gap: 8, padding: 24 },
  emptyTitle: { fontSize: 20, fontFamily: "Inter_700Bold", marginTop: 8 },
  emptySub: { fontSize: 14 },
});
