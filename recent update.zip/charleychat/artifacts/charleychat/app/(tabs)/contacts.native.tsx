import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Linking,
  Platform,
  RefreshControl,
  Share,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { customFetch } from "@workspace/api-client-react";

import { useColors } from "@/hooks/useColors";

const CHARLEY_INVITE_LINK = "https://charleychat.app/join";

interface CharleyUser {
  id: string;
  phone: string;
  fullName: string;
  username?: string;
  avatar?: string;
  avatarUrl?: string;
  fpId?: string;
  isKycVerified?: boolean;
}

interface DeviceContact {
  name: string;
  phone: string;
  rawPhone: string;
  charleyUser?: CharleyUser;
  isFavorite?: boolean;
  contactId?: string;
}

function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.startsWith("233") && digits.length >= 12) return "0" + digits.slice(3);
  if (digits.startsWith("0") && digits.length === 10) return digits;
  if (digits.length === 9) return "0" + digits;
  return digits;
}

type TabId = "contacts" | "discover" | "favorites";

// ─── Avatar helper ─────────────────────────────────────────────────────────

const AVATAR_COLORS = ["#12D9A0", "#3B82F6", "#10B981", "#F59E0B", "#EC4899", "#F97316"];

function getAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

function Avatar({ name, uri, size = 44 }: { name: string; uri?: string; size?: number }) {
  const initials = name.split(" ").filter(Boolean).map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const color = getAvatarColor(name);
  if (uri) {
    return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  }
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: "center", justifyContent: "center", backgroundColor: color + "22" }}>
      <Text style={{ fontSize: size * 0.36, color, fontFamily: "Inter_700Bold" }}>{initials}</Text>
    </View>
  );
}

// ─── Discover row ──────────────────────────────────────────────────────────

function DiscoverRow({ user, colors, onChat, onPay }: {
  user: CharleyUser;
  colors: ReturnType<typeof useColors>;
  onChat: () => void;
  onPay: () => void;
}) {
  return (
    <View style={[dStyles.row]}>
      <Avatar name={user.fullName} uri={user.avatarUrl ?? user.avatar} size={46} />
      <View style={dStyles.info}>
        <View style={dStyles.nameRow}>
          <Text style={[dStyles.name, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>
            {user.fullName}
          </Text>
          {user.isKycVerified && (
            <Feather name="check-circle" size={13} color={colors.primary} />
          )}
        </View>
        <Text style={[dStyles.handle, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
          @{user.username ?? user.fpId ?? "charleyuser"}
        </Text>
      </View>
      <View style={dStyles.actions}>
        <TouchableOpacity
          style={[dStyles.btn, { backgroundColor: colors.primary + "18" }]}
          onPress={onChat}
          activeOpacity={0.7}
        >
          <Feather name="message-circle" size={16} color={colors.primary} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[dStyles.btn, { backgroundColor: "#10B98118" }]}
          onPress={onPay}
          activeOpacity={0.7}
        >
          <Feather name="send" size={15} color="#10B981" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const dStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, gap: 12 },
  info: { flex: 1, gap: 2 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  name: { fontSize: 15, flexShrink: 1 },
  handle: { fontSize: 12 },
  actions: { flexDirection: "row", gap: 6 },
  btn: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
});

// ─── Main screen ──────────────────────────────────────────────────────────

export default function ContactsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [tab, setTab] = useState<TabId>("contacts");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [allContacts, setAllContacts] = useState<DeviceContact[]>([]);
  const [savedFavorites, setSavedFavorites] = useState<Set<string>>(new Set());
  const [favoriteContactIds, setFavoriteContactIds] = useState<Map<string, string>>(new Map());

  // Discover state
  const [discoverUsers, setDiscoverUsers] = useState<CharleyUser[]>([]);
  const [discoverLoading, setDiscoverLoading] = useState(false);
  const [discoverQuery, setDiscoverQuery] = useState("");
  const [discoverPage, setDiscoverPage] = useState(1);
  const [discoverTotal, setDiscoverTotal] = useState(0);
  const [discoverRefreshing, setDiscoverRefreshing] = useState(false);
  const discoverQueryTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const PAGE_SIZE = 20;

  const topPad = Platform.OS === "web" ? 0 : insets.top;
  const botPad = Math.max(insets.bottom, 16);

  // ── Contacts (saved via API) ──────────────────────────────────────────────

  const loadContacts = useCallback(async () => {
    setLoading(true);
    try {
      type SavedContact = { id: string; contactUserId: string; isFavorite: boolean; contactPhone: string; contactName: string; contactAvatar?: string; };
      const savedContacts = await customFetch<SavedContact[]>("/api/contacts");

      const favSet = new Set<string>();
      const favIdMap = new Map<string, string>();
      for (const sc of savedContacts) {
        favIdMap.set(sc.contactPhone, sc.id);
        if (sc.isFavorite) favSet.add(sc.contactPhone);
      }
      setSavedFavorites(favSet);
      setFavoriteContactIds(favIdMap);

      const mapped: DeviceContact[] = savedContacts.map(sc => ({
        name: sc.contactName,
        phone: sc.contactPhone,
        rawPhone: sc.contactPhone,
        charleyUser: { id: sc.contactUserId, phone: sc.contactPhone, fullName: sc.contactName, avatarUrl: sc.contactAvatar },
        isFavorite: sc.isFavorite,
        contactId: sc.id,
      }));

      setAllContacts(mapped);
    } catch {
      Alert.alert("Error", "Could not load contacts.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadContacts(); }, []);
  const onRefreshContacts = () => { setRefreshing(true); loadContacts(); };

  // ── Discover ─────────────────────────────────────────────────────────────

  const loadDiscover = useCallback(async (q: string, page: number, append = false) => {
    if (page === 1) setDiscoverLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(PAGE_SIZE) });
      if (q.trim()) params.set("q", q.trim());
      const data = await customFetch<{ users: CharleyUser[]; total: number; page: number }>(`/api/users/discover?${params}`);
      setDiscoverTotal(data.total);
      setDiscoverUsers(prev => append ? [...prev, ...data.users] : data.users);
    } catch { /* ignore */ }
    finally { setDiscoverLoading(false); setDiscoverRefreshing(false); }
  }, []);

  useEffect(() => {
    if (tab === "discover") loadDiscover(discoverQuery, 1);
  }, [tab]);

  const handleDiscoverQueryChange = (q: string) => {
    setDiscoverQuery(q);
    setDiscoverPage(1);
    if (discoverQueryTimer.current) clearTimeout(discoverQueryTimer.current);
    discoverQueryTimer.current = setTimeout(() => loadDiscover(q, 1), 350);
  };

  const loadMoreDiscover = () => {
    if (discoverUsers.length >= discoverTotal) return;
    const next = discoverPage + 1;
    setDiscoverPage(next);
    loadDiscover(discoverQuery, next, true);
  };

  const onRefreshDiscover = () => {
    setDiscoverRefreshing(true);
    setDiscoverPage(1);
    loadDiscover(discoverQuery, 1);
  };

  // ── Favorites / contacts filtering ───────────────────────────────────────

  const toggleFavorite = async (contact: DeviceContact) => {
    if (!contact.charleyUser) return;
    try {
      const existingId = favoriteContactIds.get(contact.phone);
      if (existingId) {
        await customFetch<unknown>(`/api/contacts/${existingId}/favorite`, { method: "PATCH" });
        setSavedFavorites(prev => {
          const next = new Set(prev);
          if (next.has(contact.phone)) next.delete(contact.phone); else next.add(contact.phone);
          return next;
        });
        setAllContacts(prev => prev.map(c => c.phone === contact.phone ? { ...c, isFavorite: !c.isFavorite } : c));
      } else {
        const added = await customFetch<{ id: string }>("/api/contacts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ phone: contact.phone }),
        });
        setFavoriteContactIds(prev => new Map(prev).set(contact.phone, added.id));
        await customFetch<unknown>(`/api/contacts/${added.id}/favorite`, { method: "PATCH" });
        setSavedFavorites(prev => new Set(prev).add(contact.phone));
        setAllContacts(prev => prev.map(c => c.phone === contact.phone ? { ...c, isFavorite: true, contactId: added.id } : c));
      }
    } catch { Alert.alert("Error", "Could not update favorite."); }
  };

  const sendInvite = async (contact: DeviceContact) => {
    const msg = `Hey ${contact.name}! Join me on CharLey — send and receive money instantly. Download now: ${CHARLEY_INVITE_LINK}`;
    try {
      const canSMS = await Linking.canOpenURL(`sms:${contact.rawPhone}`);
      if (canSMS) await Linking.openURL(`sms:${contact.rawPhone}?body=${encodeURIComponent(msg)}`);
      else await Share.share({ message: msg });
    } catch { await Share.share({ message: msg }); }
  };

  const filteredContacts = allContacts.filter(c => {
    const q = query.toLowerCase();
    const match = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q);
    if (!match) return false;
    if (tab === "contacts") return !!c.charleyUser;
    if (tab === "favorites") return c.isFavorite;
    return false;
  });

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Contacts</Text>
      </View>

      {/* Search bar (contacts/favorites tabs) */}
      {tab !== "discover" && (
        <View style={[styles.searchBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={[styles.searchInput, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
            <Feather name="search" size={16} color={colors.textMuted} />
            <TextInput
              style={[styles.searchText, { color: colors.text, fontFamily: "Inter_400Regular" }]}
              placeholder="Search contacts…"
              placeholderTextColor={colors.textMuted}
              value={query}
              onChangeText={setQuery}
              returnKeyType="search"
            />
            {query.length > 0 && (
              <TouchableOpacity onPress={() => setQuery("")}><Feather name="x" size={14} color={colors.textMuted} /></TouchableOpacity>
            )}
          </View>
        </View>
      )}

      {/* Tabs */}
      <TabBar tab={tab} onTab={t => { setTab(t); setQuery(""); }} colors={colors} />

      {/* ── Discover tab ────────────────────────────────────────────────── */}
      {tab === "discover" && (
        <View style={{ flex: 1 }}>
          {/* Discover search */}
          <View style={[styles.searchBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
            <View style={[styles.searchInput, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
              <Feather name="search" size={16} color={colors.textMuted} />
              <TextInput
                style={[styles.searchText, { color: colors.text, fontFamily: "Inter_400Regular" }]}
                placeholder="Search by name or @username…"
                placeholderTextColor={colors.textMuted}
                value={discoverQuery}
                onChangeText={handleDiscoverQueryChange}
                returnKeyType="search"
                autoCorrect={false}
                autoCapitalize="none"
              />
              {discoverQuery.length > 0 && (
                <TouchableOpacity onPress={() => handleDiscoverQueryChange("")}>
                  <Feather name="x" size={14} color={colors.textMuted} />
                </TouchableOpacity>
              )}
            </View>
          </View>

          {/* User count badge */}
          {!discoverLoading && discoverTotal > 0 && (
            <View style={[styles.countBadge, { backgroundColor: colors.surfaceElevated }]}>
              <Text style={[styles.countText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                {discoverTotal} {discoverTotal === 1 ? "person" : "people"} on CharLey
                {discoverQuery ? ` matching "${discoverQuery}"` : ""}
              </Text>
            </View>
          )}

          {discoverLoading && discoverUsers.length === 0 ? (
            <View style={styles.loadingState}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.loadingText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Finding people…</Text>
            </View>
          ) : discoverUsers.length === 0 ? (
            <View style={styles.emptyState}>
              <Feather name="search" size={40} color={colors.textMuted} />
              <Text style={[styles.emptyTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                {discoverQuery ? "No users found" : "No users yet"}
              </Text>
              <Text style={[styles.emptySub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                {discoverQuery ? `Nobody matching "${discoverQuery}"` : "Be the first to invite friends!"}
              </Text>
            </View>
          ) : (
            <FlatList
              data={discoverUsers}
              keyExtractor={item => item.id}
              contentContainerStyle={{ paddingBottom: botPad }}
              refreshControl={<RefreshControl refreshing={discoverRefreshing} onRefresh={onRefreshDiscover} tintColor={colors.primary} />}
              renderItem={({ item }) => (
                <DiscoverRow
                  user={item}
                  colors={colors}
                  onChat={() => router.push(`/chat/${item.id}` as never)}
                  onPay={() => router.push({ pathname: "/pay", params: { recipientPhone: item.phone, recipientName: item.fullName } } as never)}
                />
              )}
              ItemSeparatorComponent={() => <View style={[styles.separator, { backgroundColor: colors.border }]} />}
              onEndReached={loadMoreDiscover}
              onEndReachedThreshold={0.3}
              ListFooterComponent={discoverUsers.length < discoverTotal ? (
                <View style={{ padding: 20, alignItems: "center" }}>
                  <ActivityIndicator size="small" color={colors.primary} />
                </View>
              ) : null}
            />
          )}
        </View>
      )}

      {/* ── Contacts / Favorites tabs ────────────────────────────────────── */}
      {tab !== "discover" && (
        <>
          {loading && allContacts.length === 0 ? (
            <View style={styles.loadingState}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={[styles.loadingText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Syncing contacts…</Text>
            </View>
          ) : filteredContacts.length === 0 ? (
            <View style={styles.emptyState}>
              <Feather name={tab === "favorites" ? "star" : "users"} size={40} color={colors.textMuted} />
              <Text style={[styles.emptyTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                {tab === "favorites" ? "No favorites yet" : "No contacts yet"}
              </Text>
              <Text style={[styles.emptySub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                {tab === "favorites"
                  ? "Star a contact to add them here."
                  : "Go to the Discover tab to find people and add them as contacts."}
              </Text>
            </View>
          ) : (
            <FlatList
              data={filteredContacts}
              keyExtractor={item => item.phone}
              contentContainerStyle={[styles.list, { paddingBottom: botPad }]}
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefreshContacts} tintColor={colors.primary} />}
              renderItem={({ item }) => (
                <ContactRow
                  contact={item}
                  colors={colors}
                  onFavorite={() => toggleFavorite(item)}
                  onChat={item.charleyUser ? () => router.push(`/chat/${item.charleyUser!.id}` as never) : undefined}
                  onSendMoney={item.charleyUser
                    ? () => router.push({ pathname: "/pay", params: { recipientPhone: item.phone, recipientName: item.name } } as never)
                    : undefined}
                  onInvite={!item.charleyUser ? () => sendInvite(item) : undefined}
                />
              )}
              ItemSeparatorComponent={() => <View style={[styles.separator, { backgroundColor: colors.border }]} />}
            />
          )}
        </>
      )}
    </View>
  );
}

// ─── Tab bar ────────────────────────────────────────────────────────────────

function TabBar({ tab, onTab, colors }: { tab: TabId; onTab: (t: TabId) => void; colors: ReturnType<typeof useColors> }) {
  const tabs: { id: TabId; label: string; icon: string }[] = [
    { id: "contacts", label: "Contacts",  icon: "book"   },
    { id: "discover", label: "Discover",  icon: "globe"  },
    { id: "favorites",label: "Favorites", icon: "star"   },
  ];
  return (
    <View style={[styles.tabs, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
      {tabs.map(t => {
        const active = tab === t.id;
        return (
          <TouchableOpacity key={t.id} style={[styles.tabBtn, active && { borderBottomColor: colors.primary, borderBottomWidth: 2 }]} onPress={() => onTab(t.id)}>
            <Feather name={t.icon as any} size={14} color={active ? colors.primary : colors.textMuted} />
            <Text style={[styles.tabLabel, { color: active ? colors.primary : colors.textMuted, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ─── Contact row (address book) ─────────────────────────────────────────────

function ContactRow({ contact, colors, onFavorite, onChat, onSendMoney, onInvite }: {
  contact: DeviceContact;
  colors: ReturnType<typeof useColors>;
  onFavorite?: () => void;
  onChat?: () => void;
  onSendMoney?: () => void;
  onInvite?: () => void;
}) {
  const isCharley = !!contact.charleyUser;
  return (
    <View style={styles.contactRow}>
      <Avatar name={contact.name} uri={contact.charleyUser?.avatar ?? contact.charleyUser?.avatarUrl} size={44} />
      <View style={styles.contactInfo}>
        <View style={styles.nameRow}>
          <Text style={[styles.contactName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>
            {contact.name}
          </Text>
          {isCharley && (
            <View style={[styles.charleyBadge, { backgroundColor: colors.primary + "18" }]}>
              <Feather name="check-circle" size={10} color={colors.primary} />
              <Text style={[styles.charleyBadgeText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>CharLey</Text>
            </View>
          )}
        </View>
        <Text style={[styles.contactPhone, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
          {contact.charleyUser?.username ? `@${contact.charleyUser.username}  ·  ` : ""}{contact.phone}
        </Text>
      </View>
      <View style={styles.contactActions}>
        {isCharley ? (
          <>
            <TouchableOpacity onPress={onFavorite} style={styles.iconBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Feather name="star" size={18} color={contact.isFavorite ? "#F59E0B" : colors.textMuted} />
            </TouchableOpacity>
            {onChat && (
              <TouchableOpacity onPress={onChat} style={[styles.iconBtn, { backgroundColor: colors.primary + "18", borderRadius: 8, padding: 6 }]}>
                <Feather name="message-circle" size={16} color={colors.primary} />
              </TouchableOpacity>
            )}
            {onSendMoney && (
              <TouchableOpacity onPress={onSendMoney} style={[styles.iconBtn, { backgroundColor: "#10B98118", borderRadius: 8, padding: 6 }]}>
                <Feather name="send" size={16} color="#10B981" />
              </TouchableOpacity>
            )}
          </>
        ) : (
          <TouchableOpacity onPress={onInvite} style={[styles.inviteBtn, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
            <Text style={[styles.inviteBtnText, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Invite</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  header:       { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  headerTitle:  { fontSize: 24 },
  searchBar:    { paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  searchInput:  { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, borderWidth: 1 },
  searchText:   { flex: 1, fontSize: 14 },
  tabs:         { flexDirection: "row", borderBottomWidth: StyleSheet.hairlineWidth },
  tabBtn:       { flex: 1, paddingVertical: 10, alignItems: "center", gap: 3, flexDirection: "row", justifyContent: "center" },
  tabLabel:     { fontSize: 12 },
  countBadge:   { marginHorizontal: 16, marginTop: 10, marginBottom: 2, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, alignSelf: "flex-start" },
  countText:    { fontSize: 12 },
  list:         { paddingTop: 4 },
  contactRow:   { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  contactInfo:  { flex: 1, gap: 2 },
  nameRow:      { flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" },
  contactName:  { fontSize: 15 },
  charleyBadge: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  charleyBadgeText: { fontSize: 10 },
  contactPhone: { fontSize: 12 },
  contactActions: { flexDirection: "row", alignItems: "center", gap: 4 },
  iconBtn:      { padding: 4 },
  inviteBtn:    { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1 },
  inviteBtnText:{ fontSize: 12 },
  separator:    { height: StyleSheet.hairlineWidth, marginLeft: 72 },
  loadingState: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  loadingText:  { fontSize: 14 },
  emptyState:   { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, gap: 12 },
  emptyTitle:   { fontSize: 18, textAlign: "center" },
  emptySub:     { fontSize: 14, textAlign: "center", lineHeight: 21, maxWidth: 280 },
  actionBtn:    { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  actionBtnText:{ color: "#fff", fontSize: 15 },
});
