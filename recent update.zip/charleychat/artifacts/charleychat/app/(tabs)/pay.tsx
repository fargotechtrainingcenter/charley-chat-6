import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  Animated,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { searchUsers } from "@workspace/api-client-react";

import { Card, Divider, EscrowRow, SectionHeader } from "@/components/FargoComponents";
import { PinConfirmModal } from "@/components/PinConfirmModal";
import { Escrow, PayLink, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { calculateFee, FeeBreakdown, fmtFee } from "@/utils/feeEngine";

// ─── Constants ────────────────────────────────────────────────────────────────

const TONE_MAP: Record<Escrow["status"], "indigo" | "success" | "warning" | "danger"> = {
  "In Escrow":       "indigo",
  "Completed":       "success",
  "Pending Release": "warning",
  "Disputed":        "danger",
};

const AVATAR_COLORS = ["#12D9A0", "#F59E0B", "#EC4899", "#10B981", "#3B82F6", "#F97316"];

const NETWORKS = [
  {
    id: "mtn",
    name: "MTN MoMo",
    short: "MTN",
    color: "#FFCC00",
    textColor: "#1A1A1A",
    prefixes: ["024", "054", "055", "059", "025"],
  },
  {
    id: "airteltigo",
    name: "AirtelTigo",
    short: "Tigo",
    color: "#E4002B",
    textColor: "#fff",
    prefixes: ["026", "056", "027", "057"],
  },
  {
    id: "telecel",
    name: "Telecel",
    short: "TEL",
    color: "#C0392B",
    textColor: "#fff",
    prefixes: ["020", "050", "030"],
  },
];

function lookupName(_phone: string): string {
  return "";
}
function detectNetwork(phone: string) {
  const clean = phone.replace(/\s/g, "");
  for (const net of NETWORKS) {
    if (net.prefixes.some((p) => clean.startsWith(p))) return net;
  }
  return null;
}

// ─── CharLey user lookup + recipient types ────────────────────────────────────

interface FPUser {
  name: string;
  verified: boolean;
  userId: string;
  avatarColor: string;
}


const BANKS = [
  "GCB Bank", "Ecobank Ghana", "Absa Ghana", "Fidelity Bank",
  "Standard Chartered", "Zenith Bank", "Stanbic Bank", "CalBank",
  "UBA Ghana", "Access Bank Ghana", "GT Bank Ghana", "Prudential Bank",
];

type RecipientType = "charley" | "mtn" | "telecel" | "airteltigo" | "bank" | "phone" | "email";

const RECIPIENT_TYPES: Array<{
  id: RecipientType;
  label: string;
  sub: string;
  icon: React.ComponentProps<typeof Feather>["name"];
  bg: string;
  fg: string;
}> = [
  { id: "charley",    label: "CharLey User",   sub: "Instant · Free",    icon: "shield",      bg: "#12D9A0", fg: "#fff"    },
  { id: "mtn",        label: "MTN MoMo",        sub: "Mobile money",      icon: "smartphone",  bg: "#FFCC00", fg: "#1A1A1A" },
  { id: "telecel",    label: "Telecel Cash",     sub: "Mobile money",      icon: "smartphone",  bg: "#C0392B", fg: "#fff"    },
  { id: "airteltigo", label: "AirtelTigo",       sub: "Mobile money",      icon: "smartphone",  bg: "#E4002B", fg: "#fff"    },
  { id: "bank",       label: "Bank Account",     sub: "Ghanaian banks",    icon: "credit-card", bg: "#2980B9", fg: "#fff"    },
  { id: "phone",      label: "Phone Number",     sub: "Any phone number",  icon: "phone",       bg: "#27AE60", fg: "#fff"    },
  { id: "email",      label: "Email Address",    sub: "Send via email",    icon: "mail",        bg: "#8E44AD", fg: "#fff"    },
];

function avatarColorFor(name: string): string {
  return AVATAR_COLORS[name.charCodeAt(0) % AVATAR_COLORS.length];
}

// ─── Toast notification ───────────────────────────────────────────────────────

function Toast({ visible, message, sub }: { visible: boolean; message: string; sub: string }) {
  const anim = useRef(new Animated.Value(-80)).current;
  useEffect(() => {
    if (visible) {
      Animated.spring(anim, { toValue: 0, useNativeDriver: true, friction: 8 }).start();
      const t = setTimeout(() => {
        Animated.timing(anim, { toValue: -80, useNativeDriver: true, duration: 300 }).start();
      }, 3500);
      return () => clearTimeout(t);
    }
  }, [visible]);
  const insets = useSafeAreaInsets();
  const colors = useColors();
  return (
    <Animated.View
      style={[
        toastStyles.wrap,
        { top: (Platform.OS === "web" ? 70 : insets.top) + 10, transform: [{ translateY: anim }], backgroundColor: colors.surface, borderColor: colors.primary + "44" },
      ]}
      pointerEvents="none"
    >
      <View style={[toastStyles.icon, { backgroundColor: colors.primary + "20" }]}>
        <Feather name="check-circle" size={18} color={colors.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[toastStyles.msg, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{message}</Text>
        <Text style={[toastStyles.sub, { color: colors.textMuted }]}>{sub}</Text>
      </View>
    </Animated.View>
  );
}
const toastStyles = StyleSheet.create({
  wrap: { position: "absolute", left: 14, right: 14, zIndex: 999, flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1, padding: 14, gap: 12, shadowColor: "#000", shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 10 },
  icon: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  msg: { fontSize: 14 },
  sub: { fontSize: 12, marginTop: 2 },
});

// ─── Send Money Modal ─────────────────────────────────────────────────────────

type SendStep = "type" | "form" | "confirm" | "success";
type LookupState = "idle" | "searching" | "found" | "notfound";

function SendMoneyModal({
  visible,
  onDismiss,
  onSuccess,
  balance,
}: {
  visible: boolean;
  onDismiss: () => void;
  onSuccess: (amount: number, name: string, reference: string) => void;
  balance: number;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { sendMobileMoney, currentUser } = useApp();

  const [step, setStep] = useState<SendStep>("type");
  const [recipientType, setRecipientType] = useState<RecipientType | null>(null);

  // CharLey / email search
  const [query, setQuery] = useState("");
  const [foundUser, setFoundUser] = useState<FPUser | null>(null);
  const [lookupState, setLookupState] = useState<LookupState>("idle");

  // Phone / mobile money
  const [phone, setPhone] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState<typeof NETWORKS[0] | null>(null);

  // Bank
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [showBankPicker, setShowBankPicker] = useState(false);

  // Shared
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [formError, setFormError] = useState("");
  const [fees, setFees] = useState<FeeBreakdown | null>(null);

  // Transfer state
  const [sending, setSending] = useState(false);
  const [txRef, setTxRef] = useState("");
  const [txRecipient, setTxRecipient] = useState("");
  const [txNewBalance, setTxNewBalance] = useState(0);
  const [showPinModal, setShowPinModal] = useState(false);

  const lookupTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reset = () => {
    setStep("type"); setRecipientType(null);
    setQuery(""); setFoundUser(null); setLookupState("idle");
    setPhone(""); setRecipientName(""); setSelectedNetwork(null);
    setBankName(""); setAccountNumber(""); setShowBankPicker(false);
    setAmount(""); setNote(""); setFormError(""); setFees(null);
    setSending(false); setTxRef(""); setTxRecipient(""); setTxNewBalance(0);
    setShowPinModal(false);
  };

  const handleClose = () => { reset(); onDismiss(); };

  useEffect(() => {
    const num = parseFloat(amount);
    if (num > 0 && recipientType) {
      setFees(calculateFee(recipientType, num));
    } else {
      setFees(null);
    }
  }, [amount, recipientType]);

  const handleTypeSelect = (type: RecipientType) => {
    setRecipientType(type);
    if (type === "mtn")        setSelectedNetwork(NETWORKS.find(n => n.id === "mtn") ?? null);
    else if (type === "telecel")    setSelectedNetwork(NETWORKS.find(n => n.id === "telecel") ?? null);
    else if (type === "airteltigo") setSelectedNetwork(NETWORKS.find(n => n.id === "airteltigo") ?? null);
    Haptics.selectionAsync();
    setStep("form");
  };

  // Debounced lookup for CharLey users (phone or email)
  const handleQueryChange = (val: string) => {
    setQuery(val);
    setFoundUser(null);
    setLookupState("idle");
    if (lookupTimer.current) clearTimeout(lookupTimer.current);
    const clean = val.trim().replace(/\s/g, "");
    if (clean.length < 5) return;
    setLookupState("searching");
    lookupTimer.current = setTimeout(async () => {
      try {
        const results = await searchUsers({ q: clean });
        const hit = (results as any[])[0];
        if (hit) {
          setFoundUser({
            name: hit.fullName,
            verified: hit.isKycVerified ?? false,
            userId: hit.phone ?? hit.id,
            avatarColor: avatarColorFor(hit.fullName),
          });
          setLookupState("found");
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        } else {
          setLookupState("notfound");
        }
      } catch {
        setLookupState("notfound");
      }
    }, 900);
  };

  // Debounced lookup for phone-based types
  const handlePhoneChange = (val: string) => {
    const clean = val.replace(/[^0-9]/g, "").slice(0, 10);
    setPhone(clean);
    setRecipientName("");
    setLookupState("idle");
    if (recipientType && ["mtn", "telecel", "airteltigo"].includes(recipientType)) {
      const detected = detectNetwork(clean);
      if (detected) setSelectedNetwork(detected);
    }
    if (lookupTimer.current) clearTimeout(lookupTimer.current);
    if (clean.length === 10) {
      setLookupState("searching");
      lookupTimer.current = setTimeout(() => {
        setRecipientName(lookupName(clean));
        setLookupState("found");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }, 900);
    }
  };

  const amountNum = parseFloat(amount) || 0;

  const getRecipientDisplay = (): string => {
    if (recipientType === "charley") return foundUser?.name ?? "";
    if (recipientType === "email") return foundUser?.name ?? query;
    if (recipientType === "bank") return bankName || "Bank Account";
    return recipientName || phone;
  };

  const getMethodDisplay = (): string => {
    if (recipientType === "charley") return "CharLey Wallet (Instant)";
    if (recipientType === "bank") return bankName;
    if (recipientType === "email") return "CharLey (Email)";
    if (recipientType === "phone") return "Phone Transfer";
    return selectedNetwork?.name ?? "";
  };

  const canGoToConfirm = (): boolean => {
    if (!amount || amountNum <= 0 || (fees?.totalCharged ?? amountNum) > balance) return false;
    switch (recipientType) {
      case "charley": return lookupState === "found" && foundUser !== null;
      case "email":    return lookupState === "found" && foundUser !== null;
      case "bank":     return !!bankName && accountNumber.length >= 10;
      case "phone":    return phone.length === 10 && lookupState === "found";
      case "mtn":
      case "telecel":
      case "airteltigo": return phone.length === 10 && lookupState === "found";
      default: return false;
    }
  };

  const handleReview = () => {
    setFormError("");
    if (amountNum <= 0) { setFormError("Please enter a valid amount."); return; }
    if ((fees?.totalCharged ?? amountNum) > balance) { setFormError(`Total with fees (GH₵ ${(fees?.totalCharged ?? amountNum).toFixed(2)}) exceeds your balance.`); return; }
    if (!canGoToConfirm()) { setFormError("Please fill in all required fields."); return; }
    setStep("confirm");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleOpenPin = () => {
    setFormError("");
    setShowPinModal(true);
  };

  const handleConfirm = async (pin: string): Promise<{ ok: boolean; error?: string }> => {
    const dest = recipientType === "charley" || recipientType === "email"
      ? (foundUser?.userId ?? query)
      : recipientType === "bank" ? accountNumber : phone;
    setSending(true);
    setFormError("");
    try {
      const result = await sendMobileMoney(
        amountNum,
        dest,
        getMethodDisplay(),
        note || undefined,
        fees?.totalCharged,
        pin
      );
      setShowPinModal(false);
      setTxRef(result.reference);
      setTxRecipient(result.recipientName || getRecipientDisplay());
      setTxNewBalance(result.newBalancePesewas / 100);
      setStep("success");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onSuccess(amountNum, result.recipientName || getRecipientDisplay(), result.reference);
      return { ok: true };
    } catch (err: any) {
      const msg: string = err?.response?.data?.error ?? err?.message ?? "Transfer failed. Please try again.";
      // PIN-specific error → return to PIN modal with message
      if (msg.toLowerCase().includes("pin") || msg.toLowerCase().includes("incorrect")) {
        return { ok: false, error: msg };
      }
      // Other error → dismiss PIN modal, show inline
      setShowPinModal(false);
      setFormError(msg);
      return { ok: false, error: msg };
    } finally {
      setSending(false);
    }
  };

  const botPad = Math.max((Platform.OS === "web" ? 0 : insets.bottom) + 16, 24);
  const typeInfo = RECIPIENT_TYPES.find(t => t.id === recipientType);
  const isMoMo = recipientType === "mtn" || recipientType === "telecel" || recipientType === "airteltigo";
  const isWalletType = recipientType === "charley" || recipientType === "email";
  const { height: screenH } = useWindowDimensions();
  const sheetMaxH = Platform.OS === "web" ? 680 : screenH * 0.92;

  return (
    <>
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={step === "type" ? handleClose : undefined} />
        <View style={[
          styles.sheet,
          {
            backgroundColor: colors.surface,
            paddingBottom: step === "form" || step === "confirm" ? 0 : botPad,
            maxHeight: sheetMaxH,
          },
        ]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />

        {/* ── KYC GATE ────────────────────────────────────────────────────── */}
        {currentUser?.kycStatus !== "approved" && !currentUser?.verified && (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 24, paddingBottom: botPad, alignItems: "center", gap: 16 }}>
            <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated, alignSelf: "flex-end" }]} activeOpacity={0.7}>
              <Feather name="x" size={18} color={colors.textMuted} />
            </TouchableOpacity>
            <View style={{ width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center",
              backgroundColor: currentUser?.kycStatus === "rejected" ? "#EF444418" : currentUser?.kycStatus === "pending" ? "#F59E0B18" : colors.primary + "18" }}>
              <Feather
                name={currentUser?.kycStatus === "rejected" ? "x-circle" : currentUser?.kycStatus === "pending" ? "clock" : "shield"}
                size={34}
                color={currentUser?.kycStatus === "rejected" ? "#EF4444" : currentUser?.kycStatus === "pending" ? "#F59E0B" : colors.primary}
              />
            </View>
            <Text style={{ color: colors.text, fontSize: 20, fontFamily: "Inter_700Bold", textAlign: "center" }}>
              {currentUser?.kycStatus === "pending"
                ? "Verification Under Review"
                : currentUser?.kycStatus === "rejected"
                ? "Verification Rejected"
                : "Identity Verification Required"}
            </Text>
            <Text style={{ color: colors.textMuted, fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 21 }}>
              {currentUser?.kycStatus === "pending"
                ? "Your identity verification is being reviewed. Sending money will be enabled once approved (1–2 business days)."
                : currentUser?.kycStatus === "rejected"
                ? `Your submission was rejected: ${currentUser?.kycRejectionReason ?? "Please resubmit with clearer photos."}`
                : "Identity verification is required before sending money. Complete KYC verification to unlock transfers."}
            </Text>
            {currentUser?.kycStatus !== "pending" && (
              <TouchableOpacity
                style={{ backgroundColor: currentUser?.kycStatus === "rejected" ? "#EF4444" : colors.primary, borderRadius: 14, paddingVertical: 16, paddingHorizontal: 32, flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "stretch", justifyContent: "center", marginTop: 8 }}
                onPress={() => { handleClose(); router.push("/kyc-verify" as never); }}
                activeOpacity={0.8}
              >
                <Feather name="shield" size={16} color="#fff" />
                <Text style={{ color: "#fff", fontSize: 16, fontFamily: "Inter_600SemiBold" }}>
                  {currentUser?.kycStatus === "rejected" ? "Resubmit Verification" : "Verify Identity"}
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        )}

        {/* ── STEP: type ──────────────────────────────────────────────────── */}
        {(currentUser?.verified || currentUser?.kycStatus === "approved") && step === "type" && (
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
            <View style={styles.sendHeader}>
              <View style={[styles.sendHeaderIcon, { backgroundColor: colors.primary + "20" }]}>
                <Feather name="send" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Send Money</Text>
                <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 0 }]}>Choose how to send</Text>
              </View>
              <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                <Feather name="x" size={18} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <View style={[styles.balancePill, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
              <Feather name="credit-card" size={14} color={colors.primary} />
              <Text style={[styles.balancePillText, { color: colors.textMuted }]}>
                {" "}Available:{" "}
                <Text style={{ color: colors.text, fontFamily: "Inter_700Bold" }}>GH₵ {balance.toLocaleString()}</Text>
              </Text>
            </View>

            <View style={styles.typeGrid}>
              {RECIPIENT_TYPES.map((t) => (
                <TouchableOpacity
                  key={t.id}
                  style={[styles.typeCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}
                  onPress={() => handleTypeSelect(t.id)}
                  activeOpacity={0.75}
                >
                  <View style={[styles.typeIcon, { backgroundColor: t.bg }]}>
                    <Feather name={t.icon} size={17} color={t.fg} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.typeLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{t.label}</Text>
                    <Text style={[styles.typeSub, { color: colors.textMuted }]}>{t.sub}</Text>
                  </View>
                  <Feather name="chevron-right" size={16} color={colors.textMuted} />
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        )}

        {/* ── STEP: form ──────────────────────────────────────────────────── */}
        {step === "form" && recipientType && (
          <View style={{ flex: 1 }}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ paddingBottom: botPad }}
            >
              {/* Header */}
              <View style={styles.sendHeader}>
                <TouchableOpacity onPress={() => setStep("type")} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <View style={[styles.typeIcon, { backgroundColor: typeInfo?.bg ?? colors.primary, marginLeft: 6 }]}>
                  <Feather name={typeInfo?.icon ?? "send"} size={16} color={typeInfo?.fg ?? "#fff"} />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{typeInfo?.label}</Text>
                  <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 0 }]}>Balance: GH₵ {balance.toLocaleString()}</Text>
                </View>
                <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                  <Feather name="x" size={18} color={colors.textMuted} />
                </TouchableOpacity>
              </View>

              {/* ── CharLey user search ── */}
              {isWalletType && (
                <>
                  <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>
                    {recipientType === "email" ? "EMAIL ADDRESS" : "SEARCH FARGOPAY USER"}
                  </Text>
                  <View style={[
                    styles.phoneBox,
                    {
                      backgroundColor: colors.surfaceElevated,
                      borderColor: lookupState === "found" ? colors.primary : lookupState === "notfound" ? colors.danger : colors.border,
                    },
                  ]}>
                    <Feather
                      name={recipientType === "email" ? "mail" : "search"}
                      size={16}
                      color={colors.textMuted}
                      style={{ marginRight: 8 }}
                    />
                    <TextInput
                      style={[styles.phoneInput, { color: colors.text, fontFamily: "Inter_500Medium", flex: 1 }]}
                      placeholder={recipientType === "email" ? "recipient@example.com" : "Phone number or email"}
                      placeholderTextColor={colors.textMuted}
                      value={query}
                      onChangeText={handleQueryChange}
                      autoCapitalize="none"
                      keyboardType="email-address"
                    />
                    {lookupState === "searching" && <Feather name="loader" size={15} color={colors.primary} />}
                    {lookupState === "found"     && <Feather name="check-circle" size={15} color={colors.primary} />}
                    {lookupState === "notfound"  && <Feather name="x-circle" size={15} color={colors.danger} />}
                  </View>

                  {lookupState === "found" && foundUser && (
                    <View style={[styles.recipientConfirm, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "44" }]}>
                      <View style={[styles.recipientAvatar, { backgroundColor: foundUser.avatarColor }]}>
                        <Text style={[styles.recipientAvatarText, { fontFamily: "Inter_700Bold" }]}>
                          {foundUser.name.split(" ").map(w => w[0]).join("").slice(0, 2)}
                        </Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                          <Text style={[styles.recipientName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{foundUser.name}</Text>
                          {foundUser.verified && (
                            <View style={[styles.verifiedChip, { backgroundColor: colors.primary + "20" }]}>
                              <Feather name="check-circle" size={10} color={colors.primary} />
                              <Text style={[styles.verifiedChipText, { color: colors.primary }]}> Verified</Text>
                            </View>
                          )}
                        </View>
                        <Text style={[styles.recipientSub, { color: colors.textMuted }]}>{foundUser.userId}</Text>
                      </View>
                      <Feather name="check-circle" size={18} color={colors.primary} />
                    </View>
                  )}
                  {lookupState === "notfound" && (
                    <View style={[styles.recipientConfirm, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
                      <Feather name="user-x" size={16} color={colors.danger} />
                      <Text style={[styles.recipientSub, { color: colors.danger, marginLeft: 10, flex: 1 }]}>
                        No CharLey user found. Try a different phone or email.
                      </Text>
                    </View>
                  )}

                  <View style={[styles.fpInfoBox, { backgroundColor: colors.successBg, borderColor: colors.success + "44" }]}>
                    <Feather name="zap" size={12} color={colors.success} />
                    <Text style={[styles.fpInfoText, { color: colors.success }]}> Instant transfer · No fees · Direct to wallet</Text>
                  </View>
                </>
              )}

              {/* ── Mobile money + phone number shared input ── */}
              {(isMoMo || recipientType === "phone") && (
                <>
                  <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>
                    {isMoMo ? "RECIPIENT PHONE" : "PHONE NUMBER"}
                  </Text>
                  <View style={[
                    styles.phoneBox,
                    { backgroundColor: colors.surfaceElevated, borderColor: lookupState === "found" ? colors.primary : colors.border },
                  ]}>
                    <Text style={[styles.phonePrefix, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>+233</Text>
                    <TextInput
                      style={[styles.phoneInput, { color: colors.text, fontFamily: "Inter_500Medium" }]}
                      placeholder="024 000 0000"
                      placeholderTextColor={colors.textMuted}
                      keyboardType="phone-pad"
                      value={phone}
                      onChangeText={handlePhoneChange}
                      maxLength={10}
                    />
                    {lookupState === "searching" && <Feather name="loader" size={14} color={colors.primary} />}
                    {lookupState === "found"     && <Feather name="check" size={14} color={colors.primary} />}
                  </View>

                  {lookupState === "found" && recipientName && (
                    <View style={[styles.recipientConfirm, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "33" }]}>
                      <View style={[styles.recipientAvatar, { backgroundColor: avatarColorFor(recipientName) }]}>
                        <Text style={[styles.recipientAvatarText, { fontFamily: "Inter_700Bold" }]}>
                          {recipientName.split(" ").map(w => w[0]).join("").slice(0, 2)}
                        </Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={[styles.recipientName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{recipientName}</Text>
                        <Text style={[styles.recipientSub, { color: colors.primary }]}>
                          {isMoMo ? selectedNetwork?.name : "Phone"} · +233 {phone}
                        </Text>
                      </View>
                      <Feather name="check-circle" size={18} color={colors.primary} />
                    </View>
                  )}
                  {phone.length === 10 && lookupState === "searching" && (
                    <View style={[styles.recipientConfirm, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                      <Feather name="loader" size={16} color={colors.textMuted} />
                      <Text style={[styles.recipientSub, { color: colors.textMuted, marginLeft: 10 }]}>Looking up recipient…</Text>
                    </View>
                  )}
                </>
              )}

              {/* ── Bank account ── */}
              {recipientType === "bank" && (
                <>
                  <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>SELECT BANK</Text>
                  <TouchableOpacity
                    style={[styles.phoneBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border, justifyContent: "space-between" }]}
                    onPress={() => setShowBankPicker(v => !v)}
                    activeOpacity={0.8}
                  >
                    <Text style={[styles.phoneInput, { color: bankName ? colors.text : colors.textMuted, fontFamily: "Inter_500Medium" }]}>
                      {bankName || "Choose a bank"}
                    </Text>
                    <Feather name={showBankPicker ? "chevron-up" : "chevron-down"} size={16} color={colors.textMuted} />
                  </TouchableOpacity>

                  {showBankPicker && (
                    <View style={[styles.bankPickerList, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                      {BANKS.map((b) => (
                        <TouchableOpacity
                          key={b}
                          style={[styles.bankPickerItem, { borderBottomColor: colors.border }]}
                          onPress={() => { setBankName(b); setShowBankPicker(false); Haptics.selectionAsync(); }}
                        >
                          <Text style={[styles.bankPickerItemText, { color: colors.text, fontFamily: b === bankName ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                            {b}
                          </Text>
                          {b === bankName && <Feather name="check" size={14} color={colors.primary} />}
                        </TouchableOpacity>
                      ))}
                    </View>
                  )}

                  <Text style={[styles.fieldLabel, { color: colors.textMuted, marginTop: 14 }]}>ACCOUNT NUMBER</Text>
                  <View style={[styles.phoneBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                    <TextInput
                      style={[styles.phoneInput, { color: colors.text, fontFamily: "Inter_500Medium" }]}
                      placeholder="Enter account number (10–13 digits)"
                      placeholderTextColor={colors.textMuted}
                      keyboardType="number-pad"
                      value={accountNumber}
                      onChangeText={(v) => setAccountNumber(v.replace(/\D/g, "").slice(0, 13))}
                      maxLength={13}
                    />
                    {accountNumber.length >= 10 && <Feather name="check" size={14} color={colors.primary} />}
                  </View>
                </>
              )}

              {/* ── Amount (shared by all types) ── */}
              <Text style={[styles.fieldLabel, { color: colors.textMuted, marginTop: 14 }]}>AMOUNT (GH₵)</Text>
              <View style={[styles.amountBox, { backgroundColor: colors.surfaceElevated, borderColor: (fees?.totalCharged ?? amountNum) > balance ? colors.danger : colors.border }]}>
                <Text style={[styles.amountCurrency, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>GH₵</Text>
                <TextInput
                  style={[styles.amountInput, { color: (fees?.totalCharged ?? amountNum) > balance ? colors.danger : colors.text, fontFamily: "Inter_700Bold" }]}
                  placeholder="0.00"
                  placeholderTextColor={colors.textMuted}
                  keyboardType="decimal-pad"
                  value={amount}
                  onChangeText={(v) => { setAmount(v); setFormError(""); }}
                />
              </View>
              {(fees?.totalCharged ?? amountNum) > balance && (
                <Text style={[styles.errorText, { color: colors.danger }]}>Total with fees (GH₵ {(fees?.totalCharged ?? amountNum).toFixed(2)}) exceeds balance</Text>
              )}

              {/* Quick amounts */}
              <View style={styles.quickAmounts}>
                {["10", "20", "50", "100", "200", "500"].map((a) => (
                  <TouchableOpacity
                    key={a}
                    style={[styles.quickChip, { backgroundColor: amount === a ? colors.primary : colors.surfaceElevated, borderColor: amount === a ? colors.primary : colors.border }]}
                    onPress={() => { setAmount(a); setFormError(""); Haptics.selectionAsync(); }}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.quickChipText, { color: amount === a ? "#fff" : colors.textMuted, fontFamily: amount === a ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                      {a}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Note */}
              <TextInput
                style={[styles.noteInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border, fontFamily: "Inter_400Regular" }]}
                placeholder="Add a note (optional)"
                placeholderTextColor={colors.textMuted}
                value={note}
                onChangeText={setNote}
              />

              {/* Fee preview */}
              {fees && amountNum > 0 && (
                <View style={[styles.feePreview, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                  <View style={styles.feePreviewRow}>
                    <Text style={[styles.feePreviewLabel, { color: colors.textMuted }]}>Transfer amount</Text>
                    <Text style={[styles.feePreviewValue, { color: colors.textMuted }]}>{fmtFee(amountNum)}</Text>
                  </View>
                  <View style={styles.feePreviewRow}>
                    <Text style={[styles.feePreviewLabel, { color: colors.textMuted }]}>Est. fees</Text>
                    <Text style={[styles.feePreviewValue, { color: colors.textMuted }]}>{fmtFee(fees.totalFees)}</Text>
                  </View>
                  <View style={[styles.feePreviewDivider, { backgroundColor: colors.border }]} />
                  <View style={styles.feePreviewRow}>
                    <Text style={[styles.feePreviewLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Total charged</Text>
                    <Text style={[styles.feePreviewValue, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{fmtFee(fees.totalCharged)}</Text>
                  </View>
                  {fees.tier.discount > 0 && (
                    <View style={[styles.tierBadge, { backgroundColor: colors.primary + "18" }]}>
                      <Feather name="zap" size={10} color={colors.primary} />
                      <Text style={[styles.tierBadgeText, { color: colors.primary }]}> {fees.tier.name} · {fees.tier.label} on CharLey fee</Text>
                    </View>
                  )}
                </View>
              )}

              {/* Payment source */}
              <View style={[styles.sourceBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                <View style={[styles.typeIcon, { backgroundColor: colors.primary + "20" }]}>
                  <Feather name="credit-card" size={15} color={colors.primary} />
                </View>
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={[styles.sourceLabel, { color: colors.textMuted }]}>Payment source</Text>
                  <Text style={[styles.sourceValue, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                    CharLey Wallet · GH₵ {balance.toLocaleString()}
                  </Text>
                </View>
                <Feather name="check-circle" size={16} color={colors.primary} />
              </View>

              {formError ? (
                <View style={[styles.errorBox, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
                  <Feather name="alert-circle" size={14} color={colors.danger} />
                  <Text style={[styles.errorInlineText, { color: colors.danger }]}> {formError}</Text>
                </View>
              ) : null}

              {/* Send button — inside scroll so it's always reachable */}
              <View style={{ marginTop: 8 }}>
                <TouchableOpacity
                  style={[styles.confirmBtn, { backgroundColor: colors.primary }]}
                  onPress={handleReview}
                  activeOpacity={0.85}
                >
                  <Feather name="send" size={16} color="#fff" />
                  <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
                    {amountNum > 0 ? `  Send GH₵ ${amountNum.toLocaleString()}` : "  Send Money"}
                  </Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        )}

        {/* ── STEP: confirm ───────────────────────────────────────────────── */}
        {step === "confirm" && (
          <View style={{ flex: 1 }}>
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 16 }} style={{ flex: 1 }}>
              <View style={styles.sendHeader}>
                <TouchableOpacity onPress={() => setStep("form")} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", flex: 1, marginLeft: 12 }]}>Confirm Transfer</Text>
                <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                  <Feather name="x" size={18} color={colors.textMuted} />
                </TouchableOpacity>
              </View>

              {/* Big amount display */}
              <View style={styles.confirmAmountWrap}>
                <Text style={[styles.confirmAmountLabel, { color: colors.textMuted }]}>Sending</Text>
                <Text style={[styles.confirmAmountValue, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                  GH₵ {amountNum.toLocaleString()}
                </Text>
                <Text style={[styles.confirmAmountTo, { color: colors.textMuted }]}>to {getRecipientDisplay()}</Text>
              </View>

              {/* Summary card */}
              <View style={[styles.summaryCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                {([
                  { label: "Recipient",  value: getRecipientDisplay(),  icon: "user"         as const },
                  ...(recipientType === "bank" ? [{ label: "Account", value: accountNumber, icon: "hash" as const }] : []),
                  { label: "Method",     value: getMethodDisplay(),      icon: "send"         as const },
                  { label: "Amount",     value: `GH₵ ${amountNum.toLocaleString()}`, icon: "dollar-sign" as const, bold: true },
                  { label: "Fees",       value: fees ? (fees.totalFees > 0 ? fmtFee(fees.totalFees) : "Free") : "—", icon: "gift" as const },
                  ...(fees && fees.totalFees > 0 ? [{ label: "Total Charged", value: fmtFee(fees.totalCharged), icon: "credit-card" as const, bold: true }] : []),
                  ...(note ? [{ label: "Note", value: note, icon: "file-text" as const }] : []),
                ] as Array<{ label: string; value: string; icon: React.ComponentProps<typeof Feather>["name"]; bold?: boolean }>).map((row, i, arr) => (
                  <View key={row.label}>
                    <View style={styles.summaryRow}>
                      <View style={[styles.summaryIcon, { backgroundColor: colors.surface }]}>
                        <Feather name={row.icon} size={14} color={colors.textMuted} />
                      </View>
                      <View style={{ flex: 1, marginLeft: 12 }}>
                        <Text style={[styles.summaryLabel, { color: colors.textMuted }]}>{row.label}</Text>
                        <Text style={[styles.summaryValue, { color: colors.text, fontFamily: row.bold ? "Inter_700Bold" : "Inter_500Medium" }]}>
                          {row.value}
                        </Text>
                      </View>
                    </View>
                    {i < arr.length - 1 && <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />}
                  </View>
                ))}
              </View>

              {fees && fees.totalFees > 0 && (
                <View style={[styles.feeBreakdown, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                  <Text style={[styles.feeBreakdownTitle, { color: colors.textMuted }]}>FEE BREAKDOWN</Text>
                  <View style={styles.feeBreakdownRow}>
                    <Text style={[styles.feeBreakdownLabel, { color: colors.textMuted }]}>CharLey Service Fee (0.5%{fees.tier.discount > 0 ? ` · ${fees.tier.label}` : ""})</Text>
                    <Text style={[styles.feeBreakdownValue, { color: colors.text }]}>{fmtFee(fees.fargoPayFee)}</Text>
                  </View>
                  {fees.hubtelFee > 0 && (
                    <View style={styles.feeBreakdownRow}>
                      <Text style={[styles.feeBreakdownLabel, { color: colors.textMuted }]}>Hubtel Processing Fee</Text>
                      <Text style={[styles.feeBreakdownValue, { color: colors.text }]}>{fmtFee(fees.hubtelFee)}</Text>
                    </View>
                  )}
                  {fees.networkFee > 0 && (
                    <View style={styles.feeBreakdownRow}>
                      <Text style={[styles.feeBreakdownLabel, { color: colors.textMuted }]}>Network Fee</Text>
                      <Text style={[styles.feeBreakdownValue, { color: colors.text }]}>{fmtFee(fees.networkFee)}</Text>
                    </View>
                  )}
                  {fees.bankFee > 0 && (
                    <View style={styles.feeBreakdownRow}>
                      <Text style={[styles.feeBreakdownLabel, { color: colors.textMuted }]}>Bank Processing Fee</Text>
                      <Text style={[styles.feeBreakdownValue, { color: colors.text }]}>{fmtFee(fees.bankFee)}</Text>
                    </View>
                  )}
                  <View style={[styles.feeBreakdownDivider, { backgroundColor: colors.border }]} />
                  <View style={styles.feeBreakdownRow}>
                    <Text style={[styles.feeBreakdownLabel, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Total Charged from Wallet</Text>
                    <Text style={[styles.feeBreakdownValue, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>{fmtFee(fees.totalCharged)}</Text>
                  </View>
                  {fees.tier.discount > 0 && (
                    <View style={[styles.tierBadge, { backgroundColor: colors.primary + "18", marginTop: 6 }]}>
                      <Feather name="zap" size={10} color={colors.primary} />
                      <Text style={[styles.tierBadgeText, { color: colors.primary }]}> {fees.tier.name} · {fees.tier.label} discount applied</Text>
                    </View>
                  )}
                </View>
              )}
              <View style={[styles.feeNote, { backgroundColor: colors.successBg, borderColor: colors.success + "44" }]}>
                <Feather name="shield" size={13} color={colors.success} />
                <Text style={[styles.feeNoteText, { color: colors.success }]}> Secured by CharLey · Transparent pricing</Text>
              </View>

              {formError ? (
                <View style={[styles.errorBox, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44", marginTop: 8 }]}>
                  <Feather name="alert-circle" size={14} color={colors.danger} />
                  <Text style={[styles.errorInlineText, { color: colors.danger }]}> {formError}</Text>
                </View>
              ) : null}

              {/* Confirm button — opens PIN modal for verification */}
              <View style={{ marginTop: 8 }}>
                <TouchableOpacity
                  style={[styles.confirmBtn, { backgroundColor: sending ? colors.primary + "88" : colors.primary }]}
                  onPress={handleOpenPin}
                  activeOpacity={0.85}
                  disabled={sending}
                >
                  <Feather name={sending ? "loader" : "lock"} size={16} color="#fff" />
                  <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
                    {sending ? "  Sending…" : `  Enter PIN · Pay ${fmtFee(fees?.totalCharged ?? amountNum)}`}
                  </Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        )}

        {/* ── STEP: success ───────────────────────────────────────────────── */}
        {step === "success" && (
          <View style={[styles.successStep, { paddingBottom: botPad }]}>
            <View style={[styles.successCircle, { backgroundColor: colors.primary + "20" }]}>
              <View style={[styles.successInner, { backgroundColor: colors.primary }]}>
                <Feather name="check" size={34} color="#fff" />
              </View>
            </View>
            <Text style={[styles.successTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Transfer Successful</Text>
            <Text style={[styles.successSub, { color: colors.textMuted }]}>
              GH₵ {amountNum.toLocaleString()} sent to {txRecipient || getRecipientDisplay()}
              {fees && fees.totalFees > 0 ? `\nFees charged: ${fmtFee(fees.totalFees)}` : ""}
            </Text>

            {/* Receipt card */}
            <View style={[styles.receiptCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
              {([
                { label: "Amount",     value: `GH₵ ${amountNum.toLocaleString()}` },
                { label: "Recipient",  value: txRecipient || getRecipientDisplay() },
                { label: "Reference",  value: txRef, mono: true },
                { label: "New Balance", value: `GH₵ ${txNewBalance.toLocaleString()}`, accent: true },
              ] as Array<{ label: string; value: string; mono?: boolean; accent?: boolean }>).map((row, i, arr) => (
                <View key={row.label}>
                  <View style={styles.receiptRow}>
                    <Text style={[styles.receiptLabel, { color: colors.textMuted }]}>{row.label}</Text>
                    <Text style={[
                      styles.receiptValue,
                      {
                        color: row.accent ? colors.primary : colors.text,
                        fontFamily: row.mono ? "Inter_600SemiBold" : row.accent ? "Inter_700Bold" : "Inter_500Medium",
                        fontSize: row.mono ? 12 : 14,
                      },
                    ]}>
                      {row.value}
                    </Text>
                  </View>
                  {i < arr.length - 1 && <View style={[{ height: 1, backgroundColor: colors.border, marginVertical: 6 }]} />}
                </View>
              ))}
            </View>

            <View style={{ flexDirection: "row", gap: 10, width: "100%", marginTop: 12 }}>
              <TouchableOpacity
                style={[styles.confirmBtn, { backgroundColor: colors.surfaceElevated, flex: 1, borderWidth: 1, borderColor: colors.border }]}
                onPress={() => {
                  const receipt = `Transfer Successful\nAmount: GH₵ ${amountNum.toLocaleString()}\nRecipient: ${txRecipient || getRecipientDisplay()}\nReference: ${txRef}\nNew Balance: GH₵ ${txNewBalance.toLocaleString()}`;
                  Alert.alert("Share Receipt", receipt, [{ text: "OK" }]);
                }}
                activeOpacity={0.8}
              >
                <Feather name="share-2" size={15} color={colors.text} />
                <Text style={[styles.confirmBtnText, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}> Share</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmBtn, { backgroundColor: colors.primary, flex: 1 }]}
                onPress={() => { reset(); onDismiss(); }}
                activeOpacity={0.8}
              >
                <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>Done</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
    <PinConfirmModal
      visible={showPinModal}
      title="Confirm Transfer"
      subtitle={`Enter your PIN to send ${fmtFee(fees?.totalCharged ?? amountNum)} to ${getRecipientDisplay()}`}
      onConfirm={handleConfirm}
      onCancel={() => { setShowPinModal(false); setSending(false); }}
    />
    </>
  );
}

// ─── Create Pay Link Modal ────────────────────────────────────────────────────

type PLStep = "form" | "created";

function CreatePayLinkModal({
  visible, onDismiss, onCreate,
}: {
  visible: boolean;
  onDismiss: () => void;
  onCreate: (title: string, desc: string, amount: number, delivery?: string) => string;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<PLStep>("form");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [delivery, setDelivery] = useState("");
  const [code, setCode] = useState("");
  const [copied, setCopied] = useState(false);

  const reset = () => { setStep("form"); setTitle(""); setDesc(""); setAmount(""); setDelivery(""); setCode(""); setCopied(false); };
  const handleClose = () => { reset(); onDismiss(); };

  const handleGenerate = () => {
    if (!title.trim()) { Alert.alert("Missing title", "Enter an item or service name."); return; }
    const num = parseFloat(amount);
    if (!num || num <= 0) { Alert.alert("Invalid amount", "Enter a valid amount."); return; }
    const newCode = onCreate(title.trim(), desc.trim(), num, delivery.trim() || undefined);
    setCode(newCode);
    setStep("created");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const linkUrl = `charley.app/pay/${code}`;
  const botPad = Math.max((Platform.OS === "web" ? 0 : insets.bottom) + 16, 24);

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={step === "form" ? handleClose : undefined} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: botPad }]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />

        {step === "form" && (
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 8 }}>
            <View style={[styles.sendHeader, { marginBottom: 16 }]}>
              <View style={[styles.sendHeaderIcon, { backgroundColor: colors.primary + "20" }]}>
                <Feather name="link" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Create Pay Link</Text>
                <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 0 }]}>Share a link — buyer pays, escrow protects</Text>
              </View>
              <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                <Feather name="x" size={18} color={colors.textMuted} />
              </TouchableOpacity>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>ITEM OR SERVICE</Text>
            <TextInput
              style={[styles.textInput, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, color: colors.text, marginBottom: 14 }]}
              value={title} onChangeText={setTitle} placeholder="e.g. iPhone 17 Pro Max" placeholderTextColor={colors.textMuted}
            />

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>DESCRIPTION</Text>
            <TextInput
              style={[styles.textInput, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, color: colors.text, marginBottom: 14, minHeight: 70 }]}
              value={desc} onChangeText={setDesc} placeholder="Condition, specs, warranty…" placeholderTextColor={colors.textMuted}
              multiline numberOfLines={3}
            />

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
            <View style={[styles.amountBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border, marginBottom: 14 }]}>
              <Text style={[styles.amountCurrency, { color: colors.textMuted, fontFamily: "Inter_600SemiBold", fontSize: 16 }]}>GH₵</Text>
              <TextInput
                style={[styles.amountInput, { color: colors.text, fontFamily: "Inter_700Bold", fontSize: 28 }]}
                placeholder="0.00" placeholderTextColor={colors.textMuted} keyboardType="decimal-pad"
                value={amount} onChangeText={setAmount}
              />
            </View>

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>DELIVERY / PICKUP INFO (optional)</Text>
            <TextInput
              style={[styles.textInput, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, color: colors.text, marginBottom: 16 }]}
              value={delivery} onChangeText={setDelivery} placeholder="e.g. Same-day delivery in Accra" placeholderTextColor={colors.textMuted}
            />

            <View style={[styles.escrowNote, { backgroundColor: colors.goldDim, marginBottom: 16 }]}>
              <Feather name="shield" size={14} color={colors.gold} />
              <Text style={[styles.escrowNoteText, { color: colors.gold }]}>{" "}Buyer's money is held in escrow until they confirm receipt</Text>
            </View>

            <TouchableOpacity style={[styles.confirmBtn, { backgroundColor: colors.primary }]} onPress={handleGenerate} activeOpacity={0.8}>
              <Feather name="link" size={16} color="#fff" />
              <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>{" "}Generate Pay Link</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={handleClose}>
              <Text style={[styles.cancelText, { color: colors.textMuted }]}>Cancel</Text>
            </TouchableOpacity>
          </ScrollView>
        )}

        {step === "created" && (
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 8, alignItems: "center" }}>
            <View style={{ flexDirection: "row", alignSelf: "stretch", justifyContent: "flex-end", marginBottom: 8 }}>
              <TouchableOpacity onPress={handleClose} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
                <Feather name="x" size={18} color={colors.textMuted} />
              </TouchableOpacity>
            </View>
            <View style={[styles.sendHeaderIcon, { backgroundColor: colors.primary + "20", width: 64, height: 64, borderRadius: 20, marginBottom: 16 }]}>
              <Feather name="check-circle" size={30} color={colors.primary} />
            </View>
            <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", textAlign: "center" }]}>Pay Link Created!</Text>
            <Text style={[styles.sheetSub, { color: colors.textMuted, textAlign: "center" }]}>
              Share this link with your buyer — they'll pay via MoMo and funds go straight to escrow.
            </Text>

            <View style={[plStyles.linkBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.primary + "44" }]}>
              <Feather name="link" size={14} color={colors.primary} />
              <Text style={[plStyles.linkText, { color: colors.text, fontFamily: "Inter_600SemiBold", flex: 1 }]} numberOfLines={1}> {linkUrl}</Text>
              <TouchableOpacity
                style={[plStyles.copyBtn, { backgroundColor: copied ? colors.primary : colors.surface }]}
                onPress={() => { setCopied(true); Haptics.selectionAsync(); setTimeout(() => setCopied(false), 2000); }}
              >
                <Feather name={copied ? "check" : "copy"} size={14} color={copied ? "#fff" : colors.textMuted} />
              </TouchableOpacity>
            </View>

            <View style={[plStyles.codeBox, { backgroundColor: colors.goldDim, borderColor: colors.gold + "44" }]}>
              <Text style={[plStyles.codeLabel, { color: colors.gold }]}>LINK CODE</Text>
              <Text style={[plStyles.codeValue, { color: colors.gold, fontFamily: "Inter_700Bold" }]}>{code}</Text>
            </View>

            <View style={[styles.escrowNote, { backgroundColor: colors.goldDim, alignSelf: "stretch" }]}>
              <Feather name="shield" size={14} color={colors.gold} />
              <Text style={[styles.escrowNoteText, { color: colors.gold }]}>{" "}Buyer funds are escrow-protected until you deliver</Text>
            </View>

            <TouchableOpacity
              style={[styles.confirmBtn, { backgroundColor: colors.primary, alignSelf: "stretch", marginTop: 16 }]}
              onPress={handleClose} activeOpacity={0.8}
            >
              <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>Done</Text>
            </TouchableOpacity>
          </ScrollView>
        )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const plStyles = StyleSheet.create({
  linkBox: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1.5, padding: 12, width: "100%", marginBottom: 12, gap: 6 },
  linkText: { fontSize: 13 },
  copyBtn: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  codeBox: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, borderWidth: 1, padding: 14, width: "100%", marginBottom: 14 },
  codeLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1 },
  codeValue: { fontSize: 22, letterSpacing: 2 },
});

// ─── Create Escrow Modal ──────────────────────────────────────────────────────

function CreateEscrowModal({
  visible, onDismiss, onCreate,
}: {
  visible: boolean; onDismiss: () => void;
  onCreate: (data: Omit<Escrow, "id" | "date">) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [title, setTitle] = useState("");
  const [with_, setWith] = useState("");
  const [amount, setAmount] = useState("");

  const handleCreate = () => {
    if (!title.trim() || !with_.trim() || !amount.trim()) {
      Alert.alert("Missing fields", "Please fill in all fields."); return;
    }
    const num = parseFloat(amount);
    if (!num || num <= 0) { Alert.alert("Invalid amount", "Enter a valid amount."); return; }
    onCreate({ title: title.trim(), withWho: with_.trim(), amount: `GH₵ ${num.toLocaleString()}`, amountRaw: num, status: "In Escrow", tone: "indigo", direction: "sent" });
    setTitle(""); setWith(""); setAmount("");
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onDismiss}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={onDismiss} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: (Platform.OS === "web" ? 0 : insets.bottom) + 20 }]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 8 }}>
          <View style={[styles.sendHeader, { marginBottom: 16 }]}>
            <View style={[styles.sendHeaderIcon, { backgroundColor: colors.gold + "20" }]}>
              <Feather name="lock" size={20} color={colors.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Create Secure Deal</Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 0 }]}>Lock funds safely until both parties confirm</Text>
            </View>
            <TouchableOpacity onPress={onDismiss} style={[styles.closeBtn, { backgroundColor: colors.surfaceElevated }]} activeOpacity={0.7}>
              <Feather name="x" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          </View>

          {([
            { label: "Item / Service", value: title, setter: setTitle, placeholder: "e.g. iPhone 17 Pro Max", key: "t" },
            { label: "Counterparty Name", value: with_, setter: setWith, placeholder: "e.g. John Electronics", key: "w" },
          ] as const).map(({ label, value, setter, placeholder, key }) => (
            <View key={key} style={{ marginBottom: 14 }}>
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>{label.toUpperCase()}</Text>
              <TextInput style={[styles.textInput, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, color: colors.text }]} value={value} onChangeText={setter} placeholder={placeholder} placeholderTextColor={colors.textMuted} />
            </View>
          ))}
          <View style={{ marginBottom: 16 }}>
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
            <TextInput style={[styles.textInput, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, color: colors.text }]} value={amount} onChangeText={setAmount} placeholder="0.00" placeholderTextColor={colors.textMuted} keyboardType="decimal-pad" />
          </View>
          <View style={[styles.escrowNote, { backgroundColor: colors.goldDim, marginBottom: 16 }]}>
            <Feather name="shield" size={14} color={colors.gold} />
            <Text style={[styles.escrowNoteText, { color: colors.gold }]}>{"  "}Funds locked until delivery is confirmed</Text>
          </View>
          <TouchableOpacity style={[styles.confirmBtn, { backgroundColor: colors.primary }]} onPress={handleCreate} activeOpacity={0.8}>
            <Feather name="lock" size={16} color="#fff" />
            <Text style={[styles.confirmBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>{"  "}Lock Funds Securely</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.cancelBtn} onPress={onDismiss}>
            <Text style={[styles.cancelText, { color: colors.textMuted }]}>Cancel</Text>
          </TouchableOpacity>
        </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Escrow Detail Modal ──────────────────────────────────────────────────────

function EscrowDetailModal({ escrow, onDismiss, onRelease }: {
  escrow: Escrow | null; onDismiss: () => void; onRelease: (id: string) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  if (!escrow) return null;
  const canRelease = escrow.status === "In Escrow" || escrow.status === "Pending Release";
  const steps = [
    { label: "Funds Secured",        done: true },
    { label: "Shipment Created",      done: escrow.status !== "In Escrow" },
    { label: "Delivery Confirmation", done: escrow.status === "Pending Release" || escrow.status === "Completed" },
    { label: "Payment Released",      done: escrow.status === "Completed" },
  ];
  return (
    <Modal visible animationType="slide" onRequestClose={onDismiss}>
      <View style={[styles.detailRoot, { backgroundColor: colors.background }]}>
        <View style={[styles.detailHeader, { backgroundColor: colors.surface, paddingTop: Platform.OS === "web" ? 67 : insets.top + 10 }]}>
          <TouchableOpacity onPress={onDismiss}><Feather name="arrow-left" size={22} color={colors.text} /></TouchableOpacity>
          <Text style={[styles.detailHeaderTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Secure Deal</Text>
          <TouchableOpacity><Feather name="more-vertical" size={22} color={colors.text} /></TouchableOpacity>
        </View>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
          <View style={[styles.lockBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.lockIcon, { backgroundColor: colors.goldDim }]}>
              <Feather name="lock" size={36} color={colors.gold} />
            </View>
            <Text style={[styles.lockTitle, { color: colors.textMuted }]}>PAYMENT LOCKED</Text>
            <Text style={[styles.lockAmount, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{escrow.amount}</Text>
            <Text style={[styles.lockFor, { color: colors.textMuted }]}>For</Text>
            <Text style={[styles.lockItem, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{escrow.title}</Text>
          </View>
          <Card style={{ marginBottom: 16 }}>
            {[
              { icon: "clock" as const, label: "Status", value: escrow.status },
              { icon: "user" as const, label: "Seller", value: escrow.withWho },
              { icon: "shield" as const, label: "Protected by", value: "CharLey Escrow" },
            ].map((row, i) => (
              <View key={row.label}>
                <View style={styles.detailRow}>
                  <View style={[styles.detailRowIcon, { backgroundColor: colors.surfaceElevated }]}>
                    <Feather name={row.icon} size={14} color={colors.primary} />
                  </View>
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={[styles.detailRowLabel, { color: colors.textMuted }]}>{row.label}</Text>
                    <Text style={[styles.detailRowValue, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{row.value}</Text>
                  </View>
                </View>
                {i < 2 && <Divider />}
              </View>
            ))}
          </Card>
          <Text style={[styles.stepsTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Deal Progress</Text>
          <View style={[styles.stepsCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {steps.map((step, i) => (
              <View key={step.label} style={styles.stepRow}>
                <View style={[styles.stepDot, { backgroundColor: step.done ? colors.primary : colors.surfaceElevated, borderColor: step.done ? colors.primary : colors.border }]}>
                  {step.done && <Feather name="check" size={10} color="#fff" />}
                </View>
                {i < steps.length - 1 && <View style={[styles.stepLine, { backgroundColor: steps[i + 1].done ? colors.primary : colors.border }]} />}
                <Text style={[styles.stepLabel, { color: step.done ? colors.text : colors.textMuted, fontFamily: step.done ? "Inter_600SemiBold" : "Inter_400Regular" }]}>{step.label}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
        {canRelease && (
          <View style={[styles.detailCTA, { backgroundColor: colors.surface, borderColor: colors.border, paddingBottom: insets.bottom + 12 }]}>
            <TouchableOpacity style={[styles.releaseBtn, { backgroundColor: colors.primary }]} onPress={() => { onRelease(escrow.id); onDismiss(); }} activeOpacity={0.8}>
              <Feather name="check-circle" size={18} color="#fff" />
              <Text style={[styles.releaseBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>{"  "}Yes, I Received It</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.problemBtn, { borderColor: colors.danger }]}>
              <Text style={[styles.problemBtnText, { color: colors.danger }]}>Report a Problem</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </Modal>
  );
}

// ─── Pay Screen ───────────────────────────────────────────────────────────────

const PL_STATUS_COLOR: Record<string, string> = {
  active:     "#00A884",
  in_escrow:  "#C8932A",
  completed:  "#27AE60",
  cancelled:  "#7F8C8D",
  disputed:   "#E74C3C",
};
const PL_STATUS_LABEL: Record<string, string> = {
  active:     "Active",
  in_escrow:  "In Escrow",
  completed:  "Completed",
  cancelled:  "Cancelled",
  disputed:   "Disputed",
};

export default function PayScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { escrows, balance, createEscrow, releaseEscrow, payLinks, createPayLink } = useApp();

  const [createVisible, setCreateVisible] = useState(false);
  const [sendVisible, setSendVisible] = useState(false);
  const [payLinkVisible, setPayLinkVisible] = useState(false);
  const [detail, setDetail] = useState<Escrow | null>(null);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMsg, setToastMsg] = useState({ message: "", sub: "" });

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const avatarColor = (name: string) => AVATAR_COLORS[name.charCodeAt(0) % AVATAR_COLORS.length];

  const handleSendSuccess = (amount: number, name: string, reference: string) => {
    setToastMsg({ message: `GH₵ ${amount.toLocaleString()} sent!`, sub: `To ${name} · ${reference}` });
    setToastVisible(true);
    setTimeout(() => setToastVisible(false), 4000);
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Toast */}
      <Toast visible={toastVisible} message={toastMsg.message} sub={toastMsg.sub} />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 8 }]}>
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Pay</Text>
        <TouchableOpacity style={[styles.newBtn, { backgroundColor: colors.primary }]} onPress={() => setCreateVisible(true)} activeOpacity={0.8}>
          <Feather name="plus" size={16} color="#fff" />
          <Text style={[styles.newBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}> New Deal</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Quick actions */}
        <View style={styles.quickGrid}>
          {[
            { icon: "lock" as const,      label: "Secure Deal",   sub: "Escrow protection",    onPress: () => setCreateVisible(true) },
            { icon: "send" as const,      label: "Send Money",    sub: "7 payment methods",    onPress: () => setSendVisible(true) },
            { icon: "smartphone" as const,label: "Mobile Top Up", sub: "Airtime & data",        onPress: () => setSendVisible(true) },
            { icon: "link" as const,      label: "Pay Link",      sub: "Create & share",        onPress: () => setPayLinkVisible(true) },
          ].map((qa) => (
            <TouchableOpacity
              key={qa.label}
              style={[styles.quickTile, { backgroundColor: colors.surface, borderColor: colors.border }]}
              activeOpacity={0.7}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); qa.onPress(); }}
            >
              <View style={[styles.quickIcon, { backgroundColor: colors.surfaceElevated }]}>
                <Feather name={qa.icon} size={20} color={colors.primary} />
              </View>
              <Text style={[styles.quickLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{qa.label}</Text>
              <Text style={[styles.quickSub, { color: colors.textMuted }]}>{qa.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* ── My Pay Links ─────────────────────────────────────────────── */}
        <View style={plscStyles.header}>
          <Text style={[plscStyles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>My Pay Links</Text>
          <TouchableOpacity
            style={[plscStyles.newLink, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "44" }]}
            onPress={() => { setPayLinkVisible(true); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
            activeOpacity={0.7}
          >
            <Feather name="plus" size={13} color={colors.primary} />
            <Text style={[plscStyles.newLinkText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}> New</Text>
          </TouchableOpacity>
        </View>

        {payLinks.length === 0 ? (
          <View style={[styles.empty, { backgroundColor: colors.surface, borderRadius: 14, borderWidth: 1, borderColor: colors.border, marginBottom: 16 }]}>
            <Feather name="link" size={24} color={colors.border} />
            <Text style={[styles.emptyText, { color: colors.textMuted }]}>No pay links yet — create one to start selling</Text>
          </View>
        ) : (
          <View style={[plscStyles.list, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {payLinks.map((pl, i) => {
              const statusColor = PL_STATUS_COLOR[pl.status] ?? colors.primary;
              return (
                <View key={pl.id}>
                  <TouchableOpacity
                    style={plscStyles.row}
                    activeOpacity={0.7}
                    onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); router.push(`/paylink/${pl.code}`); }}
                  >
                    <View style={[plscStyles.rowIcon, { backgroundColor: statusColor + "20" }]}>
                      <Feather
                        name={pl.status === "completed" ? "check-circle" : pl.status === "disputed" ? "alert-octagon" : pl.status === "in_escrow" ? "lock" : "link"}
                        size={18} color={statusColor}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[plscStyles.rowTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{pl.title}</Text>
                      <Text style={[plscStyles.rowSub, { color: colors.textMuted }]}>
                        {pl.amountStr} · {pl.createdAt}
                        {pl.buyerName ? ` · ${pl.buyerName}` : ""}
                      </Text>
                    </View>
                    <View style={[plscStyles.badge, { backgroundColor: statusColor + "18" }]}>
                      <Text style={[plscStyles.badgeText, { color: statusColor, fontFamily: "Inter_600SemiBold" }]}>
                        {PL_STATUS_LABEL[pl.status] ?? pl.status}
                      </Text>
                    </View>
                    <Feather name="chevron-right" size={16} color={colors.textMuted} style={{ marginLeft: 6 }} />
                  </TouchableOpacity>

                  {/* Preview as buyer shortcut */}
                  <TouchableOpacity
                    style={[plscStyles.previewRow, { borderTopColor: colors.border + "66" }]}
                    activeOpacity={0.65}
                    onPress={() => {
                      Haptics.selectionAsync();
                      router.push(`/guest-checkout?code=${pl.code}`);
                    }}
                  >
                    <Feather name="eye" size={12} color={colors.primary} />
                    <Text style={[plscStyles.previewText, { color: colors.primary }]}>Preview as buyer</Text>
                    <Feather name="arrow-right" size={11} color={colors.primary} />
                  </TouchableOpacity>

                  {i < payLinks.length - 1 && <View style={[plscStyles.divider, { backgroundColor: colors.border }]} />}
                </View>
              );
            })}
          </View>
        )}

        <SectionHeader title="Active Deals" action="View All" />
        <Card style={{ paddingVertical: 4 }}>
          {escrows.filter((e) => e.status !== "Completed").length === 0 ? (
            <View style={styles.empty}>
              <Feather name="inbox" size={28} color={colors.border} />
              <Text style={[styles.emptyText, { color: colors.textMuted }]}>No active deals</Text>
            </View>
          ) : (
            escrows.filter((e) => e.status !== "Completed").map((e, i, arr) => (
              <View key={e.id}>
                <EscrowRow title={e.title} withWho={e.withWho} amount={e.amount} status={e.status} tone={TONE_MAP[e.status]} color={avatarColor(e.withWho)} onPress={() => setDetail(e)} />
                {i < arr.length - 1 && <Divider />}
              </View>
            ))
          )}
        </Card>

        <SectionHeader title="Completed" />
        <Card style={{ paddingVertical: 4 }}>
          {escrows.filter((e) => e.status === "Completed").length === 0 ? (
            <View style={styles.empty}>
              <Text style={[styles.emptyText, { color: colors.textMuted }]}>No completed deals yet</Text>
            </View>
          ) : (
            escrows.filter((e) => e.status === "Completed").map((e, i, arr) => (
              <View key={e.id}>
                <EscrowRow title={e.title} withWho={e.withWho} amount={e.amount} status={e.status} tone="success" color={avatarColor(e.withWho)} />
                {i < arr.length - 1 && <Divider />}
              </View>
            ))
          )}
        </Card>
        <View style={{ height: 40 }} />
      </ScrollView>

      <SendMoneyModal
        visible={sendVisible}
        onDismiss={() => setSendVisible(false)}
        onSuccess={handleSendSuccess}
        balance={balance}
      />
      <CreateEscrowModal
        visible={createVisible}
        onDismiss={() => setCreateVisible(false)}
        onCreate={(data) => { createEscrow(data); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); setCreateVisible(false); }}
      />
      <CreatePayLinkModal
        visible={payLinkVisible}
        onDismiss={() => setPayLinkVisible(false)}
        onCreate={(title, desc, amount, delivery) => {
          const newCode = createPayLink(title, desc, amount, delivery);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          return newCode;
        }}
      />
      <EscrowDetailModal
        escrow={detail}
        onDismiss={() => setDetail(null)}
        onRelease={(id) => { releaseEscrow(id); Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); }}
      />
    </View>
  );
}

const plscStyles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  title: { fontSize: 16 },
  newLink: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 5 },
  newLinkText: { fontSize: 13 },
  list: { borderRadius: 16, borderWidth: 1, marginBottom: 20, overflow: "hidden" },
  row: { flexDirection: "row", alignItems: "center", padding: 14, gap: 12 },
  rowIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  rowTitle: { fontSize: 14, marginBottom: 2 },
  rowSub: { fontSize: 12 },
  badge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  badgeText: { fontSize: 11 },
  divider: { height: 1, marginHorizontal: 14 },
  previewRow: {
    flexDirection: "row", alignItems: "center", gap: 6,
    paddingHorizontal: 14, paddingVertical: 9, borderTopWidth: 1,
  },
  previewText: { flex: 1, fontSize: 12, fontFamily: "Inter_500Medium" },
});

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12 },
  screenTitle: { fontSize: 22, fontWeight: "800" },
  newBtn: { flexDirection: "row", alignItems: "center", borderRadius: 12, paddingVertical: 8, paddingHorizontal: 14 },
  newBtnText: { fontSize: 14 },
  scroll: { paddingHorizontal: 14, paddingTop: 16, paddingBottom: 100 },

  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 20 },
  quickTile: { width: "47.5%", borderRadius: 14, padding: 14, borderWidth: 1, alignItems: "flex-start" },
  quickIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center", marginBottom: 10 },
  quickLabel: { fontSize: 14, marginBottom: 3 },
  quickSub: { fontSize: 12 },

  empty: { alignItems: "center", paddingVertical: 24, gap: 8 },
  emptyText: { fontSize: 14 },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitle: { fontSize: 20, fontWeight: "800", marginBottom: 2 },
  sheetSub: { fontSize: 13, marginBottom: 16 },

  sendHeader: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 20 },
  sendHeaderIcon: { width: 46, height: 46, borderRadius: 14, alignItems: "center", justifyContent: "center" },

  fieldLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1, marginBottom: 8, fontFamily: "Inter_700Bold" },
  textInput: { borderWidth: 1.5, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15 },

  networkRow: { gap: 8, marginBottom: 18 },
  networkChip: { flexDirection: "row", alignItems: "center", borderRadius: 14, paddingVertical: 11, paddingHorizontal: 14, gap: 10 },
  networkDot: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  networkDotText: { fontWeight: "800" },
  networkLabel: { fontSize: 14, flex: 1 },

  phoneBox: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1.5, paddingHorizontal: 14, paddingVertical: 4, marginBottom: 10 },
  phonePrefix: { fontSize: 15, marginRight: 8, paddingVertical: 12 },
  phoneInput: { flex: 1, fontSize: 17, paddingVertical: 12, letterSpacing: 1 },
  lookupSpinner: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },

  recipientConfirm: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1, padding: 12, gap: 12, marginBottom: 10 },
  recipientAvatar: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  recipientAvatarText: { color: "#fff", fontSize: 14 },
  recipientName: { fontSize: 14 },
  recipientSub: { fontSize: 12, marginTop: 2 },

  amountBox: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1.5, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 8 },
  amountCurrency: { fontSize: 22, marginRight: 8 },
  amountInput: { flex: 1, fontSize: 34, padding: 0 },
  errorText: { fontSize: 12, marginBottom: 6 },

  quickAmounts: { flexDirection: "row", gap: 8, marginBottom: 14 },
  quickChip: { borderRadius: 20, paddingVertical: 6, paddingHorizontal: 14, borderWidth: 1 },
  quickChipText: { fontSize: 13 },

  noteInput: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 11, fontSize: 14, marginBottom: 14 },

  closeBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  confirmBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 15, marginBottom: 8 },
  confirmBtnText: { fontSize: 16 },
  cancelBtn: { alignItems: "center", paddingVertical: 10 },
  cancelText: { fontSize: 14 },

  // Confirm step
  confirmStep: { marginBottom: 12 },
  confirmNetBadge: { width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  confirmNetText: { fontSize: 14 },
  confirmTitle: { fontSize: 20, marginBottom: 18 },
  summaryCard: { borderRadius: 16, borderWidth: 1, marginBottom: 12, overflow: "hidden" },
  summaryRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12 },
  summaryIcon: { width: 32, height: 32, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  summaryLabel: { fontSize: 11, marginBottom: 2 },
  summaryValue: { fontSize: 14 },
  summaryDivider: { height: 1, marginHorizontal: 16 },
  feeNote: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, padding: 10, marginBottom: 4 },
  feeNoteText: { fontSize: 12 },

  // Success step
  receiptCard: { width: "100%", borderRadius: 14, borderWidth: 1, padding: 16, marginTop: 12, marginBottom: 4 },
  receiptRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 2 },
  receiptLabel: { fontSize: 13 },
  receiptValue: { fontSize: 14, textAlign: "right", maxWidth: "60%" },
  successStep: { alignItems: "center", paddingTop: 8 },
  successCircle: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center", marginBottom: 20 },
  successInner: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  successTitle: { fontSize: 24, marginBottom: 10 },
  successSub: { fontSize: 14, textAlign: "center", marginBottom: 20, lineHeight: 20, paddingHorizontal: 10 },
  successRef: { width: "100%", flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderRadius: 12, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 8 },
  successRefLabel: { fontSize: 13 },
  successRefCode: { fontSize: 13 },

  // Escrow note
  escrowNote: { flexDirection: "row", alignItems: "center", padding: 12, borderRadius: 10, marginBottom: 16 },
  escrowNoteText: { fontSize: 13 },

  // Escrow detail
  detailRoot: { flex: 1 },
  detailHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14 },
  detailHeaderTitle: { fontSize: 18 },
  lockBox: { borderRadius: 20, padding: 24, alignItems: "center", marginBottom: 20, borderWidth: 1 },
  lockIcon: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  lockTitle: { fontSize: 12, fontWeight: "700", letterSpacing: 1.5, marginBottom: 6 },
  lockAmount: { fontSize: 30, fontWeight: "800", marginBottom: 6 },
  lockFor: { fontSize: 12, marginBottom: 4 },
  lockItem: { fontSize: 16 },
  detailRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  detailRowIcon: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  detailRowLabel: { fontSize: 11, marginBottom: 2 },
  detailRowValue: { fontSize: 14 },
  stepsTitle: { fontSize: 13, marginBottom: 10, marginTop: 4 },
  stepsCard: { borderRadius: 14, padding: 16, borderWidth: 1, marginBottom: 20 },
  stepRow: { flexDirection: "row", alignItems: "center" },
  stepDot: { width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center", borderWidth: 2 },
  stepLine: { width: 2, height: 22, marginLeft: 10, marginRight: 12 },
  stepLabel: { fontSize: 13, marginLeft: 10 },
  detailCTA: { padding: 16, borderTopWidth: 1, gap: 10 },
  releaseBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 16 },
  releaseBtnText: { fontSize: 16 },
  problemBtn: { alignItems: "center", paddingVertical: 12, borderRadius: 12, borderWidth: 1 },
  problemBtnText: { fontSize: 14, fontWeight: "600" },

  // ── New: Send Money enhanced ──────────────────────────────────────────────
  balancePill: { flexDirection: "row", alignItems: "center", borderRadius: 20, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 8, marginBottom: 18, alignSelf: "flex-start" },
  balancePillText: { fontSize: 13 },

  typeGrid: { gap: 8, marginBottom: 8 },
  typeCard: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1, padding: 14, gap: 12 },
  typeIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  typeLabel: { fontSize: 14, marginBottom: 2 },
  typeSub: { fontSize: 12 },

  verifiedChip: { flexDirection: "row", alignItems: "center", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  verifiedChipText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },

  fpInfoBox: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, padding: 10, marginBottom: 6 },
  fpInfoText: { fontSize: 12 },

  bankPickerList: { borderRadius: 14, borderWidth: 1, marginBottom: 10, overflow: "hidden" },
  bankPickerItem: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1 },
  bankPickerItemText: { fontSize: 14 },

  sourceBox: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 14 },
  sourceLabel: { fontSize: 11 },
  sourceValue: { fontSize: 14, marginTop: 2 },

  errorBox: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, padding: 10, marginBottom: 8 },
  errorInlineText: { fontSize: 12, flex: 1 },

  stickyBottom: { paddingHorizontal: 0, paddingTop: 12, borderTopWidth: 1 },

  // ── Fee engine UI ─────────────────────────────────────────────────────────
  feePreview: { borderRadius: 12, borderWidth: 1, padding: 12, marginBottom: 14 },
  feePreviewRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 4 },
  feePreviewLabel: { fontSize: 12 },
  feePreviewValue: { fontSize: 12 },
  feePreviewDivider: { height: 1, marginVertical: 6 },
  tierBadge: { flexDirection: "row", alignItems: "center", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3, alignSelf: "flex-start" },
  tierBadgeText: { fontSize: 11 },
  feeBreakdown: { borderRadius: 14, borderWidth: 1, padding: 14, marginBottom: 10 },
  feeBreakdownTitle: { fontSize: 10, letterSpacing: 1.2, marginBottom: 10, fontFamily: "Inter_700Bold" },
  feeBreakdownRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 7 },
  feeBreakdownLabel: { fontSize: 12, flex: 1, paddingRight: 8 },
  feeBreakdownValue: { fontSize: 12 },
  feeBreakdownDivider: { height: 1, marginVertical: 8 },

  confirmAmountWrap: { alignItems: "center", marginBottom: 20, paddingVertical: 16 },
  confirmAmountLabel: { fontSize: 13, marginBottom: 4 },
  confirmAmountValue: { fontSize: 42, lineHeight: 50 },
  confirmAmountTo: { fontSize: 14, marginTop: 4 },
});
