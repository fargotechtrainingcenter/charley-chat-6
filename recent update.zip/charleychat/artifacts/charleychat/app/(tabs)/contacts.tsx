import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Platform,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { customFetch } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

interface SavedContact {
  id: string;
  contactUserId: string;
  isFavorite: boolean;
  contactPhone: string;
  contactName: string;
  contactAvatar?: string;
  nickname?: string;
}

const AVATAR_COLORS = ["#12D9A0", "#3B82F6", "#10B981", "#F59E0B", "#EC4899"];
function getAvatarColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function Avatar({ name, uri, size = 44 }: { name: string; uri?: string; size?: number }) {
  const initials = name.split(" ").filter(Boolean).map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const color = getAvatarColor(name);
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: "center", justifyContent: "center", backgroundColor: color + "22" }}>
      <Text style={{ fontSize: size * 0.36, color, fontFamily: "Inter_700Bold" }}>{initials}</Text>
    </View>
  );
}

export default function ContactsScreenWeb() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const [contacts, setContacts] = useState<SavedContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState("");

  const loadContacts = useCallback(async () => {
    try {
      const data = await customFetch<SavedContact[]>("/api/contacts");
      setContacts(data);
    } catch { /* ignore */ }
    finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { loadContacts(); }, [loadContacts]);

  const handleRemove = async (id: string) => {
    try {
      await customFetch(`/api/contacts/${id}`, { method: "DELETE" });
      setContacts(prev => prev.filter(c => c.id !== id));
    } catch { /* ignore */ }
  };

  const filtered = contacts.filter(c => {
    const q = query.toLowerCase();
    return !q || c.contactName.toLowerCase().includes(q) || c.contactPhone.includes(q) || (c.nickname ?? "").toLowerCase().includes(q);
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 16, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Contacts</Text>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => router.push("/(tabs)/discover" as any)}
          activeOpacity={0.8}
        >
          <Feather name="user-plus" size={16} color="#fff" />
          <Text style={[styles.addBtnText, { fontFamily: "Inter_600SemiBold" }]}>Add</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      {contacts.length > 0 && (
        <View style={[styles.searchBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={[styles.searchWrap, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
            <Feather name="search" size={15} color={colors.textMuted} />
            <TextInput
              style={[styles.searchInput, { color: colors.text, fontFamily: "Inter_400Regular" }]}
              placeholder="Search contacts…"
              placeholderTextColor={colors.textMuted}
              value={query}
              onChangeText={setQuery}
            />
            {query.length > 0 && (
              <TouchableOpacity onPress={() => setQuery("")}><Feather name="x" size={14} color={colors.textMuted} /></TouchableOpacity>
            )}
          </View>
        </View>
      )}

      {loading ? (
        <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : filtered.length === 0 ? (
        <View style={styles.center}>
          <Feather name="users" size={44} color={colors.textMuted} style={{ marginBottom: 14 }} />
          <Text style={[styles.emptyTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
            {query ? `No results for "${query}"` : "No contacts yet"}
          </Text>
          <Text style={[styles.emptySub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            {query ? "Try a different name or number" : "Find people on CharLey and add them here."}
          </Text>
          {!query && (
            <TouchableOpacity
              style={[styles.discoverBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push("/(tabs)/discover" as any)}
              activeOpacity={0.8}
            >
              <Feather name="compass" size={16} color="#fff" />
              <Text style={[styles.discoverBtnText, { fontFamily: "Inter_600SemiBold" }]}>Find People</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={c => c.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 100 }]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadContacts(); }} />}
          ItemSeparatorComponent={() => <View style={[styles.sep, { backgroundColor: colors.border }]} />}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <Avatar name={item.contactName} uri={item.contactAvatar} size={46} />
              <View style={styles.info}>
                <Text style={[styles.name, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>
                  {item.nickname || item.contactName}
                </Text>
                <Text style={[styles.phone, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                  {item.contactPhone}
                </Text>
              </View>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: colors.primary + "18" }]}
                  onPress={() => router.push(`/chat/${item.contactUserId}` as never)}
                  activeOpacity={0.7}
                >
                  <Feather name="message-circle" size={16} color={colors.primary} />
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: "#EF444418" }]}
                  onPress={() => handleRemove(item.id)}
                  activeOpacity={0.7}
                >
                  <Feather name="user-minus" size={15} color="#EF4444" />
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1 },
  header:         { paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  headerTitle:    { fontSize: 24 },
  addBtn:         { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 12 },
  addBtnText:     { color: "#fff", fontSize: 14 },
  searchBar:      { paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  searchWrap:     { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth },
  searchInput:    { flex: 1, fontSize: 14, padding: 0 },
  list:           { paddingTop: 4 },
  row:            { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  info:           { flex: 1, gap: 2 },
  name:           { fontSize: 15 },
  phone:          { fontSize: 12 },
  actions:        { flexDirection: "row", gap: 8 },
  actionBtn:      { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  sep:            { height: StyleSheet.hairlineWidth, marginLeft: 74 },
  center:         { flex: 1, alignItems: "center", justifyContent: "center", padding: 32 },
  emptyTitle:     { fontSize: 18, marginBottom: 8, textAlign: "center" },
  emptySub:       { fontSize: 14, textAlign: "center", lineHeight: 20, marginBottom: 20 },
  discoverBtn:    { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  discoverBtnText:{ color: "#fff", fontSize: 15 },
});
