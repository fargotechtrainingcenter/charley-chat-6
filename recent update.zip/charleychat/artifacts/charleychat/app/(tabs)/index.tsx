import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { NotificationBell } from "@/components/NotificationBell";
import { CallHistoryIcon } from "@/components/CallHistoryIcon";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp, Conversation } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const FILTER_TABS = ["All", "Unread", "Groups", "Business"] as const;
type FilterTab = typeof FILTER_TABS[number];

// ─── Networks & banks ─────────────────────────────────────────────────────────
const NETWORKS = [
  { id: "mtn",        label: "MTN MoMo",    short: "MTN",  color: "#FFCC00", fg: "#1A1A1A" },
  { id: "telecel",    label: "Telecel Cash", short: "TEL",  color: "#C0392B", fg: "#fff"    },
  { id: "airteltigo", label: "AirtelTigo",  short: "Tigo", color: "#E4002B", fg: "#fff"    },
  { id: "charley",    label: "CharLey",     short: "CL",   color: "#12D9A0", fg: "#fff"    },
  { id: "bank",       label: "Bank",        short: "BNK",  color: "#2980B9", fg: "#fff"    },
];

// ─── Right-panel sections ─────────────────────────────────────────────────────
const PANEL_SECTIONS = [
  {
    title: "Payments",
    items: [
      { key: "contact",    icon: "user",           label: "New Chat",           color: "#60A5FA" },
      { key: "send_money", icon: "dollar-sign",    label: "Send Money",         color: "#4ADE80" },
      { key: "request",    icon: "trending-up",    label: "Request Payment",    color: "#5EEAD4" },
      { key: "paylink",    icon: "link",           label: "Pay Link",           color: "#F472B6" },
      { key: "qr",         icon: "grid",           label: "QR Payment",         color: "#60A5FA" },
      { key: "invoice",    icon: "file-text",      label: "Invoice",            color: "#2DD4BF" },
      { key: "add_money",  icon: "plus-circle",    label: "Add Money",          color: "#34D399" },
      { key: "withdraw",   icon: "arrow-down-circle", label: "Withdraw Funds",  color: "#FB923C" },
      { key: "merchant",   icon: "briefcase",      label: "Merchant Payment",   color: "#818CF8" },
      { key: "split",      icon: "users",          label: "Split Payment",      color: "#F472B6" },
    ],
  },
  {
    title: "Utilities",
    items: [
      { key: "airtime", icon: "phone-call", label: "Airtime Top-up", color: "#FBBF24" },
      { key: "data",    icon: "wifi",       label: "Data Top-up",    color: "#34D399" },
    ],
  },
  {
    title: "Deals",
    items: [
      { key: "escrow",        icon: "shield",       label: "Secure Deal",      color: "#FBBF24" },
      { key: "release_funds", icon: "unlock",       label: "Release Funds",    color: "#4ADE80" },
      { key: "mydeals",       icon: "briefcase",    label: "My Deals",         color: "#5EEAD4" },
      { key: "catalog",       icon: "shopping-bag", label: "Catalog",          color: "#F87171" },
    ],
  },
  {
    title: "Tools",
    items: [
      { key: "schedule", icon: "calendar",    label: "Scheduled Payments", color: "#60A5FA" },
      { key: "poll",     icon: "bar-chart-2", label: "Poll",               color: "#FB923C" },
      { key: "ai",       icon: "zap",         label: "AI Assistant",       color: "#5EEAD4" },
    ],
  },
] as const;

// ─── Quick Access grid ────────────────────────────────────────────────────────
const QUICK_ACCESS = [
  { key: "wallet",      icon: "credit-card",      label: "Wallet" },
  { key: "send_money",  icon: "send",             label: "Send Money" },
  { key: "request",     icon: "download",         label: "Request" },
  { key: "escrow",      icon: "shield",           label: "Escrow" },
  { key: "history",     icon: "clock",            label: "History" },
  { key: "vault",       icon: "check-circle",     label: "Vault" },
  { key: "pay_bills",   icon: "file-text",        label: "Pay Bills" },
  { key: "airtime",     icon: "smartphone",       label: "Top Up" },
  { key: "catalog",     icon: "shopping-bag",     label: "Marketplace" },
  { key: "more",        icon: "grid",             label: "More" },
] as const;

// ─── Adinkra watermarks ───────────────────────────────────────────────────────
const WATERMARKS = [
  { symbol: "⊕", top: 40,  left: 20,  size: 90,  rotate: "10deg"  },
  { symbol: "◈", top: 180, left: 200, size: 70,  rotate: "-8deg"  },
  { symbol: "✦", top: 300, left: 30,  size: 60,  rotate: "25deg"  },
  { symbol: "⊛", top: 420, left: 160, size: 80,  rotate: "-12deg" },
  { symbol: "❋", top: 540, left: 10,  size: 65,  rotate: "18deg"  },
  { symbol: "⊕", top: 640, left: 210, size: 75,  rotate: "-6deg"  },
];

// ─── Story avatar ─────────────────────────────────────────────────────────────
function StoryAvatar({
  name, initials, color, isAdd, hasUnviewed, avatarUrl, onPress,
}: {
  name: string; initials: string; color: string;
  isAdd?: boolean; hasUnviewed?: boolean; avatarUrl?: string | null; onPress?: () => void;
}) {
  const colors = useColors();
  const ringColor = isAdd ? colors.border : hasUnviewed ? colors.primary : colors.textMuted;
  return (
    <TouchableOpacity style={styles.storyItem} activeOpacity={0.7} onPress={onPress}>
      <View style={[styles.storyRing, { borderColor: ringColor }]}>
        <View style={[styles.storyAvatar, { backgroundColor: isAdd ? colors.surfaceElevated : color }]}>
          {isAdd ? (
            <Feather name="plus" size={18} color={colors.primary} />
          ) : avatarUrl ? (
            <Image source={{ uri: avatarUrl }} style={styles.storyAvatarImg} />
          ) : (
            <Text style={[styles.storyInitials, { color: "#fff" }]}>{initials}</Text>
          )}
        </View>
      </View>
      <Text style={[styles.storyName, { color: colors.textMuted }]} numberOfLines={1}>{name}</Text>
    </TouchableOpacity>
  );
}

// ─── Payment pill ─────────────────────────────────────────────────────────────
function PaymentPill({ amount, status }: { amount: string; status: "locked" | "delivered" | "awaiting" }) {
  const colors = useColors();
  const config = {
    locked:    { bg: colors.goldDim,         fg: colors.gold,    icon: "lock" as const,         label: amount },
    delivered: { bg: colors.successBg,       fg: colors.success, icon: "check-circle" as const, label: "Delivered" },
    awaiting:  { bg: "rgba(0,168,132,0.12)", fg: colors.primary, icon: "clock" as const,        label: amount },
  };
  const c = config[status];
  return (
    <View style={[styles.paymentPill, { backgroundColor: c.bg }]}>
      <Feather name={c.icon} size={10} color={c.fg} />
      <Text style={[styles.paymentPillText, { color: c.fg }]}> {c.label}</Text>
    </View>
  );
}

// ─── Chat row ─────────────────────────────────────────────────────────────────
function ChatRow({ conv }: { conv: Conversation }) {
  const colors = useColors();
  const router = useRouter();
  return (
    <TouchableOpacity
      style={styles.chatRow}
      activeOpacity={0.7}
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        router.push(`/chat/${conv.id}` as never);
      }}
    >
      <View style={[styles.chatAvatar, { backgroundColor: conv.color }]}>
        <Text style={styles.chatAvatarText}>{conv.initials}</Text>
        {conv.verified && (
          <View style={[styles.verifiedBadge, { backgroundColor: colors.primary }]}>
            <Feather name="check" size={8} color="#fff" />
          </View>
        )}
      </View>
      <View style={styles.chatBody}>
        <View style={styles.chatTopRow}>
          <Text style={[styles.chatName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>
            {conv.name}
          </Text>
          <Text style={[styles.chatTime, { color: colors.textMuted }]}>{conv.time}</Text>
        </View>
        <View style={styles.chatBottomRow}>
          <Text style={[styles.chatPreview, { color: colors.textMuted }]} numberOfLines={1}>
            {conv.lastMessage}
          </Text>
          {conv.unread > 0 ? (
            <View style={[styles.unreadBadge, { backgroundColor: colors.primary }]}>
              <Text style={styles.unreadText}>{conv.unread > 9 ? "9+" : conv.unread}</Text>
            </View>
          ) : conv.paymentAmount ? (
            <PaymentPill amount={conv.paymentAmount} status={conv.paymentStatus ?? "awaiting"} />
          ) : null}
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ─── Send Money Sheet ─────────────────────────────────────────────────────────
function SendMoneySheet({
  visible, onClose, balance,
}: {
  visible: boolean;
  onClose: () => void;
  balance: number;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;
  const { sendMobileMoney } = useApp();

  const [step, setStep] = useState<"pick" | "form" | "done">("pick");
  const [selectedNet, setSelectedNet] = useState<typeof NETWORKS[0] | null>(null);
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [err, setErr] = useState("");
  const [sending, setSending] = useState(false);

  const reset = () => {
    setStep("pick"); setSelectedNet(null); setPhone(""); setAmount(""); setNote(""); setErr(""); setSending(false);
  };

  const handleClose = () => { reset(); onClose(); };

  const handleSend = async () => {
    const amt = parseFloat(amount);
    if (!phone.trim() || phone.length < 9) { setErr("Enter a valid phone number."); return; }
    if (!amt || amt <= 0) { setErr("Enter a valid amount."); return; }
    if (amt > balance) { setErr("Insufficient balance."); return; }
    setSending(true);
    setErr("");
    try {
      await sendMobileMoney(amt, phone.trim(), selectedNet?.id ?? "phone", note || undefined);
      setStep("done");
    } catch (e: any) {
      setErr(e?.response?.data?.error ?? e?.message ?? "Transfer failed. Please try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={handleClose} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {step === "pick" && (
            <>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 4 }]}>Send Money</Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 18 }]}>Choose where to send to</Text>
              <View style={styles.networkGrid}>
                {NETWORKS.map((net) => (
                  <TouchableOpacity
                    key={net.id}
                    style={[styles.networkCard, { backgroundColor: net.color + "18", borderColor: net.color + "55" }]}
                    onPress={() => { setSelectedNet(net); setStep("form"); Haptics.selectionAsync(); }}
                    activeOpacity={0.75}
                  >
                    <View style={[styles.networkDot, { backgroundColor: net.color }]}>
                      <Text style={[styles.networkShort, { color: net.fg }]}>{net.short}</Text>
                    </View>
                    <Text style={[styles.networkLabel, { color: colors.text }]}>{net.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {step === "form" && (
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.sheetBackRow}>
                <TouchableOpacity onPress={() => setStep("pick")} style={styles.backBtn}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <View style={[styles.networkDot, { backgroundColor: selectedNet?.color ?? colors.primary }]}>
                  <Text style={[styles.networkShort, { color: selectedNet?.fg ?? "#fff", fontSize: 10 }]}>{selectedNet?.short}</Text>
                </View>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", fontSize: 17 }]}>{selectedNet?.label}</Text>
              </View>

              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>PHONE / ACCOUNT NUMBER</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="024 000 0000"
                placeholderTextColor={colors.textMuted}
                keyboardType="phone-pad"
                value={phone}
                onChangeText={(t) => { setPhone(t); setErr(""); }}
                autoFocus
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="0.00"
                placeholderTextColor={colors.textMuted}
                keyboardType="decimal-pad"
                value={amount}
                onChangeText={(t) => { setAmount(t); setErr(""); }}
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>NOTE (OPTIONAL)</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="What's it for?"
                placeholderTextColor={colors.textMuted}
                value={note}
                onChangeText={setNote}
              />
              {err ? <Text style={[styles.errText, { color: colors.danger }]}>{err}</Text> : null}
              <View style={styles.balanceHint}>
                <Feather name="info" size={12} color={colors.textMuted} />
                <Text style={[styles.balanceHintText, { color: colors.textMuted }]}>Balance: GH₵ {balance.toLocaleString()}</Text>
              </View>
              <TouchableOpacity
                style={[styles.ctaBtn, { backgroundColor: phone && amount ? colors.primary : colors.surfaceElevated }]}
                onPress={handleSend}
                activeOpacity={0.8}
              >
                <Feather name="send" size={16} color={phone && amount ? "#fff" : colors.textMuted} />
                <Text style={[styles.ctaBtnText, { color: phone && amount ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                  {" "}Send Money
                </Text>
              </TouchableOpacity>
            </ScrollView>
          )}

          {step === "done" && (
            <View style={styles.doneWrap}>
              <View style={[styles.doneIcon, { backgroundColor: colors.successBg }]}>
                <Feather name="check-circle" size={36} color={colors.success} />
              </View>
              <Text style={[styles.doneTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Sent!</Text>
              <Text style={[styles.doneSub, { color: colors.textMuted }]}>GH₵ {amount} sent to {phone}</Text>
              <TouchableOpacity style={[styles.ctaBtn, { backgroundColor: colors.primary, marginTop: 24 }]} onPress={handleClose} activeOpacity={0.8}>
                <Text style={[styles.ctaBtnText, { color: "#fff", fontFamily: "Inter_600SemiBold" }]}>Done</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Pay Link Sheet ───────────────────────────────────────────────────────────
function PayLinkSheet({
  visible, onClose, createPayLink,
}: {
  visible: boolean;
  onClose: () => void;
  createPayLink: (title: string, description: string, amount: number, delivery?: string) => string;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;

  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const [err, setErr] = useState("");

  const reset = () => { setTitle(""); setDesc(""); setAmount(""); setCreatedCode(null); setErr(""); };
  const handleClose = () => { reset(); onClose(); };

  const handleCreate = () => {
    if (!title.trim()) { setErr("Enter a link title."); return; }
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setErr("Enter a valid amount."); return; }
    const code = createPayLink(title.trim(), desc.trim(), amt);
    setCreatedCode(code);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={handleClose} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {!createdCode ? (
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.sheetIconRow}>
                <View style={[styles.sheetIconWrap, { backgroundColor: "#F472B618" }]}>
                  <Feather name="link" size={22} color="#F472B6" />
                </View>
                <View>
                  <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Create Pay Link</Text>
                  <Text style={[styles.sheetSub, { color: colors.textMuted }]}>Generate & share a payment link</Text>
                </View>
              </View>

              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>LINK TITLE</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="e.g. iPhone 15 Payment"
                placeholderTextColor={colors.textMuted}
                value={title}
                onChangeText={(t) => { setTitle(t); setErr(""); }}
                autoFocus
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="0.00"
                placeholderTextColor={colors.textMuted}
                keyboardType="decimal-pad"
                value={amount}
                onChangeText={(t) => { setAmount(t); setErr(""); }}
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>DESCRIPTION (OPTIONAL)</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="What's this payment for?"
                placeholderTextColor={colors.textMuted}
                value={desc}
                onChangeText={setDesc}
              />
              {err ? <Text style={[styles.errText, { color: colors.danger }]}>{err}</Text> : null}
              <TouchableOpacity
                style={[styles.ctaBtn, { backgroundColor: title && amount ? "#F472B6" : colors.surfaceElevated }]}
                onPress={handleCreate}
                activeOpacity={0.8}
              >
                <Feather name="link-2" size={16} color={title && amount ? "#fff" : colors.textMuted} />
                <Text style={[styles.ctaBtnText, { color: title && amount ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                  {" "}Generate Link
                </Text>
              </TouchableOpacity>
            </ScrollView>
          ) : (
            <View style={styles.doneWrap}>
              <View style={[styles.doneIcon, { backgroundColor: "#F472B618" }]}>
                <Feather name="link-2" size={32} color="#F472B6" />
              </View>
              <Text style={[styles.doneTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Link Created!</Text>
              <Text style={[styles.doneSub, { color: colors.textMuted }]}>Share this code with your customer</Text>
              <View style={[styles.linkCodeBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.primary + "44" }]}>
                <Text style={[styles.linkCode, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>{createdCode}</Text>
              </View>
              <TouchableOpacity
                style={[styles.ctaBtn, { backgroundColor: "#F472B6", marginTop: 8 }]}
                onPress={() => { Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); handleClose(); }}
                activeOpacity={0.8}
              >
                <Feather name="share-2" size={16} color="#fff" />
                <Text style={[styles.ctaBtnText, { color: "#fff", fontFamily: "Inter_600SemiBold" }]}>{" "}Share Link</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleClose} style={{ marginTop: 12, alignItems: "center" }}>
                <Text style={[{ color: colors.textMuted, fontSize: 13 }]}>Done</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Secure Deal Sheet ────────────────────────────────────────────────────────
function SecureDealSheet({
  visible, onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;
  const router = useRouter();

  const [dealTitle, setDealTitle] = useState("");
  const [partyPhone, setPartyPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");

  const reset = () => { setDealTitle(""); setPartyPhone(""); setAmount(""); setDesc(""); };
  const handleClose = () => { reset(); onClose(); };

  const handleCreate = () => {
    if (!dealTitle.trim() || !partyPhone.trim() || !amount.trim()) {
      Alert.alert("Required", "Please fill in all required fields.");
      return;
    }
    handleClose();
    router.push("/(tabs)/escrow" as never);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={handleClose} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <View style={styles.sheetIconRow}>
              <View style={[styles.sheetIconWrap, { backgroundColor: colors.goldDim }]}>
                <Feather name="shield" size={22} color={colors.gold} />
              </View>
              <View>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Secure Deal</Text>
                <Text style={[styles.sheetSub, { color: colors.textMuted }]}>Protected escrow transaction</Text>
              </View>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>DEAL TITLE *</Text>
            <TextInput
              style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
              placeholder="e.g. MacBook Pro Purchase"
              placeholderTextColor={colors.textMuted}
              value={dealTitle}
              onChangeText={setDealTitle}
              autoFocus
            />
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>OTHER PARTY PHONE *</Text>
            <TextInput
              style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
              placeholder="024 000 0000"
              placeholderTextColor={colors.textMuted}
              keyboardType="phone-pad"
              value={partyPhone}
              onChangeText={setPartyPhone}
            />
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵) *</Text>
            <TextInput
              style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
              placeholder="0.00"
              placeholderTextColor={colors.textMuted}
              keyboardType="decimal-pad"
              value={amount}
              onChangeText={setAmount}
            />
            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>DEAL DESCRIPTION</Text>
            <TextInput
              style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border, height: 72, textAlignVertical: "top" }]}
              placeholder="Describe the deal terms..."
              placeholderTextColor={colors.textMuted}
              value={desc}
              onChangeText={setDesc}
              multiline
            />

            <View style={[styles.escrowNote, { backgroundColor: colors.goldDim, borderColor: colors.gold + "33" }]}>
              <Feather name="info" size={14} color={colors.gold} />
              <Text style={[styles.escrowNoteText, { color: colors.gold }]}>
                Funds are locked until both parties confirm delivery.
              </Text>
            </View>

            <TouchableOpacity
              style={[styles.ctaBtn, { backgroundColor: dealTitle && partyPhone && amount ? colors.gold : colors.surfaceElevated }]}
              onPress={handleCreate}
              activeOpacity={0.8}
            >
              <Feather name="shield" size={16} color={dealTitle && partyPhone && amount ? "#1A1A1A" : colors.textMuted} />
              <Text style={[styles.ctaBtnText, { color: dealTitle && partyPhone && amount ? "#1A1A1A" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                {" "}Start Secure Deal
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Airtime / Data Sheet ─────────────────────────────────────────────────────
function TopupSheet({
  visible, onClose, mode,
}: {
  visible: boolean;
  onClose: () => void;
  mode: "airtime" | "data";
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;

  const [selectedNet, setSelectedNet] = useState<typeof NETWORKS[0] | null>(null);
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");

  const reset = () => { setSelectedNet(null); setPhone(""); setAmount(""); };
  const handleClose = () => { reset(); onClose(); };

  const QUICK_AMOUNTS = mode === "airtime"
    ? ["2", "5", "10", "20", "50"]
    : ["5", "10", "20", "50"];

  const DATA_BUNDLES = [
    { label: "1 GB", price: "5", validity: "1 day" },
    { label: "3 GB", price: "10", validity: "7 days" },
    { label: "5 GB", price: "15", validity: "30 days" },
    { label: "10 GB", price: "25", validity: "30 days" },
    { label: "20 GB", price: "40", validity: "30 days" },
  ];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={handleClose} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
            <View style={styles.sheetIconRow}>
              <View style={[styles.sheetIconWrap, { backgroundColor: mode === "airtime" ? "#FBBF2418" : "#34D39918" }]}>
                <Feather name={mode === "airtime" ? "phone-call" : "wifi"} size={22} color={mode === "airtime" ? "#FBBF24" : "#34D399"} />
              </View>
              <View>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                  {mode === "airtime" ? "Airtime Top-up" : "Data Top-up"}
                </Text>
                <Text style={[styles.sheetSub, { color: colors.textMuted }]}>Quick, instant recharge</Text>
              </View>
            </View>

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>NETWORK</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
              <View style={{ flexDirection: "row", gap: 10 }}>
                {NETWORKS.filter((n) => n.id !== "charley" && n.id !== "bank").map((net) => (
                  <TouchableOpacity
                    key={net.id}
                    style={[styles.netPill, {
                      backgroundColor: selectedNet?.id === net.id ? net.color : net.color + "18",
                      borderColor: net.color + (selectedNet?.id === net.id ? "ff" : "55"),
                    }]}
                    onPress={() => { setSelectedNet(net); Haptics.selectionAsync(); }}
                    activeOpacity={0.75}
                  >
                    <Text style={[styles.netPillText, { color: selectedNet?.id === net.id ? net.fg : colors.text }]}>{net.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>PHONE NUMBER</Text>
            <TextInput
              style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
              placeholder="024 000 0000"
              placeholderTextColor={colors.textMuted}
              keyboardType="phone-pad"
              value={phone}
              onChangeText={setPhone}
            />

            {mode === "airtime" ? (
              <>
                <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
                  {QUICK_AMOUNTS.map((q) => (
                    <TouchableOpacity
                      key={q}
                      style={[styles.quickAmtBtn, {
                        backgroundColor: amount === q ? colors.primary : colors.surfaceElevated,
                        borderColor: amount === q ? colors.primary : colors.border,
                      }]}
                      onPress={() => { setAmount(q); Haptics.selectionAsync(); }}
                      activeOpacity={0.75}
                    >
                      <Text style={[styles.quickAmtText, { color: amount === q ? "#fff" : colors.text }]}>GH₵ {q}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                <TextInput
                  style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                  placeholder="Or enter custom amount"
                  placeholderTextColor={colors.textMuted}
                  keyboardType="decimal-pad"
                  value={amount}
                  onChangeText={setAmount}
                />
              </>
            ) : (
              <>
                <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>SELECT BUNDLE</Text>
                {DATA_BUNDLES.map((b) => (
                  <TouchableOpacity
                    key={b.label}
                    style={[styles.bundleRow, {
                      backgroundColor: amount === b.price ? colors.primary + "18" : colors.surfaceElevated,
                      borderColor: amount === b.price ? colors.primary : colors.border,
                    }]}
                    onPress={() => { setAmount(b.price); Haptics.selectionAsync(); }}
                    activeOpacity={0.75}
                  >
                    <View>
                      <Text style={[styles.bundleLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{b.label}</Text>
                      <Text style={[styles.bundleValidity, { color: colors.textMuted }]}>Valid {b.validity}</Text>
                    </View>
                    <Text style={[styles.bundlePrice, { color: amount === b.price ? colors.primary : colors.textMuted, fontFamily: "Inter_700Bold" }]}>
                      GH₵ {b.price}
                    </Text>
                  </TouchableOpacity>
                ))}
              </>
            )}

            <TouchableOpacity
              style={[styles.ctaBtn, {
                backgroundColor: phone && amount && selectedNet ? (mode === "airtime" ? "#FBBF24" : "#34D399") : colors.surfaceElevated,
                marginTop: 8,
              }]}
              onPress={() => {
                if (!phone || !amount || !selectedNet) return;
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                Alert.alert("Coming Soon", "Airtime/data top-up is being set up. Try again soon!");
                handleClose();
              }}
              activeOpacity={0.8}
            >
              <Feather name={mode === "airtime" ? "phone-call" : "wifi"} size={16} color={phone && amount && selectedNet ? "#1A1A1A" : colors.textMuted} />
              <Text style={[styles.ctaBtnText, { color: phone && amount && selectedNet ? "#1A1A1A" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                {" "}Top Up Now
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Pay Bills Sheet ────────────────────────────────────────────────────────
const BILLERS = [
  { id: "electricity", icon: "zap" as const, label: "Electricity (ECG)", color: "#FBBF24" },
  { id: "water", icon: "droplet" as const, label: "Water (GWCL)", color: "#38BDF8" },
  { id: "tv", icon: "tv" as const, label: "TV (DSTV/GOtv)", color: "#5EEAD4" },
  { id: "internet", icon: "wifi" as const, label: "Internet", color: "#34D399" },
];

function PayBillSheet({
  visible, onClose, balance,
}: {
  visible: boolean;
  onClose: () => void;
  balance: number;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;
  const { payBill } = useApp();

  const [step, setStep] = useState<"pick" | "form" | "done">("pick");
  const [selectedBiller, setSelectedBiller] = useState<typeof BILLERS[0] | null>(null);
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const [paying, setPaying] = useState(false);

  const reset = () => {
    setStep("pick"); setSelectedBiller(null); setAccountNumber(""); setAmount(""); setPin(""); setErr(""); setPaying(false);
  };
  const handleClose = () => { reset(); onClose(); };

  const handlePay = async () => {
    const amt = parseFloat(amount);
    if (!accountNumber.trim()) { setErr("Enter your account/meter number."); return; }
    if (!amt || amt <= 0) { setErr("Enter a valid amount."); return; }
    if (amt > balance) { setErr("Insufficient balance."); return; }
    if (!pin.trim() || pin.trim().length < 4) { setErr("Enter your 4-digit PIN."); return; }
    setPaying(true);
    setErr("");
    try {
      await payBill(selectedBiller!.id, selectedBiller!.label, accountNumber.trim(), amt, pin.trim());
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setStep("done");
    } catch (e: any) {
      setErr(e?.response?.data?.error ?? e?.message ?? "Payment failed. Please try again.");
    } finally {
      setPaying(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={handleClose}>
      <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={handleClose} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {step === "pick" && (
            <>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 4 }]}>Pay Bills</Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted, marginBottom: 18 }]}>Choose a biller to pay</Text>
              <View style={styles.networkGrid}>
                {BILLERS.map((b) => (
                  <TouchableOpacity
                    key={b.id}
                    style={[styles.networkCard, { backgroundColor: b.color + "18", borderColor: b.color + "55" }]}
                    onPress={() => { setSelectedBiller(b); setStep("form"); Haptics.selectionAsync(); }}
                    activeOpacity={0.75}
                  >
                    <View style={[styles.networkDot, { backgroundColor: b.color }]}>
                      <Feather name={b.icon} size={16} color="#1A1A1A" />
                    </View>
                    <Text style={[styles.networkLabel, { color: colors.text }]}>{b.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {step === "form" && (
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.sheetBackRow}>
                <TouchableOpacity onPress={() => setStep("pick")} style={styles.backBtn}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <View style={[styles.networkDot, { backgroundColor: selectedBiller?.color ?? colors.primary }]}>
                  <Feather name={selectedBiller?.icon ?? "file-text"} size={14} color="#1A1A1A" />
                </View>
                <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", fontSize: 17 }]}>{selectedBiller?.label}</Text>
              </View>

              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>ACCOUNT / METER NUMBER</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="Enter account number"
                placeholderTextColor={colors.textMuted}
                keyboardType="default"
                value={accountNumber}
                onChangeText={(t) => { setAccountNumber(t); setErr(""); }}
                autoFocus
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT (GH₵)</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="0.00"
                placeholderTextColor={colors.textMuted}
                keyboardType="decimal-pad"
                value={amount}
                onChangeText={(t) => { setAmount(t); setErr(""); }}
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>WALLET PIN</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="••••"
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                secureTextEntry
                maxLength={4}
                value={pin}
                onChangeText={(t) => { setPin(t); setErr(""); }}
              />
              {err ? <Text style={[styles.errText, { color: colors.danger }]}>{err}</Text> : null}
              <View style={styles.balanceHint}>
                <Feather name="info" size={12} color={colors.textMuted} />
                <Text style={[styles.balanceHintText, { color: colors.textMuted }]}>Balance: GH₵ {balance.toLocaleString()}</Text>
              </View>
              <TouchableOpacity
                style={[styles.ctaBtn, { backgroundColor: accountNumber && amount && pin && !paying ? colors.primary : colors.surfaceElevated }]}
                onPress={handlePay}
                disabled={paying}
                activeOpacity={0.8}
              >
                {paying ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <>
                    <Feather name="file-text" size={16} color={accountNumber && amount && pin ? "#fff" : colors.textMuted} />
                    <Text style={[styles.ctaBtnText, { color: accountNumber && amount && pin ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                      {" "}Pay Bill
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            </ScrollView>
          )}

          {step === "done" && (
            <View style={styles.doneWrap}>
              <View style={[styles.doneIcon, { backgroundColor: colors.successBg }]}>
                <Feather name="check-circle" size={36} color={colors.success} />
              </View>
              <Text style={[styles.doneTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Bill Paid!</Text>
              <Text style={[styles.doneSub, { color: colors.textMuted }]}>GH₵ {amount} paid to {selectedBiller?.label}</Text>
              <TouchableOpacity style={[styles.ctaBtn, { backgroundColor: colors.primary, marginTop: 24 }]} onPress={handleClose} activeOpacity={0.8}>
                <Text style={[styles.ctaBtnText, { color: "#fff", fontFamily: "Inter_600SemiBold" }]}>Done</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function ChatsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    conversations, escrows, balance, addContact, logout,
    currentUser, storyGroups, myStories, sendMobileMoney, createPayLink,
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<FilterTab>("All");
  const [showMenu, setShowMenu] = useState(false);
  const [menuSection, setMenuSection] = useState<"main" | "profile" | "escrows">("main");
  const [showAddContact, setShowAddContact] = useState(false);
  const [contactName, setContactName] = useState("");
  const [contactPhone, setContactPhone] = useState("");

  // Inline panel sheets
  const [showSendSheet, setShowSendSheet] = useState(false);
  const [showPayLinkSheet, setShowPayLinkSheet] = useState(false);
  const [showEscrowSheet, setShowEscrowSheet] = useState(false);
  const [showAirtimeSheet, setShowAirtimeSheet] = useState(false);
  const [showDataSheet, setShowDataSheet] = useState(false);
  const [showPayBillSheet, setShowPayBillSheet] = useState(false);

  // Quick Access panel (dropdown grid under header)
  const [quickAccessOpen, setQuickAccessOpen] = useState(false);
  const [showMorePanel, setShowMorePanel] = useState(false);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;

  const firstName = (currentUser?.name ?? "there").split(" ")[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const totalUnread = conversations.reduce((s, c) => s + c.unread, 0);

  const filtered = conversations.filter((c) => {
    if (activeFilter === "All") return true;
    if (activeFilter === "Unread") return c.unread > 0;
    if (activeFilter === "Groups") return c.type === "group";
    if (activeFilter === "Business") return c.type === "business";
    return true;
  });

  const businessUserIds = new Set(
    conversations.filter((c) => c.type === "business").map((c) => c.id)
  );

  const pinnedConv = activeFilter === "All" && filtered.length > 0 ? filtered[0] : null;
  const unpinnedFiltered = pinnedConv ? filtered.slice(1) : filtered;

  const visibleStoryGroups = storyGroups.filter((g) => {
    if (g.isMe) return false;
    if (activeFilter === "All") return true;
    if (activeFilter === "Unread") return g.hasUnviewed;
    if (activeFilter === "Groups") return false;
    if (activeFilter === "Business") return businessUserIds.has(g.userId);
    return true;
  });

  const openQuickAccess = () => {
    setQuickAccessOpen(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const closeQuickAccess = () => {
    setQuickAccessOpen(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const toggleQuickAccess = () => (quickAccessOpen ? closeQuickAccess() : openQuickAccess());

  const openMenu = () => {
    setMenuSection("main");
    setShowMenu(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const [addingContact, setAddingContact] = useState(false);
  const [addContactError, setAddContactError] = useState("");

  const handleAddContact = async () => {
    if (!contactName.trim() || !contactPhone.trim()) return;
    setAddingContact(true);
    setAddContactError("");
    const userId = await addContact(contactName.trim(), contactPhone.trim());
    setAddingContact(false);
    if (!userId) {
      setAddContactError("Phone number not found. Make sure they're registered on CharLey.");
      return;
    }
    setContactName(""); setContactPhone("");
    setShowAddContact(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.push(`/chat/${userId}` as never);
  };

  const totalEscrowVol = escrows.reduce((s, e) => s + e.amountRaw, 0);
  const activeEscrows = escrows.filter((e) => e.status === "In Escrow" || e.status === "Pending Release");

  const handlePanelItem = (key: string) => {
    closeQuickAccess();
    Haptics.selectionAsync();
    switch (key) {
      case "contact":
        setTimeout(() => setShowAddContact(true), 300);
        break;
      case "wallet":
        router.push("/(tabs)/wallet" as never);
        break;
      case "send_money":
        setTimeout(() => setShowSendSheet(true), 300);
        break;
      case "request":
        setTimeout(() => setShowPayLinkSheet(true), 300);
        break;
      case "paylink":
        setTimeout(() => setShowPayLinkSheet(true), 300);
        break;
      case "escrow":
        setTimeout(() => setShowEscrowSheet(true), 300);
        break;
      case "history":
        router.push("/(tabs)/activities" as never);
        break;
      case "vault":
        Alert.alert("Vault", "Secure savings Vault is coming soon.");
        break;
      case "pay_bills":
        setTimeout(() => setShowPayBillSheet(true), 300);
        break;
      case "airtime":
        setTimeout(() => setShowAirtimeSheet(true), 300);
        break;
      case "data":
        setTimeout(() => setShowDataSheet(true), 300);
        break;
      case "add_money":
        router.push("/(tabs)/wallet" as never);
        break;
      case "withdraw":
        router.push("/(tabs)/wallet" as never);
        break;
      case "merchant":
        router.push("/(tabs)/wallet" as never);
        break;
      case "split":
        Alert.alert("Split Payment", "Split Payment is coming soon.");
        break;
      case "release_funds":
        router.push("/(tabs)/activities" as never);
        break;
      case "mydeals":
        router.push("/(tabs)/activities" as never);
        break;
      case "catalog":
        router.push("/(tabs)/market" as never);
        break;
      case "invoice":
        router.push("/invoice" as never);
        break;
      case "schedule":
        Alert.alert("Scheduled Payments", "Scheduled Payments is coming soon.");
        break;
      case "more":
        setShowMorePanel(true);
        break;
      default:
        Alert.alert("Coming Soon", "This feature is coming soon.");
    }
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>

      {/* ── Header ────────────────────────────────────────────────────────── */}
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <View style={styles.headerTopRow}>
          <Image source={require("../../assets/images/logo.png")} style={styles.headerLogoSmall} resizeMode="contain" />
        </View>
        <View style={styles.headerMainRow}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.greetingText, { color: colors.text, fontFamily: "Inter_700Bold" }]} numberOfLines={1}>
              {greeting}, {firstName} 👋
            </Text>
            <Text style={[styles.greetingSub, { color: colors.textMuted }]}>
              {totalUnread > 0 ? `${totalUnread} unread chat${totalUnread === 1 ? "" : "s"}` : "You're all caught up"}
            </Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerIcon} onPress={toggleQuickAccess} activeOpacity={0.7}>
              <Feather name={quickAccessOpen ? "chevron-up" : "chevron-down"} size={20} color={colors.primary} />
            </TouchableOpacity>
            <CallHistoryIcon size={19} color={colors.text} />
            <NotificationBell size={19} color={colors.text} />
            <TouchableOpacity style={styles.headerIcon} activeOpacity={0.7}>
              <Feather name="search" size={19} color={colors.text} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerIcon} onPress={openMenu} activeOpacity={0.7}>
              <Feather name="more-vertical" size={19} color={colors.text} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={[styles.searchBar, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
          <Feather name="search" size={15} color={colors.textMuted} />
          <TextInput
            style={[styles.searchInput, { color: colors.text, fontFamily: "Inter_400Regular" }]}
            placeholder="Search chats, users, groups..."
            placeholderTextColor={colors.textMuted}
          />
          <Feather name="sliders" size={15} color={colors.textMuted} />
        </View>

        {/* ── Quick Access dropdown ─────────────────────────────────────── */}
        {quickAccessOpen && (
          <View style={[styles.quickAccessCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
            <View style={styles.quickAccessHeader}>
              <Text style={[styles.quickAccessTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Quick Access</Text>
              <TouchableOpacity onPress={() => setShowMorePanel(true)} activeOpacity={0.7}>
                <Text style={[styles.quickAccessEdit, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Edit</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.quickAccessGrid}>
              {QUICK_ACCESS.map((item) => (
                <TouchableOpacity
                  key={item.key}
                  style={styles.quickAccessItem}
                  onPress={() => handlePanelItem(item.key)}
                  activeOpacity={0.75}
                >
                  <View style={[styles.quickAccessIconBox, { backgroundColor: colors.primary + "1E", borderColor: colors.primary + "40" }]}>
                    <Feather name={item.icon as keyof typeof Feather.glyphMap} size={19} color={colors.primary} />
                  </View>
                  <Text style={[styles.quickAccessLabel, { color: colors.textMuted }]} numberOfLines={1}>
                    {item.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}
      </View>

      {/* ── Main content area ──────────────────────────────────────────────── */}
      <View style={{ flex: 1 }}>

        {/* Adinkra watermark layer */}
        <View style={StyleSheet.absoluteFill} pointerEvents="none">
          {WATERMARKS.map((w, i) => (
            <Text
              key={i}
              style={{
                position: "absolute",
                top: w.top,
                left: w.left,
                fontSize: w.size,
                color: colors.primary,
                opacity: 0.04,
                transform: [{ rotate: w.rotate }],
              }}
            >
              {w.symbol}
            </Text>
          ))}
        </View>

        <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
          {/* ── Status row ───────────────────────────────────────────────── */}
          <View style={[styles.statusSection, { borderBottomColor: colors.border }]}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.storiesScroll}>
              <StoryAvatar
                name={myStories.length > 0 ? "My Status" : "Add Status"}
                initials={currentUser?.name?.slice(0, 2).toUpperCase() ?? "ME"}
                color="#128C7E"
                isAdd={myStories.length === 0}
                hasUnviewed={myStories.length > 0}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  if (myStories.length > 0) {
                    router.push(`/story/${myStories[0].id}` as never);
                  } else {
                    router.push("/status/create" as never);
                  }
                }}
              />
              {visibleStoryGroups.map((g) => (
                <StoryAvatar
                  key={g.userId}
                  name={g.userName}
                  initials={g.userInitials}
                  color={g.userColor}
                  avatarUrl={g.userAvatarUrl}
                  hasUnviewed={g.hasUnviewed}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    router.push(`/story/${g.stories[0].id}` as never);
                  }}
                />
              ))}
            </ScrollView>
          </View>

          {/* ── Filter tabs ──────────────────────────────────────────────── */}
          <View style={[styles.filterBar, { borderBottomColor: colors.border }]}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterScroll}>
              {FILTER_TABS.map((f) => (
                <TouchableOpacity
                  key={f}
                  style={[styles.filterChip, {
                    backgroundColor: activeFilter === f ? colors.primary : colors.surfaceElevated,
                    borderColor: activeFilter === f ? colors.primary : "transparent",
                  }]}
                  onPress={() => { setActiveFilter(f); Haptics.selectionAsync(); }}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.filterChipText, {
                    color: activeFilter === f ? "#fff" : colors.textMuted,
                    fontFamily: activeFilter === f ? "Inter_600SemiBold" : "Inter_400Regular",
                  }]}>{f}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* ── Chat list ────────────────────────────────────────────────── */}
          <View style={{ backgroundColor: "transparent" }}>
            {filtered.length === 0 ? (
              <View style={styles.emptyChats}>
                <Feather name={activeFilter === "Groups" ? "users" : "message-circle"} size={40} color={colors.textDim} />
                <Text style={[styles.emptyChatsTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                  {activeFilter === "Groups" ? "No group chats yet" : "No conversations yet"}
                </Text>
                <Text style={[styles.emptyChatsHint, { color: colors.textDim }]}>
                  {activeFilter === "Groups" ? "Join or create a group" : "Tap + to start chatting"}
                </Text>
                {activeFilter === "Groups" && (
                  <TouchableOpacity
                    style={[styles.browseGroupsBtn, { backgroundColor: colors.primary }]}
                    onPress={() => router.push("/groups" as never)}
                    activeOpacity={0.85}
                  >
                    <Feather name="users" size={16} color="#fff" />
                    <Text style={styles.browseGroupsBtnText}>Browse Groups</Text>
                  </TouchableOpacity>
                )}
              </View>
            ) : (
              <>
                {pinnedConv && (
                  <View style={styles.pinnedSection}>
                    <View style={styles.pinnedHeaderRow}>
                      <Feather name="bookmark" size={12} color={colors.primary} />
                      <Text style={[styles.pinnedHeaderText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                        PINNED
                      </Text>
                    </View>
                    <ChatRow conv={pinnedConv} />
                    <View style={[styles.chatDivider, { backgroundColor: colors.divider, marginLeft: 74 }]} />
                  </View>
                )}
                {unpinnedFiltered.map((conv, i) => (
                  <View key={conv.id}>
                    <ChatRow conv={conv} />
                    {i < unpinnedFiltered.length - 1 && (
                      <View style={[styles.chatDivider, { backgroundColor: colors.divider, marginLeft: 74 }]} />
                    )}
                  </View>
                ))}
              </>
            )}
          </View>

          <View style={{ height: 120 }} />
        </ScrollView>

        {/* ── FAB ───────────────────────────────────────────────────────── */}
        <TouchableOpacity
          style={[styles.fab, { backgroundColor: colors.primary, bottom: botPad + 90 }]}
          activeOpacity={0.85}
          onPress={() => {
            setShowAddContact(true);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          }}
        >
          <Feather name="message-circle" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* ── More tools sheet ─────────────────────────────────────────────── */}
      <Modal visible={showMorePanel} transparent animationType="slide" onRequestClose={() => setShowMorePanel(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowMorePanel(false)} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24), maxHeight: "80%" }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 12 }]}>More Tools</Text>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 16 }}>
            {PANEL_SECTIONS.map((section) => (
              <View key={section.title} style={styles.panelSection}>
                <Text style={[styles.panelSectionTitle, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                  {section.title}
                </Text>
                {section.items.map((item) => (
                  <TouchableOpacity
                    key={item.key}
                    style={styles.panelRow}
                    onPress={() => { setShowMorePanel(false); setTimeout(() => handlePanelItem(item.key), 250); }}
                    activeOpacity={0.7}
                  >
                    <View style={[styles.panelIconBox, { borderColor: item.color + "55", backgroundColor: item.color + "12" }]}>
                      <Feather name={item.icon as keyof typeof Feather.glyphMap} size={18} color={item.color} />
                    </View>
                    <Text style={[styles.panelLabel, { color: colors.text, fontFamily: "Inter_400Regular" }]}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            ))}
          </ScrollView>
        </View>
      </Modal>

      {/* ── ⋮ Menu sheet ──────────────────────────────────────────────────── */}
      <Modal visible={showMenu} transparent animationType="slide" onRequestClose={() => setShowMenu(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowMenu(false)} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {menuSection === "main" && (
            <>
              <View style={[styles.menuProfileCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                <View style={[styles.menuAvatar, { backgroundColor: colors.primary }]}>
                  <Text style={[styles.menuAvatarText, { fontFamily: "Inter_700Bold" }]}>
                    {currentUser?.name?.slice(0, 2).toUpperCase() ?? "AK"}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.menuName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                    {currentUser?.name ?? "Ama Kofi"}
                  </Text>
                  <Text style={[styles.menuPhone, { color: colors.textMuted }]}>
                    {currentUser?.phone ?? "—"}
                  </Text>
                </View>
                <View style={[styles.menuBalancePill, { backgroundColor: colors.primary + "20" }]}>
                  <Text style={[styles.menuBalanceText, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
                    GH₵ {balance.toLocaleString()}
                  </Text>
                </View>
              </View>

              {[
                { icon: "user",     label: "My Profile",       sub: "Settings, privacy & referral",                                    onPress: () => setMenuSection("profile") },
                { icon: "shield",   label: "My Escrows",        sub: `${activeEscrows.length} active · GH₵ ${totalEscrowVol.toLocaleString()} total`, onPress: () => setMenuSection("escrows"), color: colors.gold },
                { icon: "user-plus",label: "Add Contact",       sub: "Start a new conversation",                                        onPress: () => { setShowMenu(false); setTimeout(() => setShowAddContact(true), 200); } },
                { icon: "star",     label: "Starred Messages",  sub: "Coming soon",                                                      onPress: () => {} },
              ].map((item) => (
                <TouchableOpacity
                  key={item.label}
                  style={[styles.menuItem, { borderColor: colors.border }]}
                  onPress={() => { Haptics.selectionAsync(); item.onPress(); }}
                  activeOpacity={0.7}
                >
                  <View style={[styles.menuItemIcon, { backgroundColor: (item.color ?? colors.primary) + "18" }]}>
                    <Feather name={item.icon as keyof typeof Feather.glyphMap} size={18} color={item.color ?? colors.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.menuItemLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{item.label}</Text>
                    <Text style={[styles.menuItemSub, { color: colors.textMuted }]}>{item.sub}</Text>
                  </View>
                  <Feather name="chevron-right" size={16} color={colors.textMuted} />
                </TouchableOpacity>
              ))}

              <TouchableOpacity
                style={[styles.signOutBtn, { borderColor: colors.danger + "44" }]}
                onPress={() => logout()}
                activeOpacity={0.7}
              >
                <Feather name="log-out" size={16} color={colors.danger} />
                <Text style={[styles.signOutText, { color: colors.danger, fontFamily: "Inter_600SemiBold" }]}> Sign Out</Text>
              </TouchableOpacity>
            </>
          )}

          {menuSection === "profile" && (
            <>
              <View style={styles.subHeader}>
                <TouchableOpacity onPress={() => setMenuSection("main")} style={styles.backBtn}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <Text style={[styles.subTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>My Profile</Text>
              </View>
              {[
                { label: "Full Name",     value: currentUser?.name ?? "—",                              icon: "user"   },
                { label: "Phone",         value: currentUser?.phone ?? "—",                             icon: "phone"  },
                { label: "User ID",       value: currentUser?.userId ?? "—",                            icon: "hash"   },
                { label: "Account Level", value: currentUser?.verified ? "Verified ✓" : "Unverified",   icon: "shield" },
              ].map((row) => (
                <View key={row.label} style={[styles.profileRow, { borderColor: colors.border, backgroundColor: colors.surfaceElevated }]}>
                  <Feather name={row.icon as keyof typeof Feather.glyphMap} size={16} color={colors.textMuted} />
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={[styles.profileRowLabel, { color: colors.textMuted }]}>{row.label}</Text>
                    <Text style={[styles.profileRowValue, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{row.value}</Text>
                  </View>
                </View>
              ))}
              <View style={[styles.profileRow, { borderColor: colors.border, backgroundColor: colors.surfaceElevated, marginTop: 14 }]}>
                <Feather name="bell" size={16} color={colors.textMuted} />
                <Text style={[styles.profileRowLabel, { color: colors.text, marginLeft: 12, flex: 1 }]}>Notifications</Text>
                <Switch value={true} onValueChange={() => Haptics.selectionAsync()} trackColor={{ true: colors.primary }} />
              </View>
              <View style={[styles.profileRow, { borderColor: colors.border, backgroundColor: colors.surfaceElevated }]}>
                <Feather name="eye-off" size={16} color={colors.textMuted} />
                <Text style={[styles.profileRowLabel, { color: colors.text, marginLeft: 12, flex: 1 }]}>Hide Balance</Text>
                <Switch value={false} onValueChange={() => Haptics.selectionAsync()} trackColor={{ true: colors.primary }} />
              </View>
            </>
          )}

          {menuSection === "escrows" && (
            <>
              <View style={styles.subHeader}>
                <TouchableOpacity onPress={() => setMenuSection("main")} style={styles.backBtn}>
                  <Feather name="arrow-left" size={18} color={colors.textMuted} />
                </TouchableOpacity>
                <Text style={[styles.subTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>My Escrows</Text>
              </View>
              {escrows.length === 0 ? (
                <View style={styles.emptyState}>
                  <Feather name="shield" size={32} color={colors.textMuted} />
                  <Text style={[styles.emptyText, { color: colors.textMuted }]}>No escrow deals yet</Text>
                </View>
              ) : (
                escrows.map((e) => (
                  <View key={e.id} style={[styles.escrowRow, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                    <View style={[styles.escrowRowIcon, { backgroundColor: e.status === "Completed" ? colors.successBg : colors.goldDim }]}>
                      <Feather name={e.status === "Completed" ? "check-circle" : "lock"} size={16} color={e.status === "Completed" ? colors.success : colors.gold} />
                    </View>
                    <View style={{ flex: 1, marginLeft: 12 }}>
                      <Text style={[styles.escrowRowTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{e.title}</Text>
                      <Text style={[styles.escrowRowSub, { color: colors.textMuted }]}>{e.withWho} · {e.amount}</Text>
                    </View>
                    <View style={[styles.escrowRowStatus, { backgroundColor: e.status === "Completed" ? colors.successBg : colors.goldDim }]}>
                      <Text style={[styles.escrowRowStatusText, { color: e.status === "Completed" ? colors.success : colors.gold }]}>{e.status}</Text>
                    </View>
                  </View>
                ))
              )}
            </>
          )}
        </View>
      </Modal>

      {/* ── Add Contact sheet ─────────────────────────────────────────────── */}
      <Modal visible={showAddContact} transparent animationType="slide" onRequestClose={() => setShowAddContact(false)}>
        <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={() => setShowAddContact(false)} />
          <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) }]}>
            <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <View style={styles.addContactHeader}>
                <View style={[styles.addContactIcon, { backgroundColor: colors.primary + "20" }]}>
                  <Feather name="user-plus" size={22} color={colors.primary} />
                </View>
                <View>
                  <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Add Contact</Text>
                  <Text style={[styles.sheetSub, { color: colors.textMuted }]}>Start a new conversation</Text>
                </View>
              </View>
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>FULL NAME</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="e.g. Kofi Mensah"
                placeholderTextColor={colors.textMuted}
                value={contactName}
                onChangeText={setContactName}
                autoFocus
              />
              <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>PHONE NUMBER</Text>
              <TextInput
                style={[styles.fieldInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="233 24 000 0000"
                placeholderTextColor={colors.textMuted}
                keyboardType="phone-pad"
                value={contactPhone}
                onChangeText={setContactPhone}
              />
              {addContactError ? (
                <Text style={{ color: "#F59E0B", fontSize: 12, fontFamily: "Inter_400Regular", marginBottom: 8, textAlign: "center" }}>
                  {addContactError}
                </Text>
              ) : null}
              <TouchableOpacity
                style={[styles.ctaBtn, { backgroundColor: contactName && contactPhone && !addingContact ? colors.primary : colors.surfaceElevated }]}
                onPress={handleAddContact}
                activeOpacity={0.8}
                disabled={addingContact}
              >
                <Feather name="message-circle" size={16} color={contactName && contactPhone && !addingContact ? "#fff" : colors.textMuted} />
                <Text style={[styles.ctaBtnText, { color: contactName && contactPhone && !addingContact ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                  {" "}{addingContact ? "Adding…" : "Start Chat"}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* ── Inline action sheets ───────────────────────────────────────────── */}
      <SendMoneySheet
        visible={showSendSheet}
        onClose={() => setShowSendSheet(false)}
        balance={balance}
      />
      <PayLinkSheet
        visible={showPayLinkSheet}
        onClose={() => setShowPayLinkSheet(false)}
        createPayLink={createPayLink}
      />
      <SecureDealSheet
        visible={showEscrowSheet}
        onClose={() => setShowEscrowSheet(false)}
      />
      <TopupSheet
        visible={showAirtimeSheet}
        onClose={() => setShowAirtimeSheet(false)}
        mode="airtime"
      />
      <TopupSheet
        visible={showDataSheet}
        onClose={() => setShowDataSheet(false)}
        mode="data"
      />
      <PayBillSheet
        visible={showPayBillSheet}
        onClose={() => setShowPayBillSheet(false)}
        balance={balance}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerTopRow: { flexDirection: "row", alignItems: "center", marginBottom: 6 },
  headerLogoSmall: { width: 26, height: 26 },
  headerMainRow: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  greetingText: { fontSize: 19 },
  greetingSub: { fontSize: 12, marginTop: 2 },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 2 },
  headerIcon: { padding: 6 },

  searchBar: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
  searchInput: { flex: 1, fontSize: 13 },

  quickAccessCard: { marginTop: 12, borderRadius: 16, borderWidth: 1, padding: 14 },
  quickAccessHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  quickAccessTitle: { fontSize: 14 },
  quickAccessEdit: { fontSize: 12 },
  quickAccessGrid: { flexDirection: "row", flexWrap: "wrap" },
  quickAccessItem: { width: "20%" as any, alignItems: "center", marginBottom: 14, gap: 6 },
  quickAccessIconBox: { width: 46, height: 46, borderRadius: 14, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  quickAccessLabel: { fontSize: 10, textAlign: "center" },

  pinnedSection: { paddingTop: 4, paddingBottom: 6 },
  pinnedHeaderRow: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingBottom: 6 },
  pinnedHeaderText: { fontSize: 10, letterSpacing: 1 },

  statusSection: { borderBottomWidth: 1 },
  storiesScroll: { paddingHorizontal: 12, paddingVertical: 12, gap: 14 },
  storyItem: { alignItems: "center", width: 58 },
  storyRing: { width: 56, height: 56, borderRadius: 28, borderWidth: 2, padding: 2, marginBottom: 4 },
  storyAvatar: { flex: 1, borderRadius: 25, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  storyAvatarImg: { width: "100%" as any, height: "100%" as any, borderRadius: 25 },
  storyInitials: { fontSize: 16, fontWeight: "700", fontFamily: "Inter_700Bold" },
  storyName: { fontSize: 10, textAlign: "center", fontFamily: "Inter_400Regular" },

  filterBar: { borderBottomWidth: 1 },
  filterScroll: { paddingHorizontal: 12, paddingVertical: 10, gap: 8 },
  filterChip: { borderRadius: 20, paddingVertical: 5, paddingHorizontal: 14, borderWidth: 1 },
  filterChipText: { fontSize: 13 },

  chatRow: { flexDirection: "row", paddingHorizontal: 14, paddingVertical: 10, alignItems: "center" },
  chatAvatar: { width: 50, height: 50, borderRadius: 25, alignItems: "center", justifyContent: "center" },
  chatAvatarText: { color: "#fff", fontSize: 16, fontWeight: "700", fontFamily: "Inter_700Bold" },
  verifiedBadge: { position: "absolute", bottom: 0, right: 0, width: 16, height: 16, borderRadius: 8, alignItems: "center", justifyContent: "center", borderWidth: 1.5, borderColor: "#070C14" },
  chatBody: { flex: 1, marginLeft: 12 },
  chatTopRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 3 },
  chatName: { flex: 1, fontSize: 15, marginRight: 8 },
  chatTime: { fontSize: 12 },
  chatBottomRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  chatPreview: { flex: 1, fontSize: 13, marginRight: 8 },
  unreadBadge: { minWidth: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center", paddingHorizontal: 5 },
  unreadText: { color: "#fff", fontSize: 11, fontWeight: "700" },
  paymentPill: { flexDirection: "row", alignItems: "center", paddingHorizontal: 7, paddingVertical: 3, borderRadius: 20 },
  paymentPillText: { fontSize: 10, fontWeight: "700" },
  chatDivider: { height: 1 },

  emptyChats: { alignItems: "center", paddingTop: 80, gap: 10 },
  emptyChatsTitle: { fontSize: 16 },
  emptyChatsHint: { fontSize: 13 },
  browseGroupsBtn: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  browseGroupsBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold" },

  panelSection: { marginBottom: 4 },
  panelSectionTitle: { fontSize: 11, letterSpacing: 1, paddingHorizontal: 4, paddingTop: 14, paddingBottom: 4 },
  panelRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 4, paddingVertical: 10, gap: 14 },
  panelIconBox: { width: 38, height: 38, borderRadius: 10, borderWidth: 1.5, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  panelLabel: { fontSize: 14 },

  fab: { position: "absolute", right: 20, width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOpacity: 0.3, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 6 },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitle: { fontSize: 20, fontWeight: "800" },
  sheetSub: { fontSize: 13, marginTop: 2 },
  sheetIconRow: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 18 },
  sheetIconWrap: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  sheetBackRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 18 },

  menuProfileCard: { flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1, padding: 14, marginBottom: 16, gap: 12 },
  menuAvatar: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center" },
  menuAvatarText: { color: "#fff", fontSize: 17, fontWeight: "800" },
  menuName: { fontSize: 15 },
  menuPhone: { fontSize: 12, marginTop: 2 },
  menuBalancePill: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 5 },
  menuBalanceText: { fontSize: 13 },
  menuItem: { flexDirection: "row", alignItems: "center", paddingVertical: 13, borderBottomWidth: 1, gap: 12 },
  menuItemIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  menuItemLabel: { fontSize: 14 },
  menuItemSub: { fontSize: 12, marginTop: 1 },
  signOutBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", marginTop: 16, borderWidth: 1, borderRadius: 14, paddingVertical: 13 },
  signOutText: { fontSize: 15 },

  subHeader: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 18 },
  backBtn: { padding: 4 },
  subTitle: { fontSize: 18, fontWeight: "800" },
  profileRow: { flexDirection: "row", alignItems: "center", borderRadius: 12, borderWidth: 1, padding: 14, marginBottom: 8 },
  profileRowLabel: { fontSize: 11, marginBottom: 2 },
  profileRowValue: { fontSize: 14 },
  escrowRow: { flexDirection: "row", alignItems: "center", borderRadius: 12, borderWidth: 1, padding: 12, marginBottom: 8 },
  escrowRowIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  escrowRowTitle: { fontSize: 14 },
  escrowRowSub: { fontSize: 12, marginTop: 2 },
  escrowRowStatus: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  escrowRowStatusText: { fontSize: 11, fontWeight: "700" },
  emptyState: { alignItems: "center", paddingVertical: 30, gap: 8 },
  emptyText: { fontSize: 14 },

  addContactHeader: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 22 },
  addContactIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  fieldLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1, marginBottom: 8, marginTop: 4 },
  fieldInput: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, marginBottom: 14 },
  ctaBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 15, marginTop: 4 },
  ctaBtnText: { fontSize: 16 },

  // Send money sheets
  networkGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 8 },
  networkCard: { width: "30%" as any, alignItems: "center", paddingVertical: 14, borderRadius: 14, borderWidth: 1.5, gap: 8 },
  networkDot: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  networkShort: { fontSize: 11, fontWeight: "700" },
  networkLabel: { fontSize: 11, textAlign: "center" },
  errText: { fontSize: 13, marginBottom: 10 },
  balanceHint: { flexDirection: "row", alignItems: "center", gap: 5, marginBottom: 14 },
  balanceHintText: { fontSize: 12 },

  doneWrap: { alignItems: "center", paddingVertical: 24 },
  doneIcon: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  doneTitle: { fontSize: 22, marginBottom: 6 },
  doneSub: { fontSize: 14, textAlign: "center" },

  linkCodeBox: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 20, paddingVertical: 12, marginTop: 16, marginBottom: 8 },
  linkCode: { fontSize: 18, letterSpacing: 2, textAlign: "center" },

  // Topup
  netPill: { borderRadius: 20, paddingVertical: 7, paddingHorizontal: 16, borderWidth: 1.5 },
  netPillText: { fontSize: 13, fontWeight: "600" },
  quickAmtBtn: { borderRadius: 10, paddingVertical: 8, paddingHorizontal: 14, borderWidth: 1 },
  quickAmtText: { fontSize: 13, fontWeight: "600" },
  bundleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 12, borderWidth: 1, padding: 14, marginBottom: 8 },
  bundleLabel: { fontSize: 14 },
  bundleValidity: { fontSize: 11, marginTop: 2 },
  bundlePrice: { fontSize: 16 },

  // Escrow note
  escrowNote: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 10, padding: 12, borderWidth: 1, marginBottom: 14 },
  escrowNoteText: { fontSize: 12, flex: 1, lineHeight: 17 },
});
