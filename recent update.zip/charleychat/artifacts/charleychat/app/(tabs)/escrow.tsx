import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Card, Divider, EscrowRow, Pill, SectionHeader, StatTile } from "@/components/FargoComponents";
import { Escrow, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const STATUS_FILTERS = ["All", "In Escrow", "Completed", "Pending Release", "Disputed"] as const;
type FilterType = typeof STATUS_FILTERS[number];

export default function EscrowScreen() {
  const colors = useColors();
  const { escrows, createEscrow, releaseEscrow } = useApp();
  const insets = useSafeAreaInsets();
  const [filter, setFilter] = useState<FilterType>("All");
  const [createVisible, setCreateVisible] = useState(false);
  const [detailEscrow, setDetailEscrow] = useState<Escrow | null>(null);

  const active = escrows.filter(
    (e) => e.status === "In Escrow" || e.status === "Pending Release"
  ).length;
  const completed = escrows.filter((e) => e.status === "Completed").length;

  const filtered =
    filter === "All" ? escrows : escrows.filter((e) => e.status === filter);

  return (
    <View style={[styles.root, { backgroundColor: colors.parchment }]}>
      <View
        style={[
          styles.headerBar,
          { backgroundColor: colors.parchment, borderBottomColor: colors.border },
        ]}
      >
        <Text
          style={[styles.screenTitle, { color: colors.indigoDeep, fontFamily: "Inter_700Bold" }]}
        >
          Escrow
        </Text>
        <TouchableOpacity
          style={[styles.newBtn, { backgroundColor: colors.gold }]}
          onPress={() => setCreateVisible(true)}
          activeOpacity={0.8}
        >
          <Feather name="plus" size={16} color={colors.indigoDeep} />
          <Text style={[styles.newBtnText, { color: colors.indigoDeep, fontFamily: "Inter_700Bold" }]}>
            New
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statRow}>
          <StatTile label="Active" value={String(active)} sub="In Progress" subTone="indigo" />
          <StatTile label="Completed" value={String(completed)} sub="All Time" subTone="success" />
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {STATUS_FILTERS.map((f) => (
            <TouchableOpacity
              key={f}
              style={[
                styles.filterChip,
                {
                  backgroundColor: filter === f ? colors.indigo : colors.white,
                  borderColor: filter === f ? colors.indigo : colors.border,
                },
              ]}
              onPress={() => {
                setFilter(f);
                Haptics.selectionAsync();
              }}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.filterText,
                  {
                    color: filter === f ? colors.white : colors.inkSoft,
                    fontFamily: filter === f ? "Inter_700Bold" : "Inter_500Medium",
                  },
                ]}
              >
                {f}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SectionHeader title={`${filter === "All" ? "All" : filter} Escrows`} />
        <Card style={{ paddingVertical: 4 }}>
          {filtered.length === 0 ? (
            <View style={styles.emptyState}>
              <Feather name="inbox" size={32} color={colors.border} />
              <Text style={[styles.emptyText, { color: colors.inkSoft }]}>
                No escrows found
              </Text>
            </View>
          ) : (
            filtered.map((e, i) => (
              <View key={e.id}>
                <EscrowRow
                  title={e.title}
                  withWho={e.withWho}
                  amount={e.amount}
                  status={e.status}
                  tone={e.tone}
                  onPress={() => setDetailEscrow(e)}
                />
                {i < filtered.length - 1 && <Divider />}
              </View>
            ))
          )}
        </Card>

        <Card
          style={{
            backgroundColor: colors.indigoDeep,
            borderColor: colors.indigo,
          }}
        >
          <Text
            style={[styles.howTitle, { color: colors.goldLight, fontFamily: "Inter_700Bold" }]}
          >
            How Escrow Works
          </Text>
          {[
            { icon: "lock" as const, text: "Funds locked safely in escrow" },
            { icon: "check-circle" as const, text: "Both parties confirm the trade" },
            { icon: "shield" as const, text: "Release code protects every deal" },
          ].map(({ icon, text }) => (
            <View key={text} style={styles.howRow}>
              <View
                style={[
                  styles.howIconWrap,
                  { backgroundColor: "rgba(200,147,42,0.2)" },
                ]}
              >
                <Feather name={icon} size={14} color={colors.goldLight} />
              </View>
              <Text
                style={[styles.howText, { color: "#C9C7E8", fontFamily: "Inter_400Regular" }]}
              >
                {text}
              </Text>
            </View>
          ))}
        </Card>
      </ScrollView>

      <CreateEscrowModal
        visible={createVisible}
        onDismiss={() => setCreateVisible(false)}
        onCreate={(data) => {
          createEscrow(data);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setCreateVisible(false);
        }}
      />

      <EscrowDetailModal
        escrow={detailEscrow}
        onDismiss={() => setDetailEscrow(null)}
        onRelease={(id) => {
          releaseEscrow(id);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          setDetailEscrow(null);
        }}
      />
    </View>
  );
}

function CreateEscrowModal({
  visible,
  onDismiss,
  onCreate,
}: {
  visible: boolean;
  onDismiss: () => void;
  onCreate: (data: Omit<Escrow, "id" | "date">) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [title, setTitle] = useState("");
  const [withWho, setWithWho] = useState("");
  const [amount, setAmount] = useState("");

  const handleCreate = () => {
    if (!title.trim() || !withWho.trim() || !amount.trim()) {
      Alert.alert("Missing fields", "Please fill in all fields.");
      return;
    }
    const num = parseFloat(amount);
    if (!num || num <= 0) {
      Alert.alert("Invalid amount", "Enter a valid amount.");
      return;
    }
    onCreate({
      title: title.trim(),
      withWho: withWho.trim(),
      amount: `GH₵ ${num.toLocaleString()}`,
      amountRaw: num,
      status: "In Escrow",
      tone: "indigo",
      direction: "sent",
    });
    setTitle("");
    setWithWho("");
    setAmount("");
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onDismiss}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <TouchableOpacity style={StyleSheet.absoluteFillObject} activeOpacity={1} onPress={onDismiss} />
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.parchment, paddingBottom: insets.bottom + 20 },
          ]}
        >
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 8 }}>
            <Text style={[styles.sheetTitle, { color: colors.ink, fontFamily: "Inter_700Bold" }]}>
              Create Escrow
            </Text>
            <Text style={[styles.sheetSub, { color: colors.inkSoft }]}>
              Secure funds until both parties confirm
            </Text>

            {[
              { label: "Item / Service", value: title, setter: setTitle, placeholder: "e.g. iPhone 15 Pro Max" },
              { label: "Counterparty Name", value: withWho, setter: setWithWho, placeholder: "e.g. Kofi Mensah" },
            ].map(({ label, value, setter, placeholder }) => (
              <View key={label} style={{ marginBottom: 14 }}>
                <Text style={[styles.inputLabel, { color: colors.inkSoft }]}>{label}</Text>
                <TextInput
                  style={[
                    styles.textInput,
                    { borderColor: colors.border, backgroundColor: colors.white, color: colors.ink },
                  ]}
                  value={value}
                  onChangeText={setter}
                  placeholder={placeholder}
                  placeholderTextColor={colors.inkSoft}
                />
              </View>
            ))}

            <View style={{ marginBottom: 20 }}>
              <Text style={[styles.inputLabel, { color: colors.inkSoft }]}>Amount (GH₵)</Text>
              <TextInput
                style={[
                  styles.textInput,
                  { borderColor: colors.border, backgroundColor: colors.white, color: colors.ink },
                ]}
                value={amount}
                onChangeText={setAmount}
                placeholder="0.00"
                placeholderTextColor={colors.inkSoft}
                keyboardType="decimal-pad"
              />
            </View>

            <TouchableOpacity
              style={[styles.confirmBtn, { backgroundColor: colors.indigo }]}
              onPress={handleCreate}
              activeOpacity={0.8}
            >
              <Feather name="lock" size={16} color={colors.white} />
              <Text style={[styles.confirmBtnText, { color: colors.white, fontFamily: "Inter_700Bold" }]}>
                {" "}Lock in Escrow
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={onDismiss}>
              <Text style={[styles.cancelText, { color: colors.inkSoft }]}>Cancel</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function EscrowDetailModal({
  escrow,
  onDismiss,
  onRelease,
}: {
  escrow: Escrow | null;
  onDismiss: () => void;
  onRelease: (id: string) => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  if (!escrow) return null;

  const canRelease = escrow.status === "In Escrow" || escrow.status === "Pending Release";

  return (
    <Modal visible={!!escrow} transparent animationType="slide" onRequestClose={onDismiss}>
      <View style={styles.overlay}>
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.parchment, paddingBottom: insets.bottom + 20 },
          ]}
        >
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <Text style={[styles.sheetTitle, { color: colors.ink, fontFamily: "Inter_700Bold" }]}>
            {escrow.title}
          </Text>
          <Text style={[styles.sheetSub, { color: colors.inkSoft }]}>
            With {escrow.withWho} · {escrow.date}
          </Text>

          <View style={[styles.detailAmountBox, { backgroundColor: colors.indigoDeep }]}>
            <Text style={[styles.detailAmountLabel, { color: "#C9C7E8" }]}>Escrow Amount</Text>
            <Text style={[styles.detailAmount, { color: colors.white, fontFamily: "Inter_700Bold" }]}>
              {escrow.amount}
            </Text>
            <Pill label={escrow.status} tone={escrow.tone} />
          </View>

          {canRelease && (
            <TouchableOpacity
              style={[styles.confirmBtn, { backgroundColor: colors.success }]}
              onPress={() => onRelease(escrow.id)}
              activeOpacity={0.8}
            >
              <Feather name="unlock" size={16} color={colors.white} />
              <Text
                style={[styles.confirmBtnText, { color: colors.white, fontFamily: "Inter_700Bold" }]}
              >
                {" "}Release Funds
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.cancelBtn} onPress={onDismiss}>
            <Text style={[styles.cancelText, { color: colors.inkSoft }]}>Close</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  screenTitle: { fontSize: 24, fontWeight: "800" },
  newBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 14,
    gap: 4,
  },
  newBtnText: { fontSize: 14, fontWeight: "800" },
  scroll: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 100 },
  statRow: { flexDirection: "row", justifyContent: "space-between", gap: 12 },

  filterRow: { paddingVertical: 2, paddingBottom: 14, gap: 8 },
  filterChip: {
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderWidth: 1,
  },
  filterText: { fontSize: 13 },

  emptyState: { alignItems: "center", paddingVertical: 30, gap: 10 },
  emptyText: { fontSize: 14 },

  howTitle: { fontSize: 15, fontWeight: "800", marginBottom: 14 },
  howRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 10 },
  howIconWrap: { width: 28, height: 28, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  howText: { fontSize: 13, flex: 1 },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.35)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitle: { fontSize: 22, fontWeight: "800", marginBottom: 4 },
  sheetSub: { fontSize: 14, marginBottom: 20 },

  inputLabel: { fontSize: 12, fontWeight: "600", marginBottom: 6, fontFamily: "Inter_600SemiBold" },
  textInput: {
    borderWidth: 1.5,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },

  confirmBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    paddingVertical: 16,
    marginBottom: 10,
  },
  confirmBtnText: { fontSize: 16, fontWeight: "700" },
  cancelBtn: { alignItems: "center", paddingVertical: 10 },
  cancelText: { fontSize: 14 },

  detailAmountBox: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    gap: 6,
  },
  detailAmountLabel: { fontSize: 12, fontWeight: "600" },
  detailAmount: { fontSize: 28, fontWeight: "800" },
});
