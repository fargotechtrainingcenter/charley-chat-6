import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useRouter } from "expo-router";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";


export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    escrows, balance, profilePicture,
    currentUser, updateSettings, updateAvatar, setProfilePicture,
    notifPayments, notifEscrow, notifMarketing, biometricEnabled,
  } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const [photoOpen, setPhotoOpen] = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoSuccess, setPhotoSuccess] = useState(false);
  const [hideBalance, setHideBalance] = useState(false);

  const doUpload = async (uri: string) => {
    setPhotoUploading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await setProfilePicture(uri);
      setPhotoSuccess(true);
      setTimeout(() => { setPhotoSuccess(false); setPhotoOpen(false); }, 1400);
    } catch {
      Alert.alert("Upload failed", "Could not update your profile photo. Please try again.");
    } finally {
      setPhotoUploading(false);
    }
  };

  const handleCameraSelect = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission required", "Camera access is needed to take a photo.");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ mediaTypes: "images", quality: 0.85, allowsEditing: true, aspect: [1, 1] });
    if (!result.canceled && result.assets[0]) {
      await doUpload(result.assets[0].uri);
    }
  };

  const handleGallerySelect = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      Alert.alert("Permission required", "Gallery access is needed to choose a photo.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: "images", quality: 0.85, allowsEditing: true, aspect: [1, 1] });
    if (!result.canceled && result.assets[0]) {
      await doUpload(result.assets[0].uri);
    }
  };

  const handleRemovePhoto = () => {
    Alert.alert("Remove Photo", "Are you sure you want to remove your profile photo?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Remove", style: "destructive", onPress: () => {
          updateAvatar("");
          setPhotoOpen(false);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        },
      },
    ]);
  };
  const [codeCopied, setCodeCopied]         = useState(false);

  const completed = escrows.filter((e) => e.status === "Completed").length;
  const totalVol  = escrows.reduce((s, e) => s + e.amountRaw, 0);

  const copyCode = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setCodeCopied(true);
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const toggle = (setter: (v: boolean) => void, current: boolean) => {
    Haptics.selectionAsync();
    setter(!current);
  };

  const toggleSetting = (key: "notifPayments" | "notifEscrow" | "notifMarketing" | "biometricEnabled", current: boolean) => {
    Haptics.selectionAsync();
    updateSettings({ [key]: !current });
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 8 }]}>
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
          Profile
        </Text>
        <TouchableOpacity
          style={[styles.editBtn, { backgroundColor: colors.surfaceElevated }]}
          activeOpacity={0.7}
        >
          <Feather name="edit-2" size={16} color={colors.textMuted} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* ── Avatar card ─────────────────────────────────────── */}
        <View style={[styles.profileCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <TouchableOpacity onPress={() => setPhotoOpen(true)} activeOpacity={0.85}>
            <View style={{ width: 72, height: 72, marginBottom: 4 }}>
              <View style={[styles.avatar, { backgroundColor: colors.primary, overflow: "hidden", marginBottom: 0 }]}>
                {profilePicture
                  ? <Image source={{ uri: profilePicture }} style={{ width: 72, height: 72, borderRadius: 36 }} />
                  : <Text style={[styles.avatarText, { color: "#fff" }]}>
                      {currentUser?.name?.trim().split(" ").slice(0, 2).map((n) => n[0]).join("").toUpperCase() || "?"}
                    </Text>
                }
              </View>
              <View style={[styles.cameraOverlay, { backgroundColor: colors.surface, borderColor: colors.background }]}>
                <Feather name="camera" size={13} color={colors.primary} />
              </View>
            </View>
          </TouchableOpacity>
          <Text style={[styles.profileName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
            {currentUser?.name ?? "Loading…"}
          </Text>
          <Text style={[styles.profilePhone, { color: colors.textMuted }]}>{currentUser?.phone ?? ""}</Text>
          {currentUser?.fpId ? (
            <Text style={{ color: colors.textMuted, fontSize: 11, fontFamily: "Inter_500Medium", marginTop: 2 }}>
              ID: {currentUser.fpId}
            </Text>
          ) : null}
          <View style={styles.profileBadges}>
            {currentUser?.verified ? (
              <View style={[styles.badge, { backgroundColor: colors.successBg }]}>
                <Feather name="check-circle" size={11} color={colors.success} />
                <Text style={[styles.badgeText, { color: colors.success }]}> KYC Verified</Text>
              </View>
            ) : (
              <View style={[styles.badge, { backgroundColor: "#F59E0B18" }]}>
                <Feather name="clock" size={11} color="#F59E0B" />
                <Text style={[styles.badgeText, { color: "#F59E0B" }]}> KYC Pending</Text>
              </View>
            )}
            <View style={[styles.badge, { backgroundColor: colors.goldDim }]}>
              <Feather name="star" size={11} color={colors.gold} />
              <Text style={[styles.badgeText, { color: colors.gold }]}> 4.8 / 5</Text>
            </View>
          </View>
        </View>

        {/* ── Stats row ───────────────────────────────────────── */}
        <View style={styles.statsRow}>
          {[
            { label: "Completed", value: String(completed) },
            { label: "Volume",    value: `GH₵ ${(totalVol / 1000).toFixed(1)}k` },
            { label: "Balance",   value: `GH₵ ${(balance / 1000).toFixed(1)}k` },
          ].map((s) => (
            <View key={s.label} style={[styles.statBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.statValue, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{s.value}</Text>
              <Text style={[styles.statLabel, { color: colors.textMuted }]}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* ── Gold member banner ──────────────────────────────── */}
        <View style={[styles.trustCard, { backgroundColor: colors.goldDim, borderColor: colors.gold + "33" }]}>
          <View style={styles.trustLeft}>
            <Feather name="award" size={22} color={colors.gold} />
            <View style={{ marginLeft: 12 }}>
              <Text style={[styles.trustTitle, { color: colors.gold, fontFamily: "Inter_700Bold" }]}>
                Gold Member
              </Text>
              <Text style={[styles.trustSub, { color: colors.gold + "BB" }]}>
                Top 10% of trusted traders
              </Text>
            </View>
          </View>
          <Feather name="chevron-right" size={18} color={colors.gold} />
        </View>

        {/* ── Referral card ───────────────────────────────────── */}
        <View style={[styles.referralCard, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "40" }]}>
          <View style={styles.referralTop}>
            <View style={[styles.referralIcon, { backgroundColor: colors.primary + "22" }]}>
              <Feather name="gift" size={20} color={colors.primary} />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={[styles.referralTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                Invite Friends, Earn GH₵ 50
              </Text>
              <Text style={[styles.referralSub, { color: colors.textMuted }]}>
                Both you and your friend get rewarded
              </Text>
            </View>
          </View>
          <View style={[styles.referralCodeRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.referralCode, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
              {currentUser?.fpId ?? "—"}
            </Text>
            <TouchableOpacity
              style={[styles.copyBtn, { backgroundColor: codeCopied ? colors.primary : colors.surfaceElevated }]}
              onPress={copyCode}
              activeOpacity={0.7}
            >
              <Feather name={codeCopied ? "check" : "copy"} size={14} color={codeCopied ? "#fff" : colors.textMuted} />
              <Text style={[styles.copyBtnText, { color: codeCopied ? "#fff" : colors.textMuted }]}>
                {codeCopied ? " Copied!" : " Copy"}
              </Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={[styles.shareBtn, { backgroundColor: colors.primary }]} activeOpacity={0.8}>
            <Feather name="share-2" size={14} color="#fff" />
            <Text style={[styles.shareBtnText, { color: "#fff", fontFamily: "Inter_600SemiBold" }]}>
              {" "}Share Invite Link
            </Text>
          </TouchableOpacity>
        </View>

        {/* ── ACCOUNT ─────────────────────────────────────────── */}
        <SectionLabel title="ACCOUNT" colors={colors} />
        <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow icon="user" label="Personal Info" sub="Akosua Mensah" colors={colors} />
          <RowDivider colors={colors} />
          <SettingRow
            icon="shield"
            label="KYC Verification"
            sub={
              currentUser?.kycStatus === "approved" ? "Verified ✓"
              : currentUser?.kycStatus === "pending" ? "Under review"
              : currentUser?.kycStatus === "rejected" ? "Rejected — tap to resubmit"
              : "Not submitted — tap to verify"
            }
            highlight={currentUser?.verified}
            danger={currentUser?.kycStatus === "rejected"}
            colors={colors}
            onPress={currentUser?.verified ? undefined : () => router.push("/kyc-verify" as never)}
          />
          <RowDivider colors={colors} />
          <SettingRow icon="credit-card" label="Transaction Limits" sub="Daily: GH₵ 50,000" colors={colors} />
          <RowDivider colors={colors} />
          <ToggleRow
            icon="eye-off"
            label="Hide Balance"
            sub="Mask wallet balance"
            value={hideBalance}
            onToggle={() => toggle(setHideBalance, hideBalance)}
            colors={colors}
          />
          <RowDivider colors={colors} />
          <ToggleRow
            icon="zap"
            label="Biometric Login"
            sub="Fingerprint / Face ID"
            value={biometricEnabled}
            onToggle={() => toggleSetting("biometricEnabled", biometricEnabled)}
            colors={colors}
          />
          <RowDivider colors={colors} />
          <SettingRow icon="lock" label="Change PIN" sub="Last changed 30 days ago" colors={colors} />
        </View>

        {/* ── NOTIFICATIONS ───────────────────────────────────── */}
        <SectionLabel title="NOTIFICATIONS" colors={colors} />
        <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <ToggleRow
            icon="dollar-sign"
            label="Payment Alerts"
            sub="Escrow locks & releases"
            value={notifPayments}
            onToggle={() => toggleSetting("notifPayments", notifPayments)}
            colors={colors}
            iconColor={colors.primary}
          />
          <RowDivider colors={colors} />
          <ToggleRow
            icon="bell"
            label="Escrow Updates"
            sub="Status changes & disputes"
            value={notifEscrow}
            onToggle={() => toggleSetting("notifEscrow", notifEscrow)}
            colors={colors}
          />
          <RowDivider colors={colors} />
          <ToggleRow
            icon="tag"
            label="Promotions"
            sub="Offers & new features"
            value={notifMarketing}
            onToggle={() => toggleSetting("notifMarketing", notifMarketing)}
            colors={colors}
          />
        </View>

        {/* ── PRIVACY & DATA ──────────────────────────────────── */}
        <SectionLabel title="PRIVACY & DATA" colors={colors} />
        <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow icon="lock" label="Privacy Policy" sub="How we use your data" colors={colors} />
          <RowDivider colors={colors} />
          <SettingRow icon="file-text" label="Terms of Service" sub="CharLey user agreement" colors={colors} />
          <RowDivider colors={colors} />
          <SettingRow
            icon="trash-2"
            label="Delete Account"
            sub="Permanently remove data"
            danger
            colors={colors}
            onPress={() => Alert.alert("Delete Account", "This action cannot be undone. Contact support to proceed.")}
          />
        </View>

        {/* ── SUPPORT ─────────────────────────────────────────── */}
        <SectionLabel title="SUPPORT" colors={colors} />
        <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <SettingRow icon="help-circle" label="Help Centre" sub="FAQs & guides" colors={colors} />
          <RowDivider colors={colors} />
          <SettingRow icon="message-circle" label="Contact Support" sub="Live chat 24/7" colors={colors} />
          <RowDivider colors={colors} />
          <SettingRow icon="star" label="Rate CharLey" sub="Leave a review" colors={colors} />
          <RowDivider colors={colors} />
          <View style={styles.versionRow}>
            <Feather name="info" size={15} color={colors.textMuted} />
            <Text style={[styles.versionText, { color: colors.textMuted }]}>
              {"  "}Version 1.0.0 · Build 2025.06
            </Text>
          </View>
        </View>

        {/* ── Sign out ────────────────────────────────────────── */}
        <TouchableOpacity
          style={[styles.signOutBtn, { borderColor: colors.danger + "44" }]}
          activeOpacity={0.7}
          onPress={() => Alert.alert("Sign Out", "Are you sure you want to sign out?", [
            { text: "Cancel", style: "cancel" },
            { text: "Sign Out", style: "destructive" },
          ])}
        >
          <Feather name="log-out" size={16} color={colors.danger} />
          <Text style={[styles.signOutText, { color: colors.danger, fontFamily: "Inter_600SemiBold" }]}>
            {"  "}Sign Out
          </Text>
        </TouchableOpacity>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* ── Photo upload modal ────────────────────────────────────── */}
      <Modal visible={photoOpen} transparent animationType="slide" onRequestClose={() => !photoUploading && setPhotoOpen(false)}>
        <TouchableOpacity style={styles.photoOverlay} activeOpacity={1} onPress={() => !photoUploading && setPhotoOpen(false)} />
        <View style={[styles.photoSheet, { backgroundColor: colors.surface }]}>
          <View style={[styles.photoHandle, { backgroundColor: colors.border }]} />

          {photoSuccess ? (
            <View style={styles.photoSuccessWrap}>
              <View style={[styles.photoSuccessCircle, { backgroundColor: colors.successBg }]}>
                <Feather name="check" size={32} color={colors.success} />
              </View>
              <Text style={[styles.photoSuccessText, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Photo Updated!</Text>
              <Text style={[{ color: colors.textMuted, fontSize: 13, marginBottom: 24 }]}>Your profile photo has been saved.</Text>
            </View>
          ) : photoUploading ? (
            <View style={styles.photoProgress}>
              <Feather name="upload-cloud" size={22} color={colors.primary} />
              <Text style={[styles.photoProgressText, { color: colors.text }]}>Uploading photo…</Text>
            </View>
          ) : (
            <>
              <Text style={[styles.photoTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Update Profile Photo</Text>
              <Text style={[styles.photoSub, { color: colors.textMuted }]}>Choose how you'd like to update your photo</Text>

              <TouchableOpacity
                style={[styles.photoOption, { backgroundColor: colors.primary + "15" }]}
                activeOpacity={0.7}
                onPress={handleCameraSelect}
              >
                <View style={[{ width: 40, height: 40, borderRadius: 12, backgroundColor: colors.primary + "22", alignItems: "center", justifyContent: "center" }]}>
                  <Feather name="camera" size={20} color={colors.primary} />
                </View>
                <Text style={[styles.photoOptionText, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Take Photo</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.photoOption, { backgroundColor: colors.surfaceElevated }]}
                activeOpacity={0.7}
                onPress={handleGallerySelect}
              >
                <View style={[{ width: 40, height: 40, borderRadius: 12, backgroundColor: colors.border, alignItems: "center", justifyContent: "center" }]}>
                  <Feather name="image" size={20} color={colors.textMuted} />
                </View>
                <Text style={[styles.photoOptionText, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Choose from Gallery</Text>
              </TouchableOpacity>

              {profilePicture && (
                <TouchableOpacity
                  style={[styles.photoOption, { backgroundColor: colors.dangerBg }]}
                  activeOpacity={0.7}
                  onPress={handleRemovePhoto}
                >
                  <View style={[{ width: 40, height: 40, borderRadius: 12, backgroundColor: colors.danger + "22", alignItems: "center", justifyContent: "center" }]}>
                    <Feather name="trash-2" size={20} color={colors.danger} />
                  </View>
                  <Text style={[styles.photoOptionText, { color: colors.danger, fontFamily: "Inter_600SemiBold" }]}>Remove Photo</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity style={styles.photoCancel} onPress={() => setPhotoOpen(false)}>
                <Text style={[styles.photoCancelText, { color: colors.textMuted }]}>Cancel</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>
    </View>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionLabel({ title, colors }: { title: string; colors: ReturnType<typeof import("@/hooks/useColors").useColors> }) {
  return (
    <Text style={[styles.sectionLabel, { color: colors.textMuted }]}>{title}</Text>
  );
}

function RowDivider({ colors }: { colors: ReturnType<typeof import("@/hooks/useColors").useColors> }) {
  return <View style={[styles.rowDivider, { backgroundColor: colors.border, marginLeft: 58 }]} />;
}

function SettingRow({
  icon,
  label,
  sub,
  highlight,
  danger,
  colors,
  onPress,
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  sub: string;
  highlight?: boolean;
  danger?: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onPress?: () => void;
}) {
  const iconColor = danger ? colors.danger : highlight ? colors.primary : colors.textMuted;
  return (
    <TouchableOpacity style={styles.settingRow} activeOpacity={0.7} onPress={onPress}>
      <View style={[styles.settingIcon, { backgroundColor: danger ? colors.dangerBg : colors.surfaceElevated }]}>
        <Feather name={icon} size={16} color={iconColor} />
      </View>
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={[styles.settingLabel, { color: danger ? colors.danger : colors.text, fontFamily: "Inter_500Medium" }]}>
          {label}
        </Text>
        <Text style={[styles.settingSub, { color: highlight ? colors.primary : colors.textMuted }]}>{sub}</Text>
      </View>
      <Feather name="chevron-right" size={16} color={colors.border} />
    </TouchableOpacity>
  );
}

function ToggleRow({
  icon,
  label,
  sub,
  value,
  onToggle,
  colors,
  iconColor,
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  sub: string;
  value: boolean;
  onToggle: () => void;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  iconColor?: string;
}) {
  return (
    <View style={styles.settingRow}>
      <View style={[styles.settingIcon, { backgroundColor: colors.surfaceElevated }]}>
        <Feather name={icon} size={16} color={iconColor ?? colors.textMuted} />
      </View>
      <View style={{ flex: 1, marginLeft: 12 }}>
        <Text style={[styles.settingLabel, { color: colors.text, fontFamily: "Inter_500Medium" }]}>{label}</Text>
        <Text style={[styles.settingSub, { color: colors.textMuted }]}>{sub}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onToggle}
        trackColor={{ false: colors.surfaceElevated, true: colors.primary + "88" }}
        thumbColor={value ? colors.primary : colors.border}
        ios_backgroundColor={colors.surfaceElevated}
      />
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  screenTitle: { fontSize: 22, fontWeight: "800" },
  editBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  scroll: { paddingHorizontal: 14, paddingTop: 16 },

  profileCard: { borderRadius: 16, padding: 20, alignItems: "center", borderWidth: 1, marginBottom: 12 },
  avatar: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center", marginBottom: 12 },
  avatarText: { fontSize: 28, fontWeight: "800", fontFamily: "Inter_700Bold" },
  profileName: { fontSize: 20, fontWeight: "800", marginBottom: 4 },
  profilePhone: { fontSize: 14, marginBottom: 12 },
  profileBadges: { flexDirection: "row", gap: 8 },
  badge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  badgeText: { fontSize: 12, fontWeight: "600" },

  statsRow: { flexDirection: "row", gap: 10, marginBottom: 12 },
  statBox: { flex: 1, borderRadius: 12, padding: 12, alignItems: "center", borderWidth: 1 },
  statValue: { fontSize: 16, fontWeight: "800", marginBottom: 2 },
  statLabel: { fontSize: 11 },

  trustCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    marginBottom: 16,
  },
  trustLeft: { flexDirection: "row", alignItems: "center" },
  trustTitle: { fontSize: 14, fontWeight: "700" },
  trustSub: { fontSize: 12, marginTop: 2 },

  referralCard: { borderRadius: 16, padding: 16, borderWidth: 1, marginBottom: 16 },
  referralTop: { flexDirection: "row", alignItems: "center", marginBottom: 14 },
  referralIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  referralTitle: { fontSize: 15, fontWeight: "700" },
  referralSub: { fontSize: 12, marginTop: 2 },
  referralCodeRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 10,
  },
  referralCode: { fontSize: 15, letterSpacing: 1 },
  copyBtn: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  copyBtnText: { fontSize: 13, fontWeight: "600" },
  shareBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    paddingVertical: 11,
  },
  shareBtnText: { fontSize: 14 },

  sectionLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1.2, marginBottom: 8, marginLeft: 4, marginTop: 4, fontFamily: "Inter_700Bold" },
  sectionCard: { borderRadius: 14, overflow: "hidden", borderWidth: 1, marginBottom: 16 },
  settingRow: { flexDirection: "row", alignItems: "center", padding: 14 },
  settingIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  settingLabel: { fontSize: 14 },
  settingSub: { fontSize: 12, marginTop: 1 },
  rowDivider: { height: 1 },
  versionRow: { flexDirection: "row", alignItems: "center", padding: 14 },
  versionText: { fontSize: 13 },

  signOutBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderRadius: 14,
    paddingVertical: 14,
    marginBottom: 12,
  },
  signOutText: { fontSize: 15 },
  cameraOverlay: {
    position: "absolute", bottom: 0, right: 0,
    width: 24, height: 24, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
    borderWidth: 1.5,
  },
  // photo modal
  photoOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  photoSheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 14 },
  photoHandle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  photoTitle: { fontSize: 18, fontWeight: "700", marginBottom: 6 },
  photoSub: { fontSize: 13, marginBottom: 20 },
  photoOption: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 16, borderRadius: 14, paddingHorizontal: 14, marginBottom: 10 },
  photoOptionText: { fontSize: 15, fontWeight: "600" },
  photoCancel: { alignItems: "center", paddingVertical: 16, marginBottom: 8 },
  photoCancelText: { fontSize: 15 },
  photoSuccessWrap: { alignItems: "center", padding: 32, gap: 12 },
  photoSuccessCircle: { width: 70, height: 70, borderRadius: 35, alignItems: "center", justifyContent: "center" },
  photoSuccessText: { fontSize: 16, fontWeight: "700" },
  photoProgress: { flexDirection: "row", alignItems: "center", gap: 12, padding: 24 },
  photoProgressText: { fontSize: 14 },
});
