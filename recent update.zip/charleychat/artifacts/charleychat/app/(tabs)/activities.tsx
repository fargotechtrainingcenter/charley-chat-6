import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BalanceCard } from "@/components/FargoComponents";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const FILTER_TABS = ["All", "Transfers", "Deals", "Pay Links"] as const;
type FilterTab = typeof FILTER_TABS[number];

export default function ActivitiesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { transactions, escrows, payLinks } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const [activeFilter, setActiveFilter] = useState<FilterTab>("All");

  const txnIcon: Record<string, keyof typeof Feather.glyphMap> = {
    lock: "lock",
    "plus-circle": "plus-circle",
    "arrow-up-circle": "arrow-up-circle",
    unlock: "unlock",
    send: "send",
    receive: "download",
  };

  const DEAL_STATUS_COLOR: Record<string, { bg: string; fg: string }> = {
    "In Escrow":        { bg: colors.goldDim,    fg: colors.gold    },
    "Pending Release":  { bg: colors.goldDim,    fg: colors.gold    },
    "Completed":        { bg: colors.successBg,  fg: colors.success },
    "Disputed":         { bg: colors.dangerBg ?? colors.surfaceElevated, fg: colors.danger },
  };

  const LINK_STATUS_COLOR: Record<string, { bg: string; fg: string }> = {
    active:     { bg: colors.primary + "18", fg: colors.primary },
    paid:       { bg: colors.successBg,      fg: colors.success },
    delivered:  { bg: colors.successBg,      fg: colors.success },
    disputed:   { bg: colors.dangerBg ?? colors.surfaceElevated, fg: colors.danger },
    expired:    { bg: colors.surfaceElevated, fg: colors.textMuted },
  };

  const showTxns    = activeFilter === "All" || activeFilter === "Transfers";
  const showDeals   = activeFilter === "All" || activeFilter === "Deals";
  const showLinks   = activeFilter === "All" || activeFilter === "Pay Links";

  const hasContent = (showTxns && transactions.length > 0)
    || (showDeals && escrows.length > 0)
    || (showLinks && payLinks.length > 0);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 8, borderBottomColor: colors.border }]}>
        <Text style={[styles.screenTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Activities</Text>
        <TouchableOpacity
          style={[styles.newPayBtn, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "44" }]}
          onPress={() => router.push("/pay" as never)}
          activeOpacity={0.75}
        >
          <Feather name="plus" size={15} color={colors.primary} />
          <Text style={[styles.newPayText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>New</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Balance summary at top */}
        <BalanceCard />

        {/* Filter chips */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterBar} contentContainerStyle={styles.filterScroll}>
          {FILTER_TABS.map((f) => (
            <TouchableOpacity
              key={f}
              style={[styles.filterChip, {
                backgroundColor: activeFilter === f ? colors.primary : colors.surfaceElevated,
                borderColor: activeFilter === f ? colors.primary : "transparent",
              }]}
              onPress={() => setActiveFilter(f)}
              activeOpacity={0.7}
            >
              <Text style={[styles.filterChipText, {
                color: activeFilter === f ? "#fff" : colors.textMuted,
                fontFamily: activeFilter === f ? "Inter_600SemiBold" : "Inter_400Regular",
              }]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {!hasContent && (
          <View style={styles.emptyWrap}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.surfaceElevated }]}>
              <Feather name="activity" size={32} color={colors.textMuted} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>No activity yet</Text>
            <Text style={[styles.emptySub, { color: colors.textDim }]}>Send money or create a deal to get started</Text>
          </View>
        )}

        {/* ── Transfers ──────────────────────────────────────────────────────── */}
        {showTxns && transactions.length > 0 && (
          <>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Transfers</Text>
              <Text style={[styles.sectionCount, { color: colors.textDim }]}>{transactions.length}</Text>
            </View>
            <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              {transactions.map((t, i) => (
                <View key={t.id}>
                  <View style={styles.txnRow}>
                    <View style={[styles.txnIcon, { backgroundColor: t.type === "credit" ? colors.successBg : colors.surfaceElevated }]}>
                      <Feather
                        name={txnIcon[t.icon] ?? "circle"}
                        size={16}
                        color={t.type === "credit" ? colors.success : colors.textMuted}
                      />
                    </View>
                    <View style={{ flex: 1, marginLeft: 12 }}>
                      <Text style={[styles.txnTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{t.title}</Text>
                      <Text style={[styles.txnSub, { color: colors.textMuted }]}>{t.sub} · {t.date}</Text>
                    </View>
                    <Text style={[styles.txnAmount, { color: t.type === "credit" ? colors.success : colors.danger, fontFamily: "Inter_700Bold" }]}>
                      {t.amount}
                    </Text>
                  </View>
                  {i < transactions.length - 1 && <View style={[styles.divider, { backgroundColor: colors.divider }]} />}
                </View>
              ))}
            </View>
          </>
        )}

        {/* ── Escrow Deals ───────────────────────────────────────────────────── */}
        {showDeals && escrows.length > 0 && (
          <>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Deals</Text>
              <Text style={[styles.sectionCount, { color: colors.textDim }]}>{escrows.length}</Text>
            </View>
            {escrows.map((e) => {
              const sc = DEAL_STATUS_COLOR[e.status] ?? { bg: colors.surfaceElevated, fg: colors.textMuted };
              return (
                <TouchableOpacity
                  key={e.id}
                  style={[styles.dealCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
                  onPress={() => router.push("/(tabs)/escrow" as never)}
                  activeOpacity={0.75}
                >
                  <View style={[styles.dealIconWrap, { backgroundColor: sc.bg }]}>
                    <Feather
                      name={e.status === "Completed" ? "check-circle" : e.status === "Disputed" ? "alert-triangle" : "lock"}
                      size={18}
                      color={sc.fg}
                    />
                  </View>
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={[styles.dealTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{e.title}</Text>
                    <Text style={[styles.dealSub, { color: colors.textMuted }]}>{e.withWho} · {e.amount}</Text>
                  </View>
                  <View style={[styles.statusPill, { backgroundColor: sc.bg }]}>
                    <Text style={[styles.statusPillText, { color: sc.fg }]}>{e.status}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </>
        )}

        {/* ── Pay Links ──────────────────────────────────────────────────────── */}
        {showLinks && payLinks.length > 0 && (
          <>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Pay Links</Text>
              <Text style={[styles.sectionCount, { color: colors.textDim }]}>{payLinks.length}</Text>
            </View>
            {payLinks.map((link) => {
              const sc = LINK_STATUS_COLOR[link.status] ?? { bg: colors.surfaceElevated, fg: colors.textMuted };
              return (
                <View key={link.id} style={[styles.dealCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <View style={[styles.dealIconWrap, { backgroundColor: "#F472B618" }]}>
                    <Feather name="link" size={18} color="#F472B6" />
                  </View>
                  <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={[styles.dealTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{link.title}</Text>
                    <Text style={[styles.dealSub, { color: colors.textMuted }]}>
                      {link.amount} · code: {link.code}
                    </Text>
                  </View>
                  <View style={[styles.statusPill, { backgroundColor: sc.bg }]}>
                    <Text style={[styles.statusPillText, { color: sc.fg }]}>{link.status}</Text>
                  </View>
                </View>
              );
            })}
          </>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  screenTitle: { fontSize: 22, fontWeight: "800" },
  newPayBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  newPayText: { fontSize: 13 },

  scroll: { paddingHorizontal: 14, paddingTop: 16 },

  filterBar: { marginBottom: 18 },
  filterScroll: { gap: 8, paddingBottom: 4 },
  filterChip: { borderRadius: 20, paddingVertical: 5, paddingHorizontal: 14, borderWidth: 1 },
  filterChipText: { fontSize: 13 },

  emptyWrap: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyIcon: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  emptyTitle: { fontSize: 16 },
  emptySub: { fontSize: 13, textAlign: "center" },

  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10, marginTop: 6 },
  sectionTitle: { fontSize: 12, letterSpacing: 0.8, textTransform: "uppercase" },
  sectionCount: { fontSize: 12 },

  card: { borderRadius: 16, borderWidth: 1, paddingVertical: 4, marginBottom: 20, overflow: "hidden" },
  txnRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12, paddingHorizontal: 14 },
  txnIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  txnTitle: { fontSize: 14 },
  txnSub: { fontSize: 12, marginTop: 2 },
  txnAmount: { fontSize: 14 },
  divider: { height: 1, marginHorizontal: 14 },

  dealCard: { flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1, padding: 14, marginBottom: 10 },
  dealIconWrap: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  dealTitle: { fontSize: 14 },
  dealSub: { fontSize: 12, marginTop: 2 },
  statusPill: { borderRadius: 8, paddingHorizontal: 9, paddingVertical: 4 },
  statusPillText: { fontSize: 11, fontWeight: "700" },
});
