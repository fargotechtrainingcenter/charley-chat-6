import { Feather } from "@expo/vector-icons";
import { Image as CachedImage } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { customFetch } from "@workspace/api-client-react";
import React, { useState, useEffect, useMemo } from "react";
import {
  FlatList,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { SectionHeader } from "@/components/FargoComponents";
import {
  CATEGORY_CHIPS,
  StreamTitle,
} from "@/constants/streamData";
import { useColors } from "@/hooks/useColors";

function PosterCard({
  item,
  width = 108,
  height = 152,
  showProgress = false,
  showBadge = false,
  onPress,
}: {
  item: StreamTitle;
  width?: number;
  height?: number;
  showProgress?: boolean;
  showBadge?: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <TouchableOpacity
      style={[s.posterCard, { width }]}
      onPress={onPress}
      activeOpacity={0.85}
    >
      <View style={[s.posterImage, { width, height }]}>
        {item.posterUrl ? (
          <CachedImage source={{ uri: item.posterUrl }} style={StyleSheet.absoluteFill} contentFit="cover" transition={150} />
        ) : (
          <>
            <LinearGradient colors={item.gradient} style={StyleSheet.absoluteFill} />
            <View style={s.posterIconWrap}>
              <Feather name="film" size={22} color="rgba(255,255,255,0.55)" />
            </View>
          </>
        )}
        {showBadge && item.isNew && (
          <View style={[s.newBadge, { backgroundColor: colors.primary }]}>
            <Text style={s.newBadgeText}>NEW</Text>
          </View>
        )}
        {showProgress && typeof item.progress === "number" && (
          <View style={s.progressTrack}>
            <View
              style={[
                s.progressFill,
                { width: `${Math.round(item.progress * 100)}%`, backgroundColor: colors.primary },
              ]}
            />
          </View>
        )}
      </View>
      <Text style={[s.posterTitle, { color: colors.text }]} numberOfLines={1}>
        {item.title}
      </Text>
      <Text style={[s.posterSub, { color: colors.textMuted }]} numberOfLines={1}>
        {item.seasonInfo ?? item.genre}
      </Text>
    </TouchableOpacity>
  );
}

function Row({
  title,
  data,
  onSeeAll,
  onPressItem,
  showProgress = false,
  showBadge = false,
}: {
  title: string;
  data: StreamTitle[];
  onSeeAll?: () => void;
  onPressItem: (id: string) => void;
  showProgress?: boolean;
  showBadge?: boolean;
}) {
  return (
    <View style={{ marginBottom: 22 }}>
      <View style={{ paddingHorizontal: 16 }}>
        <SectionHeader title={title} action={onSeeAll ? "View all" : undefined} onAction={onSeeAll} />
      </View>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}
        renderItem={({ item }) => (
          <PosterCard
            item={item}
            showProgress={showProgress}
            showBadge={showBadge}
            onPress={() => onPressItem(item.id)}
          />
        )}
      />
    </View>
  );
}

function toStreamTitle(m: any): StreamTitle {
  const mins = m.durationMinutes ?? 0;
  return {
    id: m.id,
    title: m.title,
    kind: "movie",
    genre: m.genre ?? "Drama",
    year: m.releaseYear ?? new Date().getFullYear(),
    duration: mins ? `${Math.floor(mins / 60)}h ${mins % 60}m` : "—",
    rating: (m.rating ?? 0) / 10,
    ageRating: "PG",
    description: m.description ?? "",
    gradient: ["#0F2A3D", "#070C14"],
    posterUrl: m.posterUrl ?? undefined,
    isPremium: m.isPremium,
    isNew: m.isNew,
  };
}

export default function StreamScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [activeChip, setActiveChip] = useState<string>(CATEGORY_CHIPS[0]);
  const isWeb = Platform.OS === "web";
  const [rawMovies, setRawMovies] = useState<any[]>([]);

  useEffect(() => {
    customFetch<any[]>("/api/movies")
      .then((rows) => setRawMovies(Array.isArray(rows) ? rows : []))
      .catch(() => setRawMovies([]));
  }, []);

  // API already orders by newest first, so this list doubles as "New Releases"
  const newReleases = useMemo(
    () => rawMovies.slice(0, 10).map((m, i) => ({ ...toStreamTitle(m), isNew: i < 3 })),
    [rawMovies],
  );
  const popular = useMemo(
    () => [...rawMovies].sort((a, b) => (b.viewCount ?? 0) - (a.viewCount ?? 0)).map(toStreamTitle),
    [rawMovies],
  );
  const topPicks = useMemo(
    () => [...rawMovies].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0)).map(toStreamTitle),
    [rawMovies],
  );
  const featured = newReleases[0];

  const goToMovie = (id: string) => router.push(`/movie/${id}`);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingTop: insets.top + 10, paddingBottom: (isWeb ? 100 : 24) + insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={s.header}>
          <View style={s.headerLeft}>
            <LinearGradient colors={["#0D9488", "#12D9A0"]} style={s.logoBadge}>
              <Feather name="play" size={14} color="#fff" />
            </LinearGradient>
            <Text style={[s.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
              CharLey Stream
            </Text>
          </View>
          <View style={{ flexDirection: "row", gap: 14 }}>
            <TouchableOpacity onPress={() => router.push("/my-list")}>
              <Feather name="bookmark" size={20} color={colors.text} />
            </TouchableOpacity>
            <TouchableOpacity>
              <Feather name="search" size={20} color={colors.text} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Category chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8, marginBottom: 16 }}
        >
          {CATEGORY_CHIPS.map((chip) => {
            const active = chip === activeChip;
            return (
              <TouchableOpacity
                key={chip}
                onPress={() => setActiveChip(chip)}
                style={[
                  s.chip,
                  {
                    backgroundColor: active ? colors.primary : colors.surfaceElevated,
                    borderColor: active ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    s.chipText,
                    { color: active ? "#04241D" : colors.textMuted, fontFamily: "Inter_600SemiBold" },
                  ]}
                >
                  {chip}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Hero / featured */}
        {featured ? (
          <TouchableOpacity
            style={s.hero}
            activeOpacity={0.9}
            onPress={() => goToMovie(featured.id)}
          >
            {featured.posterUrl ? (
              <CachedImage source={{ uri: featured.posterUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
            ) : (
              <LinearGradient colors={featured.gradient} style={StyleSheet.absoluteFill} />
            )}
            <LinearGradient
              colors={["transparent", "rgba(7,12,20,0.95)"]}
              style={[StyleSheet.absoluteFill, { justifyContent: "flex-end" }]}
            >
              <View style={{ padding: 18 }}>
                <Text style={s.heroTitle} numberOfLines={1}>{featured.title}</Text>
                <Text style={s.heroMeta}>
                  {featured.genre} · {featured.year} · {featured.duration}
                </Text>
                <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
                  <TouchableOpacity
                    style={[s.heroBtn, { backgroundColor: colors.primary }]}
                    onPress={() => goToMovie(featured.id)}
                  >
                    <Feather name="play" size={15} color="#04241D" />
                    <Text style={s.heroBtnText}>Play Now</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[s.heroBtn, s.heroBtnGhost]}>
                    <Feather name="plus" size={15} color="#fff" />
                    <Text style={[s.heroBtnText, { color: "#fff" }]}>My List</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        ) : (
          <View style={{ paddingHorizontal: 16, paddingVertical: 30, alignItems: "center" }}>
            <Text style={{ color: colors.textMuted, fontFamily: "Inter_400Regular" }}>
              No titles have been added yet — check back soon.
            </Text>
          </View>
        )}

        <Row
          title="Popular on CharLey Stream"
          data={popular}
          onSeeAll={() => {}}
          onPressItem={goToMovie}
        />
        <Row
          title="New Releases"
          data={newReleases}
          onSeeAll={() => {}}
          onPressItem={goToMovie}
          showBadge
        />
        <Row
          title="Top Picks for You"
          data={topPicks}
          onSeeAll={() => {}}
          onPressItem={goToMovie}
        />
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    marginBottom: 14,
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  logoBadge: { width: 26, height: 26, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 17 },

  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
  },
  chipText: { fontSize: 13 },

  hero: {
    height: 220,
    marginHorizontal: 16,
    borderRadius: 18,
    overflow: "hidden",
    marginBottom: 22,
  },
  heroTitle: { color: "#fff", fontSize: 22, fontWeight: "800", fontFamily: "Inter_700Bold" },
  heroMeta: { color: "rgba(255,255,255,0.8)", fontSize: 12, marginTop: 4, fontFamily: "Inter_500Medium" },
  heroBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 10,
  },
  heroBtnGhost: { backgroundColor: "rgba(255,255,255,0.15)" },
  heroBtnText: { color: "#04241D", fontSize: 13, fontWeight: "700", fontFamily: "Inter_700Bold" },

  posterCard: {},
  posterImage: {
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 6,
    justifyContent: "center",
    alignItems: "center",
  },
  posterIconWrap: { position: "absolute" },
  posterTitle: { fontSize: 12.5, fontFamily: "Inter_600SemiBold" },
  posterSub: { fontSize: 11, marginTop: 1, fontFamily: "Inter_400Regular" },

  newBadge: {
    position: "absolute",
    top: 6,
    left: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  newBadgeText: { color: "#04241D", fontSize: 9, fontWeight: "800", fontFamily: "Inter_700Bold" },

  progressTrack: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: "rgba(255,255,255,0.25)",
  },
  progressFill: { height: 3 },
});
