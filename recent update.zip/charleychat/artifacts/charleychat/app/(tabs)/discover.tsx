import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Location from "expo-location";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { customFetch } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

interface DiscoverUser {
  id: string;
  fullName: string;
  username?: string;
  phone: string;
  avatarUrl?: string;
  isKycVerified?: boolean;
  interests?: string[];
  bio?: string;
  distanceMetres?: number;
  mutualCount?: number;
  isOnline?: boolean;
}

interface Group {
  id: string;
  name: string;
  description?: string;
  avatarUrl?: string;
  isPaid: boolean;
  membershipFeePesewas?: number;
  memberCount: number;
}

const AVATAR_COLORS = ["#12D9A0", "#3B82F6", "#10B981", "#F59E0B", "#EC4899", "#EF4444", "#06B6D4"];

function getAvatarColor(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function Avatar({ name, uri, size = 44 }: { name: string; uri?: string; size?: number }) {
  const initials = name.split(" ").filter(Boolean).map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const color = getAvatarColor(name);
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color + "30", alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: size * 0.36, color, fontFamily: "Inter_700Bold" }}>{initials}</Text>
    </View>
  );
}

function formatDistance(metres?: number): string {
  if (!metres) return "";
  if (metres < 1000) return `${Math.round(metres)} m`;
  return `${(metres / 1000).toFixed(1)} km`;
}

// ─── Nearby banner ───────────────────────────────────────────────────────────

function NearbyBanner({ onEnable, users, enabling }: { onEnable: () => void; users: DiscoverUser[]; enabling?: boolean }) {
  const colors = useColors();
  return (
    <View style={[nb.card, { backgroundColor: "#0F2A3D" }]}>
      <View style={nb.content}>
        <Text style={[nb.title, { color: "#fff", fontFamily: "Inter_700Bold" }]}>Find people around you</Text>
        <Text style={[nb.sub, { color: "#99F6E4", fontFamily: "Inter_400Regular" }]}>
          Connect and chat with nearby{"\n"}CharLey users.
        </Text>
        <TouchableOpacity
          style={[nb.btn, { backgroundColor: colors.primary, opacity: enabling ? 0.75 : 1 }]}
          onPress={onEnable}
          activeOpacity={0.85}
          disabled={enabling}
        >
          {enabling ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Feather name="map-pin" size={13} color="#fff" />
          )}
          <Text style={[nb.btnText, { fontFamily: "Inter_600SemiBold" }]}>
            {enabling ? "Finding your location…" : "Enable Nearby"}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={nb.cluster}>
        {users.slice(0, 3).map((u, i) => (
          <View key={u.id} style={[nb.floatAvatar, { top: i * 36, right: i % 2 === 0 ? 4 : 38 }]}>
            <Avatar name={u.fullName} uri={u.avatarUrl} size={40} />
          </View>
        ))}
        <View style={[nb.pin, { backgroundColor: colors.primary }]}>
          <Feather name="map-pin" size={20} color="#fff" />
        </View>
      </View>
    </View>
  );
}

const nb = StyleSheet.create({
  card:        { marginHorizontal: 16, marginBottom: 16, borderRadius: 20, padding: 20, overflow: "hidden", flexDirection: "row", minHeight: 138 },
  content:     { flex: 1, gap: 6 },
  title:       { fontSize: 16 },
  sub:         { fontSize: 12, lineHeight: 18 },
  btn:         { flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start", marginTop: 8, paddingHorizontal: 16, paddingVertical: 9, borderRadius: 10 },
  btnText:     { color: "#fff", fontSize: 13 },
  cluster:     { width: 92, position: "relative" },
  floatAvatar: { position: "absolute", borderRadius: 99, borderWidth: 2, borderColor: "#0F2A3D" },
  pin:         { position: "absolute", bottom: 0, left: 18, width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
});

// ─── Section header ──────────────────────────────────────────────────────────

function SectionHeader({ title, icon, onViewAll, colors }: {
  title: string;
  icon?: string;
  onViewAll?: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={sh.row}>
      <View style={sh.left}>
        {icon && <Feather name={icon as any} size={15} color={colors.primary} />}
        <Text style={[sh.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title}</Text>
      </View>
      {onViewAll && (
        <TouchableOpacity onPress={onViewAll} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Text style={[sh.link, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>View all</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const sh = StyleSheet.create({
  row:  { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, marginBottom: 12 },
  left: { flexDirection: "row", alignItems: "center", gap: 6 },
  title:{ fontSize: 16 },
  link: { fontSize: 13 },
});

// ─── Category chips ───────────────────────────────────────────────────────────

const CATEGORIES = [
  { id: "nearby",   label: "Nearby\nUsers",        icon: "map-pin",  color: "#0D9488" },
  { id: "people",   label: "People You\nMay Know",  icon: "user-plus",color: "#10B981" },
  { id: "groups",   label: "Groups",               icon: "users",    color: "#F59E0B" },
  { id: "channels", label: "Channels",             icon: "volume-2", color: "#3B82F6" },
  { id: "events",   label: "Events",               icon: "calendar", color: "#EC4899" },
] as const;

// ─── Trending discussions (backed by /api/discussions) ────────────────────────

const CATEGORY_ICONS: Record<string, string> = {
  "General": "message-circle",
  "Money & Finance": "dollar-sign",
  "Relationships": "heart",
  "Tech & Gadgets": "cpu",
  "Confessions": "lock",
  "Ghana Life": "flag",
};
const CATEGORY_COLORS = ["#F59E0B", "#10B981", "#3B82F6", "#EC4899", "#EF4444", "#06B6D4", "#12D9A0"];

function categoryIcon(name: string): string {
  return CATEGORY_ICONS[name] ?? "message-circle";
}

function categoryColor(name: string): string {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return CATEGORY_COLORS[Math.abs(h) % CATEGORY_COLORS.length];
}

function formatTimeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "now";
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  const days = Math.floor(hrs / 24);
  return `${days}d`;
}

interface DiscussionCategory {
  id: string;
  name: string;
  icon?: string | null;
}

interface DiscussionSummary {
  id: string;
  authorId: string;
  categoryId: string;
  categoryName?: string | null;
  isAnonymous: boolean;
  title: string;
  body?: string | null;
  viewCount: number;
  replyCount: number;
  authorName?: string | null;
  authorAvatarUrl?: string | null;
  createdAt: string;
}

interface DiscussionReply {
  id: string;
  discussionId: string;
  authorId: string;
  isAnonymous: boolean;
  body: string;
  likeCount: number;
  authorName?: string | null;
  authorAvatarUrl?: string | null;
  createdAt: string;
}

interface DiscussionDetail {
  discussion: DiscussionSummary;
  replies: DiscussionReply[];
}

// ─── Main screen ─────────────────────────────────────────────────────────────

export default function DiscoverScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const searchRef = useRef<TextInput>(null);

  const [topTab, setTopTab] = useState<"discover" | "trending">("discover");
  const [discussionCategories, setDiscussionCategories] = useState<DiscussionCategory[]>([]);
  const [exploreCategoryId, setExploreCategoryId] = useState<string | null>(null);
  const [discussionSort, setDiscussionSort] = useState<"hot" | "new">("hot");
  const [discussions, setDiscussions] = useState<DiscussionSummary[]>([]);
  const [discussionsLoading, setDiscussionsLoading] = useState(false);
  const [selectedDiscussionDetail, setSelectedDiscussionDetail] = useState<DiscussionDetail | null>(null);
  const [discussionDetailLoading, setDiscussionDetailLoading] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [replyAnonymous, setReplyAnonymous] = useState(true);
  const [postingReply, setPostingReply] = useState(false);
  const [newDiscussionVisible, setNewDiscussionVisible] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newBody, setNewBody] = useState("");
  const [newCategoryId, setNewCategoryId] = useState<string | null>(null);
  const [newAnonymous, setNewAnonymous] = useState(true);
  const [postingDiscussion, setPostingDiscussion] = useState(false);

  const [locationEnabled, setLocationEnabled] = useState(false);
  const [enablingNearby, setEnablingNearby] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("nearby");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<DiscoverUser[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [nearbyUsers, setNearbyUsers] = useState<DiscoverUser[]>([]);
  const [suggestedUsers, setSuggestedUsers] = useState<DiscoverUser[]>([]);
  const [activeNowUsers, setActiveNowUsers] = useState<DiscoverUser[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [joiningGroup, setJoiningGroup] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try {
      const [sug, grp] = await Promise.all([
        customFetch<{ users: DiscoverUser[] }>("/api/discovery/suggest"),
        customFetch<Group[]>("/api/groups/discover?limit=5"),
      ]);
      const sugUsers = sug.users ?? [];
      setSuggestedUsers(sugUsers);
      setActiveNowUsers(sugUsers.filter(u => u.isOnline).slice(0, 8));
      setGroups(Array.isArray(grp) ? grp : []);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  }, []);

  const loadNearby = useCallback(async () => {
    try {
      const data = await customFetch<{ users: DiscoverUser[] }>("/api/discovery/nearby?radius=5000");
      setNearbyUsers(data.users ?? []);
    } catch { /* ignore */ }
  }, []);

  const loadDiscussionCategories = useCallback(async () => {
    try {
      const cats = await customFetch<DiscussionCategory[]>("/api/discussions/categories");
      setDiscussionCategories(Array.isArray(cats) ? cats : []);
    } catch { /* ignore */ }
  }, []);

  const loadDiscussions = useCallback(async (categoryId: string | null, sort: "hot" | "new") => {
    setDiscussionsLoading(true);
    try {
      const params = new URLSearchParams({ sort });
      if (categoryId) params.set("categoryId", categoryId);
      const data = await customFetch<DiscussionSummary[]>(`/api/discussions?${params.toString()}`);
      setDiscussions(Array.isArray(data) ? data : []);
    } catch { /* ignore */ }
    finally { setDiscussionsLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  useEffect(() => {
    if (topTab === "trending") {
      loadDiscussionCategories();
      loadDiscussions(exploreCategoryId, discussionSort);
    }
  }, [topTab, exploreCategoryId, discussionSort, loadDiscussionCategories, loadDiscussions]);

  const openDiscussion = async (id: string) => {
    setDiscussionDetailLoading(true);
    setSelectedDiscussionDetail(null);
    setReplyText("");
    setReplyAnonymous(true);
    try {
      const detail = await customFetch<DiscussionDetail>(`/api/discussions/${id}`);
      setSelectedDiscussionDetail(detail);
    } catch { /* ignore */ }
    finally { setDiscussionDetailLoading(false); }
  };

  const handlePostReply = async () => {
    if (!selectedDiscussionDetail || !replyText.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setPostingReply(true);
    try {
      const reply = await customFetch<DiscussionReply>(`/api/discussions/${selectedDiscussionDetail.discussion.id}/replies`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: replyText.trim(), isAnonymous: replyAnonymous }),
      });
      setSelectedDiscussionDetail(prev => prev ? {
        discussion: { ...prev.discussion, replyCount: prev.discussion.replyCount + 1 },
        replies: [...prev.replies, reply],
      } : prev);
      setDiscussions(prev => prev.map(d => d.id === selectedDiscussionDetail.discussion.id ? { ...d, replyCount: d.replyCount + 1 } : d));
      setReplyText("");
    } catch { /* ignore */ }
    finally { setPostingReply(false); }
  };

  const handleLikeReply = async (replyId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setSelectedDiscussionDetail(prev => prev ? {
      ...prev,
      replies: prev.replies.map(r => r.id === replyId ? { ...r, likeCount: r.likeCount + 1 } : r),
    } : prev);
    try {
      await customFetch(`/api/discussions/replies/${replyId}/like`, { method: "POST" });
    } catch { /* ignore */ }
  };

  const handleCreateDiscussion = async () => {
    if (!newTitle.trim() || !newCategoryId) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setPostingDiscussion(true);
    try {
      const created = await customFetch<DiscussionSummary>("/api/discussions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          categoryId: newCategoryId,
          title: newTitle.trim(),
          body: newBody.trim() || undefined,
          isAnonymous: newAnonymous,
        }),
      });
      setDiscussions(prev => [created, ...prev]);
      setNewDiscussionVisible(false);
      setNewTitle("");
      setNewBody("");
    } catch { /* ignore */ }
    finally { setPostingDiscussion(false); }
  };

  const handleEnableNearby = async () => {
    if (enablingNearby) return; // guard against double-tap while a request is in flight
    setEnablingNearby(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === "granted") {
        // Race against a timeout — getCurrentPositionAsync can hang indefinitely
        // on some devices/emulators with no GPS fix, which would leave the button
        // stuck spinning forever otherwise.
        const loc = await Promise.race([
          Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error("location-timeout")), 10000),
          ),
        ]);
        await customFetch("/api/discovery/location", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
            nearbyEnabled: true,
          }),
        });
        setLocationEnabled(true);
        loadNearby();
      } else {
        Alert.alert("Location access needed", "Enable location permissions to find people nearby.");
      }
    } catch {
      Alert.alert("Couldn't get your location", "Please check your location settings and try again.");
    } finally {
      setEnablingNearby(false);
    }
    router.push("/nearby-users" as any);
  };

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (!q.trim()) { setSearchResults([]); return; }
    if (searchTimer.current) clearTimeout(searchTimer.current);
    setSearchLoading(true);
    searchTimer.current = setTimeout(async () => {
      try {
        const data = await customFetch<{ users: DiscoverUser[] }>(`/api/users/discover?q=${encodeURIComponent(q)}&limit=10`);
        setSearchResults(data.users ?? []);
      } catch { /* ignore */ }
      finally { setSearchLoading(false); }
    }, 300);
  };

  const handleJoinGroup = async (group: Group) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setJoiningGroup(group.id);
    try {
      await customFetch(`/api/groups/${group.id}/join`, { method: "POST" });
      setGroups(prev => prev.filter(g => g.id !== group.id));
    } catch { /* already member */ }
    finally { setJoiningGroup(null); }
  };

  const displayNearby = nearbyUsers.length > 0 ? nearbyUsers : suggestedUsers.slice(0, 8);
  const isSearching = searchFocused && searchQuery.length > 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* ── Header ── */}
      <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <View style={styles.headerRow}>
          <View style={styles.headerLeft}>
            <View style={[styles.logoBox, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="message-circle" size={18} color={colors.primary} />
            </View>
            <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Discover</Text>
          </View>
          <View style={styles.headerIcons}>
            <TouchableOpacity style={styles.iconBtn} onPress={() => router.push("/notifications" as any)} activeOpacity={0.7}>
              <Feather name="bell" size={22} color={colors.text} />
              <View style={[styles.badge, { backgroundColor: colors.primary }]}>
                <Text style={styles.badgeText}>7</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconBtn} onPress={() => searchRef.current?.focus()} activeOpacity={0.7}>
              <Feather name="search" size={22} color={colors.text} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Always-visible search bar */}
        <View style={[styles.searchBar, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
          <Feather name="search" size={15} color={colors.textMuted} />
          <TextInput
            ref={searchRef}
            style={[styles.searchInput, { color: colors.text, fontFamily: "Inter_400Regular" }]}
            placeholder="Search users, interests, or groups..."
            placeholderTextColor={colors.textMuted}
            value={searchQuery}
            onChangeText={handleSearch}
            onFocus={() => setSearchFocused(true)}
            onBlur={() => setSearchFocused(false)}
            returnKeyType="search"
            autoCapitalize="none"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => { setSearchQuery(""); setSearchResults([]); }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Feather name="x" size={14} color={colors.textMuted} />
            </TouchableOpacity>
          )}
        </View>

        {!isSearching && (
          <View style={[styles.tabSwitch, { backgroundColor: colors.surfaceElevated }]}>
            {(["discover", "trending"] as const).map(t => (
              <TouchableOpacity
                key={t}
                style={[styles.tabSwitchItem, topTab === t && { backgroundColor: colors.primary }]}
                onPress={() => { setTopTab(t); Haptics.selectionAsync().catch(() => {}); }}
                activeOpacity={0.8}
              >
                <Text style={[
                  styles.tabSwitchText,
                  { color: topTab === t ? "#fff" : colors.textMuted, fontFamily: topTab === t ? "Inter_600SemiBold" : "Inter_400Regular" },
                ]}>
                  {t === "discover" ? "Discover" : "Trending"}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      {/* ── Search results ── */}
      {isSearching ? (
        <View style={{ flex: 1 }}>
          {searchLoading ? (
            <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
          ) : searchResults.length === 0 ? (
            <View style={styles.center}>
              <Text style={[styles.emptyText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                No results for "{searchQuery}"
              </Text>
            </View>
          ) : (
            <FlatList
              data={searchResults}
              keyExtractor={u => u.id}
              contentContainerStyle={{ padding: 16, gap: 10 }}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[styles.searchRow, { backgroundColor: colors.surface, borderColor: colors.border }]}
                  onPress={() => router.push(`/chat/${item.id}` as never)}
                  activeOpacity={0.8}
                >
                  <Avatar name={item.fullName} uri={item.avatarUrl} size={44} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.text, fontFamily: "Inter_600SemiBold", fontSize: 14 }} numberOfLines={1}>{item.fullName}</Text>
                    <Text style={{ color: colors.textMuted, fontFamily: "Inter_400Regular", fontSize: 12 }}>
                      {item.username ? `@${item.username}` : item.phone}
                    </Text>
                  </View>
                  <View style={[styles.msgBtn, { backgroundColor: colors.primary }]}>
                    <Feather name="message-circle" size={16} color="#fff" />
                  </View>
                </TouchableOpacity>
              )}
            />
          )}
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}>
          <View style={{ height: 16 }} />

          {topTab === "trending" ? (
            <>
              {/* ── Explore Categories ── */}
              <SectionHeader title="Explore Categories" icon="compass" colors={colors} />
              <View style={styles.exploreGrid}>
                <TouchableOpacity
                  key="all"
                  style={[
                    styles.exploreItem,
                    !exploreCategoryId
                      ? { backgroundColor: colors.primary + "22", borderColor: colors.primary + "70" }
                      : { backgroundColor: colors.surface, borderColor: colors.border },
                  ]}
                  onPress={() => { setExploreCategoryId(null); Haptics.selectionAsync().catch(() => {}); }}
                  activeOpacity={0.85}
                >
                  <View style={[styles.exploreIcon, { backgroundColor: colors.primary + "22" }]}>
                    <Feather name="grid" size={20} color={colors.primary} />
                  </View>
                  <Text style={[styles.exploreLabel, { color: !exploreCategoryId ? colors.text : colors.textMuted, fontFamily: !exploreCategoryId ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                    All
                  </Text>
                </TouchableOpacity>
                {discussionCategories.map(cat => {
                  const active = exploreCategoryId === cat.id;
                  const color = categoryColor(cat.name);
                  return (
                    <TouchableOpacity
                      key={cat.id}
                      style={[
                        styles.exploreItem,
                        active
                          ? { backgroundColor: color + "22", borderColor: color + "70" }
                          : { backgroundColor: colors.surface, borderColor: colors.border },
                      ]}
                      onPress={() => { setExploreCategoryId(cat.id); Haptics.selectionAsync().catch(() => {}); }}
                      activeOpacity={0.85}
                    >
                      <View style={[styles.exploreIcon, { backgroundColor: color + "22" }]}>
                        <Feather name={categoryIcon(cat.name) as any} size={20} color={color} />
                      </View>
                      <Text style={[styles.exploreLabel, { color: active ? colors.text : colors.textMuted, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" }]} numberOfLines={2}>
                        {cat.name}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              <View style={{ height: 24 }} />

              {/* ── Trending banner ── */}
              <View style={[styles.trendingBanner, { backgroundColor: "#0F2A3D" }]}>
                <View style={[styles.trendingBannerIcon, { backgroundColor: "#F59E0B22" }]}>
                  <Feather name="trending-up" size={20} color="#F59E0B" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.trendingBannerTitle, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
                    Trending Discussions
                  </Text>
                  <Text style={[styles.trendingBannerSub, { color: "#99F6E4", fontFamily: "Inter_400Regular" }]}>
                    Join the conversation on what's hot right now
                  </Text>
                </View>
                <TouchableOpacity
                  style={styles.newDiscussionBtn}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
                    setNewCategoryId(exploreCategoryId ?? discussionCategories[0]?.id ?? null);
                    setNewDiscussionVisible(true);
                  }}
                  activeOpacity={0.85}
                >
                  <Feather name="plus" size={18} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={{ height: 16 }} />

              {/* ── Sort toggle ── */}
              <View style={[styles.sortRow]}>
                {(["hot", "new"] as const).map(s => (
                  <TouchableOpacity
                    key={s}
                    style={[
                      styles.sortPill,
                      discussionSort === s
                        ? { backgroundColor: colors.primary + "22", borderColor: colors.primary + "60" }
                        : { backgroundColor: colors.surface, borderColor: colors.border },
                    ]}
                    onPress={() => { setDiscussionSort(s); Haptics.selectionAsync().catch(() => {}); }}
                    activeOpacity={0.85}
                  >
                    <Feather name={s === "hot" ? "trending-up" : "clock"} size={12} color={discussionSort === s ? colors.primary : colors.textMuted} />
                    <Text style={[styles.sortPillText, { color: discussionSort === s ? colors.primary : colors.textMuted, fontFamily: discussionSort === s ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                      {s === "hot" ? "Hot" : "New"}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={{ height: 12 }} />

              {/* ── Trending Discussions list ── */}
              {discussionsLoading ? (
                <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
              ) : discussions.length === 0 ? (
                <View style={styles.center}>
                  <Text style={[styles.emptyText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                    No discussions yet. Be the first to start one!
                  </Text>
                </View>
              ) : (
                <View style={styles.discussionsList}>
                  {discussions.map(d => (
                    <TouchableOpacity
                      key={d.id}
                      style={[styles.discussionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
                      onPress={() => openDiscussion(d.id)}
                      activeOpacity={0.85}
                    >
                      <View style={styles.discussionTopRow}>
                        <View style={[styles.discussionCatPill, { backgroundColor: colors.primary + "18" }]}>
                          <Text style={[styles.discussionCatText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                            {d.categoryName ?? "General"}
                          </Text>
                        </View>
                        {d.replyCount >= 5 && (
                          <View style={styles.hotPill}>
                            <Feather name="trending-up" size={10} color="#F59E0B" />
                            <Text style={styles.hotPillText}>Hot</Text>
                          </View>
                        )}
                      </View>
                      <Text style={[styles.discussionTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={2}>
                        {d.title}
                      </Text>
                      {!!d.body && (
                        <Text style={[styles.discussionPreview, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]} numberOfLines={2}>
                          {d.body}
                        </Text>
                      )}
                      <View style={styles.discussionFooter}>
                        <View style={styles.discussionAuthorRow}>
                          <Avatar name={d.isAnonymous ? "Anonymous" : (d.authorName ?? "User")} uri={d.isAnonymous ? undefined : d.authorAvatarUrl ?? undefined} size={20} />
                          <Text style={[styles.discussionAuthor, { color: colors.textMuted }]}>
                            {d.isAnonymous ? "Anonymous" : (d.authorName ?? "User")} · {formatTimeAgo(d.createdAt)}
                          </Text>
                        </View>
                        <View style={styles.discussionStats}>
                          <View style={styles.discussionStatItem}>
                            <Feather name="message-circle" size={12} color={colors.textMuted} />
                            <Text style={[styles.discussionStatText, { color: colors.textMuted }]}>{d.replyCount}</Text>
                          </View>
                          <View style={styles.discussionStatItem}>
                            <Feather name="eye" size={12} color={colors.textMuted} />
                            <Text style={[styles.discussionStatText, { color: colors.textMuted }]}>{d.viewCount}</Text>
                          </View>
                        </View>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              <View style={{ height: 16 }} />
            </>
          ) : (
          <>
          {/* Nearby banner */}
          {!locationEnabled && <NearbyBanner onEnable={handleEnableNearby} users={suggestedUsers} enabling={enablingNearby} />}

          {/* Category shortcuts */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categories}>
            {CATEGORIES.map(cat => {
              const active = activeCategory === cat.id;
              return (
                <TouchableOpacity
                  key={cat.id}
                  style={[
                    styles.catItem,
                    active
                      ? { backgroundColor: colors.primary + "22", borderColor: colors.primary + "60" }
                      : { backgroundColor: colors.surface, borderColor: colors.border },
                  ]}
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
                    setActiveCategory(cat.id);
                    if (cat.id === "nearby") router.push("/nearby-users" as any);
                    else if (cat.id === "groups") router.push("/groups" as any);
                  }}
                  activeOpacity={0.8}
                >
                  <View style={[styles.catIcon, { backgroundColor: cat.color + "22" }]}>
                    <Feather name={cat.icon as any} size={22} color={cat.color} />
                  </View>
                  <Text style={[styles.catLabel, { color: active ? colors.primary : colors.text, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                    {cat.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          <View style={{ height: 24 }} />

          {/* ── Nearby Users ── */}
          {displayNearby.length > 0 && (
            <>
              <SectionHeader
                title="Nearby Users"
                icon="map-pin"
                onViewAll={() => router.push("/nearby-users" as any)}
                colors={colors}
              />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
                {/* You bubble */}
                <View style={styles.nearbyItem}>
                  <View style={[styles.youRing, { borderColor: colors.primary }]}>
                    <View style={[styles.youCenter, { backgroundColor: colors.primary }]}>
                      <Feather name="user" size={22} color="#fff" />
                    </View>
                  </View>
                  <Text style={[styles.nearbyName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>You</Text>
                </View>

                {displayNearby.map(u => (
                  <TouchableOpacity
                    key={u.id}
                    style={styles.nearbyItem}
                    onPress={() => router.push("/nearby-users" as any)}
                    activeOpacity={0.8}
                  >
                    <View style={styles.avatarWrap}>
                      <Avatar name={u.fullName} uri={u.avatarUrl} size={58} />
                      {u.isOnline && (
                        <View style={[styles.onlineDot, { backgroundColor: "#22C55E", borderColor: colors.background }]} />
                      )}
                    </View>
                    <Text style={[styles.nearbyName, { color: colors.text, fontFamily: "Inter_500Medium" }]} numberOfLines={1}>
                      {u.fullName.split(" ")[0]}
                    </Text>
                    {u.distanceMetres != null && (
                      <Text style={[styles.nearbyDist, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                        {formatDistance(u.distanceMetres)}
                      </Text>
                    )}
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <View style={{ height: 24 }} />
            </>
          )}

          {/* ── Active Now ── */}
          {suggestedUsers.length > 0 && (
            <>
              <SectionHeader
                title="Active Now"
                onViewAll={() => {}}
                colors={colors}
              />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hScroll}>
                {(activeNowUsers.length > 0 ? activeNowUsers : suggestedUsers.slice(0, 6)).map(u => (
                  <TouchableOpacity
                    key={u.id}
                    style={styles.nearbyItem}
                    onPress={() => router.push(`/chat/${u.id}` as never)}
                    activeOpacity={0.8}
                  >
                    <View style={styles.avatarWrap}>
                      <Avatar name={u.fullName} uri={u.avatarUrl} size={58} />
                      <View style={[styles.onlineDot, { backgroundColor: "#22C55E", borderColor: colors.background }]} />
                    </View>
                    <Text style={[styles.nearbyName, { color: colors.text, fontFamily: "Inter_500Medium" }]} numberOfLines={1}>
                      {u.fullName.split(" ")[0]}
                    </Text>
                    <View style={styles.onlineLabel}>
                      <View style={{ width: 5, height: 5, borderRadius: 3, backgroundColor: "#22C55E" }} />
                      <Text style={{ color: "#22C55E", fontSize: 10, fontFamily: "Inter_400Regular" }}>Online</Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              <View style={{ height: 24 }} />
            </>
          )}

          {/* ── Popular Groups ── */}
          {groups.length > 0 && (
            <>
              <SectionHeader
                title="Popular Groups"
                onViewAll={() => router.push("/groups" as any)}
                colors={colors}
              />
              <View style={styles.groupsList}>
                {groups.map(g => (
                  <View key={g.id} style={[styles.groupRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                    <View style={[styles.groupIcon, { backgroundColor: colors.primary + "20" }]}>
                      {g.avatarUrl
                        ? <Image source={{ uri: g.avatarUrl }} style={{ width: 46, height: 46, borderRadius: 13 }} />
                        : <Feather name="layers" size={20} color={colors.primary} />
                      }
                    </View>
                    <View style={styles.groupInfo}>
                      <Text style={[styles.groupName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>{g.name}</Text>
                      <Text style={[styles.groupSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                        {g.memberCount >= 1000 ? `${(g.memberCount / 1000).toFixed(1)}K` : g.memberCount} members
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={[styles.joinBtn, { backgroundColor: colors.primary + "18", borderColor: colors.primary + "40", borderWidth: 1 }]}
                      onPress={() => handleJoinGroup(g)}
                      activeOpacity={0.85}
                      disabled={joiningGroup === g.id}
                    >
                      {joiningGroup === g.id
                        ? <ActivityIndicator size="small" color={colors.primary} />
                        : <Text style={[styles.joinText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                            {g.isPaid ? `₵${((g.membershipFeePesewas ?? 0) / 100).toFixed(0)}` : "Join"}
                          </Text>
                      }
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            </>
          )}

          {loading && (
            <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
          )}

          <View style={{ height: 16 }} />
          </>
          )}
        </ScrollView>
      )}

      {/* ── Discussion detail modal ── */}
      <Modal
        visible={discussionDetailLoading || !!selectedDiscussionDetail}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedDiscussionDetail(null)}
      >
        <KeyboardAvoidingView
          style={[styles.discussionModal, { backgroundColor: colors.background, paddingTop: topPad + 12 }]}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={styles.discussionModalHeader}>
            <TouchableOpacity onPress={() => setSelectedDiscussionDetail(null)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Feather name="arrow-left" size={22} color={colors.text} />
            </TouchableOpacity>
            <Text style={[styles.discussionModalHeaderTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
              Discussion
            </Text>
            <View style={{ width: 22 }} />
          </View>

          {discussionDetailLoading ? (
            <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
          ) : selectedDiscussionDetail && (
            <>
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
                <View style={[styles.discussionCatPill, { backgroundColor: colors.primary + "18", alignSelf: "flex-start", marginBottom: 10 }]}>
                  <Text style={[styles.discussionCatText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
                    {selectedDiscussionDetail.discussion.categoryName ?? "General"}
                  </Text>
                </View>
                <Text style={[styles.discussionDetailTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                  {selectedDiscussionDetail.discussion.title}
                </Text>
                <View style={[styles.discussionAuthorRow, { marginTop: 12, marginBottom: 14 }]}>
                  <Avatar
                    name={selectedDiscussionDetail.discussion.isAnonymous ? "Anonymous" : (selectedDiscussionDetail.discussion.authorName ?? "User")}
                    uri={selectedDiscussionDetail.discussion.isAnonymous ? undefined : selectedDiscussionDetail.discussion.authorAvatarUrl ?? undefined}
                    size={28}
                  />
                  <Text style={[styles.discussionAuthor, { color: colors.textMuted, fontSize: 13 }]}>
                    {selectedDiscussionDetail.discussion.isAnonymous ? "Anonymous" : (selectedDiscussionDetail.discussion.authorName ?? "User")} · {formatTimeAgo(selectedDiscussionDetail.discussion.createdAt)}
                  </Text>
                </View>
                {!!selectedDiscussionDetail.discussion.body && (
                  <Text style={[styles.discussionDetailBody, { color: colors.text, fontFamily: "Inter_400Regular" }]}>
                    {selectedDiscussionDetail.discussion.body}
                  </Text>
                )}

                <View style={[styles.discussionDetailStats, { borderColor: colors.border }]}>
                  <View style={styles.discussionStatItem}>
                    <Feather name="eye" size={14} color={colors.textMuted} />
                    <Text style={[styles.discussionStatText, { color: colors.textMuted }]}>{selectedDiscussionDetail.discussion.viewCount} views</Text>
                  </View>
                  <View style={styles.discussionStatItem}>
                    <Feather name="message-circle" size={14} color={colors.textMuted} />
                    <Text style={[styles.discussionStatText, { color: colors.textMuted }]}>{selectedDiscussionDetail.discussion.replyCount} replies</Text>
                  </View>
                </View>

                <Text style={[styles.repliesHeading, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Replies</Text>
                {selectedDiscussionDetail.replies.length === 0 ? (
                  <Text style={[styles.emptyText, { color: colors.textMuted, fontFamily: "Inter_400Regular", marginTop: 8 }]}>
                    No replies yet. Start the conversation!
                  </Text>
                ) : selectedDiscussionDetail.replies.map(r => (
                  <View key={r.id} style={[styles.replyRow, { borderColor: colors.border }]}>
                    <Avatar name={r.isAnonymous ? "Anonymous" : (r.authorName ?? "User")} uri={r.isAnonymous ? undefined : r.authorAvatarUrl ?? undefined} size={32} />
                    <View style={{ flex: 1, marginLeft: 10 }}>
                      <View style={styles.replyTopRow}>
                        <Text style={[styles.replyAuthor, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                          {r.isAnonymous ? "Anonymous" : (r.authorName ?? "User")}
                        </Text>
                        <Text style={[styles.replyTime, { color: colors.textMuted }]}>{formatTimeAgo(r.createdAt)}</Text>
                      </View>
                      <Text style={[styles.replyBody, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{r.body}</Text>
                      <TouchableOpacity style={styles.replyLikeRow} onPress={() => handleLikeReply(r.id)} activeOpacity={0.7}>
                        <Feather name="heart" size={12} color={colors.textMuted} />
                        <Text style={[styles.replyLikeText, { color: colors.textMuted }]}>{r.likeCount}</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </ScrollView>

              <View style={[styles.replyComposer, { borderColor: colors.border, backgroundColor: colors.background, paddingBottom: insets.bottom + 10 }]}>
                <TouchableOpacity
                  style={styles.anonToggle}
                  onPress={() => setReplyAnonymous(v => !v)}
                  activeOpacity={0.7}
                >
                  <Feather name={replyAnonymous ? "eye-off" : "eye"} size={16} color={replyAnonymous ? colors.primary : colors.textMuted} />
                </TouchableOpacity>
                <TextInput
                  style={[styles.replyInput, { color: colors.text, borderColor: colors.border }]}
                  placeholder="Write a reply..."
                  placeholderTextColor={colors.textMuted}
                  value={replyText}
                  onChangeText={setReplyText}
                  multiline
                />
                <TouchableOpacity
                  style={[styles.replySendBtn, { backgroundColor: colors.primary, opacity: replyText.trim() && !postingReply ? 1 : 0.5 }]}
                  onPress={handlePostReply}
                  disabled={!replyText.trim() || postingReply}
                  activeOpacity={0.85}
                >
                  {postingReply ? <ActivityIndicator size="small" color="#fff" /> : <Feather name="send" size={16} color="#fff" />}
                </TouchableOpacity>
              </View>
            </>
          )}
        </KeyboardAvoidingView>
      </Modal>

      {/* ── New discussion modal ── */}
      <Modal
        visible={newDiscussionVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setNewDiscussionVisible(false)}
      >
        <KeyboardAvoidingView
          style={[styles.discussionModal, { backgroundColor: colors.background, paddingTop: topPad + 12 }]}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <View style={styles.discussionModalHeader}>
            <TouchableOpacity onPress={() => setNewDiscussionVisible(false)} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Feather name="x" size={22} color={colors.text} />
            </TouchableOpacity>
            <Text style={[styles.discussionModalHeaderTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
              New Discussion
            </Text>
            <TouchableOpacity
              onPress={handleCreateDiscussion}
              disabled={!newTitle.trim() || !newCategoryId || postingDiscussion}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              {postingDiscussion
                ? <ActivityIndicator size="small" color={colors.primary} />
                : <Text style={{ color: newTitle.trim() && newCategoryId ? colors.primary : colors.textMuted, fontFamily: "Inter_600SemiBold" }}>Post</Text>
              }
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 40 }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingBottom: 16 }}>
              {discussionCategories.map(cat => {
                const active = newCategoryId === cat.id;
                const color = categoryColor(cat.name);
                return (
                  <TouchableOpacity
                    key={cat.id}
                    style={[
                      styles.discussionCatPill,
                      { paddingHorizontal: 14, paddingVertical: 8 },
                      active ? { backgroundColor: color + "22", borderColor: color, borderWidth: 1 } : { backgroundColor: colors.surface },
                    ]}
                    onPress={() => setNewCategoryId(cat.id)}
                    activeOpacity={0.85}
                  >
                    <Text style={{ color: active ? color : colors.textMuted, fontFamily: "Inter_600SemiBold", fontSize: 13 }}>{cat.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            <TextInput
              style={[styles.newDiscussionTitleInput, { color: colors.text, borderColor: colors.border }]}
              placeholder="Title"
              placeholderTextColor={colors.textMuted}
              value={newTitle}
              onChangeText={setNewTitle}
              maxLength={200}
            />
            <TextInput
              style={[styles.newDiscussionBodyInput, { color: colors.text, borderColor: colors.border }]}
              placeholder="Add more details (optional)"
              placeholderTextColor={colors.textMuted}
              value={newBody}
              onChangeText={setNewBody}
              multiline
              textAlignVertical="top"
            />

            <TouchableOpacity
              style={styles.anonRow}
              onPress={() => setNewAnonymous(v => !v)}
              activeOpacity={0.7}
            >
              <Feather name={newAnonymous ? "check-square" : "square"} size={18} color={newAnonymous ? colors.primary : colors.textMuted} />
              <Text style={{ color: colors.text, fontFamily: "Inter_400Regular", fontSize: 14 }}>Post anonymously</Text>
            </TouchableOpacity>
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1 },
  header:      { paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  headerRow:   { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  headerLeft:  { flexDirection: "row", alignItems: "center", gap: 10 },
  headerIcons: { flexDirection: "row", alignItems: "center", gap: 2 },
  logoBox:     { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 22 },
  iconBtn:     { width: 40, height: 40, alignItems: "center", justifyContent: "center", position: "relative" },
  badge:       { position: "absolute", top: 6, right: 4, minWidth: 16, height: 16, borderRadius: 8, alignItems: "center", justifyContent: "center", paddingHorizontal: 3 },
  badgeText:   { color: "#fff", fontSize: 9, fontFamily: "Inter_700Bold" },
  searchBar:   { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, paddingVertical: 12, borderRadius: 14, borderWidth: StyleSheet.hairlineWidth },
  searchInput: { flex: 1, fontSize: 14, padding: 0 },
  searchRow:   { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderRadius: 14, borderWidth: StyleSheet.hairlineWidth },
  msgBtn:      { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  categories:  { paddingHorizontal: 16, gap: 10 },
  catItem:     { alignItems: "center", gap: 8, paddingHorizontal: 14, paddingVertical: 12, borderRadius: 18, borderWidth: StyleSheet.hairlineWidth, minWidth: 78 },
  catIcon:     { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  catLabel:    { fontSize: 11, textAlign: "center", lineHeight: 15 },
  hScroll:     { paddingHorizontal: 16, gap: 16 },
  nearbyItem:  { alignItems: "center", gap: 5, width: 68 },
  avatarWrap:  { position: "relative" },
  onlineDot:   { position: "absolute", bottom: 2, right: 2, width: 14, height: 14, borderRadius: 7, borderWidth: 2 },
  nearbyName:  { fontSize: 12, textAlign: "center" },
  nearbyDist:  { fontSize: 11, textAlign: "center" },
  onlineLabel: { flexDirection: "row", alignItems: "center", gap: 3 },
  youRing:     { width: 60, height: 60, borderRadius: 30, borderWidth: 2, borderStyle: "dashed", alignItems: "center", justifyContent: "center" },
  youCenter:   { width: 50, height: 50, borderRadius: 25, alignItems: "center", justifyContent: "center" },
  groupsList:  { paddingHorizontal: 16, gap: 10 },
  groupRow:    { flexDirection: "row", alignItems: "center", gap: 12, padding: 14, borderRadius: 18, borderWidth: StyleSheet.hairlineWidth },
  groupIcon:   { width: 46, height: 46, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  groupInfo:   { flex: 1, gap: 2 },
  groupName:   { fontSize: 14 },
  groupSub:    { fontSize: 12 },
  joinBtn:     { paddingHorizontal: 18, paddingVertical: 9, borderRadius: 12 },
  joinText:    { fontSize: 13 },
  center:      { padding: 40, alignItems: "center", justifyContent: "center" },
  emptyText:   { fontSize: 14 },

  tabSwitch:     { flexDirection: "row", borderRadius: 12, padding: 3, marginTop: 12 },
  tabSwitchItem: { flex: 1, alignItems: "center", paddingVertical: 8, borderRadius: 10 },
  tabSwitchText: { fontSize: 13 },

  exploreGrid: { flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 16, gap: 10 },
  exploreItem: { width: "31%" as any, alignItems: "center", gap: 8, paddingVertical: 14, borderRadius: 16, borderWidth: StyleSheet.hairlineWidth },
  exploreIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  exploreLabel: { fontSize: 11, textAlign: "center" },

  trendingBanner: { flexDirection: "row", alignItems: "center", gap: 12, marginHorizontal: 16, borderRadius: 18, padding: 16 },
  trendingBannerIcon: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  trendingBannerTitle: { fontSize: 15 },
  trendingBannerSub: { fontSize: 12, marginTop: 2 },
  newDiscussionBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: "#FFFFFF22" },

  sortRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16 },
  sortPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, borderWidth: StyleSheet.hairlineWidth },
  sortPillText: { fontSize: 12 },

  discussionsList: { paddingHorizontal: 16, gap: 12 },
  discussionCard: { borderRadius: 18, borderWidth: StyleSheet.hairlineWidth, padding: 14, gap: 8 },
  discussionTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  discussionCatPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  discussionCatText: { fontSize: 11 },
  hotPill: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20, backgroundColor: "#F59E0B22" },
  hotPillText: { fontSize: 10, color: "#F59E0B", fontFamily: "Inter_700Bold" },
  discussionTitle: { fontSize: 15, lineHeight: 20 },
  discussionPreview: { fontSize: 13, lineHeight: 18 },
  discussionFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 4 },
  discussionAuthorRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  discussionAuthor: { fontSize: 11 },
  discussionStats: { flexDirection: "row", alignItems: "center", gap: 12 },
  discussionStatItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  discussionStatText: { fontSize: 11 },

  discussionModal: { flex: 1 },
  discussionModalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14 },
  discussionModalHeaderTitle: { fontSize: 16 },
  discussionDetailTitle: { fontSize: 20, lineHeight: 27 },
  discussionDetailBody: { fontSize: 14, lineHeight: 21 },
  discussionDetailStats: { flexDirection: "row", gap: 20, marginTop: 16, paddingVertical: 14, borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  repliesHeading: { fontSize: 15, marginTop: 18, marginBottom: 10 },
  replyRow: { flexDirection: "row", paddingVertical: 12, borderTopWidth: StyleSheet.hairlineWidth },
  replyTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  replyAuthor: { fontSize: 13 },
  replyTime: { fontSize: 11 },
  replyBody: { fontSize: 13, marginTop: 3, lineHeight: 18 },
  replyLikeRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 },
  replyLikeText: { fontSize: 11 },

  replyComposer: { flexDirection: "row", alignItems: "flex-end", gap: 8, paddingHorizontal: 16, paddingTop: 10, borderTopWidth: StyleSheet.hairlineWidth },
  anonToggle: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  replyInput: { flex: 1, borderWidth: StyleSheet.hairlineWidth, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 9, fontSize: 14, maxHeight: 100 },
  replySendBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },

  newDiscussionTitleInput: { fontSize: 17, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 10, marginBottom: 12 },
  newDiscussionBodyInput: { fontSize: 14, minHeight: 120, borderWidth: StyleSheet.hairlineWidth, borderRadius: 12, padding: 12 },
  anonRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 16 },
});
