import { Feather } from "@expo/vector-icons";
import * as Location from "expo-location";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { customFetch } from "@workspace/api-client-react";
import { useColors } from "@/hooks/useColors";

const { width: SCREEN_W } = Dimensions.get("window");
const MAP_W = Math.min(SCREEN_W - 32, 380);
const MAP_H = 260;
const CX = MAP_W / 2;
const CY = MAP_H / 2;
const RINGS = [52, 96, 132] as const;

interface NearbyUser {
  id: string;
  fullName: string;
  username?: string;
  phone: string;
  avatarUrl?: string;
  isKycVerified?: boolean;
  interests?: string[];
  distanceMetres: number;
  isOnline: boolean;
}

type Filter = "all" | "online" | "verified";
type DistRange = "5km" | "10km" | "50km";

const DIST_METRES: Record<DistRange, number> = { "5km": 5000, "10km": 10000, "50km": 50000 };
const RADAR_ANGLES = [-55, 20, 175, 5, 220, 305, 140, 60];

const AVATAR_COLORS = ["#12D9A0", "#3B82F6", "#10B981", "#F59E0B", "#EC4899", "#EF4444", "#06B6D4"];
function getAvatarColor(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = s.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function Avatar({ name, uri, size = 44 }: { name: string; uri?: string; size?: number }) {
  const initials = name.split(" ").filter(Boolean).map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const color = getAvatarColor(name);
  if (uri) return <Image source={{ uri }} style={{ width: size, height: size, borderRadius: size / 2 }} />;
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color + "30", alignItems: "center", justifyContent: "center" }}>
      <Text style={{ fontSize: size * 0.36, color, fontFamily: "Inter_700Bold" }}>{initials}</Text>
    </View>
  );
}

function formatDistance(metres: number): string {
  if (metres < 1000) return `${Math.round(metres)} m`;
  return `${(metres / 1000).toFixed(1)} km`;
}

function polarXY(angleDeg: number, r: number) {
  const rad = (angleDeg * Math.PI) / 180;
  return { x: CX + r * Math.cos(rad), y: CY + r * Math.sin(rad) };
}

function ringForDistance(metres: number, maxMetres: number): 0 | 1 | 2 {
  const ratio = metres / maxMetres;
  if (ratio < 0.33) return 0;
  if (ratio < 0.66) return 1;
  return 2;
}

// ─── Radar map ────────────────────────────────────────────────────────────────

function RadarMap({ users, distRange, colors }: {
  users: NearbyUser[];
  distRange: DistRange;
  colors: ReturnType<typeof useColors>;
}) {
  const SZ = 38;
  const HALF = SZ / 2;
  const maxM = DIST_METRES[distRange];

  return (
    <View style={[rm.container, { backgroundColor: "#080816" }]}>
      {/* Subtle grid dots */}
      {[0.25, 0.5, 0.75].map((y, yi) =>
        [0.25, 0.5, 0.75].map((x, xi) => (
          <View key={`${yi}-${xi}`} style={[rm.gridDot, { left: MAP_W * x, top: MAP_H * y }]} />
        ))
      )}

      {/* Concentric rings */}
      {RINGS.map((r, i) => (
        <View key={i} style={[rm.ring, {
          width: r * 2, height: r * 2, borderRadius: r,
          left: CX - r, top: CY - r,
          borderColor: "#0D9488" + (i === 0 ? "80" : i === 1 ? "50" : "28"),
        }]} />
      ))}

      {/* Cross lines */}
      <View style={[rm.crossH, { top: CY - 0.5 }]} />
      <View style={[rm.crossV, { left: CX - 0.5 }]} />

      {/* You – center */}
      <View style={[rm.abs, { left: CX - 22, top: CY - 22 }]}>
        <View style={[rm.youRing, { borderColor: colors.primary }]}>
          <View style={[rm.youCenter, { backgroundColor: colors.primary }]}>
            <Feather name="user" size={14} color="#fff" />
          </View>
        </View>
      </View>

      {/* Nearby users */}
      {users.slice(0, 6).map((u, i) => {
        const ring = ringForDistance(u.distanceMetres, maxM);
        const { x, y } = polarXY(RADAR_ANGLES[i % RADAR_ANGLES.length], RINGS[ring]);
        return (
          <View key={u.id} style={[rm.abs, { left: x - HALF, top: y - HALF }]}>
            <View style={[rm.userRing, { borderColor: u.isOnline ? "#22C55E" : "#ffffff30" }]}>
              <Avatar name={u.fullName} uri={u.avatarUrl} size={SZ - 6} />
            </View>
            {u.isOnline && <View style={rm.onlineDot} />}
            <View style={rm.distBubble}>
              <Text style={rm.distText}>{formatDistance(u.distanceMetres)}</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}

const rm = StyleSheet.create({
  container:  { width: MAP_W, height: MAP_H, position: "relative", borderRadius: 18, overflow: "hidden" },
  gridDot:    { position: "absolute", width: 2, height: 2, borderRadius: 1, backgroundColor: "#0D948818" },
  ring:       { position: "absolute", borderWidth: 1 },
  crossH:     { position: "absolute", left: 0, right: 0, height: 1, backgroundColor: "#0D948818" },
  crossV:     { position: "absolute", top: 0, bottom: 0, width: 1, backgroundColor: "#0D948818" },
  abs:        { position: "absolute" },
  youRing:    { width: 44, height: 44, borderRadius: 22, borderWidth: 2.5, alignItems: "center", justifyContent: "center" },
  youCenter:  { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  userRing:   { width: 38, height: 38, borderRadius: 19, borderWidth: 2, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  onlineDot:  { position: "absolute", bottom: 0, right: 0, width: 10, height: 10, borderRadius: 5, backgroundColor: "#22C55E", borderWidth: 1.5, borderColor: "#080816" },
  distBubble: { position: "absolute", top: 40, left: "50%", transform: [{ translateX: -18 }], paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5, backgroundColor: "#00000095", minWidth: 36, alignItems: "center" },
  distText:   { color: "#fff", fontSize: 9, fontFamily: "Inter_500Medium" },
});

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function NearbyUsersScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const topPad = Platform.OS === "web" ? 0 : insets.top;

  const [users, setUsers] = useState<NearbyUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<Filter>("all");
  const [distRange, setDistRange] = useState<DistRange>("5km");
  const [nearbyOn, setNearbyOn] = useState(false);
  const [locError, setLocError] = useState(false);

  const fetchNearby = useCallback(async (radius: number, filter?: Filter) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ radius: String(radius) });
      if (filter && filter !== "all") params.set("filter", filter);
      const data = await customFetch<{ users: NearbyUser[] }>(`/api/discovery/nearby?${params}`);
      setUsers(data.users ?? []);
    } catch { /* location not set or network err */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    (async () => {
      const { status } = await Location.getForegroundPermissionsAsync();
      if (status === "granted") {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        try {
          await customFetch("/api/discovery/location", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              latitude: loc.coords.latitude,
              longitude: loc.coords.longitude,
              nearbyEnabled: true,
            }),
          });
          setNearbyOn(true);
          fetchNearby(DIST_METRES["5km"]);
        } catch { setLocError(true); setLoading(false); }
      } else {
        setLocError(true);
        setLoading(false);
      }
    })();
  }, [fetchNearby]);

  const handleFilterChange = (f: Filter) => {
    setActiveFilter(f);
    fetchNearby(DIST_METRES[distRange], f);
  };

  const handleDistChange = () => {
    const next: DistRange = distRange === "5km" ? "10km" : distRange === "10km" ? "50km" : "5km";
    setDistRange(next);
    fetchNearby(DIST_METRES[next], activeFilter);
  };

  const handleEnableNearby = async () => {
    // Give instant visual feedback the tap registered — previously nothing changed
    // until the GPS fix resolved (several seconds), which read as "barely responds."
    setLoading(true);
    setLocError(false);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        setLocError(true);
        setLoading(false);
        return;
      }
      // getCurrentPositionAsync can hang on some devices/emulators with no GPS fix;
      // race it against a timeout so the UI never gets stuck on the spinner forever.
      const loc = await Promise.race([
        Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error("location-timeout")), 10000),
        ),
      ]);
      await customFetch("/api/discovery/location", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, nearbyEnabled: true }),
      });
      setNearbyOn(true);
      setLocError(false);
      await fetchNearby(DIST_METRES[distRange]);
    } catch {
      setLocError(true);
      setLoading(false);
    }
  };

  const filtered = users.filter(u => {
    if (activeFilter === "online") return u.isOnline;
    if (activeFilter === "verified") return u.isKycVerified;
    return true;
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* ── Header ── */}
      <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.iconBtn} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Nearby Users</Text>
        <TouchableOpacity style={styles.iconBtn} activeOpacity={0.7}>
          <Feather name="sliders" size={20} color={colors.text} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}>

        {/* ── Status banner ── */}
        <View style={[styles.statusBar, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <View style={styles.statusLeft}>
            <View style={[styles.statusIconWrap, { backgroundColor: nearbyOn ? "#22C55E20" : colors.surfaceElevated }]}>
              <Feather name="map-pin" size={16} color={nearbyOn ? "#22C55E" : colors.textMuted} />
            </View>
            <View>
              <Text style={[styles.statusTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                {nearbyOn ? "Nearby discovery is ON" : "Nearby discovery is OFF"}
              </Text>
              <Text style={[styles.statusSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                {nearbyOn ? `You are visible to users within ${distRange}` : "Enable to appear on nearby maps"}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.changeBtn, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}
            onPress={nearbyOn
              ? async () => {
                  await customFetch("/api/discovery/nearby-toggle", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ enabled: false }),
                  });
                  setNearbyOn(false);
                }
              : handleEnableNearby
            }
            activeOpacity={0.8}
          >
            <Text style={[styles.changeBtnText, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
              {nearbyOn ? "Change" : "Enable"}
            </Text>
          </TouchableOpacity>
        </View>

        {/* ── Radar map ── */}
        <View style={styles.mapWrap}>
          {loading ? (
            <View style={[rm.container, { alignItems: "center", justifyContent: "center", backgroundColor: "#080816" }]}>
              <ActivityIndicator color={colors.primary} />
              <Text style={{ color: "#ffffff50", fontSize: 12, marginTop: 10, fontFamily: "Inter_400Regular" }}>
                Finding nearby users…
              </Text>
            </View>
          ) : locError ? (
            <View style={[rm.container, { alignItems: "center", justifyContent: "center", backgroundColor: "#080816", gap: 14 }]}>
              <Feather name="map-pin" size={34} color="#ffffff30" />
              <Text style={{ color: "#ffffff55", fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 20 }}>
                Enable location to{"\n"}see nearby users
              </Text>
              <TouchableOpacity
                style={[styles.enableBtn, { borderColor: colors.primary, backgroundColor: colors.primary + "18" }]}
                onPress={handleEnableNearby}
              >
                <Feather name="map-pin" size={13} color={colors.primary} />
                <Text style={{ color: colors.primary, fontFamily: "Inter_600SemiBold", fontSize: 13 }}>Enable Location</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <RadarMap users={filtered} distRange={distRange} colors={colors} />
          )}
        </View>

        {/* ── Filter chips ── */}
        <View style={styles.filters}>
          {/* All */}
          {(["all", "online", "verified"] as Filter[]).map(f => {
            const active = activeFilter === f;
            return (
              <TouchableOpacity
                key={f}
                style={[
                  styles.chip,
                  active
                    ? { backgroundColor: colors.primary, borderColor: colors.primary }
                    : { backgroundColor: colors.surface, borderColor: colors.border },
                ]}
                onPress={() => handleFilterChange(f)}
                activeOpacity={0.8}
              >
                {f === "online" && (
                  <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: active ? "#fff" : "#22C55E" }} />
                )}
                {f === "verified" && (
                  <Feather name="check-circle" size={12} color={active ? "#fff" : "#3B82F6"} />
                )}
                <Text style={[
                  styles.chipText,
                  { color: active ? "#fff" : colors.text, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" },
                ]}>
                  {f === "all" ? "All" : f === "online" ? "Online" : "Verified"}
                </Text>
              </TouchableOpacity>
            );
          })}

          {/* Distance */}
          <TouchableOpacity
            style={[styles.chip, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={handleDistChange}
            activeOpacity={0.8}
          >
            <Text style={[styles.chipText, { color: colors.text, fontFamily: "Inter_400Regular" }]}>{distRange}</Text>
            <Feather name="chevron-down" size={13} color={colors.textMuted} />
          </TouchableOpacity>
        </View>

        {/* ── User list ── */}
        <View style={styles.list}>
          {filtered.length === 0 && !loading && (
            <View style={{ padding: 32, alignItems: "center", gap: 10 }}>
              <Feather name="users" size={36} color={colors.textMuted} />
              <Text style={{ color: colors.textMuted, fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center" }}>
                {locError
                  ? "Enable location to find nearby users"
                  : activeFilter !== "all"
                  ? "No users match this filter"
                  : `No users within ${distRange}`}
              </Text>
            </View>
          )}

          {filtered.map(u => (
            <View key={u.id} style={[styles.userRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={{ position: "relative" }}>
                <Avatar name={u.fullName} uri={u.avatarUrl} size={54} />
                {u.isOnline && (
                  <View style={[styles.onlineDot, { backgroundColor: "#22C55E", borderColor: colors.surface }]} />
                )}
              </View>

              <View style={styles.userInfo}>
                <View style={styles.nameRow}>
                  <Text style={[styles.userName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]} numberOfLines={1}>
                    {u.fullName}
                  </Text>
                  {u.isKycVerified && (
                    <Feather name="check-circle" size={14} color="#3B82F6" />
                  )}
                </View>
                <Text style={[styles.userDist, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                  {formatDistance(u.distanceMetres)} away
                </Text>
                {(u.interests ?? []).length > 0 && (
                  <View style={styles.tags}>
                    {(u.interests ?? []).slice(0, 3).map(tag => (
                      <View key={tag} style={[styles.tag, { backgroundColor: colors.surfaceElevated }]}>
                        <Text style={[styles.tagText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{tag}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>

              <TouchableOpacity
                style={[styles.chatBtn, { backgroundColor: colors.primary }]}
                onPress={() => router.push(`/chat/${u.id}` as never)}
                activeOpacity={0.8}
              >
                <Feather name="message-circle" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1 },
  header:       { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  iconBtn:      { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerTitle:  { fontSize: 18 },
  statusBar:    { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 16, borderBottomWidth: StyleSheet.hairlineWidth },
  statusLeft:   { flexDirection: "row", alignItems: "center", gap: 12, flex: 1, marginRight: 12 },
  statusIconWrap:{ width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" },
  statusTitle:  { fontSize: 14 },
  statusSub:    { fontSize: 12, marginTop: 2 },
  changeBtn:    { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10, borderWidth: 1 },
  changeBtnText:{ fontSize: 13 },
  enableBtn:    { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 16, paddingVertical: 9, borderRadius: 10, borderWidth: 1 },
  mapWrap:      { padding: 16 },
  filters:      { flexDirection: "row", flexWrap: "nowrap", paddingHorizontal: 16, gap: 8, paddingBottom: 4 },
  chip:         { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 22, borderWidth: 1 },
  chipText:     { fontSize: 13 },
  list:         { padding: 16, gap: 14 },
  userRow:      { flexDirection: "row", alignItems: "center", gap: 14, padding: 14, borderRadius: 20, borderWidth: StyleSheet.hairlineWidth },
  userInfo:     { flex: 1, gap: 3 },
  nameRow:      { flexDirection: "row", alignItems: "center", gap: 5 },
  userName:     { fontSize: 15, flexShrink: 1 },
  userDist:     { fontSize: 12 },
  tags:         { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 4 },
  tag:          { paddingHorizontal: 9, paddingVertical: 4, borderRadius: 8 },
  tagText:      { fontSize: 11 },
  onlineDot:    { position: "absolute", bottom: 1, right: 1, width: 13, height: 13, borderRadius: 7, borderWidth: 2 },
  chatBtn:      { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
});
