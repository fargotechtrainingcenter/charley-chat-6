import { Feather } from "@expo/vector-icons";
import { Image as CachedImage } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Video, ResizeMode } from "expo-av";
import { useLocalSearchParams, useRouter } from "expo-router";
import { customFetch } from "@workspace/api-client-react";
import { safeGoBack } from "@/lib/navigation";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { SectionHeader } from "@/components/FargoComponents";
import { useColors } from "@/hooks/useColors";

interface RemoteMovie {
  id: string;
  title: string;
  description: string | null;
  posterUrl: string | null;
  genre: string | null;
  releaseYear: number | null;
  durationMinutes: number | null;
  rating: number | null;
  isPremium: boolean;
  viewCount: number;
}

function MoreCard({ item, onPress }: { item: RemoteMovie; onPress: () => void }) {
  const colors = useColors();
  return (
    <TouchableOpacity style={{ width: 108 }} onPress={onPress} activeOpacity={0.85}>
      <View style={[mS.poster, { width: 108, height: 152, backgroundColor: colors.surfaceElevated }]}>
        {item.posterUrl ? (
          <CachedImage source={{ uri: item.posterUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
        ) : (
          <Feather name="film" size={20} color="rgba(255,255,255,0.5)" />
        )}
      </View>
      <Text style={[mS.posterTitle, { color: colors.text }]} numberOfLines={1}>{item.title}</Text>
    </TouchableOpacity>
  );
}

export default function MovieDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [inMyList, setInMyList] = useState(false);
  const [checkingAccess, setCheckingAccess] = useState(false);
  const [title, setTitle] = useState<RemoteMovie | null | undefined>(undefined); // undefined = loading
  const [related, setRelated] = useState<RemoteMovie[]>([]);
  const [playingUrl, setPlayingUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    customFetch<RemoteMovie>(`/api/movies/${id}`)
      .then((m) => setTitle(m))
      .catch(() => setTitle(null));
  }, [id]);

  useEffect(() => {
    if (!title) return;
    customFetch<RemoteMovie[]>("/api/movies")
      .then((rows) => setRelated(rows.filter((m) => m.id !== title.id && m.genre === title.genre).slice(0, 8)))
      .catch(() => setRelated([]));
  }, [title]);

  const startPlayback = async () => {
    if (checkingAccess || !id) return;
    setCheckingAccess(true);
    try {
      const result = await customFetch<{ videoUrl: string }>(`/api/movies/${id}/play`, { method: "POST" });
      setPlayingUrl(result.videoUrl);
    } catch (err: any) {
      if (err?.message?.includes("subscription")) {
        Alert.alert(
          "Premium subscription required",
          "Streaming this title requires an active movie subscription.",
          [
            { text: "Not now", style: "cancel" },
            {
              text: "Subscribe",
              onPress: async () => {
                try {
                  await customFetch("/api/movies/subscription/subscribe", { method: "POST" });
                  const result = await customFetch<{ videoUrl: string }>(`/api/movies/${id}/play`, { method: "POST" });
                  setPlayingUrl(result.videoUrl);
                } catch (subErr: any) {
                  Alert.alert("Couldn't subscribe", subErr?.message?.includes("Insufficient") ? "Please fund your wallet and try again." : "Something went wrong. Please try again.");
                }
              },
            },
          ],
        );
      } else {
        Alert.alert("Couldn't play this title", "Please try again.");
      }
    } finally {
      setCheckingAccess(false);
    }
  };

  if (title === undefined) {
    return (
      <View style={[mS.centered, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!title) {
    return (
      <View style={[mS.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textMuted }}>Title not found</Text>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={{ marginTop: 12 }}>
          <Text style={{ color: colors.primary, fontFamily: "Inter_600SemiBold" }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const durationLabel = title.durationMinutes ? `${Math.floor(title.durationMinutes / 60)}h ${title.durationMinutes % 60}m` : "—";
  const ratingLabel = ((title.rating ?? 0) / 10).toFixed(1);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}>
        <View style={mS.backdrop}>
          {title.posterUrl ? (
            <CachedImage source={{ uri: title.posterUrl }} style={StyleSheet.absoluteFill} contentFit="cover" />
          ) : (
            <LinearGradient colors={["#0F2A3D", "#070C14"]} style={StyleSheet.absoluteFill} />
          )}
          <LinearGradient
            colors={["rgba(0,0,0,0.35)", "transparent", "rgba(7,12,20,1)"]}
            style={StyleSheet.absoluteFill}
          />
          <View style={[mS.backdropTopBar, { paddingTop: insets.top + 6 }]}>
            <TouchableOpacity style={mS.roundBtn} onPress={() => safeGoBack(router)}>
              <Feather name="arrow-left" size={18} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={mS.roundBtn}>
              <Feather name="share-2" size={17} color="#fff" />
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={mS.playCircle} onPress={startPlayback} disabled={checkingAccess}>
            {checkingAccess ? <ActivityIndicator color="#fff" /> : <Feather name="play" size={26} color="#fff" />}
          </TouchableOpacity>
        </View>

        <View style={{ paddingHorizontal: 16, marginTop: 16 }}>
          <Text style={[mS.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title.title}</Text>
          <Text style={[mS.meta, { color: colors.textMuted }]}>
            {title.releaseYear ?? "—"} · {title.genre ?? "—"} · {durationLabel}
          </Text>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 }}>
            <Feather name="star" size={13} color={colors.gold} />
            <Text style={{ color: colors.gold, fontSize: 12, fontFamily: "Inter_600SemiBold" }}>
              {ratingLabel}/5
            </Text>
            {title.isPremium && (
              <View style={{ marginLeft: 8, backgroundColor: colors.primary, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                <Text style={{ color: "#04241D", fontSize: 10, fontFamily: "Inter_700Bold" }}>PREMIUM</Text>
              </View>
            )}
          </View>

          <Text style={[mS.description, { color: colors.textMuted }]}>{title.description}</Text>

          <View style={{ flexDirection: "row", gap: 10, marginTop: 18 }}>
            <TouchableOpacity
              style={[mS.actionBtn, { backgroundColor: colors.primary, flex: 1.3, opacity: checkingAccess ? 0.7 : 1 }]}
              onPress={startPlayback}
              disabled={checkingAccess}
              activeOpacity={0.85}
            >
              <Feather name="play" size={16} color="#04241D" />
              <Text style={[mS.actionBtnText, { color: "#04241D" }]}>{checkingAccess ? "Checking…" : "Play Now"}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[mS.actionBtn, { backgroundColor: colors.surfaceElevated, flex: 1, borderWidth: 1, borderColor: colors.border }]}
              onPress={() => setInMyList((v) => !v)}
              activeOpacity={0.85}
            >
              <Feather name={inMyList ? "check" : "plus"} size={16} color={colors.text} />
              <Text style={[mS.actionBtnText, { color: colors.text }]}>{inMyList ? "Added" : "My List"}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[mS.actionBtn, { backgroundColor: colors.surfaceElevated, flex: 1, borderWidth: 1, borderColor: colors.border }]}
              onPress={() => Alert.alert("Download", `"${title.title}" will be available offline shortly.`)}
              activeOpacity={0.85}
            >
              <Feather name="download" size={16} color={colors.text} />
              <Text style={[mS.actionBtnText, { color: colors.text }]}>Download</Text>
            </TouchableOpacity>
          </View>
        </View>

        {related.length > 0 && (
          <View style={{ marginTop: 26 }}>
            <View style={{ paddingHorizontal: 16 }}>
              <SectionHeader title="More Like This" />
            </View>
            <FlatList
              data={related}
              keyExtractor={(item) => item.id}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}
              renderItem={({ item }) => (
                <MoreCard item={item} onPress={() => router.push(`/movie/${item.id}`)} />
              )}
            />
          </View>
        )}
      </ScrollView>

      {/* Full-screen video player */}
      <Modal visible={!!playingUrl} animationType="fade" statusBarTranslucent onRequestClose={() => setPlayingUrl(null)}>
        <View style={{ flex: 1, backgroundColor: "#000", justifyContent: "center" }}>
          {playingUrl && (
            <Video
              source={{ uri: playingUrl }}
              style={{ width: "100%", height: "100%" }}
              resizeMode={ResizeMode.CONTAIN}
              useNativeControls
              shouldPlay
            />
          )}
          <TouchableOpacity
            style={[mS.roundBtn, { position: "absolute", top: insets.top + 12, left: 16 }]}
            onPress={() => setPlayingUrl(null)}
          >
            <Feather name="x" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

const mS = StyleSheet.create({
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },

  backdrop: { height: 300, justifyContent: "space-between" },
  backdropTopBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 16,
  },
  roundBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(0,0,0,0.4)",
    alignItems: "center",
    justifyContent: "center",
  },
  playCircle: {
    alignSelf: "center",
    marginBottom: 34,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "rgba(255,255,255,0.18)",
    borderWidth: 1.5,
    borderColor: "rgba(255,255,255,0.5)",
    alignItems: "center",
    justifyContent: "center",
  },

  title: { fontSize: 24 },
  meta: { fontSize: 13, marginTop: 4, fontFamily: "Inter_500Medium" },
  description: { fontSize: 14, lineHeight: 21, marginTop: 14, fontFamily: "Inter_400Regular" },

  actionBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 12,
    paddingVertical: 13,
  },
  actionBtnText: { fontSize: 12.5, fontWeight: "700", fontFamily: "Inter_700Bold" },

  poster: {
    borderRadius: 12,
    overflow: "hidden",
    marginBottom: 6,
    alignItems: "center",
    justifyContent: "center",
  },
  posterTitle: { fontSize: 12.5, fontFamily: "Inter_600SemiBold" },
});
