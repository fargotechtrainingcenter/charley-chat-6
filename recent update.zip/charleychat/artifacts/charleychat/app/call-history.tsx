import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useState } from "react";
import {
  Alert,
  FlatList,
  Image,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { customFetch } from "@workspace/api-client-react";

interface CallEntry {
  id: string;
  type: "voice" | "video";
  status: "initiated" | "ringing" | "answered" | "declined" | "missed" | "ended" | "failed";
  durationSeconds: number | null;
  createdAt: string;
  callerId: string;
  receiverId: string;
  callerName: string | null;
  callerAvatarUrl: string | null;
  receiverName: string | null;
  receiverAvatarUrl: string | null;
}

type CallDirection = "outgoing" | "incoming";

function getDirectionAndPeer(entry: CallEntry, myId: string): {
  direction: CallDirection;
  peerName: string;
  peerAvatarUrl: string | null;
  displayStatus: string;
  isNegative: boolean;
} {
  const isOutgoing = entry.callerId === myId;
  const peerName = isOutgoing
    ? (entry.receiverName ?? "Unknown")
    : (entry.callerName ?? "Unknown");
  const peerAvatarUrl = isOutgoing ? entry.receiverAvatarUrl : entry.callerAvatarUrl;

  let displayStatus: string;
  let isNegative = false;

  if (isOutgoing) {
    switch (entry.status) {
      case "ended":    displayStatus = "Outgoing";  break;
      case "missed":   displayStatus = "Cancelled"; break;
      case "declined": displayStatus = "Declined";  isNegative = true; break;
      default:         displayStatus = "Outgoing";
    }
  } else {
    switch (entry.status) {
      case "ended":    displayStatus = "Incoming";  break;
      case "answered": displayStatus = "Incoming";  break;
      case "missed":   displayStatus = "Missed";    isNegative = true; break;
      case "declined": displayStatus = "Declined";  isNegative = true; break;
      default:         displayStatus = "Incoming";
    }
  }

  return { direction: isOutgoing ? "outgoing" : "incoming", peerName, peerAvatarUrl, displayStatus, isNegative };
}

function formatDuration(secs: number | null): string {
  if (!secs) return "";
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } else if (days === 1) {
    return "Yesterday";
  } else if (days < 7) {
    return d.toLocaleDateString([], { weekday: "short" });
  }
  return d.toLocaleDateString([], { day: "numeric", month: "short" });
}

function AvatarCircle({ name, url, size = 46 }: { name: string; url?: string | null; size?: number }) {
  const colors = useColors();
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const colorSeeds = ["#12D9A0", "#F59E0B", "#EC4899", "#10B981", "#3B82F6"];
  const bg = colorSeeds[name.charCodeAt(0) % colorSeeds.length];

  if (url) {
    return (
      <Image source={{ uri: url }} style={{ width: size, height: size, borderRadius: size / 2 }} />
    );
  }
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: bg, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ color: "#fff", fontSize: size * 0.35, fontFamily: "Inter_700Bold" }}>{initials}</Text>
    </View>
  );
}

export default function CallHistoryScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { authUserId, startCall } = useApp();

  const [calls, setCalls] = useState<CallEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchCalls = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const data = await customFetch<CallEntry[]>("/api/calls/history");
      setCalls(Array.isArray(data) ? data : []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { fetchCalls(); }, [fetchCalls]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchCalls(true);
  }, [fetchCalls]);

  const handleDelete = useCallback(async (id: string) => {
    Alert.alert("Delete entry", "Remove this call from your history?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await customFetch<{ ok: boolean }>(`/api/calls/${id}`, { method: "DELETE" });
            setCalls(prev => prev.filter(c => c.id !== id));
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
          } catch {
            Alert.alert("Error", "Could not delete entry.");
          }
        },
      },
    ]);
  }, []);

  const handleCallBack = useCallback((entry: CallEntry) => {
    if (!authUserId) return;
    const { direction } = getDirectionAndPeer(entry, authUserId);
    const peerId = direction === "outgoing" ? entry.receiverId : entry.callerId;
    Alert.alert("Call back", "Choose call type", [
      {
        text: "Voice call",
        onPress: () => {
          safeGoBack(router);
          startCall(peerId, "voice");
        },
      },
      {
        text: "Video call",
        onPress: () => {
          safeGoBack(router);
          startCall(peerId, "video");
        },
      },
      { text: "Cancel", style: "cancel" },
    ]);
  }, [authUserId, router, startCall]);

  const renderItem = ({ item }: { item: CallEntry }) => {
    if (!authUserId) return null;
    const { peerName, peerAvatarUrl, displayStatus, isNegative } = getDirectionAndPeer(item, authUserId);
    const isOutgoing = item.callerId === authUserId;
    const dirIcon: string = isNegative
      ? (item.type === "video" ? "video-off" : "phone-missed")
      : isOutgoing
        ? (item.type === "video" ? "video" : "phone-outgoing")
        : (item.type === "video" ? "video" : "phone-incoming");
    const dirColor = isNegative ? "#EF4444" : isOutgoing ? colors.primary : "#22C55E";
    const dur = formatDuration(item.durationSeconds);

    return (
      <TouchableOpacity
        style={[styles.row, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}
        activeOpacity={0.75}
        onPress={() => handleCallBack(item)}
        onLongPress={() => {
          Haptics.selectionAsync();
          Alert.alert(peerName, "Choose an action", [
            { text: "Voice call", onPress: () => { safeGoBack(router); startCall(isOutgoing ? item.receiverId : item.callerId, "voice"); } },
            { text: "Video call", onPress: () => { safeGoBack(router); startCall(isOutgoing ? item.receiverId : item.callerId, "video"); } },
            { text: "Delete entry", style: "destructive", onPress: () => handleDelete(item.id) },
            { text: "Cancel", style: "cancel" },
          ]);
        }}
      >
        <AvatarCircle name={peerName} url={peerAvatarUrl} size={46} />
        <View style={styles.rowBody}>
          <View style={styles.rowTop}>
            <Text style={[styles.peerName, { color: colors.text }]} numberOfLines={1}>{peerName}</Text>
            <Text style={[styles.timeText, { color: colors.textMuted }]}>{formatDate(item.createdAt)}</Text>
          </View>
          <View style={styles.rowBottom}>
            <Feather name={dirIcon as any} size={13} color={dirColor} />
            <Text style={[styles.statusText, { color: isNegative ? "#EF4444" : colors.textMuted }]}>
              {"  "}{displayStatus}{dur ? ` · ${dur}` : ""}
            </Text>
          </View>
        </View>
        <View style={styles.typeChip}>
          <Feather name={item.type === "video" ? "video" : "phone"} size={13} color={colors.textMuted} />
        </View>
      </TouchableOpacity>
    );
  };

  const empty = !loading && calls.length === 0;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: insets.top + 8, borderBottomColor: colors.border }]}>
        <TouchableOpacity style={styles.backBtn} onPress={() => safeGoBack(router)} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Call History</Text>
        <View style={{ width: 40 }} />
      </View>

      {empty ? (
        <View style={styles.empty}>
          <Feather name="phone" size={48} color={colors.textMuted} style={{ marginBottom: 16 }} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No calls yet</Text>
          <Text style={[styles.emptyBody, { color: colors.textMuted }]}>Your call history will appear here.</Text>
        </View>
      ) : (
        <FlatList
          data={calls}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
          }
          contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1 },
  header:      { flexDirection: "row", alignItems: "center", paddingBottom: 12, paddingHorizontal: 16, borderBottomWidth: 1 },
  backBtn:     { width: 40, alignItems: "flex-start" },
  title:       { flex: 1, textAlign: "center", fontSize: 17, fontFamily: "Inter_700Bold" },
  row:         { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, gap: 12 },
  rowBody:     { flex: 1, gap: 4 },
  rowTop:      { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  rowBottom:   { flexDirection: "row", alignItems: "center" },
  peerName:    { fontSize: 15, fontFamily: "Inter_600SemiBold", flex: 1 },
  timeText:    { fontSize: 12, fontFamily: "Inter_400Regular" },
  statusText:  { fontSize: 13, fontFamily: "Inter_400Regular" },
  typeChip:    { padding: 6 },
  empty:       { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32 },
  emptyTitle:  { fontSize: 18, fontFamily: "Inter_700Bold", marginBottom: 8 },
  emptyBody:   { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center" },
});
