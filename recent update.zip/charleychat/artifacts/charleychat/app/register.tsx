import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const TOP_INSET = Platform.OS === "web" ? 67 : 0;
const TOTAL_STEPS = 2;

type FormData = {
  name: string;
  phone: string;
  pin: string;
  confirmPin: string;
};

export default function RegisterScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { register } = useApp();

  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormData>({
    name: "", phone: "", pin: "", confirmPin: "",
  });
  const [errors, setErrors] = useState<Partial<FormData>>({});

  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [generatedFpId, setGeneratedFpId] = useState("");

  const slideAnim = useRef(new Animated.Value(0)).current;
  const progressWidth = useRef(new Animated.Value(1 / TOTAL_STEPS)).current;

  React.useEffect(() => {
    Animated.timing(progressWidth, {
      toValue: step / TOTAL_STEPS,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [step]);

  const nd = Platform.OS !== "web";

  const animateSlide = (nextStep: number) => {
    Animated.sequence([
      Animated.timing(slideAnim, { toValue: -20, duration: 120, useNativeDriver: nd }),
      Animated.timing(slideAnim, { toValue: 0, duration: 180, useNativeDriver: nd }),
    ]).start();
    setStep(nextStep);
  };

  const set = (field: keyof FormData) => (val: string) => {
    setForm((f) => ({ ...f, [field]: val }));
    setErrors((e) => ({ ...e, [field]: "" }));
  };

  // ── Validation ───────────────────────────────────────────────────────────────

  const validateStep1 = () => {
    const e: Partial<FormData> = {};
    if (!form.name.trim()) e.name = "Full name is required";
    const phone = form.phone.trim();
    if (!phone || phone.replace(/\s/g, "").length < 9) e.phone = "Enter a valid phone number";
    if (form.pin.length < 4) e.pin = "PIN must be at least 4 digits";
    if (!/^\d+$/.test(form.pin)) e.pin = "PIN must be numbers only";
    if (form.pin !== form.confirmPin) e.confirmPin = "PINs do not match";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  // ── Registration submit ──────────────────────────────────────────────────────

  const handleNext1 = async () => {
    if (!validateStep1()) return;
    setFormError("");
    setSubmitting(true);
    try {
      const { fpId } = await register({
        name: form.name.trim(),
        phone: form.phone.trim(),
        pin: form.pin,
      });
      setGeneratedFpId(fpId);
      animateSlide(2);
    } catch (err: any) {
      const msg = err?.data?.error ?? err?.message ?? "Registration failed. Please try again.";
      setFormError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  // ── Input style helper ───────────────────────────────────────────────────────

  const inputStyle = (hasErr?: string) => [
    styles.input,
    {
      backgroundColor: colors.surface,
      borderColor: hasErr ? colors.danger : colors.border,
      color: colors.text,
      fontFamily: "Inter_400Regular",
    },
  ];

  // ── Render ───────────────────────────────────────────────────────────────────

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={[styles.circle, { backgroundColor: colors.primary + "12" }]} />

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border, paddingTop: TOP_INSET + (insets.top || 0) }]}>
        <TouchableOpacity
          style={[styles.headerBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => safeGoBack(router)}
        >
          <Feather name="arrow-left" size={18} color={colors.text} />
        </TouchableOpacity>

        <View style={styles.headerCenter}>
          <Text style={[styles.stepLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>
            {step === 1 && "Create Account"}
            {step === 2 && "All Done!"}
          </Text>
          <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            Step {Math.min(step, TOTAL_STEPS)} of {TOTAL_STEPS}
          </Text>
        </View>

        <View style={styles.headerBtn} />
      </View>

      {/* Progress bar */}
      <View style={[styles.progressTrack, { backgroundColor: colors.border }]}>
        <Animated.View
          style={[
            styles.progressFill,
            { backgroundColor: colors.primary, width: progressWidth.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] }) },
          ]}
        />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <Animated.View style={{ transform: [{ translateY: slideAnim }] }}>

          {/* ── STEP 1: Account Info ───────────────────────────────────── */}
          {step === 1 && (
            <View style={styles.stepContainer}>
              <View style={styles.brandBlock}>
                <Image source={require("../assets/images/logo.png")} style={styles.logoMini} resizeMode="contain" />
                <Image source={require("../assets/images/charley-wordmark.png")} style={styles.wordmark} resizeMode="contain" />
              </View>

              <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                Create your account
              </Text>
              <Text style={[styles.stepDesc, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                Start sending money in seconds
              </Text>

              <View style={styles.fields}>
                {/* Full Name */}
                <View>
                  <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Full Name</Text>
                  <TextInput
                    style={inputStyle(errors.name)}
                    value={form.name}
                    onChangeText={set("name")}
                    placeholder="Kwame Mensah"
                    placeholderTextColor={colors.textMuted}
                    autoCapitalize="words"
                    returnKeyType="next"
                  />
                  {errors.name ? <Text style={[styles.errText, { color: colors.danger }]}>{errors.name}</Text> : null}
                </View>

                {/* Phone */}
                <View>
                  <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Phone Number</Text>
                  <View style={styles.inputWrap}>
                    <View style={[styles.flagPill, { backgroundColor: colors.surface, borderColor: errors.phone ? colors.danger : colors.border }]}>
                      <Text style={[styles.flagText, { color: colors.text }]}>🇬🇭 +233</Text>
                    </View>
                    <TextInput
                      style={[inputStyle(errors.phone), { paddingLeft: 86 }]}
                      value={form.phone}
                      onChangeText={set("phone")}
                      placeholder="0244 567 890"
                      placeholderTextColor={colors.textMuted}
                      keyboardType="phone-pad"
                      returnKeyType="next"
                    />
                  </View>
                  {errors.phone ? <Text style={[styles.errText, { color: colors.danger }]}>{errors.phone}</Text> : null}
                </View>

                {/* PIN */}
                <View>
                  <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Create PIN</Text>
                  <TextInput
                    style={inputStyle(errors.pin)}
                    value={form.pin}
                    onChangeText={set("pin")}
                    placeholder="4–6 digit PIN"
                    placeholderTextColor={colors.textMuted}
                    keyboardType="numeric"
                    maxLength={6}
                    secureTextEntry
                    returnKeyType="next"
                  />
                  {errors.pin ? <Text style={[styles.errText, { color: colors.danger }]}>{errors.pin}</Text> : null}
                </View>

                {/* Confirm PIN */}
                <View>
                  <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Confirm PIN</Text>
                  <TextInput
                    style={inputStyle(errors.confirmPin)}
                    value={form.confirmPin}
                    onChangeText={set("confirmPin")}
                    placeholder="Re-enter PIN"
                    placeholderTextColor={colors.textMuted}
                    keyboardType="numeric"
                    maxLength={6}
                    secureTextEntry
                    returnKeyType="done"
                    onSubmitEditing={handleNext1}
                  />
                  {errors.confirmPin ? <Text style={[styles.errText, { color: colors.danger }]}>{errors.confirmPin}</Text> : null}
                </View>
              </View>

              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: submitting ? colors.primary + "88" : colors.primary }]}
                onPress={handleNext1}
                disabled={submitting}
                activeOpacity={0.85}
              >
                {submitting ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}>Create Account</Text>
                    <Feather name="arrow-right" size={17} color="#fff" />
                  </>
                )}
              </TouchableOpacity>

              {formError ? (
                <View style={[styles.errorBox, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
                  <Feather name="alert-circle" size={13} color={colors.danger} />
                  <Text style={[styles.errorText, { color: colors.danger, fontFamily: "Inter_400Regular" }]}>{" "}{formError}</Text>
                </View>
              ) : null}

              <View style={styles.footer}>
                <Text style={[styles.footerText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Already have an account?{" "}</Text>
                <TouchableOpacity onPress={() => router.replace("/login")}>
                  <Text style={[styles.footerLink, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Sign In</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* ── STEP 2: Success ────────────────────────────────────────── */}
          {step === 2 && (
            <View style={styles.stepContainer}>
              <View style={[styles.successIcon, { backgroundColor: "#22c55e18" }]}>
                <Feather name="check-circle" size={48} color="#22c55e" />
              </View>

              <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                Welcome to CharLey! 🎉
              </Text>
              <Text style={[styles.stepDesc, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                Your account is ready. Complete KYC from your profile to unlock wallet features.
              </Text>

              {generatedFpId ? (
                <View style={[styles.fpIdBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.fpIdLabel, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Your CharLey ID</Text>
                  <Text style={[styles.fpIdValue, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>{generatedFpId}</Text>
                </View>
              ) : null}

              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: colors.primary }]}
                onPress={() => router.replace("/(tabs)")}
                activeOpacity={0.85}
              >
                <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}>Go to My Wallet</Text>
                <Feather name="arrow-right" size={17} color="#fff" />
              </TouchableOpacity>
            </View>
          )}

        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: { flex: 1, overflow: "hidden" },
  circle: { position: "absolute", width: 360, height: 360, borderRadius: 180, top: -140, right: -80 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  headerBtn: { width: 36, height: 36, borderRadius: 10, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  headerCenter: { flex: 1, alignItems: "center" },
  stepLabel: { fontSize: 14 },
  stepSub: { fontSize: 11, marginTop: 1 },
  progressTrack: { height: 3 },
  progressFill: { height: 3, borderRadius: 2 },
  scrollContent: { paddingHorizontal: 24, paddingBottom: 48 },
  stepContainer: { paddingTop: 28, gap: 16 },
  brandBlock: { alignItems: "center", marginBottom: 4 },
  logoMini: { width: 64, height: 64 },
  wordmark: { width: 170, height: 52, marginTop: -4 },
  stepTitle: { fontSize: 22, letterSpacing: -0.3 },
  stepDesc: { fontSize: 14, lineHeight: 22, marginTop: -4 },
  fields: { gap: 12 },
  label: { fontSize: 12, marginBottom: 5, letterSpacing: 0.2 },
  inputWrap: { position: "relative" },
  flagPill: { position: "absolute", left: 0, top: 0, bottom: 0, zIndex: 1, justifyContent: "center", paddingHorizontal: 10, borderTopLeftRadius: 12, borderBottomLeftRadius: 12, borderRightWidth: 1 },
  flagText: { fontSize: 12 },
  input: { height: 46, borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, fontSize: 14 },
  errText: { fontSize: 11, marginTop: 3 },
  primaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 14, gap: 8, marginTop: 4 },
  primaryBtnText: { color: "#fff", fontSize: 15 },
  errorBox: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, padding: 10 },
  errorText: { fontSize: 12, flex: 1 },
  footer: { flexDirection: "row", alignItems: "center", justifyContent: "center" },
  footerText: { fontSize: 13 },
  footerLink: { fontSize: 13 },
  successIcon: { width: 88, height: 88, borderRadius: 44, alignItems: "center", justifyContent: "center", alignSelf: "center" },
  fpIdBox: { borderRadius: 14, borderWidth: 1, padding: 16, alignItems: "center", gap: 4 },
  fpIdLabel: { fontSize: 12 },
  fpIdValue: { fontSize: 20, letterSpacing: 1 },
});
