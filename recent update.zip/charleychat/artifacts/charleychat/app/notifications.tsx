import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback } from "react";
import {
  FlatList, RefreshControl, StyleSheet, Text, TouchableOpacity, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  useListNotifications,
  useMarkAllNotificationsRead,
  useMarkNotificationRead,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const TYPE_META: Record<string, { icon: string; color: string }> = {
  p2p_receive:    { icon: "arrow-down-circle", color: "#22C55E" },
  p2p_send:       { icon: "arrow-up-circle",   color: "#12D9A0" },
  momo_in:        { icon: "plus-circle",        color: "#22C55E" },
  momo_out:       { icon: "minus-circle",       color: "#F59E0B" },
  escrow_hold:    { icon: "shield",             color: "#F59E0B" },
  escrow_release: { icon: "unlock",             color: "#22C55E" },
  missed_call:    { icon: "phone-missed",       color: "#EF4444" },
  system:         { icon: "bell",               color: "#6B7280" },
};

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function NotificationsScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();

  const queryKey = getListNotificationsQueryKey();
  const { data, isLoading, refetch } = useListNotifications({
    query: { queryKey, refetchInterval: 60000 },
  });

  const markAllMut    = useMarkAllNotificationsRead();
  const markOneMut    = useMarkNotificationRead();

  const notifications = Array.isArray(data) ? data : [];
  const unread = notifications.filter((n: any) => !n.isRead).length;

  const handleMarkAll = useCallback(() => {
    markAllMut.mutate(undefined, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey }),
    });
  }, [markAllMut, queryClient, queryKey]);

  const handleTap = useCallback((id: string, isRead: boolean, type: string) => {
    if (!isRead) {
      markOneMut.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey }),
      });
    }
    if (type === "missed_call") {
      router.push("/call-history" as any);
    }
  }, [markOneMut, queryClient, queryKey, router]);

  const renderItem = ({ item }: { item: any }) => {
    const meta = TYPE_META[item.type] ?? TYPE_META.system;
    return (
      <TouchableOpacity
        style={[
          styles.row,
          { backgroundColor: item.isRead ? colors.surface : colors.surfaceElevated ?? colors.surface, borderBottomColor: colors.border },
        ]}
        activeOpacity={0.75}
        onPress={() => handleTap(item.id, item.isRead, item.type)}
      >
        <View style={[styles.iconWrap, { backgroundColor: meta.color + "20" }]}>
          <Feather name={meta.icon as any} size={18} color={meta.color} />
        </View>
        <View style={styles.rowContent}>
          <View style={styles.rowTop}>
            <Text style={[styles.title, { color: colors.text, fontFamily: item.isRead ? "Inter_400Regular" : "Inter_600SemiBold" }]} numberOfLines={1}>
              {item.title}
            </Text>
            {!item.isRead && <View style={[styles.dot, { backgroundColor: colors.primary }]} />}
          </View>
          <Text style={[styles.body, { color: colors.textMuted }]} numberOfLines={2}>
            {item.body}
          </Text>
          <Text style={[styles.time, { color: colors.textMuted }]}>{timeAgo(item.createdAt)}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Notifications</Text>
        {unread > 0 ? (
          <TouchableOpacity onPress={handleMarkAll} style={styles.markAllBtn}>
            <Text style={[styles.markAllText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Mark all read</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 80 }} />
        )}
      </View>

      <FlatList
        data={notifications}
        keyExtractor={(n) => n.id}
        renderItem={renderItem}
        refreshControl={<RefreshControl refreshing={isLoading} onRefresh={refetch} tintColor={colors.primary} />}
        ListEmptyComponent={
          !isLoading ? (
            <View style={styles.empty}>
              <Feather name="bell-off" size={36} color={colors.textMuted} />
              <Text style={[styles.emptyText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>No notifications yet</Text>
            </View>
          ) : null
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1 },
  header:      { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn:     { padding: 4, marginRight: 8 },
  headerTitle: { flex: 1, fontSize: 18 },
  markAllBtn:  { width: 80, alignItems: "flex-end" },
  markAllText: { fontSize: 13 },
  row:         { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, gap: 12 },
  iconWrap:    { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", marginTop: 2, flexShrink: 0 },
  rowContent:  { flex: 1 },
  rowTop:      { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 2 },
  title:       { flex: 1, fontSize: 14 },
  dot:         { width: 8, height: 8, borderRadius: 4, flexShrink: 0 },
  body:        { fontSize: 13, lineHeight: 18, marginBottom: 4 },
  time:        { fontSize: 11 },
  empty:       { alignItems: "center", justifyContent: "center", paddingTop: 80, gap: 12 },
  emptyText:   { fontSize: 15 },
});
