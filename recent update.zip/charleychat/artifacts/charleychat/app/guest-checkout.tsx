import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const nd = Platform.OS !== "web";

const BENEFITS = [
  { icon: "eye" as const,          label: "Track your transaction in real time" },
  { icon: "unlock" as const,       label: "Release escrow funds instantly" },
  { icon: "flag" as const,         label: "Open disputes with buyer protection" },
  { icon: "message-circle" as const, label: "Chat directly with the seller" },
  { icon: "file-text" as const,    label: "Download receipts & invoices" },
  { icon: "zap" as const,          label: "Faster future payments" },
  { icon: "shield" as const,       label: "Secure wallet & payment history" },
];

const NETWORKS = [
  { id: "mtn" as const,       name: "MTN MoMo",   color: "#FFCC00", textColor: "#1A1A1A" },
  { id: "airteltigo" as const, name: "AirtelTigo", color: "#E4002B", textColor: "#fff" },
  { id: "telecel" as const,   name: "Telecel",    color: "#C0392B", textColor: "#fff" },
];

type GuestStep = "landing" | "pay" | "download" | "success";

export default function GuestCheckoutScreen() {
  const colors   = useColors();
  const insets   = useSafeAreaInsets();
  const router   = useRouter();
  const { code } = useLocalSearchParams<{ code?: string }>();
  const { payLinks, payPayLink } = useApp();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 20 : insets.bottom;

  const pl = code ? payLinks.find((l) => l.code === code) : payLinks[0];

  const [step, setStep] = useState<GuestStep>("landing");
  const [guestPhone, setGuestPhone]   = useState("");
  const [guestName, setGuestName]     = useState("");
  const [network, setNetwork]         = useState<"mtn" | "airteltigo" | "telecel">("mtn");
  const [payError, setPayError]       = useState("");
  const [processing, setProcessing]   = useState(false);

  // ── Animations ───────────────────────────────────────────────────────────────
  const smsBannerY  = useRef(new Animated.Value(-80)).current;
  const glowOpacity = useRef(new Animated.Value(0.6)).current;
  const btnScale    = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // SMS banner slides down then auto-hides
    Animated.spring(smsBannerY, { toValue: 0, useNativeDriver: nd, delay: 800, friction: 8, tension: 55 }).start();
    const t = setTimeout(() =>
      Animated.timing(smsBannerY, { toValue: -80, duration: 350, useNativeDriver: nd }).start(),
    6000);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    // Glow pulse on benefits card
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowOpacity, { toValue: 1, duration: 2200, useNativeDriver: false }),
        Animated.timing(glowOpacity, { toValue: 0.55, duration: 2200, useNativeDriver: false }),
      ])
    ).start();
  }, []);

  const pressBtnIn  = () => Animated.spring(btnScale, { toValue: 0.965, useNativeDriver: nd, friction: 5 }).start();
  const pressBtnOut = () => Animated.spring(btnScale, { toValue: 1, useNativeDriver: nd, friction: 5 }).start();

  // ── Guest pay ────────────────────────────────────────────────────────────────
  const handleGuestPay = () => {
    setPayError("");
    if (guestPhone.length < 10) { setPayError("Enter a valid 10-digit phone number"); return; }
    if (!guestName.trim()) { setPayError("Enter your name"); return; }
    setProcessing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setTimeout(() => {
      if (pl) payPayLink(pl.code, guestPhone, network);
      setProcessing(false);
      setStep("success");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }, 2200);
  };

  if (!pl) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background, paddingTop: topPad }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Feather name="link" size={40} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textMuted }]}>Pay link not found</Text>
        </View>
      </View>
    );
  }

  const ref = pl.code;
  const sellerColor = "#12D9A0";

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* ── Floating SMS notification banner ──────────────────────────────── */}
      <Animated.View
        style={[
          styles.smsBanner,
          { backgroundColor: "#10B98110", borderColor: "#10B98133", top: topPad + 8 },
          { transform: [{ translateY: smsBannerY }] },
        ]}
      >
        <View style={[styles.smsDot, { backgroundColor: "#10B981" }]} />
        <View style={{ flex: 1 }}>
          <Text style={[styles.smsSender, { color: "#10B981" }]}>CharLey · SMS</Text>
          <Text style={[styles.smsText, { color: colors.text }]} numberOfLines={2}>
            Your payment of {pl.amountStr} is secured by CharLey Escrow.
            Track it live in the app.
          </Text>
        </View>
        <Feather name="smartphone" size={16} color="#10B981" />
      </Animated.View>

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <View style={[styles.header, { paddingTop: topPad }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="arrow-left" size={20} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.logoRow}>
          <View style={[styles.logoIcon, { backgroundColor: colors.primary }]}>
            <Feather name="shield" size={14} color="#fff" />
          </View>
          <Text style={[styles.logoText, { color: colors.text }]}>CharLey</Text>
        </View>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: botPad + 32 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* ── Transaction card ─────────────────────────────────────────────── */}
        <View style={[styles.txCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {/* Escrow badge */}
          <View style={[styles.escrowBadge, { backgroundColor: colors.primary + "18" }]}>
            <Feather name="lock" size={11} color={colors.primary} />
            <Text style={[styles.escrowBadgeText, { color: colors.primary }]}>  ESCROW PROTECTED</Text>
          </View>

          {/* Seller info */}
          <View style={styles.sellerRow}>
            <View style={[styles.sellerAvatar, { backgroundColor: sellerColor }]}>
              <Text style={styles.sellerAvatarText}>AM</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.sellerName, { color: colors.text }]}>Akosua Mensah</Text>
              <Text style={[styles.sellerSub, { color: colors.textMuted }]}>Verified seller · CharLey</Text>
            </View>
            <View style={[styles.verifiedBadge, { backgroundColor: colors.successBg }]}>
              <Feather name="check-circle" size={11} color={colors.success} />
              <Text style={[styles.verifiedText, { color: colors.success }]}>  KYC</Text>
            </View>
          </View>

          <View style={[styles.txDivider, { backgroundColor: colors.border }]} />

          {/* Amount */}
          <View style={styles.amountBlock}>
            <Text style={[styles.requestsLabel, { color: colors.textMuted }]}>Requesting payment of</Text>
            <Text style={[styles.txAmount, { color: colors.text }]}>{pl.amountStr}</Text>
            <Text style={[styles.txTitle, { color: colors.textMuted }]}>"{pl.title}"</Text>
            {pl.description ? (
              <Text style={[styles.txDesc, { color: colors.textMuted }]}>{pl.description}</Text>
            ) : null}
          </View>

          <View style={[styles.txDivider, { backgroundColor: colors.border }]} />

          {/* Ref + delivery */}
          <View style={styles.txMeta}>
            <View style={styles.txMetaItem}>
              <Feather name="hash" size={12} color={colors.textMuted} />
              <Text style={[styles.txMetaText, { color: colors.textMuted }]}>Ref: {ref}</Text>
            </View>
            {pl.delivery ? (
              <View style={styles.txMetaItem}>
                <Feather name="truck" size={12} color={colors.textMuted} />
                <Text style={[styles.txMetaText, { color: colors.textMuted }]}>Delivery: {pl.delivery}</Text>
              </View>
            ) : null}
            <View style={styles.txMetaItem}>
              <Feather name="calendar" size={12} color={colors.textMuted} />
              <Text style={[styles.txMetaText, { color: colors.textMuted }]}>Created {pl.createdAt}</Text>
            </View>
          </View>
        </View>

        {/* ── Smart download banner ─────────────────────────────────────────── */}
        <Animated.View
          style={[
            styles.benefitsCard,
            { borderColor: colors.primary, backgroundColor: colors.surface },
            { shadowColor: colors.primary, shadowOpacity: glowOpacity, shadowRadius: 22, shadowOffset: { width: 0, height: 0 }, elevation: 12 },
          ]}
        >
          {/* Gradient-style top strip */}
          <View style={[styles.benefitsTop, { backgroundColor: colors.primary + "18" }]}>
            <View style={[styles.sparkIcon, { backgroundColor: colors.primary }]}>
              <Feather name="star" size={16} color="#fff" />
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={[styles.benefitsTitle, { color: colors.text }]}>Get the full experience</Text>
              <Text style={[styles.benefitsSub, { color: colors.textMuted }]}>Download CharLey — it's free</Text>
            </View>
            <View style={[styles.bonusPill, { backgroundColor: "#F59E0B22", borderColor: "#F59E0B55" }]}>
              <Text style={[styles.bonusPillText, { color: "#F59E0B" }]}>🎁 GH₵2</Text>
            </View>
          </View>

          <View style={styles.benefitsList}>
            {BENEFITS.map((b) => (
              <View key={b.icon} style={styles.benefitRow}>
                <View style={[styles.benefitIconWrap, { backgroundColor: colors.primary + "18" }]}>
                  <Feather name={b.icon} size={14} color={colors.primary} />
                </View>
                <Text style={[styles.benefitLabel, { color: colors.text }]}>{b.label}</Text>
              </View>
            ))}
          </View>

          {/* Reward callout */}
          <View style={[styles.rewardRow, { backgroundColor: "#F59E0B12", borderColor: "#F59E0B33" }]}>
            <Feather name="gift" size={16} color="#F59E0B" />
            <Text style={[styles.rewardText, { color: colors.text }]}>
              {"  "}New users get a{" "}
              <Text style={{ color: "#F59E0B", fontFamily: "Inter_700Bold" }}>GH₵2 welcome bonus</Text>
              {" "}added to their wallet on first payment.
            </Text>
          </View>
        </Animated.View>

        {/* ── Primary CTA: Download ─────────────────────────────────────────── */}
        <Animated.View style={{ transform: [{ scale: btnScale }] }}>
          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: colors.primary }]}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setStep("download"); }}
            onPressIn={pressBtnIn}
            onPressOut={pressBtnOut}
            activeOpacity={1}
          >
            <Feather name="smartphone" size={20} color="#fff" />
            <Text style={[styles.primaryBtnText, { color: "#fff" }]}>  Download CharLey</Text>
          </TouchableOpacity>
        </Animated.View>

        <View style={styles.ctaDivider}>
          <View style={[styles.ctaDividerLine, { backgroundColor: colors.border }]} />
          <Text style={[styles.ctaDividerText, { color: colors.textMuted }]}>or</Text>
          <View style={[styles.ctaDividerLine, { backgroundColor: colors.border }]} />
        </View>

        {/* ── Secondary CTA: Continue as Guest ─────────────────────────────── */}
        <TouchableOpacity
          style={[styles.secondaryBtn, { borderColor: colors.border }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setStep("pay"); }}
          activeOpacity={0.7}
        >
          <Text style={[styles.secondaryBtnText, { color: colors.textMuted }]}>Continue as Guest  →</Text>
        </TouchableOpacity>

        {/* ── Trust footer ─────────────────────────────────────────────────── */}
        <View style={styles.trustFooter}>
          <Feather name="lock" size={12} color={colors.textMuted} />
          <Text style={[styles.trustText, { color: colors.textMuted }]}>
            {"  "}Bank-level encryption · Escrow protection · KYC verified
          </Text>
        </View>
      </ScrollView>

      {/* ── Guest payment modal ───────────────────────────────────────────────── */}
      <Modal visible={step === "pay"} transparent animationType="slide" onRequestClose={() => setStep("landing")}>
        <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.6)" }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={() => !processing && setStep("landing")} />
          <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: botPad + 20 }]}>
            <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[styles.sheetTitle, { color: colors.text }]}>Pay as Guest</Text>
          <Text style={[styles.sheetSub, { color: colors.textMuted }]}>
            Your funds will be held in escrow until you confirm delivery.
          </Text>

          {/* Amount reminder */}
          <View style={[styles.amountReminder, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "33" }]}>
            <Feather name="lock" size={14} color={colors.primary} />
            <Text style={[styles.amountReminderText, { color: colors.primary }]}>
              {"  "}{pl.amountStr} will be held in escrow
            </Text>
          </View>

          {/* Network selector */}
          <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>MOBILE NETWORK</Text>
          <View style={styles.networkRow}>
            {NETWORKS.map((n) => (
              <TouchableOpacity
                key={n.id}
                style={[
                  styles.networkChip,
                  {
                    backgroundColor: network === n.id ? n.color : colors.surfaceElevated,
                    borderColor: network === n.id ? n.color : colors.border,
                  },
                ]}
                onPress={() => { setNetwork(n.id); Haptics.selectionAsync(); }}
                activeOpacity={0.7}
              >
                <Text style={[styles.networkChipText, { color: network === n.id ? n.textColor : colors.textMuted }]}>
                  {n.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Name */}
          <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>YOUR NAME</Text>
          <TextInput
            style={[styles.input, { backgroundColor: colors.surfaceElevated, borderColor: colors.border, color: colors.text }]}
            placeholder="Full name"
            placeholderTextColor={colors.textMuted}
            value={guestName}
            onChangeText={setGuestName}
          />

          {/* Phone */}
          <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>PHONE NUMBER</Text>
          <TextInput
            style={[styles.input, { backgroundColor: colors.surfaceElevated, borderColor: colors.border, color: colors.text }]}
            placeholder="024XXXXXXX"
            placeholderTextColor={colors.textMuted}
            keyboardType="phone-pad"
            value={guestPhone}
            onChangeText={setGuestPhone}
            maxLength={10}
          />

          {payError ? (
            <Text style={[styles.errorText, { color: colors.danger }]}>{payError}</Text>
          ) : null}

          <TouchableOpacity
            style={[
              styles.primaryBtn,
              { backgroundColor: processing ? colors.primary + "88" : colors.primary, marginTop: 8 },
            ]}
            onPress={handleGuestPay}
            activeOpacity={0.85}
            disabled={processing}
          >
            <Feather name={processing ? "loader" : "send"} size={18} color="#fff" />
            <Text style={[styles.primaryBtnText, { color: "#fff" }]}>
              {"  "}{processing ? "Processing…" : `Pay ${pl.amountStr} via MoMo`}
            </Text>
          </TouchableOpacity>

          {/* Conversion nudge inside guest form */}
          <TouchableOpacity
            style={[styles.inFormNudge, { backgroundColor: colors.primary + "10", borderColor: colors.primary + "33" }]}
            onPress={() => { setStep("download"); }}
            activeOpacity={0.7}
          >
            <Feather name="star" size={13} color={colors.primary} />
            <Text style={[styles.inFormNudgeText, { color: colors.primary }]}>
              {"  "}Download CharLey for faster checkout + GH₵2 bonus
            </Text>
            <Feather name="chevron-right" size={13} color={colors.primary} />
          </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* ── Download store modal ──────────────────────────────────────────────── */}
      <Modal visible={step === "download"} transparent animationType="slide" onRequestClose={() => setStep("landing")}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setStep("landing")} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: botPad + 20, alignItems: "center" }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          <View style={[styles.appIconWrap, { backgroundColor: colors.primary }]}>
            <Feather name="shield" size={36} color="#fff" />
          </View>
          <Text style={[styles.sheetTitle, { color: colors.text, textAlign: "center" }]}>Download CharLey</Text>
          <Text style={[styles.sheetSub, { color: colors.textMuted, textAlign: "center", marginBottom: 8 }]}>
            Ghana's safest wallet & escrow platform
          </Text>

          {/* GH₵2 bonus callout */}
          <View style={[styles.bonusCallout, { backgroundColor: "#F59E0B12", borderColor: "#F59E0B44" }]}>
            <Text style={{ fontSize: 24 }}>🎁</Text>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={[styles.bonusCalloutTitle, { color: "#F59E0B" }]}>GH₵2 Welcome Bonus</Text>
              <Text style={[styles.bonusCalloutSub, { color: colors.textMuted }]}>
                Register with {guestPhone || "your number"} and the bonus is added automatically.
              </Text>
            </View>
          </View>

          {/* Store buttons */}
          <TouchableOpacity
            style={[styles.storeBtn, { backgroundColor: "#000" }]}
            activeOpacity={0.85}
            onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)}
          >
            <Feather name="download" size={20} color="#fff" />
            <View style={{ marginLeft: 12 }}>
              <Text style={styles.storeBtnSub}>Download on the</Text>
              <Text style={styles.storeBtnMain}>App Store</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.storeBtn, { backgroundColor: "#01875F", marginTop: 10 }]}
            activeOpacity={0.85}
            onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)}
          >
            <Feather name="play" size={20} color="#fff" />
            <View style={{ marginLeft: 12 }}>
              <Text style={styles.storeBtnSub}>Get it on</Text>
              <Text style={styles.storeBtnMain}>Google Play</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.photoCancel} onPress={() => setStep("landing")}>
            <Text style={[{ color: colors.textMuted, fontSize: 14, paddingTop: 8 }]}>Maybe later</Text>
          </TouchableOpacity>
        </View>
      </Modal>

      {/* ── Success modal ────────────────────────────────────────────────────── */}
      <Modal visible={step === "success"} transparent animationType="fade">
        <View style={[styles.successOverlay, { backgroundColor: "rgba(0,0,0,0.88)" }]}>
          <View style={[styles.successCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.successIcon, { backgroundColor: colors.successBg }]}>
              <Feather name="check" size={40} color={colors.success} />
            </View>
            <Text style={[styles.successTitle, { color: colors.text }]}>Payment Secured!</Text>
            <Text style={[styles.successSub, { color: colors.textMuted }]}>
              {pl.amountStr} is held safely in CharLey Escrow.{"\n"}
              You'll receive an SMS confirmation shortly.
            </Text>

            {/* Post-pay conversion nudge */}
            <View style={[styles.postNudge, { backgroundColor: colors.primary + "12", borderColor: colors.primary + "33" }]}>
              <Text style={[styles.postNudgeTitle, { color: colors.text }]}>Want to track this?</Text>
              <Text style={[styles.postNudgeSub, { color: colors.textMuted }]}>
                Download CharLey to see real-time escrow updates, release funds, and chat with the seller.
              </Text>
              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: colors.primary, marginTop: 10 }]}
                onPress={() => setStep("download")}
                activeOpacity={0.85}
              >
                <Feather name="smartphone" size={16} color="#fff" />
                <Text style={[styles.primaryBtnText, { color: "#fff", fontSize: 14 }]}>  Download CharLey</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={() => safeGoBack(router)} style={{ marginTop: 12 }}>
              <Text style={[{ color: colors.textMuted, fontSize: 13 }]}>Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  // SMS banner
  smsBanner: {
    position: "absolute", left: 16, right: 16, zIndex: 100,
    flexDirection: "row", alignItems: "center", gap: 10,
    borderWidth: 1, borderRadius: 14, padding: 12,
    shadowColor: "#10B981", shadowOpacity: 0.3, shadowRadius: 12, shadowOffset: { width: 0, height: 4 },
  },
  smsDot: { width: 8, height: 8, borderRadius: 4 },
  smsSender: { fontSize: 10, fontFamily: "Inter_700Bold", letterSpacing: 0.8, marginBottom: 2 },
  smsText: { fontSize: 12, lineHeight: 16, fontFamily: "Inter_400Regular" },

  // Header
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 12,
  },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  logoIcon: { width: 28, height: 28, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  logoText: { fontSize: 17, fontFamily: "Inter_700Bold" },

  scroll: { paddingHorizontal: 16, paddingTop: 8, gap: 16 },

  // Transaction card
  txCard: { borderRadius: 18, borderWidth: 1, overflow: "hidden" },
  escrowBadge: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    paddingVertical: 8, paddingHorizontal: 16,
  },
  escrowBadgeText: { fontSize: 11, fontFamily: "Inter_700Bold", letterSpacing: 1.2 },
  sellerRow: { flexDirection: "row", alignItems: "center", gap: 12, padding: 16 },
  sellerAvatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  sellerAvatarText: { color: "#fff", fontSize: 16, fontFamily: "Inter_700Bold" },
  sellerName: { fontSize: 15, fontFamily: "Inter_700Bold" },
  sellerSub: { fontSize: 12, marginTop: 1 },
  verifiedBadge: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 20,
  },
  verifiedText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  txDivider: { height: 1, marginHorizontal: 16 },
  amountBlock: { alignItems: "center", padding: 20 },
  requestsLabel: { fontSize: 12, marginBottom: 6 },
  txAmount: { fontSize: 34, fontFamily: "Inter_700Bold", marginBottom: 4 },
  txTitle: { fontSize: 14, fontFamily: "Inter_500Medium", fontStyle: "italic" },
  txDesc: { fontSize: 13, marginTop: 4, textAlign: "center", lineHeight: 18 },
  txMeta: { flexDirection: "row", flexWrap: "wrap", gap: 12, padding: 14 },
  txMetaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  txMetaText: { fontSize: 11 },

  // Benefits card
  benefitsCard: { borderRadius: 18, borderWidth: 1.5, overflow: "hidden" },
  benefitsTop: { flexDirection: "row", alignItems: "center", padding: 16 },
  sparkIcon: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  benefitsTitle: { fontSize: 16, fontFamily: "Inter_700Bold" },
  benefitsSub: { fontSize: 12, marginTop: 2 },
  bonusPill: {
    borderWidth: 1, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4,
  },
  bonusPillText: { fontSize: 12, fontFamily: "Inter_700Bold" },
  benefitsList: { padding: 14, gap: 10 },
  benefitRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  benefitIconWrap: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  benefitLabel: { fontSize: 14, fontFamily: "Inter_500Medium", flex: 1 },
  rewardRow: {
    flexDirection: "row", alignItems: "flex-start",
    margin: 14, marginTop: 0, borderRadius: 12, borderWidth: 1, padding: 12,
  },
  rewardText: { fontSize: 13, lineHeight: 18, flex: 1 },

  // CTAs
  primaryBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    borderRadius: 16, paddingVertical: 16,
  },
  primaryBtnText: { fontSize: 16, fontFamily: "Inter_700Bold" },
  ctaDivider: { flexDirection: "row", alignItems: "center", gap: 12 },
  ctaDividerLine: { flex: 1, height: 1 },
  ctaDividerText: { fontSize: 13 },
  secondaryBtn: { borderRadius: 16, paddingVertical: 15, borderWidth: 1, alignItems: "center" },
  secondaryBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },

  // Trust footer
  trustFooter: { flexDirection: "row", alignItems: "center", justifyContent: "center", marginTop: 4 },
  trustText: { fontSize: 12 },

  // Sheet modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)" },
  sheet: { borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingHorizontal: 20, paddingTop: 14 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitle: { fontSize: 22, fontFamily: "Inter_700Bold", marginBottom: 6 },
  sheetSub: { fontSize: 14, lineHeight: 20, marginBottom: 18 },
  amountReminder: {
    flexDirection: "row", alignItems: "center",
    borderRadius: 12, borderWidth: 1, padding: 12, marginBottom: 16,
  },
  amountReminderText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  fieldLabel: { fontSize: 11, fontFamily: "Inter_700Bold", letterSpacing: 1, marginBottom: 8, marginTop: 4 },
  networkRow: { flexDirection: "row", gap: 8, marginBottom: 14, flexWrap: "wrap" },
  networkChip: { borderRadius: 22, paddingVertical: 8, paddingHorizontal: 14, borderWidth: 1.5 },
  networkChipText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  input: {
    borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13,
    fontSize: 16, marginBottom: 14,
  },
  errorText: { fontSize: 13, marginBottom: 10, fontFamily: "Inter_500Medium" },
  inFormNudge: {
    flexDirection: "row", alignItems: "center", borderRadius: 12, borderWidth: 1,
    padding: 12, marginTop: 12,
  },
  inFormNudgeText: { flex: 1, fontSize: 13, fontFamily: "Inter_500Medium" },

  // Download modal
  appIconWrap: { width: 72, height: 72, borderRadius: 22, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  bonusCallout: {
    flexDirection: "row", alignItems: "center",
    borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 20, width: "100%",
  },
  bonusCalloutTitle: { fontSize: 14, fontFamily: "Inter_700Bold", marginBottom: 3 },
  bonusCalloutSub: { fontSize: 12, lineHeight: 17 },
  storeBtn: {
    flexDirection: "row", alignItems: "center",
    width: "100%", borderRadius: 14, padding: 16,
  },
  storeBtnSub: { color: "rgba(255,255,255,0.7)", fontSize: 11 },
  storeBtnMain: { color: "#fff", fontSize: 17, fontFamily: "Inter_700Bold" },
  photoCancel: { alignItems: "center" },

  // Success
  successOverlay: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  successCard: { borderRadius: 24, borderWidth: 1, padding: 28, alignItems: "center", width: "100%" },
  successIcon: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  successTitle: { fontSize: 24, fontFamily: "Inter_700Bold", marginBottom: 8 },
  successSub: { fontSize: 14, lineHeight: 20, textAlign: "center", marginBottom: 20 },
  postNudge: { borderRadius: 14, borderWidth: 1, padding: 16, width: "100%" },
  postNudgeTitle: { fontSize: 16, fontFamily: "Inter_700Bold", marginBottom: 6 },
  postNudgeSub: { fontSize: 13, lineHeight: 18 },

  emptyText: { fontSize: 15, marginTop: 12 },
});
