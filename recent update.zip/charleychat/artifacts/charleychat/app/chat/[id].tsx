import { Feather, MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { Audio } from "expo-av";
import { Image as CachedImage } from "expo-image";
import MediaViewerModal, { type MediaViewerItem } from "@/components/MediaViewerModal";
import { PinConfirmModal } from "@/components/PinConfirmModal";
import CallScreen from "@/components/CallScreen";
import IncomingCallModal from "@/components/IncomingCallModal";
import { useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useEffect, useRef, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  ActivityIndicator,
  Alert,
  Animated,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Message, useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { WALLPAPERS, WALLPAPER_STORAGE_KEY } from "@/app/settings";
import { customFetch } from "@workspace/api-client-react";

// ─── Dispute helpers ──────────────────────────────────────────────────────────
const DISPUTE_REASONS = [
  "Item not received",
  "Item not as described",
  "Wrong amount charged",
  "Seller unresponsive",
  "Suspected fraud",
  "Payment already made",
  "Other",
];
type DisputeStep = "choose" | "details" | "done";

// ─── Mobile money networks ────────────────────────────────────────────────────
const NETWORKS = [
  { id: "mtn",        label: "MTN MoMo",      color: "#FFCC00", text: "#000",  icon: "📲" },
  { id: "telecel",    label: "Telecel Cash",   color: "#E30613", text: "#fff",  icon: "📲" },
  { id: "airteltigo", label: "AirtelTigo",     color: "#EF4444", text: "#fff",  icon: "📲" },
  { id: "charley",    label: "CharLey",        color: "#0D9488", text: "#fff",  icon: "💚" },
  { id: "bank",       label: "Bank Transfer",  color: "#3B82F6", text: "#fff",  icon: "🏦" },
] as const;
type NetworkId = typeof NETWORKS[number]["id"];

// Simulate a name-lookup API call (replace with real MoMo / bank API in prod)
async function lookupRecipientName(network: NetworkId, phone: string): Promise<string> {
  await new Promise(r => setTimeout(r, 1800)); // realistic round-trip
  const NAMES = [
    "Kwame Asante", "Abena Mensah", "Kojo Boateng", "Akosua Adu",
    "Yaw Darko",    "Efua Ansah",   "Kofi Nkrumah", "Adwoa Sarpong",
    "Kweku Ofori",  "Ama Owusu",    "Nana Agyei",   "Akua Baffour",
    "Kwabena Tabi", "Akosua Frimpong","Kojo Amponsah","Abena Osei",
  ];
  const seed = parseInt(phone.replace(/\D/g, "").slice(-4) || "0", 10);
  return NAMES[seed % NAMES.length];
}

// ─── Attachment action list ───────────────────────────────────────────────────
const ATTACH_TILES = [
  { key: "camera",   icon: "camera",      label: "Camera",       color: "#22D3EE" },
  { key: "photo",    icon: "image",       label: "Gallery",      color: "#60A5FA" },
  { key: "video",    icon: "film",        label: "Video",        color: "#F472B6" },
  { key: "voice",    icon: "mic",         label: "Voice",        color: "#C084FC" },
  { key: "location", icon: "map-pin",     label: "Location",     color: "#34D399" },
  { key: "send",     icon: "dollar-sign", label: "Send Money",   color: "#4ADE80" },
  { key: "escrow",   icon: "shield",      label: "Secure Deal",  color: "#FBBF24" },
  { key: "paylink",  icon: "link",        label: "Payment Link", color: "#F87171" },
  { key: "request",  icon: "trending-up", label: "Request Money",color: "#5EEAD4" },
] as const;
type AttachKey = typeof ATTACH_TILES[number]["key"];

// ─── Adinkra-style watermark symbols ─────────────────────────────────────────
const WATERMARKS = [
  { symbol: "⊕", top: 80,  left: 20,  size: 72, rotate: "15deg" },
  { symbol: "◈", top: 200, left: 220, size: 56, rotate: "-10deg" },
  { symbol: "✦", top: 350, left: 40,  size: 48, rotate: "30deg" },
  { symbol: "⊛", top: 480, left: 190, size: 64, rotate: "-5deg" },
  { symbol: "❋", top: 620, left: 30,  size: 52, rotate: "20deg" },
  { symbol: "⊕", top: 720, left: 200, size: 60, rotate: "-15deg" },
];

// ─── Screen ───────────────────────────────────────────────────────────────────
export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    isAuthenticated,
    conversations, messages, balance,
    sendMessage, loadMessages, requestMoney, payRequest, declineRequest,
    openDispute, createChatEscrow, sendMediaMessage, sendImageMessage, sendVideoMessage, sendMoneyInChat,
    verifyPin,
    socketStatus, reconnectCount,
    joinGroupRoom, leaveGroupRoom,
    // Calls
    incomingCall, activeCall, outgoingCallPending,
    startCall, acceptCall, rejectCall, endCall,
    // Voice notes
    startVoiceRecording, stopVoiceRecording, sendVoiceNote, cancelVoiceRecording,
  } = useApp();

  const convFound = conversations.find((c) => c.id === id);
  const conv = convFound ?? {
    id: id ?? "",
    name: "Loading…",
    initials: "··",
    color: "#12D9A0",
    lastMessage: "",
    time: "",
    unread: 0,
    type: "chat" as const,
    verified: false,
    paymentAmount: undefined as string | undefined,
    paymentStatus: undefined as "locked" | "delivered" | "awaiting" | undefined,
  };
  const chatMessages: Message[] = messages[id ?? ""] ?? [];

  // Full-screen media viewer (images/videos) state
  const [viewerVisible, setViewerVisible] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(0);
  const mediaItems: MediaViewerItem[] = chatMessages
    .filter((m) => (m.type === "image" || m.type === "video") && !!m.mediaUrl && m.uploadProgress === undefined)
    .map((m) => ({ id: m.id, url: m.mediaUrl!, type: m.type as "image" | "video" }));
  const openMediaViewer = (msg: Message) => {
    const idx = mediaItems.findIndex((it) => it.id === msg.id);
    setViewerIndex(idx === -1 ? 0 : idx);
    setViewerVisible(true);
  };

  useFocusEffect(
    React.useCallback(() => {
      if (id && isAuthenticated) loadMessages(id);
    }, [id, isAuthenticated, loadMessages])
  );

  // Reload missed messages whenever socket reconnects while this screen is open
  useEffect(() => {
    if (reconnectCount > 0 && id && isAuthenticated) {
      loadMessages(id);
    }
  }, [reconnectCount]); // eslint-disable-line react-hooks/exhaustive-deps

  // Join/leave group socket room so real-time group messages are received
  useFocusEffect(
    React.useCallback(() => {
      if (conv.type === "group" && id) {
        joinGroupRoom(id);
        return () => leaveGroupRoom(id);
      }
    }, [conv.type, id, joinGroupRoom, leaveGroupRoom])
  );

  const [text, setText] = useState("");
  const flatRef = useRef<FlatList>(null);

  // Wallpaper
  const [wallpaperId, setWallpaperId] = useState("ghana");
  useFocusEffect(React.useCallback(() => {
    AsyncStorage.getItem(WALLPAPER_STORAGE_KEY).then(v => { if (v) setWallpaperId(v); }).catch(() => {});
  }, []));
  const activeWallpaper = WALLPAPERS.find(w => w.id === wallpaperId);

  // Right-side attachment panel
  const [attachOpen, setAttachOpen] = useState(false);
  const panelAnim = useRef(new Animated.Value(0)).current;
  const PANEL_W = 230;

  // Request Money sheet
  const [showRequestSheet, setShowRequestSheet] = useState(false);
  const [reqAmount, setReqAmount] = useState("");
  const [reqNote, setReqNote] = useState("");

  // Send Money sheet
  const [showSendMoneySheet, setShowSendMoneySheet] = useState(false);
  const [sendAmount, setSendAmount] = useState("");
  const [sendNote, setSendNote] = useState("");
  const [sendNetwork, setSendNetwork] = useState<NetworkId>("mtn");
  const [sendPhone, setSendPhone] = useState("");
  const [sendStep, setSendStep] = useState<"enter" | "review">("enter");
  const [sendFeePesewas, setSendFeePesewas] = useState<number | null>(null);
  const [sendLoading, setSendLoading] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [showPinModal, setShowPinModal] = useState(false);
  const [recipientName, setRecipientName] = useState<string | null>(null);
  const [nameLoading, setNameLoading] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);

  const resetSendSheet = () => {
    setSendStep("enter"); setSendError(null); setSendAmount(""); setSendNote("");
    setSendPhone(""); setSendNetwork("mtn"); setRecipientName(null);
    setNameLoading(false); setNameError(null);
  };

  // Create Escrow sheet
  const [showEscrowSheet, setShowEscrowSheet] = useState(false);
  const [escrowAmount, setEscrowAmount] = useState("");
  const [escrowTitle, setEscrowTitle] = useState("");

  // Voice note — local timer state + preview-before-send
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const recIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Preview state: holds the stopped recording until user taps send or cancel
  const [previewVoice, setPreviewVoice] = useState<{ uri: string; durLabel: string } | null>(null);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const previewSoundRef = useRef<Audio.Sound | null>(null);
  const [previewPos, setPreviewPos] = useState(0); // 0–1

  const startRecording = async () => {
    closeAttach();
    const ok = await startVoiceRecording();
    if (!ok) {
      Alert.alert("Microphone permission required", "Please allow microphone access in Settings.");
      return;
    }
    setRecording(true);
    setRecSecs(0);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    recIntervalRef.current = setInterval(() => setRecSecs((s) => s + 1), 1000);
  };

  const stopRecording = async () => {
    if (!recording) return;
    if (recIntervalRef.current) clearInterval(recIntervalRef.current);
    setRecording(false);
    if (recSecs < 1) {
      cancelVoiceRecording();
      setRecSecs(0);
      return;
    }
    const result = await stopVoiceRecording();
    setRecSecs(0);
    if (result) {
      setPreviewVoice(result);
      setPreviewPos(0);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  };

  const cancelRecording = () => {
    if (recIntervalRef.current) clearInterval(recIntervalRef.current);
    setRecording(false);
    setRecSecs(0);
    cancelVoiceRecording();
  };

  // Preview play/pause
  const handlePreviewPlayPause = async () => {
    if (!previewVoice) return;
    try {
      if (!previewSoundRef.current) {
        await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true, shouldDuckAndroid: true });
        const { sound } = await Audio.Sound.createAsync(
          { uri: previewVoice.uri },
          { shouldPlay: true },
          (status) => {
            if (!status.isLoaded) return;
            const dur = status.durationMillis ?? 1;
            setPreviewPos(status.positionMillis / dur);
            if (status.didJustFinish) {
              setPreviewPlaying(false);
              setPreviewPos(0);
              previewSoundRef.current?.setPositionAsync(0).catch(() => {});
            }
          }
        );
        previewSoundRef.current = sound;
        setPreviewPlaying(true);
      } else {
        const status = await previewSoundRef.current.getStatusAsync();
        if (!status.isLoaded) return;
        if (status.isPlaying) {
          await previewSoundRef.current.pauseAsync();
          setPreviewPlaying(false);
        } else {
          await previewSoundRef.current.playAsync();
          setPreviewPlaying(true);
        }
      }
    } catch {
      setPreviewPlaying(false);
    }
  };

  const cancelPreview = async () => {
    previewSoundRef.current?.unloadAsync().catch(() => {});
    previewSoundRef.current = null;
    setPreviewVoice(null);
    setPreviewPlaying(false);
    setPreviewPos(0);
  };

  const sendPreview = async () => {
    if (!previewVoice || !id) return;
    previewSoundRef.current?.unloadAsync().catch(() => {});
    previewSoundRef.current = null;
    const snap = previewVoice;
    setPreviewVoice(null);
    setPreviewPlaying(false);
    setPreviewPos(0);
    await sendVoiceNote(id, snap.uri, snap.durLabel);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
  };

  // Dispute sheet
  const [disputeMsg, setDisputeMsg] = useState<Message | null>(null);
  const [disputeStep, setDisputeStep] = useState<DisputeStep>("choose");
  const [disputeType, setDisputeType] = useState<"flag" | "dispute" | null>(null);
  const [disputeReason, setDisputeReason] = useState("");
  const [disputeDesc, setDisputeDesc] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 0 : insets.bottom;

  const isAtBottomRef = useRef(true);

  useEffect(() => {
    if (isAtBottomRef.current) {
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: false }), 80);
    }
  }, [chatMessages.length]);

  const toggleAttach = () => {
    const open = !attachOpen;
    setAttachOpen(open);
    Animated.spring(panelAnim, {
      toValue: open ? 1 : 0,
      useNativeDriver: true,
      friction: 9,
      tension: 80,
    }).start();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const closeAttach = () => {
    if (!attachOpen) return;
    setAttachOpen(false);
    Animated.spring(panelAnim, {
      toValue: 0,
      useNativeDriver: true,
      friction: 9,
    }).start();
  };

  const panelTranslateX = panelAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [PANEL_W, 0],
  });
  const backdropOpacity = panelAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  const handleAttachTile = async (key: AttachKey) => {
    closeAttach();
    Haptics.selectionAsync();
    switch (key) {
      case "camera": {
        if (!id) break;
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== "granted") {
          Alert.alert("Permission required", "Camera access is needed to send photos.");
          break;
        }
        const result = await ImagePicker.launchCameraAsync({ mediaTypes: "images", quality: 0.85 });
        if (!result.canceled) sendImageMessage(id, result.assets[0].uri);
        break;
      }
      case "photo": {
        if (!id) break;
        const lib = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (lib.status !== "granted") {
          Alert.alert("Permission required", "Gallery access is needed to send photos.");
          break;
        }
        const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: "images", quality: 0.85 });
        if (!result.canceled) sendImageMessage(id, result.assets[0].uri);
        break;
      }
      case "video": {
        if (!id) break;
        const lib = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (lib.status !== "granted") {
          Alert.alert("Permission required", "Gallery access is needed to send videos.");
          break;
        }
        const result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: "videos",
          quality: 0.7,
          videoMaxDuration: 60,
        });
        if (!result.canceled) sendVideoMessage(id, result.assets[0].uri);
        break;
      }
      case "voice":
        startRecording();
        break;
      case "location":
        if (id) sendMediaMessage(id, "location", "Accra, Greater Accra");
        break;
      case "send":
        setSendAmount("");
        setSendNote("");
        setSendStep("enter");
        setShowSendMoneySheet(true);
        break;
      case "request":
        setShowRequestSheet(true);
        break;
      case "escrow":
        setShowEscrowSheet(true);
        break;
      case "paylink":
        router.push("/pay" as never);
        break;
    }
  };

  const handleSend = () => {
    const t = text.trim();
    if (!t || !id) return;
    closeAttach();
    sendMessage(id, t);
    setText("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleRequestMoney = () => {
    const amount = parseFloat(reqAmount.replace(/,/g, ""));
    if (!amount || amount <= 0 || !id) return;
    requestMoney(id, amount, reqNote.trim() || "Payment Request");
    setReqAmount(""); setReqNote("");
    setShowRequestSheet(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleCreateEscrow = () => {
    const amount = parseFloat(escrowAmount.replace(/,/g, ""));
    if (!amount || amount <= 0 || !escrowTitle.trim() || !id) return;
    createChatEscrow(id, amount, escrowTitle.trim());
    setEscrowAmount(""); setEscrowTitle("");
    setShowEscrowSheet(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handlePay = (msg: Message) => {
    if (!id || !msg.amount) return;
    if (msg.amount > balance) {
      Alert.alert("Insufficient Balance", `You need ${msg.amountStr} but your balance is GH₵ ${balance.toLocaleString()}.`);
      return;
    }
    Alert.alert(
      "Confirm Payment",
      `Pay ${msg.amountStr} to ${conv?.name}?\n\n"${msg.note}"`,
      [
        { text: "Cancel", style: "cancel" },
        { text: `Pay ${msg.amountStr}`, onPress: () => {
          const ok = payRequest(id, msg.id, msg.amount!);
          if (ok) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }},
      ]
    );
  };

  const handleDecline = (msg: Message) => {
    if (!id) return;
    Alert.alert("Decline Request", "Are you sure you want to decline this payment request?", [
      { text: "Cancel", style: "cancel" },
      { text: "Decline", style: "destructive", onPress: () => declineRequest(id, msg.id) },
    ]);
  };

  const openDisputeSheet = (msg: Message) => {
    setDisputeMsg(msg); setDisputeStep("choose");
    setDisputeType(null); setDisputeReason(""); setDisputeDesc("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };
  const closeDisputeSheet = () => setDisputeMsg(null);

  const handleSelectDisputeType = (type: "flag" | "dispute") => {
    setDisputeType(type); setDisputeStep("details"); Haptics.selectionAsync();
  };

  const handleSubmitDispute = () => {
    if (!id || !disputeMsg || !disputeType || !disputeReason) return;
    openDispute(id, disputeMsg.id, disputeType, disputeReason, disputeDesc.trim(), disputeMsg.amountStr);
    setDisputeStep("done");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <View style={[styles.root, { backgroundColor: activeWallpaper?.bg ?? colors.background }]}>
      {/* ── Call overlays ─────────────────────────────────────────────────────── */}
      {activeCall && (
        <CallScreen call={activeCall} onEnd={endCall} />
      )}
      {incomingCall && !activeCall && (
        <IncomingCallModal
          call={incomingCall}
          callerColor={incomingCall.callerId.charCodeAt(0) % 2 === 0 ? "#12D9A0" : "#F59E0B"}
          onAccept={acceptCall}
          onDecline={rejectCall}
        />
      )}

      {/* ── Wallpaper image (portrait, full-cover) ──────────────────────────── */}
      {activeWallpaper?.img ? (
        <Image
          source={activeWallpaper.img}
          style={[StyleSheet.absoluteFill, styles.wallpaperImg]}
          resizeMode="cover"
        />
      ) : (
        /* ── Adinkra watermark layer ─────────────────────────────────────── */
        <View style={StyleSheet.absoluteFill} pointerEvents="none">
          {WATERMARKS.map((w, i) => (
            <Text
              key={i}
              style={{
                position: "absolute",
                top: w.top,
                left: w.left,
                fontSize: w.size,
                color: colors.primary,
                opacity: 0.04,
                transform: [{ rotate: w.rotate }],
              }}
            >
              {w.symbol}
            </Text>
          ))}
        </View>
      )}

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.surface,
            paddingTop: topPad + 6,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>

        <View style={[styles.headerAvatar, { backgroundColor: conv.color }]}>
          <Text style={styles.headerAvatarText}>{conv.initials}</Text>
          {/* Online indicator */}
          <View style={styles.onlineDot} />
        </View>

        <View style={styles.headerInfo}>
          <View style={styles.headerNameRow}>
            <Text
              style={[styles.headerName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}
              numberOfLines={1}
            >
              {conv.name}
            </Text>
            {conv.verified && (
              <View style={[styles.verifiedDot, { backgroundColor: colors.primary }]}>
                <Feather name="check" size={8} color="#fff" />
              </View>
            )}
          </View>
          <Text style={[styles.headerOnline, { color: socketStatus === "connected" ? "#4ADE80" : "#F59E0B" }]}>
          {socketStatus === "connected" ? "Online" : socketStatus === "reconnecting" ? "Reconnecting…" : "Offline"}
        </Text>
        </View>

        <TouchableOpacity
          style={styles.headerAction}
          activeOpacity={0.7}
          onPress={() => id && startCall(id, "video")}
        >
          <Feather name="video" size={20} color={colors.primary} />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.headerAction}
          activeOpacity={0.7}
          onPress={() => id && startCall(id, "voice")}
        >
          <Feather name="phone" size={20} color={colors.primary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.headerAction} activeOpacity={0.7}>
          <Feather name="more-vertical" size={20} color={colors.textMuted} />
        </TouchableOpacity>
      </View>

      {/* ── Reconnecting banner ─────────────────────────────────────────────── */}
      {socketStatus !== "connected" && (
        <View style={[styles.reconnectBanner, { backgroundColor: socketStatus === "reconnecting" ? "#F59E0B" : "#6B7280" }]}>
          {socketStatus === "reconnecting" && (
            <Feather name="wifi-off" size={12} color="#fff" style={{ marginRight: 6 }} />
          )}
          <Text style={styles.reconnectBannerText}>
            {socketStatus === "reconnecting" ? "Reconnecting…" : "Offline"}
          </Text>
        </View>
      )}

      {/* ── Messages + input ───────────────────────────────────────────────── */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={0}
      >
        <FlatList
          ref={flatRef}
          data={chatMessages}
          keyExtractor={(m) => m.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.messageList, { paddingBottom: botPad + 8 }]}
          onScroll={(e) => {
            const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
            isAtBottomRef.current = contentOffset.y + layoutMeasurement.height >= contentSize.height - 80;
          }}
          scrollEventThrottle={100}
          onScrollBeginDrag={closeAttach}
          ListHeaderComponent={<DateSeparator label="Today" />}
          renderItem={({ item: msg }) => (
            <MessageBubble
              msg={msg}
              conv={conv}
              colors={colors}
              onPay={handlePay}
              onDecline={handleDecline}
              onDispute={openDisputeSheet}
              onOpenMedia={openMediaViewer}
              onLongPress={(m) => {
                if (m.from === "me") {
                  Alert.alert("Message Options", m.text ?? "", [
                    {
                      text: "Delete for Everyone",
                      style: "destructive",
                      onPress: () => {
                        const domain = process.env["EXPO_PUBLIC_DOMAIN"];
                        if (!domain) return;
                        customFetch(`/api/messages/${m.id}?forEveryone=true`, { method: "DELETE" })
                          .catch(() => {});
                        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
                      },
                    },
                    { text: "Cancel", style: "cancel" },
                  ]);
                } else {
                  const REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🔥"];
                  Alert.alert(
                    "React",
                    "Choose a reaction",
                    REACTIONS.map((emoji) => ({
                      text: emoji,
                      onPress: () => {
                        customFetch(`/api/messages/${m.id}/reactions`, {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ emoji }),
                        }).catch(() => {});
                      },
                    })).concat([{ text: "Cancel", style: "cancel" } as any])
                  );
                }
              }}
            />
          )}
        />

        {/* ── Recording indicator ──────────────────────────────────────────── */}
        {recording && (
          <View style={[styles.recIndicator, { backgroundColor: "#EF444412", borderTopColor: "#EF444433" }]}>
            <View style={styles.recDot} />
            <Text style={[styles.recText, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
              Recording  {Math.floor(recSecs / 60)}:{(recSecs % 60).toString().padStart(2, "0")}
            </Text>
            <TouchableOpacity onPress={cancelRecording} style={{ padding: 4 }}>
              <Feather name="x" size={16} color={colors.textMuted} />
            </TouchableOpacity>
          </View>
        )}

        {/* ── Voice preview bar ────────────────────────────────────────────── */}
        {previewVoice && !recording && (
          <View style={[styles.previewBar, { backgroundColor: colors.surfaceElevated, borderTopColor: colors.border }]}>
            <TouchableOpacity onPress={handlePreviewPlayPause} style={[styles.previewPlayBtn, { backgroundColor: colors.primary }]} activeOpacity={0.8}>
              <Feather name={previewPlaying ? "pause" : "play"} size={14} color="#fff" />
            </TouchableOpacity>
            <View style={styles.previewWave}>
              {[0.3,0.7,1,0.6,0.9,0.5,0.8,0.4,0.7,0.9,0.5,0.3].map((h, i) => {
                const filled = previewPos > i / 12;
                return (
                  <View key={i} style={[styles.previewBar2, { height: h * 24, backgroundColor: colors.primary, opacity: filled ? 0.95 : 0.3 }]} />
                );
              })}
            </View>
            <Text style={[styles.previewDur, { color: colors.textMuted }]}>{previewVoice.durLabel}</Text>
            <TouchableOpacity onPress={cancelPreview} style={{ padding: 6 }} activeOpacity={0.7}>
              <Feather name="trash-2" size={16} color="#EF4444" />
            </TouchableOpacity>
            <TouchableOpacity onPress={sendPreview} style={[styles.previewSendBtn, { backgroundColor: colors.primary }]} activeOpacity={0.8}>
              <Feather name="send" size={14} color="#fff" />
            </TouchableOpacity>
          </View>
        )}

        {/* ── Input bar ──────────────────────────────────────────────────────── */}
        <View
          style={[
            styles.inputBar,
            { backgroundColor: colors.surface, paddingBottom: Math.max(botPad, 8) },
          ]}
        >
          {/* Emoji */}
          <TouchableOpacity style={styles.inputIconBtn} activeOpacity={0.7}>
            <Text style={[styles.emojiIcon, { color: colors.textMuted }]}>😊</Text>
          </TouchableOpacity>

          {/* Text input */}
          <TextInput
            style={[
              styles.textInput,
              { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border },
            ]}
            placeholder="Message"
            placeholderTextColor={colors.textMuted}
            value={text}
            onChangeText={(t) => {
              setText(t);
              if (attachOpen) closeAttach();
            }}
            multiline
            returnKeyType="send"
            onSubmitEditing={handleSend}
            onFocus={closeAttach}
          />

          {/* Mic / stop-circle / send */}
          {text.trim() ? (
            <TouchableOpacity style={[styles.inputIconBtn]} onPress={handleSend} activeOpacity={0.8}>
              <Feather name="send" size={20} color={colors.primary} />
            </TouchableOpacity>
          ) : recording ? (
            <TouchableOpacity style={[styles.inputIconBtn]} onPress={stopRecording} activeOpacity={0.8}>
              <Feather name="stop-circle" size={20} color="#EF4444" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.inputIconBtn} activeOpacity={0.7} onPress={startRecording}>
              <Feather name="mic" size={20} color={colors.textMuted} />
            </TouchableOpacity>
          )}

          {/* + FAB — opens right panel */}
          <TouchableOpacity
            style={[styles.fabBtn, { backgroundColor: attachOpen ? colors.primaryLight : colors.primary }]}
            onPress={toggleAttach}
            activeOpacity={0.85}
          >
            <Feather name={attachOpen ? "x" : "plus"} size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* ── Right-side action panel ────────────────────────────────────────── */}
      {attachOpen && (
        <Animated.View
          style={[styles.backdrop, { opacity: backdropOpacity }]}
          pointerEvents="box-none"
        >
          <TouchableOpacity
            style={StyleSheet.absoluteFill}
            activeOpacity={1}
            onPress={closeAttach}
          />
        </Animated.View>
      )}

      <Animated.View
        style={[
          styles.rightPanel,
          {
            backgroundColor: colors.surface,
            borderLeftColor: colors.border,
            width: PANEL_W,
            paddingBottom: Math.max(botPad + 12, 20),
            transform: [{ translateX: panelTranslateX }],
          },
        ]}
        pointerEvents={attachOpen ? "auto" : "none"}
      >
        {/* Panel header */}
        <View style={[styles.panelHeader, { borderBottomColor: colors.border, paddingTop: topPad + 6 }]}>
          <TouchableOpacity
            style={styles.hideBtn}
            onPress={closeAttach}
            activeOpacity={0.7}
          >
            <Feather name="chevron-right" size={16} color={colors.textMuted} />
            <Text style={[styles.hideBtnText, { color: colors.textMuted }]}>Hide</Text>
          </TouchableOpacity>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.panelList}
          showsVerticalScrollIndicator={false}
        >
          {ATTACH_TILES.map((tile) => (
            <TouchableOpacity
              key={tile.key}
              style={styles.panelRow}
              onPress={() => handleAttachTile(tile.key)}
              activeOpacity={0.7}
            >
              <View
                style={[
                  styles.panelIconBox,
                  { borderColor: tile.color + "55", backgroundColor: tile.color + "15" },
                ]}
              >
                <Feather
                  name={tile.icon as keyof typeof Feather.glyphMap}
                  size={20}
                  color={tile.color}
                />
              </View>
              <Text
                style={[styles.panelLabel, { color: colors.text, fontFamily: "Inter_500Medium" }]}
              >
                {tile.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </Animated.View>

      {/* ── Request Money Sheet ────────────────────────────────────────────── */}
      <Modal
        visible={showRequestSheet}
        transparent
        animationType="slide"
        onRequestClose={() => setShowRequestSheet(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowRequestSheet(false)}
        />
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) },
          ]}
        >
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <View style={styles.sheetTitleRow}>
            <View style={[styles.sheetTitleIcon, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="dollar-sign" size={18} color={colors.primary} />
            </View>
            <View>
              <Text
                style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}
              >
                Request Money
              </Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted }]}>
                from {conv.name}
              </Text>
            </View>
          </View>
          <View
            style={[
              styles.amountBox,
              { backgroundColor: colors.surfaceElevated, borderColor: colors.border },
            ]}
          >
            <Text
              style={[
                styles.amountCurrency,
                { color: colors.textMuted, fontFamily: "Inter_600SemiBold" },
              ]}
            >
              GH₵
            </Text>
            <TextInput
              style={[styles.amountInput, { color: colors.text, fontFamily: "Inter_700Bold" }]}
              placeholder="0.00"
              placeholderTextColor={colors.textMuted}
              keyboardType="numeric"
              value={reqAmount}
              onChangeText={setReqAmount}
              autoFocus
            />
          </View>
          <View style={styles.quickAmounts}>
            {["50", "100", "200", "500", "1000"].map((a) => (
              <TouchableOpacity
                key={a}
                style={[
                  styles.quickChip,
                  {
                    backgroundColor:
                      reqAmount === a ? colors.primary : colors.surfaceElevated,
                    borderColor: reqAmount === a ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => {
                  setReqAmount(a);
                  Haptics.selectionAsync();
                }}
                activeOpacity={0.7}
              >
                <Text
                  style={[
                    styles.quickChipText,
                    { color: reqAmount === a ? "#fff" : colors.textMuted },
                  ]}
                >
                  {a}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput
            style={[
              styles.noteInput,
              {
                backgroundColor: colors.surfaceElevated,
                color: colors.text,
                borderColor: colors.border,
              },
            ]}
            placeholder="Add a note (e.g. iPhone deposit)"
            placeholderTextColor={colors.textMuted}
            value={reqNote}
            onChangeText={setReqNote}
          />
          <TouchableOpacity
            style={[
              styles.actionBtn,
              {
                backgroundColor:
                  parseFloat(reqAmount) > 0 ? colors.primary : colors.surfaceElevated,
              },
            ]}
            onPress={handleRequestMoney}
            activeOpacity={0.8}
          >
            <Feather
              name="send"
              size={16}
              color={parseFloat(reqAmount) > 0 ? "#fff" : colors.textMuted}
            />
            <Text
              style={[
                styles.actionBtnText,
                {
                  color: parseFloat(reqAmount) > 0 ? "#fff" : colors.textMuted,
                  fontFamily: "Inter_600SemiBold",
                },
              ]}
            >
              {"  "}Send Request
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>

      {/* ── Create Escrow Sheet ────────────────────────────────────────────── */}
      <Modal
        visible={showEscrowSheet}
        transparent
        animationType="slide"
        onRequestClose={() => setShowEscrowSheet(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowEscrowSheet(false)}
        />
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) },
          ]}
        >
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <View style={styles.sheetTitleRow}>
            <View style={[styles.sheetTitleIcon, { backgroundColor: colors.gold + "22" }]}>
              <Feather name="shield" size={18} color={colors.gold} />
            </View>
            <View>
              <Text
                style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}
              >
                Create Escrow Deal
              </Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted }]}>
                with {conv.name}
              </Text>
            </View>
          </View>

          <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>ITEM / DEAL TITLE</Text>
          <TextInput
            style={[
              styles.noteInput,
              {
                backgroundColor: colors.surfaceElevated,
                color: colors.text,
                borderColor: colors.border,
              },
            ]}
            placeholder="e.g. iPhone 17 Pro Max, Rent deposit…"
            placeholderTextColor={colors.textMuted}
            value={escrowTitle}
            onChangeText={setEscrowTitle}
            autoFocus
          />

          <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>AMOUNT TO LOCK</Text>
          <View
            style={[
              styles.amountBox,
              { backgroundColor: colors.surfaceElevated, borderColor: colors.border },
            ]}
          >
            <Text
              style={[
                styles.amountCurrency,
                { color: colors.textMuted, fontFamily: "Inter_600SemiBold" },
              ]}
            >
              GH₵
            </Text>
            <TextInput
              style={[styles.amountInput, { color: colors.text, fontFamily: "Inter_700Bold" }]}
              placeholder="0.00"
              placeholderTextColor={colors.textMuted}
              keyboardType="numeric"
              value={escrowAmount}
              onChangeText={setEscrowAmount}
            />
          </View>

          <View
            style={[
              styles.escrowHint,
              { backgroundColor: colors.gold + "11", borderColor: colors.gold + "33" },
            ]}
          >
            <Feather name="info" size={13} color={colors.gold} style={{ marginRight: 8, marginTop: 1 }} />
            <Text style={[styles.escrowHintText, { color: colors.textMuted }]}>
              Funds are held securely until both parties confirm delivery.
            </Text>
          </View>

          <TouchableOpacity
            style={[
              styles.actionBtn,
              {
                backgroundColor:
                  parseFloat(escrowAmount) > 0 && escrowTitle.trim()
                    ? colors.gold
                    : colors.surfaceElevated,
              },
            ]}
            onPress={handleCreateEscrow}
            activeOpacity={0.8}
          >
            <Feather
              name="lock"
              size={16}
              color={
                parseFloat(escrowAmount) > 0 && escrowTitle.trim() ? "#fff" : colors.textMuted
              }
            />
            <Text
              style={[
                styles.actionBtnText,
                {
                  color:
                    parseFloat(escrowAmount) > 0 && escrowTitle.trim()
                      ? "#fff"
                      : colors.textMuted,
                  fontFamily: "Inter_600SemiBold",
                },
              ]}
            >
              {"  "}Create Escrow Deal
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>

      {/* ── Send Money Sheet ───────────────────────────────────────────────── */}
      <Modal
        visible={showSendMoneySheet}
        transparent
        animationType="slide"
        onRequestClose={() => { if (!sendLoading) { setShowSendMoneySheet(false); resetSendSheet(); } }}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => { if (!sendLoading) { setShowSendMoneySheet(false); resetSendSheet(); } }}
        />
        <View
          style={[
            styles.sheet,
            { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) },
          ]}
        >
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />
          <View style={styles.sheetTitleRow}>
            <View style={[styles.sheetTitleIcon, { backgroundColor: "#4ADE8020" }]}>
              <Feather name="dollar-sign" size={18} color="#4ADE80" />
            </View>
            <View>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                Send Money
              </Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted }]}>
                to {conv.name}
              </Text>
            </View>
          </View>

          {sendStep === "enter" ? (
            <>
              {/* ── Network selector ── */}
              <Text style={[sm.fieldLabel, { color: colors.textMuted }]}>SELECT NETWORK</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
                <View style={{ flexDirection: "row", gap: 8, paddingRight: 4 }}>
                  {NETWORKS.map((n) => {
                    const active = sendNetwork === n.id;
                    return (
                      <TouchableOpacity
                        key={n.id}
                        onPress={() => { setSendNetwork(n.id); Haptics.selectionAsync(); }}
                        activeOpacity={0.75}
                        style={[sm.netChip, {
                          backgroundColor: active ? n.color : colors.surfaceElevated,
                          borderColor: active ? n.color : colors.border,
                        }]}
                      >
                        <Text style={[sm.netChipText, { color: active ? n.text : colors.textMuted }]}>{n.label}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>

              {/* ── Recipient phone ── */}
              <Text style={[sm.fieldLabel, { color: colors.textMuted }]}>
                {sendNetwork === "bank" ? "ACCOUNT NUMBER" : "MOBILE NUMBER"}
              </Text>
              <TextInput
                style={[sm.phoneInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder={sendNetwork === "bank" ? "Enter account number" : "e.g. 0244 000 000"}
                placeholderTextColor={colors.textMuted}
                keyboardType="phone-pad"
                value={sendPhone}
                onChangeText={setSendPhone}
              />

              {/* ── Amount ── */}
              <Text style={[sm.fieldLabel, { color: colors.textMuted, marginTop: 6 }]}>AMOUNT</Text>
              <View style={[styles.amountBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                <Text style={[styles.amountCurrency, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>GH₵</Text>
                <TextInput
                  style={[styles.amountInput, { color: colors.text, fontFamily: "Inter_700Bold" }]}
                  placeholder="0.00"
                  placeholderTextColor={colors.textMuted}
                  keyboardType="numeric"
                  value={sendAmount}
                  onChangeText={setSendAmount}
                />
              </View>
              <View style={styles.quickAmounts}>
                {["20", "50", "100", "200", "500"].map((a) => (
                  <TouchableOpacity key={a}
                    style={[styles.quickChip, { backgroundColor: sendAmount === a ? "#4ADE80" : colors.surfaceElevated, borderColor: sendAmount === a ? "#4ADE80" : colors.border }]}
                    onPress={() => { setSendAmount(a); Haptics.selectionAsync(); }} activeOpacity={0.7}>
                    <Text style={[styles.quickChipText, { color: sendAmount === a ? "#fff" : colors.textMuted }]}>{a}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* ── What's it for ── */}
              <TextInput
                style={[styles.noteInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border }]}
                placeholder="What's it for? (optional)"
                placeholderTextColor={colors.textMuted}
                value={sendNote}
                onChangeText={setSendNote}
              />

              <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 6, marginBottom: 4 }}>
                <Text style={[styles.sheetSub, { color: colors.textMuted }]}>Balance</Text>
                <Text style={[styles.sheetSub, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>GH₵ {balance.toLocaleString()}</Text>
              </View>

              <TouchableOpacity
                style={[styles.actionBtn, { backgroundColor: parseFloat(sendAmount) > 0 && sendPhone.replace(/\D/g,"").length >= 9 ? "#4ADE80" : colors.surfaceElevated }]}
                onPress={async () => {
                  const amt = parseFloat(sendAmount.replace(/,/g, ""));
                  const digits = sendPhone.replace(/\D/g,"");
                  if (!amt || amt <= 0) { Alert.alert("Enter Amount", "Please enter a valid amount."); return; }
                  if (digits.length < 9) { Alert.alert("Enter Number", "Please enter a valid phone/account number."); return; }
                  if (amt > balance) { Alert.alert("Insufficient Balance", `Your balance is GH₵ ${balance.toLocaleString()}.`); return; }
                  // Move to review & kick off name lookup + fee preview
                  setSendStep("review");
                  setRecipientName(null);
                  setNameError(null);
                  setNameLoading(true);
                  setSendFeePesewas(null);
                  Haptics.selectionAsync();
                  customFetch(`/api/wallets/fee-preview?type=send&amountPesewas=${Math.round(amt * 100)}`)
                    .then((r: any) => setSendFeePesewas(r?.feePesewas ?? 0))
                    .catch(() => setSendFeePesewas(0));
                  try {
                    const name = await lookupRecipientName(sendNetwork, sendPhone);
                    setRecipientName(name);
                  } catch {
                    setNameError("Could not verify recipient. Check the number and try again.");
                  } finally {
                    setNameLoading(false);
                  }
                }}
                activeOpacity={0.8}
              >
                <Feather name="search" size={16} color={parseFloat(sendAmount) > 0 && sendPhone.replace(/\D/g,"").length >= 9 ? "#fff" : colors.textMuted} />
                <Text style={[styles.actionBtnText, { color: parseFloat(sendAmount) > 0 && sendPhone.replace(/\D/g,"").length >= 9 ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                  {"  "}Review & Verify
                </Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              {/* ── Name verification card ── */}
              {nameLoading ? (
                <View style={sm.nameCard}>
                  <View style={[sm.networkBadge, { backgroundColor: NETWORKS.find(n => n.id === sendNetwork)?.color + "22" }]}>
                    <Text style={[sm.networkBadgeText, { color: NETWORKS.find(n => n.id === sendNetwork)?.color }]}>
                      {NETWORKS.find(n => n.id === sendNetwork)?.label}
                    </Text>
                  </View>
                  <View style={{ alignItems: "center", paddingVertical: 16, gap: 10 }}>
                    <Text style={[sm.lookupLabel, { color: colors.textMuted }]}>Verifying recipient…</Text>
                    <View style={sm.dotsRow}>
                      {[0,1,2].map(i => <View key={i} style={[sm.dot, { backgroundColor: colors.primary, opacity: 0.3 + i * 0.3 }]} />)}
                    </View>
                    <Text style={{ color: colors.textMuted, fontSize: 11 }}>{sendPhone}</Text>
                  </View>
                </View>
              ) : nameError ? (
                <View style={[sm.nameCard, { borderColor: "#EF444455" }]}>
                  <Feather name="alert-circle" size={28} color="#EF4444" style={{ marginBottom: 8, alignSelf: "center" }} />
                  <Text style={{ color: "#EF4444", textAlign: "center", fontFamily: "Inter_600SemiBold", fontSize: 14, marginBottom: 12 }}>{nameError}</Text>
                  <TouchableOpacity onPress={() => { setSendStep("enter"); setNameError(null); }}
                    style={[sm.retryBtn, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                    <Text style={{ color: colors.text, fontFamily: "Inter_500Medium", fontSize: 13 }}>← Change Details</Text>
                  </TouchableOpacity>
                </View>
              ) : recipientName ? (
                <View style={[sm.nameCard, { borderColor: "#4ADE8055" }]}>
                  <View style={[sm.networkBadge, { backgroundColor: NETWORKS.find(n => n.id === sendNetwork)?.color + "22", marginBottom: 12 }]}>
                    <Text style={[sm.networkBadgeText, { color: NETWORKS.find(n => n.id === sendNetwork)?.color }]}>
                      {NETWORKS.find(n => n.id === sendNetwork)?.label}
                    </Text>
                  </View>
                  <Text style={{ color: colors.textMuted, fontSize: 11, marginBottom: 4 }}>RECIPIENT VERIFIED ✓</Text>
                  <Text style={{ color: "#4ADE80", fontFamily: "Inter_700Bold", fontSize: 20, marginBottom: 4 }}>{recipientName}</Text>
                  <Text style={{ color: colors.textMuted, fontSize: 13, marginBottom: 14 }}>{sendPhone}</Text>
                  <View style={[sm.divider, { backgroundColor: colors.border }]} />
                  <View style={{ marginTop: 12 }}>
                    <Text style={{ color: colors.textMuted, fontSize: 11, marginBottom: 2 }}>AMOUNT</Text>
                    <Text style={{ color: colors.text, fontFamily: "Inter_700Bold", fontSize: 26, marginBottom: 8 }}>
                      GH₵ {parseFloat(sendAmount.replace(/,/g, "")).toLocaleString()}
                    </Text>
                    {sendNote.trim() ? (
                      <>
                        <Text style={{ color: colors.textMuted, fontSize: 11, marginBottom: 2 }}>FOR</Text>
                        <Text style={{ color: colors.text, fontSize: 13 }}>{sendNote}</Text>
                      </>
                    ) : null}
                  </View>
                  <View style={[sm.divider, { backgroundColor: colors.border, marginTop: 12 }]} />
                  <View style={{ marginTop: 12, gap: 6 }}>
                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                      <Text style={{ color: colors.textMuted, fontSize: 13 }}>Transfer fee (0.65%)</Text>
                      <Text style={{ color: colors.text, fontSize: 13 }}>
                        {sendFeePesewas === null ? "…" : `GH₵ ${(sendFeePesewas / 100).toFixed(2)}`}
                      </Text>
                    </View>
                    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                      <Text style={{ color: colors.text, fontFamily: "Inter_600SemiBold", fontSize: 14 }}>You'll pay</Text>
                      <Text style={{ color: colors.text, fontFamily: "Inter_700Bold", fontSize: 14 }}>
                        {sendFeePesewas === null
                          ? "…"
                          : `GH₵ ${(parseFloat(sendAmount.replace(/,/g, "")) + sendFeePesewas / 100).toFixed(2)}`}
                      </Text>
                    </View>
                  </View>
                </View>
              ) : null}

              {sendError ? (
                <View style={{ backgroundColor: sendError.includes("KYC") ? "#F59E0B18" : "#EF444418", borderWidth: 1, borderColor: sendError.includes("KYC") ? "#F59E0B55" : "#EF444455", borderRadius: 12, padding: 12, marginBottom: 12 }}>
                  <Text style={{ color: sendError.includes("KYC") ? "#F59E0B" : "#EF4444", fontSize: 13, fontFamily: "Inter_600SemiBold", marginBottom: sendError.includes("KYC") ? 8 : 0 }}>{sendError}</Text>
                  {sendError.includes("KYC") && (
                    <TouchableOpacity onPress={() => { setShowSendMoneySheet(false); resetSendSheet(); router.push("/(tabs)/profile"); }}
                      style={{ backgroundColor: "#F59E0B", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6, alignSelf: "flex-start" }}>
                      <Text style={{ color: "#000", fontSize: 12, fontFamily: "Inter_600SemiBold" }}>Complete Verification →</Text>
                    </TouchableOpacity>
                  )}
                </View>
              ) : null}

              <View style={{ flexDirection: "row", gap: 10 }}>
                <TouchableOpacity
                  style={[styles.actionBtn, { flex: 1, backgroundColor: colors.surfaceElevated }]}
                  onPress={() => { setSendStep("enter"); setSendError(null); }}
                  activeOpacity={0.8} disabled={sendLoading || nameLoading}>
                  <Text style={[styles.actionBtnText, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.actionBtn, { flex: 2, backgroundColor: recipientName && !nameLoading ? "#4ADE80" : colors.surfaceElevated }]}
                  onPress={() => {
                    if (!recipientName || nameLoading) return;
                    setSendError(null);
                    setShowPinModal(true);
                  }}
                  activeOpacity={0.8}
                  disabled={sendLoading || nameLoading || !recipientName}
                >
                  {sendLoading ? (
                    <Text style={[styles.actionBtnText, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Sending…</Text>
                  ) : (
                    <>
                      <Feather name="lock" size={16} color={recipientName && !nameLoading ? "#fff" : colors.textMuted} />
                      <Text style={[styles.actionBtnText, { color: recipientName && !nameLoading ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
                        {"  "}Enter PIN & Send
                      </Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </Modal>

      {/* ── PIN Confirmation Modal ─────────────────────────────────────────── */}
      <PinConfirmModal
        visible={showPinModal}
        title="Confirm Transfer"
        subtitle={`Send GH₵ ${parseFloat(sendAmount.replace(/,/g, "") || "0").toLocaleString()}${sendFeePesewas ? ` + GH₵ ${(sendFeePesewas / 100).toFixed(2)} fee` : ""} to ${recipientName ?? conv?.name ?? "recipient"} via ${NETWORKS.find(n => n.id === sendNetwork)?.label ?? sendNetwork}`}
        onCancel={() => setShowPinModal(false)}
        onConfirm={async (pin) => {
          const ok = await verifyPin(pin);
          if (!ok) return { ok: false, error: "Incorrect PIN. Please try again." };
          // PIN verified — execute the transfer
          setShowPinModal(false);
          const amt = parseFloat(sendAmount.replace(/,/g, ""));
          setSendLoading(true);
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          const result = await sendMoneyInChat(id, amt, sendNote.trim(), conv.phone ?? "", pin);
          setSendLoading(false);
          if (result.success) {
            setShowSendMoneySheet(false);
            setSendStep("enter");
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          } else {
            setSendError(result.error ?? "Transfer failed. Please try again.");
          }
          return { ok: true };
        }}
      />

      {/* ── Full-screen media viewer (images/videos) ─────────────────────────── */}
      <MediaViewerModal
        visible={viewerVisible}
        items={mediaItems}
        initialIndex={viewerIndex}
        onClose={() => setViewerVisible(false)}
      />

      {/* ── Dispute Sheet ──────────────────────────────────────────────────── */}
      <Modal
        visible={!!disputeMsg}
        transparent
        animationType="slide"
        onRequestClose={closeDisputeSheet}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={closeDisputeSheet}
        />
        <View
          style={[
            styles.sheet,
            styles.disputeSheet,
            { backgroundColor: colors.surface, paddingBottom: Math.max(botPad + 16, 24) },
          ]}
        >
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {disputeStep === "done" ? (
            <View style={styles.doneView}>
              <View style={[styles.doneIcon, { backgroundColor: colors.successBg }]}>
                <Feather name="check-circle" size={32} color={colors.success} />
              </View>
              <Text
                style={[styles.doneTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}
              >
                Submitted
              </Text>
              <Text style={[styles.doneSub, { color: colors.textMuted }]}>
                Your report has been received. Our team will review it within 24 hours.
              </Text>
              <TouchableOpacity
                style={[styles.actionBtn, { backgroundColor: colors.primary, width: "100%" }]}
                onPress={closeDisputeSheet}
                activeOpacity={0.8}
              >
                <Text
                  style={[
                    styles.actionBtnText,
                    { color: "#fff", fontFamily: "Inter_600SemiBold" },
                  ]}
                >
                  Done
                </Text>
              </TouchableOpacity>
            </View>
          ) : disputeStep === "choose" ? (
            <>
              <Text
                style={[
                  styles.sheetTitle,
                  { color: colors.text, fontFamily: "Inter_700Bold", marginBottom: 6 },
                ]}
              >
                Report a problem
              </Text>
              <Text style={[{ color: colors.textMuted, marginBottom: 22, fontSize: 14 }]}>
                {disputeMsg?.amountStr} · {conv.name}
              </Text>
              <TouchableOpacity
                style={[
                  styles.disputeTypeCard,
                  { backgroundColor: colors.surfaceElevated, borderColor: colors.border },
                ]}
                onPress={() => handleSelectDisputeType("flag")}
                activeOpacity={0.7}
              >
                <View
                  style={[styles.disputeTypeIcon, { backgroundColor: colors.warning + "22" }]}
                >
                  <Feather name="flag" size={20} color={colors.warning} />
                </View>
                <View style={styles.disputeTypeInfo}>
                  <Text
                    style={[
                      styles.disputeTypeTitle,
                      { color: colors.text, fontFamily: "Inter_600SemiBold" },
                    ]}
                  >
                    Flag a concern
                  </Text>
                  <Text style={[styles.disputeTypeSub, { color: colors.textMuted }]}>
                    Something seems off — let us know
                  </Text>
                </View>
                <Feather name="chevron-right" size={16} color={colors.textMuted} />
              </TouchableOpacity>
              <View style={{ height: 10 }} />
              <TouchableOpacity
                style={[
                  styles.disputeTypeCard,
                  { backgroundColor: colors.surfaceElevated, borderColor: colors.border },
                ]}
                onPress={() => handleSelectDisputeType("dispute")}
                activeOpacity={0.7}
              >
                <View
                  style={[styles.disputeTypeIcon, { backgroundColor: colors.danger + "18" }]}
                >
                  <Feather name="alert-triangle" size={20} color={colors.danger} />
                </View>
                <View style={styles.disputeTypeInfo}>
                  <Text
                    style={[
                      styles.disputeTypeTitle,
                      { color: colors.text, fontFamily: "Inter_600SemiBold" },
                    ]}
                  >
                    Open a dispute
                  </Text>
                  <Text style={[styles.disputeTypeSub, { color: colors.textMuted }]}>
                    Request a formal investigation and possible refund
                  </Text>
                </View>
                <Feather name="chevron-right" size={16} color={colors.textMuted} />
              </TouchableOpacity>
            </>
          ) : (
            <>
              <View style={styles.disputeStepHeader}>
                <TouchableOpacity
                  style={styles.backChevron}
                  onPress={() => setDisputeStep("choose")}
                  activeOpacity={0.7}
                >
                  <Feather name="chevron-left" size={20} color={colors.textMuted} />
                </TouchableOpacity>
                <View>
                  <Text
                    style={[
                      styles.sheetTitle,
                      { color: colors.text, fontFamily: "Inter_700Bold" },
                    ]}
                  >
                    {disputeType === "flag" ? "Flag a concern" : "Open a dispute"}
                  </Text>
                  <Text style={[{ color: colors.textMuted, fontSize: 13, marginTop: 2 }]}>
                    {disputeMsg?.amountStr} · {conv.name}
                  </Text>
                </View>
              </View>

              <Text
                style={[
                  styles.sectionLabel,
                  { color: colors.textMuted, marginTop: 18, marginBottom: 10 },
                ]}
              >
                REASON
              </Text>
              <View style={styles.reasonGrid}>
                {DISPUTE_REASONS.map((r) => (
                  <TouchableOpacity
                    key={r}
                    style={[
                      styles.reasonChip,
                      {
                        backgroundColor:
                          disputeReason === r ? colors.primary + "22" : colors.surfaceElevated,
                        borderColor:
                          disputeReason === r ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => {
                      setDisputeReason(r);
                      Haptics.selectionAsync();
                    }}
                    activeOpacity={0.7}
                  >
                    <Text
                      style={[
                        styles.reasonChipText,
                        {
                          color:
                            disputeReason === r ? colors.primaryLight : colors.textMuted,
                        },
                      ]}
                    >
                      {r}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text
                style={[
                  styles.sectionLabel,
                  { color: colors.textMuted, marginTop: 18, marginBottom: 8 },
                ]}
              >
                DETAILS (OPTIONAL)
              </Text>
              <TextInput
                style={[
                  styles.descInput,
                  {
                    backgroundColor: colors.surfaceElevated,
                    color: colors.text,
                    borderColor: colors.border,
                  },
                ]}
                placeholder="Describe what happened…"
                placeholderTextColor={colors.textMuted}
                value={disputeDesc}
                onChangeText={setDisputeDesc}
                multiline
                numberOfLines={3}
              />

              <TouchableOpacity
                style={[
                  styles.actionBtn,
                  {
                    backgroundColor: disputeReason
                      ? disputeType === "flag"
                        ? colors.warning
                        : colors.danger
                      : colors.surfaceElevated,
                    marginTop: 16,
                  },
                ]}
                onPress={handleSubmitDispute}
                activeOpacity={0.8}
              >
                <Feather
                  name={disputeType === "flag" ? "flag" : "alert-triangle"}
                  size={15}
                  color={disputeReason ? "#fff" : colors.textMuted}
                />
                <Text
                  style={[
                    styles.actionBtnText,
                    {
                      color: disputeReason ? "#fff" : colors.textMuted,
                      fontFamily: "Inter_600SemiBold",
                      marginLeft: 8,
                    },
                  ]}
                >
                  Submit {disputeType === "flag" ? "Flag" : "Dispute"}
                </Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </Modal>

    </View>
  );
}

// ─── Date separator ───────────────────────────────────────────────────────────
function DateSeparator({ label }: { label: string }) {
  const colors = useColors();
  return (
    <View style={dateSepStyles.row}>
      <View style={[dateSepStyles.line, { backgroundColor: colors.border }]} />
      <View style={[dateSepStyles.pill, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
        <Text style={[dateSepStyles.text, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>{label}</Text>
      </View>
      <View style={[dateSepStyles.line, { backgroundColor: colors.border }]} />
    </View>
  );
}
const dateSepStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", marginVertical: 16, paddingHorizontal: 16 },
  line: { flex: 1, height: 1 },
  pill: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 4, marginHorizontal: 10 },
  text: { fontSize: 12 },
});

// ─── MessageBubble dispatcher ─────────────────────────────────────────────────
function MessageBubble({
  msg, conv, colors, onPay, onDecline, onDispute, onLongPress, onOpenMedia,
}: {
  msg: Message;
  conv: { name: string; initials: string; color: string; verified?: boolean };
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onPay: (m: Message) => void;
  onDecline: (m: Message) => void;
  onDispute: (m: Message) => void;
  onLongPress?: (m: Message) => void;
  onOpenMedia?: (m: Message) => void;
}) {
  const isMe = msg.from === "me";

  if (msg.type === "money_request")
    return <PaymentRequestCard msg={msg} isMe={isMe} conv={conv} colors={colors} onPay={onPay} onDecline={onDecline} onDispute={onDispute} />;
  if (msg.type === "escrow_deal")
    return <EscrowDealCard msg={msg} isMe={isMe} colors={colors} />;
  if (msg.type === "payment_sent")
    return <PaymentSentCard msg={msg} isMe={isMe} colors={colors} />;
  if (msg.type === "image" || msg.type === "video")
    return <MediaBubble msg={msg} isMe={isMe} colors={colors} onOpenMedia={onOpenMedia} />;
  if (msg.type === "location")
    return <LocationBubble msg={msg} isMe={isMe} colors={colors} />;
  if (msg.type === "voice_note")
    return <VoiceNoteBubble msg={msg} isMe={isMe} colors={colors} />;

  // Plain text
  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onLongPress={() => onLongPress?.(msg)}
      delayLongPress={400}
      style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}
    >
      {!isMe && (
        <View style={[styles.tinyAvatar, { backgroundColor: conv.color }]}>
          <Text style={styles.tinyAvatarText}>{conv.initials}</Text>
        </View>
      )}
      <View
        style={[
          styles.bubble,
          isMe ? styles.bubbleMe : styles.bubbleThem,
          {
            backgroundColor: isMe ? colors.primary : colors.surfaceElevated,
            shadowColor: isMe ? colors.primary : "transparent",
            shadowOpacity: isMe ? 0.25 : 0,
            shadowRadius: 8,
            shadowOffset: { width: 0, height: 2 },
            elevation: isMe ? 4 : 0,
          },
        ]}
      >
        <Text style={[styles.bubbleText, { color: isMe ? "#fff" : colors.text }]}>
          {msg.text}
        </Text>
        <View style={styles.bubbleFooter}>
          <Text style={[styles.bubbleTime, { color: isMe ? "rgba(255,255,255,0.6)" : colors.textMuted }]}>
            {msg.time}
          </Text>
          {isMe && <MessageStatusTicks status={msg.queued ? "sending" : msg.status} />}
        </View>
      </View>
    </TouchableOpacity>
  );
}

// ─── Message status ticks (Sending / Sent / Delivered / Seen) ─────────────────
function MessageStatusTicks({ status }: { status?: Message["status"] }) {
  if (!status || status === "sending") {
    return <Feather name="clock" size={11} color="rgba(255,255,255,0.55)" style={{ marginLeft: 3 }} />;
  }
  if (status === "sent") {
    return <Feather name="check" size={12} color="rgba(255,255,255,0.55)" style={{ marginLeft: 3 }} />;
  }
  // "delivered" and "seen" both show a double check; "seen" is tinted to stand out
  return (
    <MaterialIcons
      name="done-all"
      size={14}
      color={status === "seen" ? "#34D3A6" : "rgba(255,255,255,0.55)"}
      style={{ marginLeft: 3 }}
    />
  );
}

// ─── Payment Request Card ─────────────────────────────────────────────────────
function PaymentRequestCard({
  msg, isMe, conv, colors, onPay, onDecline, onDispute,
}: {
  msg: Message; isMe: boolean;
  conv: { name: string };
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onPay: (m: Message) => void;
  onDecline: (m: Message) => void;
  onDispute: (m: Message) => void;
}) {
  const isPending = msg.requestStatus === "pending";
  const isPaid = msg.requestStatus === "paid";
  const isDeclined = msg.requestStatus === "declined";
  const isFlagged = msg.disputeStatus === "flagged";
  const isDisputed = msg.disputeStatus === "disputed";

  const statusColor = isPaid
    ? colors.success
    : isDeclined || isFlagged || isDisputed
    ? colors.danger
    : colors.textMuted;
  const statusBg = isPaid
    ? colors.successBg
    : isDeclined || isFlagged || isDisputed
    ? colors.dangerBg
    : colors.surfaceElevated;
  const statusIcon: keyof typeof Feather.glyphMap = isPaid
    ? "check-circle"
    : isDeclined
    ? "x-circle"
    : isFlagged
    ? "flag"
    : isDisputed
    ? "alert-triangle"
    : "clock";
  const statusLabel = isPaid
    ? "Paid"
    : isDeclined
    ? "Declined"
    : isFlagged
    ? "Flagged"
    : isDisputed
    ? "Disputed"
    : "Pending";

  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.requestCard,
          { backgroundColor: colors.surface, borderColor: colors.primary + "55" },
        ]}
      >
        {(isFlagged || isDisputed) && (
          <View
            style={[
              styles.disputeBadge,
              { backgroundColor: colors.dangerBg, borderBottomColor: colors.border },
            ]}
          >
            <Feather name="alert-triangle" size={11} color={colors.danger} />
            <Text style={[styles.disputeBadgeText, { color: colors.danger, marginLeft: 5 }]}>
              {isDisputed ? "Dispute open" : "Flagged for review"}
            </Text>
          </View>
        )}
        <View style={[styles.requestCardTop, { borderBottomColor: colors.border }]}>
          <View style={[styles.requestIconWrap, { backgroundColor: colors.primary + "20" }]}>
            <Feather name="dollar-sign" size={18} color={colors.primary} />
          </View>
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={[styles.requestLabel, { color: colors.textMuted }]}>
              {isMe ? "You requested" : `${conv.name} requests`}
            </Text>
            <Text
              style={[styles.requestAmount, { color: colors.text, fontFamily: "Inter_700Bold" }]}
            >
              {msg.amountStr}
            </Text>
          </View>
        </View>
        {msg.note && (
          <Text
            style={[styles.requestNote, { color: colors.textMuted }]}
            numberOfLines={2}
          >
            {msg.note}
          </Text>
        )}
        {!isMe && isPending ? (
          <View style={styles.requestActions}>
            <TouchableOpacity
              style={[styles.declineBtn, { borderColor: colors.danger + "55" }]}
              onPress={() => onDecline(msg)}
              activeOpacity={0.7}
            >
              <Text style={[styles.declineBtnText, { color: colors.danger }]}>Decline</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.payBtn, { backgroundColor: colors.primary }]}
              onPress={() => onPay(msg)}
              activeOpacity={0.8}
            >
              <Feather name="zap" size={13} color="#fff" />
              <Text style={[styles.payBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
                {" "}Pay {msg.amountStr}
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.requestStatus, { backgroundColor: statusBg }]}>
            <Feather name={statusIcon as keyof typeof Feather.glyphMap} size={13} color={statusColor} />
            <Text style={[styles.requestStatusText, { color: statusColor }]}>
              {" "}
              {statusLabel}
            </Text>
          </View>
        )}
        {isPaid && !isFlagged && !isDisputed && (
          <TouchableOpacity
            style={[styles.flagBtn, { borderTopColor: colors.border }]}
            onPress={() => onDispute(msg)}
            activeOpacity={0.7}
          >
            <Feather name="alert-triangle" size={12} color={colors.textMuted} />
            <Text style={[styles.flagBtnText, { color: colors.textMuted }]}>
              {" "}Flag a problem or open dispute
            </Text>
          </TouchableOpacity>
        )}
        <Text
          style={[
            styles.bubbleTime,
            { color: colors.textMuted, textAlign: "right", marginRight: 12, marginBottom: 8 },
          ]}
        >
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Escrow Deal Card ─────────────────────────────────────────────────────────
function EscrowDealCard({
  msg, isMe, colors,
}: {
  msg: Message; isMe: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const isFunded = msg.escrowStatus === "funded";
  const isReleased = msg.escrowStatus === "released";
  const statusColor = isReleased ? colors.success : isFunded ? colors.primary : colors.gold;
  const statusBg = isReleased
    ? colors.successBg
    : isFunded
    ? colors.primary + "18"
    : colors.goldDim;
  const statusLabel = isReleased
    ? "Released ✓"
    : isFunded
    ? "Funded · Locked"
    : "Awaiting payment";
  const statusIcon: keyof typeof Feather.glyphMap = isReleased
    ? "unlock"
    : isFunded
    ? "lock"
    : "clock";

  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.requestCard,
          { backgroundColor: colors.surface, borderColor: colors.gold + "55", maxWidth: 285 },
        ]}
      >
        <View
          style={[
            styles.requestCardTop,
            { borderBottomColor: colors.border, borderBottomWidth: 1 },
          ]}
        >
          <View style={[styles.requestIconWrap, { backgroundColor: colors.gold + "22" }]}>
            <Feather name="shield" size={18} color={colors.gold} />
          </View>
          <View style={{ flex: 1, marginLeft: 10 }}>
            <Text style={[styles.requestLabel, { color: colors.textMuted }]}>
              {isMe ? "You created" : "Escrow deal"}
            </Text>
            <Text
              style={[styles.requestAmount, { color: colors.text, fontFamily: "Inter_700Bold" }]}
            >
              {msg.amountStr}
            </Text>
          </View>
        </View>
        {msg.escrowTitle && (
          <Text
            style={[styles.requestNote, { color: colors.textMuted }]}
            numberOfLines={2}
          >
            {msg.escrowTitle}
          </Text>
        )}
        <View style={[styles.requestStatus, { backgroundColor: statusBg }]}>
          <Feather name={statusIcon} size={13} color={statusColor} />
          <Text style={[styles.requestStatusText, { color: statusColor }]}>
            {" "}
            {statusLabel}
          </Text>
        </View>
        {!isMe && msg.escrowStatus === "pending" && (
          <View style={styles.requestActions}>
            <TouchableOpacity
              style={[styles.payBtn, { backgroundColor: colors.gold, flex: 1 }]}
              activeOpacity={0.8}
            >
              <Feather name="lock" size={13} color="#fff" />
              <Text style={[styles.payBtnText, { color: "#fff", fontFamily: "Inter_700Bold" }]}>
                {" "}Fund Escrow
              </Text>
            </TouchableOpacity>
          </View>
        )}
        <Text
          style={[
            styles.bubbleTime,
            { color: colors.textMuted, textAlign: "right", marginRight: 12, marginBottom: 8 },
          ]}
        >
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Payment Sent Card ────────────────────────────────────────────────────────
function PaymentSentCard({
  msg, isMe, colors,
}: {
  msg: Message; isMe: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.paymentSentCard,
          { backgroundColor: colors.successBg, borderColor: colors.success + "44" },
        ]}
      >
        <Feather name="check-circle" size={18} color={colors.success} />
        <View style={{ marginLeft: 10 }}>
          <Text
            style={[
              styles.paymentSentLabel,
              { color: colors.success, fontFamily: "Inter_600SemiBold" },
            ]}
          >
            Payment Sent
          </Text>
          <Text
            style={[
              styles.paymentSentAmount,
              { color: colors.success, fontFamily: "Inter_700Bold" },
            ]}
          >
            {msg.amountStr}
          </Text>
        </View>
        <Text
          style={[styles.bubbleTime, { color: colors.success + "88", marginLeft: "auto" }]}
        >
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Media Bubble ─────────────────────────────────────────────────────────────
function MediaBubble({
  msg, isMe, colors, onOpenMedia,
}: {
  msg: Message; isMe: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
  onOpenMedia?: (msg: Message) => void;
}) {
  const isVideo = msg.type === "video";
  const hasImage = !isVideo && !!msg.mediaUrl;
  const canOpen = !!msg.mediaUrl;
  const isUploading = msg.uploadProgress !== undefined && msg.uploadProgress < 1;
  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.mediaBubble,
          { backgroundColor: isMe ? colors.primary : colors.surfaceElevated },
        ]}
      >
        <TouchableOpacity
          activeOpacity={0.85}
          disabled={!canOpen || isUploading}
          onPress={() => onOpenMedia?.(msg)}
          style={[
            styles.mediaThumb,
            { backgroundColor: colors.surfaceElevated, overflow: "hidden" },
          ]}
        >
          {hasImage ? (
            <CachedImage
              source={{ uri: msg.mediaUrl }}
              style={{ width: "100%", height: "100%" }}
              contentFit="cover"
              cachePolicy="disk"
              transition={150}
            />
          ) : (
            <Feather name={isVideo ? "film" : "image"} size={28} color={colors.textMuted} />
          )}
          {isVideo && !isUploading && (
            <View style={[styles.playBtn, { backgroundColor: "rgba(0,0,0,0.5)" }]}>
              <Feather name="play" size={14} color="#fff" />
            </View>
          )}
          {isUploading && (
            <View style={[StyleSheet.absoluteFill, { alignItems: "center", justifyContent: "center", backgroundColor: "rgba(0,0,0,0.35)" }]}>
              <ActivityIndicator color="#fff" />
              <Text style={{ color: "#fff", fontSize: 11, marginTop: 4, fontWeight: "600" }}>
                {Math.round((msg.uploadProgress ?? 0) * 100)}%
              </Text>
            </View>
          )}
        </TouchableOpacity>
        {!hasImage && msg.mediaLabel ? (
          <Text style={[styles.mediaLabel, { color: colors.textMuted }]}>
            {msg.mediaLabel}
          </Text>
        ) : null}
        <Text style={[styles.bubbleTime, { color: colors.textMuted, textAlign: "right" }]}>
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Location Bubble ──────────────────────────────────────────────────────────
function LocationBubble({
  msg, isMe, colors,
}: {
  msg: Message; isMe: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.locationBubble,
          { backgroundColor: isMe ? colors.primary : colors.surfaceElevated },
        ]}
      >
        <View style={[styles.mapPreview, { backgroundColor: colors.surfaceElevated }]}>
          <Feather name="map" size={32} color={colors.primary} />
        </View>
        <View style={styles.locationInfo}>
          <Feather name="map-pin" size={13} color={colors.primary} />
          <Text
            style={[
              styles.locationName,
              { color: colors.text, fontFamily: "Inter_600SemiBold" },
            ]}
          >
            {" "}
            {msg.mediaLabel}
          </Text>
        </View>
        <Text
          style={[
            styles.bubbleTime,
            { color: colors.textMuted, textAlign: "right", paddingRight: 10, paddingBottom: 6 },
          ]}
        >
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Voice Note Bubble ────────────────────────────────────────────────────────
function VoiceNoteBubble({
  msg, isMe, colors,
}: {
  msg: Message;
  isMe: boolean;
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0); // 0–1
  const soundRef = useRef<Audio.Sound | null>(null);
  const BARS = [0.3, 0.6, 0.8, 0.5, 1.0, 0.7, 0.4, 0.9, 0.6, 0.8, 0.5, 0.3, 0.7, 0.9, 0.4];
  const accent = isMe ? colors.primaryLight : colors.primary;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      soundRef.current?.unloadAsync().catch(() => {});
    };
  }, []);

  const handlePlayPause = async () => {
    if (!msg.mediaUrl) return;
    try {
      if (!soundRef.current) {
        // First play — load the sound
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          shouldDuckAndroid: true,
        });
        const { sound } = await Audio.Sound.createAsync(
          { uri: msg.mediaUrl },
          { shouldPlay: true },
          (status) => {
            if (!status.isLoaded) return;
            const dur = status.durationMillis ?? 1;
            setPosition(status.positionMillis / dur);
            if (status.didJustFinish) {
              setPlaying(false);
              setPosition(0);
              soundRef.current?.setPositionAsync(0).catch(() => {});
            }
          }
        );
        soundRef.current = sound;
        setPlaying(true);
      } else {
        const status = await soundRef.current.getStatusAsync();
        if (!status.isLoaded) return;
        if (status.isPlaying) {
          await soundRef.current.pauseAsync();
          setPlaying(false);
        } else {
          await soundRef.current.playAsync();
          setPlaying(true);
        }
      }
    } catch {
      setPlaying(false);
    }
  };

  return (
    <View style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}>
      <View
        style={[
          styles.voiceNoteBubble,
          { backgroundColor: isMe ? colors.primary : colors.surfaceElevated },
        ]}
      >
        <TouchableOpacity
          onPress={handlePlayPause}
          style={[styles.voicePlayBtn, { backgroundColor: accent }]}
          activeOpacity={0.8}
        >
          <Feather name={playing ? "pause" : "play"} size={14} color="#fff" />
        </TouchableOpacity>
        <View style={styles.waveform}>
          {BARS.map((h, i) => {
            const threshold = i / BARS.length;
            const isPlayed = position > threshold;
            return (
              <View
                key={i}
                style={[
                  styles.waveBar,
                  {
                    height: h * 28,
                    backgroundColor: accent,
                    opacity: isPlayed ? 0.95 : playing ? 0.45 : 0.35,
                  },
                ]}
              />
            );
          })}
        </View>
        <Text style={[styles.voiceDuration, { color: isMe ? "rgba(255,255,255,0.7)" : colors.textMuted }]}>
          {msg.mediaLabel ?? "0:00"}
        </Text>
        <Text style={[styles.bubbleTime, { color: isMe ? "rgba(255,255,255,0.5)" : colors.textMuted }]}>
          {msg.time}
        </Text>
      </View>
    </View>
  );
}

// ─── Send-Money sheet styles ──────────────────────────────────────────────────
const sm = StyleSheet.create({
  fieldLabel:    { fontSize: 10, letterSpacing: 0.8, fontFamily: "Inter_700Bold" as any, marginBottom: 6 },
  netChip:       { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5 },
  netChipText:   { fontSize: 13, fontFamily: "Inter_600SemiBold" as any },
  phoneInput:    { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, marginBottom: 12 },
  nameCard:      { borderRadius: 18, borderWidth: 1.5, borderColor: "transparent", padding: 18, marginBottom: 14, backgroundColor: "rgba(255,255,255,0.04)" },
  networkBadge:  { alignSelf: "flex-start", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4, marginBottom: 4 },
  networkBadgeText: { fontSize: 11, fontFamily: "Inter_700Bold" as any },
  lookupLabel:   { fontSize: 14, fontFamily: "Inter_500Medium" as any },
  dotsRow:       { flexDirection: "row", gap: 8, marginVertical: 4 },
  dot:           { width: 10, height: 10, borderRadius: 5 },
  divider:       { height: 1, marginVertical: 4 },
  retryBtn:      { borderRadius: 10, borderWidth: 1, paddingVertical: 10, alignItems: "center" },
});

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  root: { flex: 1 },
  wallpaperImg: { opacity: 0.42, width: "100%", height: "100%" } as any,

  // Header
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 6,
    paddingBottom: 10,
    gap: 4,
    borderBottomWidth: 1,
  },
  backBtn: { padding: 6 },
  headerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  headerAvatarText: { color: "#fff", fontSize: 14, fontWeight: "700", fontFamily: "Inter_700Bold" },
  onlineDot: {
    position: "absolute",
    bottom: 1,
    right: 1,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#4ADE80",
    borderWidth: 1.5,
    borderColor: "#0C1524",
  },
  headerInfo: { flex: 1, marginLeft: 8 },
  headerNameRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  headerName: { fontSize: 15, fontWeight: "700", flexShrink: 1 },
  headerOnline: { fontSize: 11, marginTop: 1 },
  verifiedDot: { width: 16, height: 16, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  headerAction: { padding: 8 },

  // Messages
  messageList: { paddingHorizontal: 12, paddingTop: 6, gap: 2 },

  // Bubbles
  bubbleRow: { flexDirection: "row", marginVertical: 3, alignItems: "flex-end", gap: 6 },
  bubbleRowMe: { justifyContent: "flex-end" },
  bubbleRowThem: { justifyContent: "flex-start" },

  tinyAvatar: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", marginBottom: 2, flexShrink: 0 },
  tinyAvatarText: { color: "#fff", fontSize: 10, fontWeight: "700" },

  bubble: { maxWidth: "72%", borderRadius: 18, paddingHorizontal: 13, paddingTop: 9, paddingBottom: 7 },
  bubbleMe: { borderBottomRightRadius: 4 },
  bubbleThem: { borderBottomLeftRadius: 4 },
  bubbleText: { fontSize: 14.5, lineHeight: 21 },
  bubbleFooter: { flexDirection: "row", alignItems: "center", justifyContent: "flex-end", marginTop: 3, gap: 2 },
  bubbleTime: { fontSize: 10 },

  // Right panel
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(0,0,0,0.45)" },
  rightPanel: {
    position: "absolute",
    right: 0,
    top: 0,
    bottom: 0,
    borderLeftWidth: 1,
    shadowColor: "#000",
    shadowOpacity: 0.5,
    shadowRadius: 20,
    shadowOffset: { width: -4, height: 0 },
    elevation: 20,
  },
  panelHeader: {
    paddingHorizontal: 14,
    paddingBottom: 12,
    borderBottomWidth: 1,
    alignItems: "flex-start",
  },
  hideBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingVertical: 4 },
  hideBtnText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  panelList: { paddingTop: 8, paddingBottom: 20 },
  panelRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 11,
    gap: 14,
  },
  panelIconBox: {
    width: 42,
    height: 42,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  panelLabel: { fontSize: 14 },

  // Input bar
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 6,
    paddingHorizontal: 10,
    paddingTop: 8,
  },
  inputIconBtn: { width: 36, height: 40, alignItems: "center", justifyContent: "center", marginBottom: 2 },
  emojiIcon: { fontSize: 22 },
  textInput: {
    flex: 1,
    borderRadius: 24,
    borderWidth: 1,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontSize: 14,
    maxHeight: 100,
    minHeight: 42,
  },
  fabBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
    shadowColor: "#12D9A0",
    shadowOpacity: 0.4,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 6,
  },

  // Recording indicator
  reconnectBanner: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 6, paddingHorizontal: 12 },
  reconnectBannerText: { color: "#fff", fontSize: 12, fontFamily: "Inter_600SemiBold" },
  recIndicator: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, gap: 8, borderTopWidth: 1 },
  recDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#EF4444" },
  recText: { flex: 1, fontSize: 14 },
  recHint: { fontSize: 12 },

  // Voice preview bar
  previewBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 10, gap: 8, borderTopWidth: StyleSheet.hairlineWidth },
  previewPlayBtn: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  previewWave: { flexDirection: "row", alignItems: "center", gap: 2, flex: 1, height: 28 },
  previewBar2: { width: 3, borderRadius: 2, minHeight: 4 },
  previewDur: { fontSize: 12, fontFamily: "Inter_500Medium", flexShrink: 0 },
  previewSendBtn: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center", flexShrink: 0 },

  // Voice note bubble
  voiceNoteBubble: { flexDirection: "row", alignItems: "center", borderRadius: 18, paddingHorizontal: 10, paddingVertical: 10, gap: 8, maxWidth: 280 },
  voicePlayBtn: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  waveform: { flexDirection: "row", alignItems: "center", gap: 2, flex: 1, height: 32 },
  waveBar: { width: 3, borderRadius: 2, minHeight: 4 },
  voiceDuration: { fontSize: 12, flexShrink: 0 },

  // Modals
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)" },
  sheet: { borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingHorizontal: 20, paddingTop: 12 },
  disputeSheet: { minHeight: 340 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitleRow: { flexDirection: "row", alignItems: "center", gap: 14, marginBottom: 20 },
  sheetTitleIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  sheetTitle: { fontSize: 20, fontWeight: "800" },
  sheetSub: { fontSize: 14, marginBottom: 4 },
  fieldLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1, marginBottom: 8, marginTop: 4 },

  amountBox: { flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1, paddingHorizontal: 18, paddingVertical: 16, marginBottom: 14 },
  amountCurrency: { fontSize: 22, marginRight: 8 },
  amountInput: { flex: 1, fontSize: 36, padding: 0 },
  quickAmounts: { flexDirection: "row", gap: 8, flexWrap: "wrap", marginBottom: 14 },
  quickChip: { borderRadius: 20, paddingVertical: 6, paddingHorizontal: 14, borderWidth: 1 },
  quickChipText: { fontSize: 13, fontWeight: "600" },
  noteInput: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, marginBottom: 14 },
  escrowHint: { flexDirection: "row", alignItems: "flex-start", borderRadius: 10, borderWidth: 1, padding: 12, marginBottom: 16 },
  escrowHintText: { flex: 1, fontSize: 12, lineHeight: 17 },
  actionBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 15 },
  actionBtnText: { fontSize: 16 },

  // Cards
  requestCard: { borderRadius: 16, borderWidth: 1, overflow: "hidden", minWidth: 220 },
  disputeBadge: { flexDirection: "row", alignItems: "center", paddingHorizontal: 12, paddingVertical: 7, borderBottomWidth: 1 },
  disputeBadgeText: { fontSize: 11, fontWeight: "600" },
  requestCardTop: { flexDirection: "row", alignItems: "center", padding: 14 },
  requestIconWrap: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  requestLabel: { fontSize: 11, marginBottom: 2 },
  requestAmount: { fontSize: 20 },
  requestNote: { fontSize: 12, paddingHorizontal: 14, paddingTop: 10, paddingBottom: 4, lineHeight: 16 },
  requestActions: { flexDirection: "row", gap: 8, padding: 12 },
  declineBtn: { flex: 1, borderWidth: 1, borderRadius: 10, paddingVertical: 10, alignItems: "center" },
  declineBtnText: { fontSize: 14, fontWeight: "600" },
  payBtn: { flex: 2, flexDirection: "row", borderRadius: 10, paddingVertical: 10, alignItems: "center", justifyContent: "center" },
  payBtnText: { fontSize: 14 },
  requestStatus: { flexDirection: "row", alignItems: "center", margin: 12, borderRadius: 8, padding: 8 },
  requestStatusText: { fontSize: 13, fontWeight: "600" },
  flagBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 10, borderTopWidth: 1 },
  flagBtnText: { fontSize: 11 },

  paymentSentCard: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1, padding: 14, minWidth: 180 },
  paymentSentLabel: { fontSize: 12 },
  paymentSentAmount: { fontSize: 18 },

  mediaBubble: { borderRadius: 16, overflow: "hidden", maxWidth: 220 },
  mediaThumb: { width: 220, height: 130, alignItems: "center", justifyContent: "center" },
  playBtn: { position: "absolute", width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  mediaLabel: { fontSize: 12, paddingHorizontal: 12, paddingTop: 6 },

  locationBubble: { borderRadius: 16, overflow: "hidden", maxWidth: 220 },
  mapPreview: { width: 220, height: 100, alignItems: "center", justifyContent: "center" },
  locationInfo: { flexDirection: "row", alignItems: "center", padding: 10 },
  locationName: { fontSize: 13, flex: 1 },

  // Dispute sheet
  cancelBtn: { borderWidth: 1, borderRadius: 14, paddingVertical: 13, alignItems: "center", marginTop: 16 },
  cancelBtnText: { fontSize: 15 },
  disputeTypeCard: { flexDirection: "row", alignItems: "center", borderRadius: 16, borderWidth: 1, padding: 16, gap: 12 },
  disputeTypeIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  disputeTypeInfo: { flex: 1 },
  disputeTypeTitle: { fontSize: 15, fontWeight: "700", marginBottom: 3 },
  disputeTypeSub: { fontSize: 12, lineHeight: 16 },
  disputeStepHeader: { flexDirection: "row", alignItems: "flex-start", gap: 12, marginBottom: 4 },
  backChevron: { padding: 4, marginTop: 4 },
  sectionLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1, fontFamily: "Inter_700Bold" },
  reasonGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, paddingBottom: 4 },
  reasonChip: { flexDirection: "row", alignItems: "center", borderRadius: 20, paddingVertical: 7, paddingHorizontal: 12, borderWidth: 1 },
  reasonChipText: { fontSize: 13 },
  descInput: { borderRadius: 12, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 12, fontSize: 14, textAlignVertical: "top", minHeight: 80 },
  doneView: { alignItems: "center", paddingVertical: 8 },
  doneIcon: { width: 72, height: 72, borderRadius: 22, alignItems: "center", justifyContent: "center", marginBottom: 18 },
  doneTitle: { fontSize: 22, fontWeight: "800", marginBottom: 10 },
  doneSub: { fontSize: 14, textAlign: "center", lineHeight: 20, marginBottom: 20, paddingHorizontal: 8 },

  // Calling overlay
  callingOverlay: { ...StyleSheet.absoluteFillObject, alignItems: "center", justifyContent: "center", gap: 12 },
  callingAvatar: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center" },
  callingAvatarText: { color: "#fff", fontSize: 36, fontWeight: "700" },
  callingName: { fontSize: 26, marginTop: 8 },
  callingStatus: { fontSize: 15 },
  endCallBtn: { width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center", marginTop: 24 },
});
