import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

const TOP_INSET = Platform.OS === "web" ? 67 : 0;

export default function WelcomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const logoScale = useRef(new Animated.Value(0.7)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const contentOpacity = useRef(new Animated.Value(0)).current;
  const bottomOpacity = useRef(new Animated.Value(0)).current;

  const nd = Platform.OS !== "web";

  useEffect(() => {
    Animated.parallel([
      Animated.spring(logoScale, { toValue: 1, useNativeDriver: nd, friction: 6, tension: 60 }),
      Animated.timing(logoOpacity, { toValue: 1, duration: 500, useNativeDriver: nd }),
      Animated.timing(contentOpacity, { toValue: 1, duration: 600, useNativeDriver: nd, delay: 200 }),
      Animated.timing(bottomOpacity, { toValue: 1, duration: 600, useNativeDriver: nd, delay: 350 }),
    ]).start();
  }, []);

  return (
    <View style={[styles.root, { backgroundColor: colors.background, paddingTop: TOP_INSET }]}>
      <View style={[styles.circle1, { backgroundColor: colors.primary + "15" }]} />
      <View style={[styles.circle2, { backgroundColor: colors.gold + "10" }]} />

      <View style={styles.center}>
        <Animated.View style={{ transform: [{ scale: logoScale }], opacity: logoOpacity, alignItems: "center" }}>
          <Image
            source={require("../assets/images/logo.png")}
            style={styles.logoImage}
            resizeMode="contain"
          />
          <Image
            source={require("../assets/images/charley-wordmark.png")}
            style={styles.wordmark}
            resizeMode="contain"
          />
          <Text style={[styles.tagline, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            Chat. Fun. Pay. Securely.
          </Text>
        </Animated.View>

        <Animated.View style={[styles.badges, { opacity: contentOpacity }]}>
          {[
            { icon: "shield" as const, label: "Escrow Protected" },
            { icon: "lock" as const, label: "Bank-Level Security" },
            { icon: "check-circle" as const, label: "KYC Verified" },
          ].map((b) => (
            <View
              key={b.label}
              style={[styles.badge, { backgroundColor: colors.surface, borderColor: colors.border }]}
            >
              <Feather name={b.icon} size={12} color={colors.primary} />
              <Text style={[styles.badgeText, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>
                {" "}{b.label}
              </Text>
            </View>
          ))}
        </Animated.View>
      </View>

      <Animated.View
        style={[
          styles.bottom,
          { opacity: bottomOpacity, paddingBottom: Math.max(insets.bottom, 24) + 16 },
        ]}
      >
        <TouchableOpacity
          style={[styles.primaryBtn, { backgroundColor: colors.primary }]}
          onPress={() => router.push("/register")}
          activeOpacity={0.85}
        >
          <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}>Create Account</Text>
          <Feather name="arrow-right" size={18} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.secondaryBtn, { borderColor: colors.primary + "55" }]}
          onPress={() => router.push("/login")}
          activeOpacity={0.85}
        >
          <Text style={[styles.secondaryBtnText, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>
            Sign In
          </Text>
        </TouchableOpacity>



        <Text style={[styles.legal, { color: colors.textMuted + "70", fontFamily: "Inter_400Regular" }]}>
          By continuing you agree to our Terms & Privacy Policy
        </Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, overflow: "hidden" },
  circle1: {
    position: "absolute",
    width: 500,
    height: 500,
    borderRadius: 250,
    top: -160,
    right: -140,
  },
  circle2: {
    position: "absolute",
    width: 360,
    height: 360,
    borderRadius: 180,
    bottom: 180,
    left: -120,
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 32,
  },
  logoImage: {
    width: 160,
    height: 160,
    maxWidth: "100%" as any,
  },
  wordmark: {
    width: 220,
    height: 68,
    marginTop: 3,
    marginBottom: 6,
    maxWidth: "100%" as any,
  },
  tagline: {
    fontSize: 15,
    textAlign: "center",
    lineHeight: 22,
  },
  badges: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "center",
  },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  badgeText: { fontSize: 12 },
  bottom: {
    paddingHorizontal: 24,
    gap: 12,
  },
  primaryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 18,
    paddingVertical: 18,
    gap: 10,
  },
  primaryBtnText: { color: "#fff", fontSize: 17 },
  secondaryBtn: {
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 18,
    paddingVertical: 16,
    borderWidth: 1.5,
  },
  secondaryBtnText: { fontSize: 17 },
  legal: { fontSize: 11, textAlign: "center" },
});
