import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  Animated,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const NETWORKS = [
  { id: "mtn",       name: "MTN MoMo",      color: "#FFCC00", textColor: "#1A1A1A", icon: "M" },
  { id: "telecel",   name: "Telecel Cash",   color: "#C0392B", textColor: "#fff",    icon: "T" },
  { id: "airteltigo",name: "AirtelTigo",     color: "#E4002B", textColor: "#fff",    icon: "AT" },
  { id: "card",      name: "Card Payment",   color: "#2980B9", textColor: "#fff",    icon: "💳" },
  { id: "bank",      name: "Bank Transfer",  color: "#27AE60", textColor: "#fff",    icon: "🏦" },
];

const DISPUTE_REASONS = [
  "Item not as described",
  "Item not received",
  "Wrong item sent",
  "Item damaged",
  "Seller unresponsive",
  "Other",
];

const STATUS_STEPS = [
  { key: "active",     label: "Payment Pending" },
  { key: "in_escrow",  label: "Funds in Escrow" },
  { key: "completed",  label: "Complete" },
];

// ─── Status bar ───────────────────────────────────────────────────────────────

function StatusBar({ status, colors }: {
  status: "active" | "in_escrow" | "completed" | "cancelled" | "disputed";
  colors: ReturnType<typeof import("@/hooks/useColors").useColors>;
}) {
  const idx = status === "disputed" ? 1 : STATUS_STEPS.findIndex((s) => s.key === status);
  return (
    <View style={sbStyles.row}>
      {STATUS_STEPS.map((step, i) => {
        const done = i <= idx;
        const active = i === idx;
        return (
          <React.Fragment key={step.key}>
            <View style={sbStyles.step}>
              <View style={[sbStyles.dot, {
                backgroundColor: done ? (status === "disputed" && i === 1 ? colors.danger : colors.primary) : colors.surfaceElevated,
                borderColor: done ? (status === "disputed" && i === 1 ? colors.danger : colors.primary) : colors.border,
              }]}>
                {done && <Feather name="check" size={10} color="#fff" />}
              </View>
              <Text style={[sbStyles.label, { color: active ? colors.text : colors.textMuted, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                {step.label}
              </Text>
            </View>
            {i < STATUS_STEPS.length - 1 && (
              <View style={[sbStyles.line, { backgroundColor: i < idx ? colors.primary : colors.border }]} />
            )}
          </React.Fragment>
        );
      })}
    </View>
  );
}
const sbStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 20, paddingVertical: 16 },
  step: { alignItems: "center", width: 72 },
  dot: { width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 2, marginBottom: 6 },
  label: { fontSize: 10, textAlign: "center" },
  line: { flex: 1, height: 2, marginTop: 12 },
});

// ─── Pulsing escrow badge ─────────────────────────────────────────────────────

function PulsingBadge({ label, color }: { label: string; color: string }) {
  const anim = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    Animated.loop(Animated.sequence([
      Animated.timing(anim, { toValue: 1.06, duration: 900, useNativeDriver: true }),
      Animated.timing(anim, { toValue: 1,    duration: 900, useNativeDriver: true }),
    ])).start();
  }, []);
  return (
    <Animated.View style={[badgeStyles.wrap, { backgroundColor: color + "22", borderColor: color + "55", transform: [{ scale: anim }] }]}>
      <Feather name="shield" size={14} color={color} />
      <Text style={[badgeStyles.text, { color }]}> {label}</Text>
    </Animated.View>
  );
}
const badgeStyles = StyleSheet.create({
  wrap: { flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 7, alignSelf: "center" },
  text: { fontSize: 13, fontWeight: "700", fontFamily: "Inter_700Bold" },
});

// ─── Screen ───────────────────────────────────────────────────────────────────

export default function PayLinkScreen() {
  const { code } = useLocalSearchParams<{ code: string }>();
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { payLinks, payPayLink, confirmPayLinkDelivery, disputePayLink } = useApp();

  const link = payLinks.find((l) => l.code === code);

  const [selectedNet, setSelectedNet] = useState<typeof NETWORKS[0] | null>(null);
  const [phone, setPhone] = useState("");
  const [paying, setPaying] = useState(false);
  const [showDispute, setShowDispute] = useState(false);
  const [disputeReason, setDisputeReason] = useState("");
  const [disputeStep, setDisputeStep] = useState<"choose" | "done">("choose");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 16 : insets.bottom + 12;

  if (!link) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <Feather name="link" size={40} color={colors.textMuted} />
        <Text style={[styles.notFoundText, { color: colors.textMuted }]}>Payment link not found</Text>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={[styles.backLink, { backgroundColor: colors.primary }]}>
          <Text style={{ color: "#fff", fontFamily: "Inter_600SemiBold" }}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handlePay = () => {
    if (!selectedNet) { Alert.alert("Select Network", "Please choose a payment network."); return; }
    if ((selectedNet.id === "mtn" || selectedNet.id === "telecel" || selectedNet.id === "airteltigo") && phone.replace(/\D/g, "").length < 10) {
      Alert.alert("Enter Phone", "Enter your 10-digit MoMo number."); return;
    }
    Alert.alert(
      "Confirm Payment",
      `Pay ${link.amountStr} via ${selectedNet.name}?\n\nFunds will be held in escrow until you confirm delivery.`,
      [
        { text: "Cancel", style: "cancel" },
        { text: `Pay ${link.amountStr}`, onPress: () => {
          setPaying(true);
          setTimeout(() => {
            payPayLink(link.code, phone, selectedNet.name);
            setPaying(false);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }, 2000);
        }},
      ]
    );
  };

  const handleConfirmDelivery = () => {
    Alert.alert(
      "Confirm Item Received",
      `Confirming this will release ${link.amountStr} to the seller. Have you received the item in good condition?`,
      [
        { text: "Not yet", style: "cancel" },
        { text: "Yes, Release Funds", onPress: () => {
          confirmPayLinkDelivery(link.code);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }},
      ]
    );
  };

  const handleDispute = () => {
    if (!disputeReason) { Alert.alert("Select reason", "Please choose a dispute reason."); return; }
    disputePayLink(link.code, disputeReason);
    setDisputeStep("done");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const isMoMo = selectedNet && ["mtn", "telecel", "airteltigo"].includes(selectedNet.id);
  const statusColor =
    link.status === "completed" ? colors.success :
    link.status === "disputed"  ? colors.danger :
    link.status === "in_escrow" ? colors.gold :
    colors.primary;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* ── Header ────────────────────────────────────────────────────────── */}
      <View style={[styles.header, { backgroundColor: colors.surface, paddingTop: topPad + 6 }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.headerBack} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Payment Link</Text>
          <Text style={[styles.headerCode, { color: colors.textMuted }]}>charley.app/pay/{link.code}</Text>
        </View>
        <View style={[styles.headerStatus, { backgroundColor: statusColor + "20" }]}>
          <Text style={[styles.headerStatusText, { color: statusColor, fontFamily: "Inter_700Bold" }]}>
            {link.status === "active"     ? "Active"       :
             link.status === "in_escrow" ? "In Escrow"    :
             link.status === "completed" ? "Completed"    :
             link.status === "disputed"  ? "Disputed"     : link.status}
          </Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        {/* Status progress */}
        <View style={[styles.statusSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <StatusBar status={link.status} colors={colors} />
          {link.status === "in_escrow" && (
            <PulsingBadge label="Funds Locked in Escrow — Buyer Protected" color={colors.gold} />
          )}
          {link.status === "completed" && (
            <PulsingBadge label="Transaction Complete ✓" color={colors.success} />
          )}
          {link.status === "disputed" && (
            <PulsingBadge label="Dispute Under Review" color={colors.danger} />
          )}
        </View>

        {/* ── Product card ──────────────────────────────────────────────────── */}
        <View style={[styles.productCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {/* Product image placeholder */}
          <View style={[styles.productImg, { backgroundColor: colors.primary + "22" }]}>
            <View style={[styles.productImgInner, { backgroundColor: colors.primary }]}>
              <Text style={styles.productImgText}>{link.title.charAt(0)}</Text>
            </View>
            <View style={[styles.escrowBadgeImg, { backgroundColor: colors.gold + "22", borderColor: colors.gold + "55" }]}>
              <Feather name="shield" size={12} color={colors.gold} />
              <Text style={[styles.escrowBadgeImgText, { color: colors.gold }]}> Escrow Protected</Text>
            </View>
          </View>

          <View style={styles.productBody}>
            <Text style={[styles.productTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{link.title}</Text>
            <Text style={[styles.productDesc, { color: colors.textMuted }]}>{link.description}</Text>

            {link.delivery && (
              <View style={[styles.deliveryRow, { backgroundColor: colors.surfaceElevated }]}>
                <Feather name="package" size={13} color={colors.textMuted} />
                <Text style={[styles.deliveryText, { color: colors.textMuted }]}> {link.delivery}</Text>
              </View>
            )}

            <View style={styles.amountRow}>
              <View>
                <Text style={[styles.amountLabel, { color: colors.textMuted }]}>Amount</Text>
                <Text style={[styles.amountValue, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>{link.amountStr}</Text>
              </View>
              <View style={{ alignItems: "flex-end" }}>
                <Text style={[styles.amountLabel, { color: colors.textMuted }]}>Seller</Text>
                <Text style={[styles.sellerName, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Ama Kofi</Text>
              </View>
            </View>
          </View>
        </View>

        {/* ── ACTIVE: Payment form ────────────────────────────────────────── */}
        {link.status === "active" && (
          <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Choose Payment Method</Text>

            <View style={styles.networkGrid}>
              {NETWORKS.map((net) => {
                const sel = selectedNet?.id === net.id;
                return (
                  <TouchableOpacity
                    key={net.id}
                    style={[styles.netTile, {
                      backgroundColor: sel ? net.color + "22" : colors.surfaceElevated,
                      borderColor: sel ? net.color : colors.border,
                      borderWidth: sel ? 2 : 1,
                    }]}
                    onPress={() => { setSelectedNet(net); Haptics.selectionAsync(); }}
                    activeOpacity={0.7}
                  >
                    <View style={[styles.netDot, { backgroundColor: net.color }]}>
                      <Text style={[styles.netDotText, { color: net.textColor }]}>{net.icon}</Text>
                    </View>
                    <Text style={[styles.netName, { color: sel ? colors.text : colors.textMuted, fontFamily: sel ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                      {net.name}
                    </Text>
                    {sel && <Feather name="check-circle" size={16} color={net.color} style={{ marginLeft: "auto" }} />}
                  </TouchableOpacity>
                );
              })}
            </View>

            {isMoMo && (
              <View style={{ marginTop: 14 }}>
                <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>YOUR {selectedNet?.name?.toUpperCase()} NUMBER</Text>
                <View style={[styles.phoneBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                  <Text style={[styles.phonePrefix, { color: colors.textMuted }]}>+233</Text>
                  <TextInput
                    style={[styles.phoneInput, { color: colors.text }]}
                    placeholder="024 000 0000"
                    placeholderTextColor={colors.textMuted}
                    keyboardType="phone-pad"
                    value={phone}
                    onChangeText={(v) => setPhone(v.replace(/\D/g, "").slice(0, 10))}
                  />
                </View>
                <Text style={[styles.momoHint, { color: colors.textMuted }]}>
                  A payment prompt will be sent to your phone. Approve it to complete the transaction.
                </Text>
              </View>
            )}

            <View style={[styles.escrowInfoBox, { backgroundColor: colors.goldDim, borderColor: colors.gold + "44" }]}>
              <Feather name="shield" size={15} color={colors.gold} />
              <Text style={[styles.escrowInfoText, { color: colors.gold }]}>
                {" "}Your money stays locked in escrow until you confirm receipt. You're protected.
              </Text>
            </View>
          </View>
        )}

        {/* ── IN ESCROW: confirm/dispute ─────────────────────────────────── */}
        {link.status === "in_escrow" && (
          <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.escrowLockedCard, { backgroundColor: colors.goldDim, borderColor: colors.gold + "44" }]}>
              <View style={[styles.lockIcon, { backgroundColor: colors.gold + "33" }]}>
                <Feather name="lock" size={28} color={colors.gold} />
              </View>
              <Text style={[styles.lockedTitle, { color: colors.gold, fontFamily: "Inter_700Bold" }]}>Funds Secured in Escrow</Text>
              <Text style={[styles.lockedSub, { color: colors.gold + "CC" }]}>
                {link.amountStr} is locked and will only be released when you confirm receipt.
              </Text>
            </View>

            {link.buyerPhone && (
              <View style={[styles.paymentInfo, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                <Text style={[styles.paymentInfoLabel, { color: colors.textMuted }]}>Paid via</Text>
                <Text style={[styles.paymentInfoValue, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>
                  {link.network} · +233 {link.buyerPhone}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* ── COMPLETED ─────────────────────────────────────────────────────── */}
        {link.status === "completed" && (
          <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.completedCard, { backgroundColor: colors.successBg, borderColor: colors.success + "44" }]}>
              <View style={[styles.lockIcon, { backgroundColor: colors.success + "33" }]}>
                <Feather name="check-circle" size={28} color={colors.success} />
              </View>
              <Text style={[styles.lockedTitle, { color: colors.success, fontFamily: "Inter_700Bold" }]}>Transaction Complete</Text>
              <Text style={[styles.lockedSub, { color: colors.success + "CC" }]}>
                Funds have been released to the seller. Thank you for using CharLey Escrow.
              </Text>
            </View>
          </View>
        )}

        {/* ── DISPUTED ─────────────────────────────────────────────────────── */}
        {link.status === "disputed" && (
          <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.disputedCard, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
              <View style={[styles.lockIcon, { backgroundColor: colors.danger + "25" }]}>
                <Feather name="alert-octagon" size={28} color={colors.danger} />
              </View>
              <Text style={[styles.lockedTitle, { color: colors.danger, fontFamily: "Inter_700Bold" }]}>Dispute Under Review</Text>
              <Text style={[styles.lockedSub, { color: colors.danger + "BB" }]}>
                Reason: {link.disputeReason}. CharLey will contact both parties within 48 hours. Funds remain frozen.
              </Text>
            </View>
          </View>
        )}

        {/* ── Paying spinner ─────────────────────────────────────────────── */}
        {paying && (
          <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border, alignItems: "center", paddingVertical: 30 }]}>
            <View style={[styles.lockIcon, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="loader" size={28} color={colors.primary} />
            </View>
            <Text style={[styles.lockedTitle, { color: colors.text, fontFamily: "Inter_700Bold", marginTop: 12 }]}>Processing Payment…</Text>
            <Text style={[styles.lockedSub, { color: colors.textMuted }]}>Approve the prompt on your phone</Text>
          </View>
        )}
      </ScrollView>

      {/* ── Bottom CTAs ────────────────────────────────────────────────────── */}
      <View style={[styles.bottomBar, { backgroundColor: colors.surface, borderColor: colors.border, paddingBottom: botPad }]}>
        {link.status === "active" && !paying && (
          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: colors.primary }]}
            onPress={handlePay}
            activeOpacity={0.85}
          >
            <Feather name="shield" size={18} color="#fff" />
            <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}> Pay {link.amountStr} — Escrow</Text>
          </TouchableOpacity>
        )}

        {link.status === "in_escrow" && (
          <>
            <TouchableOpacity
              style={[styles.primaryBtn, { backgroundColor: colors.primary }]}
              onPress={handleConfirmDelivery}
              activeOpacity={0.85}
            >
              <Feather name="check-circle" size={18} color="#fff" />
              <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}> Confirm Item Received</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.secondaryBtn, { borderColor: colors.danger + "55" }]}
              onPress={() => { setShowDispute(true); setDisputeStep("choose"); setDisputeReason(""); }}
              activeOpacity={0.7}
            >
              <Feather name="alert-triangle" size={15} color={colors.danger} />
              <Text style={[styles.secondaryBtnText, { color: colors.danger }]}> Open Dispute</Text>
            </TouchableOpacity>
          </>
        )}

        {link.status === "completed" && (
          <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: colors.success }]} onPress={() => safeGoBack(router)} activeOpacity={0.85}>
            <Feather name="home" size={18} color="#fff" />
            <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}> Back to Home</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* ── Dispute modal ────────────────────────────────────────────────────── */}
      <Modal visible={showDispute} transparent animationType="slide" onRequestClose={() => setShowDispute(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowDispute(false)} />
        <View style={[styles.sheet, { backgroundColor: colors.surface, paddingBottom: Math.max(botPad, 24) }]}>
          <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

          {disputeStep === "choose" && (
            <>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Open Dispute</Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted }]}>CharLey will freeze funds and mediate within 48 hours.</Text>
              <Text style={[styles.fieldLabel, { color: colors.textMuted, marginTop: 4 }]}>REASON FOR DISPUTE</Text>
              <View style={styles.reasonGrid}>
                {DISPUTE_REASONS.map((r) => {
                  const sel = disputeReason === r;
                  return (
                    <TouchableOpacity
                      key={r}
                      style={[styles.reasonChip, { backgroundColor: sel ? colors.danger + "20" : colors.surfaceElevated, borderColor: sel ? colors.danger : colors.border }]}
                      onPress={() => { setDisputeReason(r); Haptics.selectionAsync(); }}
                      activeOpacity={0.7}
                    >
                      {sel && <Feather name="check" size={12} color={colors.danger} style={{ marginRight: 4 }} />}
                      <Text style={[styles.reasonText, { color: sel ? colors.danger : colors.textMuted, fontFamily: sel ? "Inter_600SemiBold" : "Inter_400Regular" }]}>{r}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: disputeReason ? colors.danger : colors.surfaceElevated, marginTop: 18 }]}
                onPress={handleDispute}
                activeOpacity={0.85}
              >
                <Feather name="alert-octagon" size={16} color={disputeReason ? "#fff" : colors.textMuted} />
                <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold", color: disputeReason ? "#fff" : colors.textMuted }]}> Submit Dispute</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowDispute(false)}>
                <Text style={[styles.cancelText, { color: colors.textMuted }]}>Cancel</Text>
              </TouchableOpacity>
            </>
          )}

          {disputeStep === "done" && (
            <View style={{ alignItems: "center", paddingVertical: 12 }}>
              <View style={[styles.lockIcon, { backgroundColor: colors.dangerBg, marginBottom: 16 }]}>
                <Feather name="alert-octagon" size={30} color={colors.danger} />
              </View>
              <Text style={[styles.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Dispute Submitted</Text>
              <Text style={[styles.sheetSub, { color: colors.textMuted, textAlign: "center" }]}>
                CharLey is reviewing your dispute. Funds are frozen. You'll hear back within 48 hours.
              </Text>
              <View style={[styles.refBox, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
                <Text style={[styles.fieldLabel, { color: colors.textMuted }]}>Reference #</Text>
                <Text style={[styles.refCode, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>FP-{Date.now().toString().slice(-8)}</Text>
              </View>
              <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: colors.primary, width: "100%", marginTop: 8 }]} onPress={() => setShowDispute(false)} activeOpacity={0.85}>
                <Text style={[styles.primaryBtnText, { fontFamily: "Inter_700Bold" }]}>Done</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  notFoundText: { fontSize: 16, marginTop: 16, marginBottom: 24 },
  backLink: { borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 14, paddingBottom: 12, gap: 12 },
  headerBack: { padding: 4 },
  headerTitle: { fontSize: 16 },
  headerCode: { fontSize: 11, marginTop: 1 },
  headerStatus: { borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5 },
  headerStatusText: { fontSize: 11 },

  statusSection: { borderBottomWidth: 1, paddingBottom: 16 },

  productCard: { margin: 14, borderRadius: 20, borderWidth: 1, overflow: "hidden" },
  productImg: { height: 160, alignItems: "center", justifyContent: "center" },
  productImgInner: { width: 72, height: 72, borderRadius: 36, alignItems: "center", justifyContent: "center" },
  productImgText: { color: "#fff", fontSize: 28, fontWeight: "800", fontFamily: "Inter_700Bold" },
  escrowBadgeImg: { position: "absolute", bottom: 10, flexDirection: "row", alignItems: "center", borderRadius: 10, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 5 },
  escrowBadgeImgText: { fontSize: 12, fontWeight: "700" },
  productBody: { padding: 16 },
  productTitle: { fontSize: 20, marginBottom: 6 },
  productDesc: { fontSize: 13, lineHeight: 19, marginBottom: 12 },
  deliveryRow: { flexDirection: "row", alignItems: "center", borderRadius: 8, padding: 10, marginBottom: 14 },
  deliveryText: { fontSize: 12 },
  amountRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  amountLabel: { fontSize: 11, marginBottom: 2 },
  amountValue: { fontSize: 26 },
  sellerName: { fontSize: 14 },

  section: { marginHorizontal: 14, marginBottom: 14, borderRadius: 20, borderWidth: 1, padding: 18 },
  sectionTitle: { fontSize: 16, marginBottom: 16 },

  networkGrid: { gap: 8 },
  netTile: { flexDirection: "row", alignItems: "center", borderRadius: 14, padding: 13, gap: 12 },
  netDot: { width: 34, height: 34, borderRadius: 17, alignItems: "center", justifyContent: "center" },
  netDotText: { fontSize: 11, fontWeight: "800" },
  netName: { fontSize: 14, flex: 1 },

  fieldLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 1, marginBottom: 8, fontFamily: "Inter_700Bold" },
  phoneBox: { flexDirection: "row", alignItems: "center", borderRadius: 14, borderWidth: 1.5, paddingHorizontal: 14 },
  phonePrefix: { fontSize: 15, marginRight: 8, paddingVertical: 12, fontFamily: "Inter_600SemiBold" },
  phoneInput: { flex: 1, fontSize: 17, paddingVertical: 12, letterSpacing: 1 },
  momoHint: { fontSize: 12, marginTop: 8, lineHeight: 17 },

  escrowInfoBox: { flexDirection: "row", alignItems: "flex-start", borderRadius: 12, borderWidth: 1, padding: 12, marginTop: 14 },
  escrowInfoText: { flex: 1, fontSize: 12, lineHeight: 18 },

  escrowLockedCard: { borderRadius: 16, borderWidth: 1, padding: 20, alignItems: "center" },
  completedCard: { borderRadius: 16, borderWidth: 1, padding: 20, alignItems: "center" },
  disputedCard: { borderRadius: 16, borderWidth: 1, padding: 20, alignItems: "center" },
  lockIcon: { width: 64, height: 64, borderRadius: 20, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  lockedTitle: { fontSize: 17, marginBottom: 8 },
  lockedSub: { fontSize: 13, textAlign: "center", lineHeight: 19 },
  paymentInfo: { borderRadius: 12, borderWidth: 1, padding: 12, marginTop: 12 },
  paymentInfoLabel: { fontSize: 11, marginBottom: 4 },
  paymentInfoValue: { fontSize: 14 },

  bottomBar: { position: "absolute", bottom: 0, left: 0, right: 0, borderTopWidth: 1, padding: 16, gap: 10 },
  primaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 16, paddingVertical: 16 },
  primaryBtnText: { color: "#fff", fontSize: 16 },
  secondaryBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 16, paddingVertical: 13, borderWidth: 1 },
  secondaryBtnText: { fontSize: 15, fontWeight: "600" },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.55)" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 20, paddingTop: 12 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 20 },
  sheetTitle: { fontSize: 20, fontWeight: "800", marginBottom: 6 },
  sheetSub: { fontSize: 13, marginBottom: 18 },
  reasonGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  reasonChip: { flexDirection: "row", alignItems: "center", borderRadius: 20, paddingVertical: 7, paddingHorizontal: 12, borderWidth: 1 },
  reasonText: { fontSize: 13 },
  cancelBtn: { alignItems: "center", paddingVertical: 12 },
  cancelText: { fontSize: 14 },
  refBox: { width: "100%", borderRadius: 12, borderWidth: 1, padding: 14, marginTop: 16, marginBottom: 8 },
  refCode: { fontSize: 14, marginTop: 4 },
});
