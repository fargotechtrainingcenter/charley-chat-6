import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Image,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const nd = Platform.OS !== "web";

export default function LoginScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { login } = useApp();

  const [phone, setPhone] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showSplash, setShowSplash] = useState(false);
  const [error, setError] = useState("");

  const pinRef = useRef<TextInput>(null);
  const splashOpacity = useRef(new Animated.Value(0)).current;
  const splashScale = useRef(new Animated.Value(0.4)).current;

  const handleLogin = async () => {
    setError("");
    if (!phone.trim()) {
      setError("Please enter your phone number.");
      return;
    }
    if (!pin.trim()) {
      setError("Please enter your PIN.");
      return;
    }
    setLoading(true);
    const ok = await login(phone.trim(), pin.trim());
    setLoading(false);
    if (!ok) {
      setError("Incorrect phone number or PIN. Please try again.");
      return;
    }
    setShowSplash(true);
    splashScale.setValue(0.4);
    splashOpacity.setValue(0);
    Animated.sequence([
      Animated.parallel([
        Animated.spring(splashScale, { toValue: 1.15, useNativeDriver: nd, friction: 5, tension: 80 }),
        Animated.timing(splashOpacity, { toValue: 1, duration: 250, useNativeDriver: nd }),
      ]),
      Animated.spring(splashScale, { toValue: 1, useNativeDriver: nd, friction: 6, tension: 60 }),
    ]).start(() => {
      setTimeout(() => router.replace("/(tabs)"), 500);
    });
  };

  const inputStyle = [
    styles.input,
    {
      backgroundColor: colors.surface,
      borderColor: colors.border,
      color: colors.text,
      fontFamily: "Inter_400Regular",
    },
  ];

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={[styles.circle, { backgroundColor: colors.primary + "12" }]} />

      {showSplash && (
        <Animated.View
          style={[styles.splashOverlay, { backgroundColor: colors.background, opacity: splashOpacity }]}
          pointerEvents="none"
        >
          <Animated.View style={{ transform: [{ scale: splashScale }], alignItems: "center" }}>
            <Image source={require("../assets/images/logo.png")} style={styles.splashLogo} resizeMode="contain" />
            <Image source={require("../assets/images/charley-wordmark.png")} style={styles.splashWordmark} resizeMode="contain" />
          </Animated.View>
        </Animated.View>
      )}

      <View style={[styles.inner, { paddingTop: topPad + 12, paddingBottom: Math.max(insets.bottom, 16) + 8 }]}>

        {/* Back */}
        <TouchableOpacity
          style={[styles.backBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => safeGoBack(router)}
        >
          <Feather name="arrow-left" size={20} color={colors.text} />
        </TouchableOpacity>

        {/* Brand */}
        <View style={styles.brandBlock}>
          <Image source={require("../assets/images/logo.png")} style={styles.logoMini} resizeMode="contain" />
          <Image source={require("../assets/images/charley-wordmark.png")} style={styles.wordmark} resizeMode="contain" />
        </View>

        {/* Heading */}
        <View style={styles.heading}>
          <Text style={[styles.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Welcome Back 👋</Text>
          <Text style={[styles.subtitle, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Sign in to CharLey</Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          {/* Phone */}
          <View>
            <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>Phone Number</Text>
            <View style={styles.inputWrap}>
              <View style={[styles.flagPill, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <Text style={[styles.flagText, { color: colors.text }]}>🇬🇭 +233</Text>
              </View>
              <TextInput
                style={[inputStyle, { paddingLeft: 90 }]}
                value={phone}
                onChangeText={(t) => { setPhone(t); setError(""); }}
                placeholder="0244 567 890"
                placeholderTextColor={colors.textMuted}
                keyboardType="phone-pad"
                autoCapitalize="none"
                returnKeyType="next"
                onSubmitEditing={() => pinRef.current?.focus()}
              />
            </View>
          </View>

          {/* PIN */}
          <View>
            <Text style={[styles.label, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>PIN</Text>
            <View style={styles.inputWrap}>
              <TextInput
                ref={pinRef}
                style={inputStyle}
                value={pin}
                onChangeText={(t) => { setPin(t); setError(""); }}
                placeholder="Enter your PIN"
                placeholderTextColor={colors.textMuted}
                keyboardType="numeric"
                maxLength={6}
                secureTextEntry={!showPin}
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />
              <TouchableOpacity style={styles.eyeBtn} onPress={() => setShowPin((v) => !v)}>
                <Feather name={showPin ? "eye-off" : "eye"} size={18} color={colors.textMuted} />
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity style={styles.forgotRow} onPress={() => router.push("/forgot-password")}>
            <Text style={[styles.forgotText, { color: colors.primary, fontFamily: "Inter_500Medium" }]}>Forgot PIN?</Text>
          </TouchableOpacity>

          {error ? (
            <View style={[styles.errorBox, { backgroundColor: colors.dangerBg, borderColor: colors.danger + "44" }]}>
              <Feather name="alert-circle" size={13} color={colors.danger} />
              <Text style={[styles.errorText, { color: colors.danger, fontFamily: "Inter_400Regular" }]}>{" "}{error}</Text>
            </View>
          ) : null}

          {/* Sign In */}
          <TouchableOpacity
            style={[styles.signInBtn, { backgroundColor: loading ? colors.primary + "88" : colors.primary }]}
            onPress={handleLogin}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={[styles.signInText, { fontFamily: "Inter_700Bold" }]}>Sign In</Text>
                <Feather name="log-in" size={18} color="#fff" />
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>New to CharLey?{" "}</Text>
          <TouchableOpacity onPress={() => router.replace("/register")}>
            <Text style={[styles.footerLink, { color: colors.primary, fontFamily: "Inter_600SemiBold" }]}>Create Account</Text>
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, overflow: "hidden" },
  circle: {
    position: "absolute",
    width: 360,
    height: 360,
    borderRadius: 180,
    top: -140,
    right: -80,
  },
  inner: {
    flex: 1,
    paddingHorizontal: 24,
    gap: 14,
  },
  splashOverlay: {
    position: "absolute",
    top: 0, left: 0, right: 0, bottom: 0,
    zIndex: 999,
    alignItems: "center",
    justifyContent: "center",
  },
  splashLogo: { width: 160, height: 160 },
  splashWordmark: { width: 200, height: 64, marginTop: -10 },
  backBtn: {
    width: 38,
    height: 38,
    borderRadius: 11,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  brandBlock: {
    alignItems: "center",
    alignSelf: "flex-start",
  },
  logoMini: { width: 72, height: 72 },
  wordmark: { width: 190, height: 58, marginTop: -4 },
  heading: { gap: 2 },
  title: { fontSize: 24, letterSpacing: -0.5 },
  subtitle: { fontSize: 14, lineHeight: 20 },
  form: { gap: 12 },
  label: { fontSize: 12, marginBottom: 5, letterSpacing: 0.2 },
  inputWrap: { position: "relative" },
  flagPill: {
    position: "absolute",
    left: 0, top: 0, bottom: 0,
    zIndex: 1,
    justifyContent: "center",
    paddingHorizontal: 10,
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
    borderRightWidth: 1,
  },
  flagText: { fontSize: 12 },
  input: {
    height: 46,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 14,
    fontSize: 14,
  },
  eyeBtn: {
    position: "absolute",
    right: 12, top: 0, bottom: 0,
    justifyContent: "center",
  },
  forgotRow: { alignItems: "flex-end" },
  forgotText: { fontSize: 12 },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    padding: 10,
  },
  errorText: { fontSize: 12, flex: 1 },
  signInBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
    paddingVertical: 14,
    gap: 8,
  },
  signInText: { color: "#fff", fontSize: 15 },
  footer: { flexDirection: "row", alignItems: "center", justifyContent: "center" },
  footerText: { fontSize: 13 },
  footerLink: { fontSize: 13 },
});
