import { Feather } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQueryClient } from "@tanstack/react-query";
import { getGetMeQueryKey, useRequestUploadUrl, useSubmitKyc } from "@workspace/api-client-react";
import { customFetch } from "@workspace/api-client-react";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

type KycStep = 1 | 2 | 3 | 4 | 5 | 6;

const STEP_LABELS = [
  "ID Type",
  "ID Number",
  "Front Photo",
  "Back Photo",
  "Selfie",
  "Review & Submit",
];

const ID_TYPES = [
  { id: "ghana_card",     label: "Ghana Card",       icon: "credit-card" as const },
  { id: "passport",       label: "Passport",          icon: "book-open" as const },
  { id: "voter_id",       label: "Voter ID",          icon: "users" as const },
];

async function saveDraft(patch: Record<string, unknown>) {
  try {
    await customFetch("/api/kyc/draft", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
  } catch {
    // draft save is best-effort
  }
}

export default function KycVerifyScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { currentUser } = useApp();
  const queryClient = useQueryClient();

  const requestUploadUrlMut = useRequestUploadUrl();
  const submitKycMut = useSubmitKyc();

  const [draftLoaded, setDraftLoaded] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const [step, setStep] = useState<KycStep>(1);
  const [idType, setIdType] = useState("ghana_card");
  const [idNumber, setIdNumber] = useState("");
  const [idNumberError, setIdNumberError] = useState("");
  const [frontUri, setFrontUri] = useState<string | null>(null);
  const [backUri, setBackUri] = useState<string | null>(null);
  const [selfieUri, setSelfieUri] = useState<string | null>(null);

  // Keep a ref to capture uploaded cloud URLs after upload (for draft persistence)
  const frontUrlRef = useRef<string | null>(null);
  const backUrlRef = useRef<string | null>(null);
  const selfieUrlRef = useRef<string | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Math.max(insets.bottom, 24);

  const isPending = currentUser?.kycStatus === "pending";
  const isApproved = currentUser?.kycStatus === "approved";

  // Load draft on mount
  useEffect(() => {
    if (isPending || isApproved) { setDraftLoaded(true); return; }
    (async () => {
      try {
        type DraftShape = {
          idType?: string | null;
          idNumber?: string | null;
          frontImageUrl?: string | null;
          backImageUrl?: string | null;
          selfieUrl?: string | null;
          currentStep?: string | null;
        };
        const draft = await customFetch<DraftShape>("/api/kyc/draft", { method: "GET" });
        if (draft.idType) setIdType(draft.idType);
        if (draft.idNumber) setIdNumber(draft.idNumber);
        if (draft.frontImageUrl) {
          setFrontUri(draft.frontImageUrl);
          frontUrlRef.current = draft.frontImageUrl;
        }
        if (draft.backImageUrl) {
          setBackUri(draft.backImageUrl);
          backUrlRef.current = draft.backImageUrl;
        }
        if (draft.selfieUrl) {
          setSelfieUri(draft.selfieUrl);
          selfieUrlRef.current = draft.selfieUrl;
        }
        const stepMap: Record<string, KycStep> = {
          id_type: 1, id_number: 2, front_photo: 3,
          back_photo: 4, selfie: 5, review: 6,
        };
        if (draft.currentStep && stepMap[draft.currentStep]) {
          setStep(stepMap[draft.currentStep]);
        }
      } catch { /* no draft — 404 expected when no draft exists */ }
      setDraftLoaded(true);
    })();
  }, []);

  const pickOrCapture = async (
    front: boolean,
    setter: (uri: string) => void,
    useFront = false
  ) => {
    try {
      const camPerm = await ImagePicker.requestCameraPermissionsAsync();
      if (camPerm.status === "granted") {
        const result = await ImagePicker.launchCameraAsync({
          mediaTypes: "images",
          quality: 0.85,
          ...(useFront ? { cameraType: ImagePicker.CameraType.front } : {}),
        });
        if (!result.canceled) setter(result.assets[0].uri);
        return;
      }
      const libPerm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (libPerm.status !== "granted") {
        Alert.alert("Permission required", "Camera or gallery access is needed for KYC.");
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: "images", quality: 0.85 });
      if (!result.canceled) setter(result.assets[0].uri);
    } catch {
      Alert.alert("Error", "Could not open camera or gallery.");
    }
  };

  const uploadPhoto = async (uri: string, filename: string): Promise<string> => {
    const resp = await requestUploadUrlMut.mutateAsync({
      data: { name: filename, size: 500000, contentType: "image/jpeg" },
    });
    const { uploadURL, objectPath } = resp as { uploadURL: string; objectPath: string };
    const blob = await (await fetch(uri)).blob();
    await fetch(uploadURL, { method: "PUT", body: blob, headers: { "Content-Type": "image/jpeg" } });
    return objectPath;
  };

  const stepKey = (s: KycStep): string => {
    const keys: Record<KycStep, string> = {
      1: "id_type", 2: "id_number", 3: "front_photo",
      4: "back_photo", 5: "selfie", 6: "review",
    };
    return keys[s];
  };

  const goTo = (s: KycStep, patch?: Record<string, unknown>) => {
    setStep(s);
    saveDraft({ ...patch, currentStep: stepKey(s) });
  };

  // ── Step handlers ─────────────────────────────────────────────────────────

  const handleStep1Next = () => {
    goTo(2, { idType });
  };

  const handleStep2Next = () => {
    if (!idNumber.trim()) { setIdNumberError("Please enter your ID number."); return; }
    setIdNumberError("");
    goTo(3, { idType, idNumber: idNumber.trim() });
  };

  const handleStep3Next = () => {
    if (!frontUri) { Alert.alert("Photo required", "Please capture the front of your ID."); return; }
    goTo(4, { frontImageUrl: frontUrlRef.current ?? undefined });
  };

  const handleStep4Next = () => {
    if (!backUri) { Alert.alert("Photo required", "Please capture the back of your ID."); return; }
    goTo(5, { backImageUrl: backUrlRef.current ?? undefined });
  };

  const handleStep5Next = () => {
    if (!selfieUri) { Alert.alert("Selfie required", "Please take a selfie to continue."); return; }
    goTo(6, { selfieUrl: selfieUrlRef.current ?? undefined });
  };

  const handleFrontCapture = async (uri: string) => {
    setFrontUri(uri);
    try {
      const url = await uploadPhoto(uri, "kyc_front.jpg");
      frontUrlRef.current = url;
      saveDraft({ frontImageUrl: url });
    } catch { /* will upload again on submit */ }
  };

  const handleBackCapture = async (uri: string) => {
    setBackUri(uri);
    try {
      const url = await uploadPhoto(uri, "kyc_back.jpg");
      backUrlRef.current = url;
      saveDraft({ backImageUrl: url });
    } catch { /* will upload again on submit */ }
  };

  const handleSelfieCapture = async (uri: string) => {
    setSelfieUri(uri);
    try {
      const url = await uploadPhoto(uri, "kyc_selfie.jpg");
      selfieUrlRef.current = url;
      saveDraft({ selfieUrl: url });
    } catch { /* will upload again on submit */ }
  };

  const handleSubmit = async () => {
    if (!frontUri || !backUri || !selfieUri || !idNumber.trim()) {
      setSubmitError("Please complete all steps before submitting.");
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      // Upload any photos that weren't uploaded during capture
      const [frontPath, backPath, selfiePath] = await Promise.all([
        frontUrlRef.current ?? uploadPhoto(frontUri, "kyc_front.jpg"),
        backUrlRef.current ?? uploadPhoto(backUri, "kyc_back.jpg"),
        selfieUrlRef.current ?? uploadPhoto(selfieUri, "kyc_selfie.jpg"),
      ]);
      await submitKycMut.mutateAsync({
        data: {
          idType: idType as "ghana_card" | "passport" | "voter_id",
          idNumber: idNumber.trim(),
          idFrontUrl: frontPath,
          idBackUrl: backPath,
          selfieUrl: selfiePath,
        },
      });
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      setSubmitted(true);
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error
        ?? (err as Error)?.message
        ?? "Submission failed. Please try again.";
      setSubmitError(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (!draftLoaded) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (isPending && !submitted) {
    return <StatusScreen colors={colors} topPad={topPad} botPad={botPad} router={router}
      icon="clock" iconColor="#F59E0B" iconBg="#F59E0B18"
      title="Under Review"
      body="Your identity verification is being reviewed by our team. This usually takes 1–2 business days."
      btn="Go Back" onBtnPress={() => safeGoBack(router)} />;
  }

  if (isApproved) {
    return <StatusScreen colors={colors} topPad={topPad} botPad={botPad} router={router}
      icon="shield" iconColor="#10B981" iconBg="#10B98118"
      title="Verified ✓"
      body="Your identity has been verified. All wallet features are active."
      btn="Done" onBtnPress={() => safeGoBack(router)} />;
  }

  if (submitted) {
    return <StatusScreen colors={colors} topPad={topPad} botPad={botPad} router={router}
      icon="check-circle" iconColor="#10B981" iconBg="#10B98118"
      title="Submitted!"
      body="Your documents have been submitted for review. You'll be notified once your identity is verified (1–2 business days)."
      btn="Done" onBtnPress={() => safeGoBack(router)} />;
  }

  if (submitting) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background, alignItems: "center", justifyContent: "center", gap: 20 }]}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={[styles.bigTitle, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>Uploading documents…</Text>
        <Text style={[styles.bigSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Please keep this screen open.</Text>
      </View>
    );
  }

  const idTypeLabel = ID_TYPES.find(t => t.id === idType)?.label ?? "ID";

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          onPress={() => { if (step > 1) setStep((step - 1) as KycStep); else safeGoBack(router); }}
          style={styles.backBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Identity Verification</Text>
        <View style={{ width: 38 }} />
      </View>

      {/* Progress bar */}
      <View style={[styles.progressBar, { backgroundColor: colors.surfaceElevated }]}>
        {([1, 2, 3, 4, 5, 6] as KycStep[]).map((s) => (
          <View
            key={s}
            style={[
              styles.progressSegment,
              {
                backgroundColor: s <= step ? colors.primary : colors.border,
                opacity: s === step ? 1 : s < step ? 0.7 : 0.3,
              },
            ]}
          />
        ))}
      </View>
      <View style={[styles.progressLabel, { backgroundColor: colors.surface }]}>
        <Text style={[styles.progressText, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>
          Step {step} of 6 — {STEP_LABELS[step - 1]}
        </Text>
      </View>

      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: botPad }]} keyboardShouldPersistTaps="handled">

        {/* ── Rejection banner ── */}
        {currentUser?.kycStatus === "rejected" && currentUser?.kycRejectionReason && step === 1 && (
          <View style={[styles.rejectedBanner, { backgroundColor: "#EF444418", borderColor: "#EF444444" }]}>
            <Feather name="alert-circle" size={16} color="#EF4444" />
            <View style={{ flex: 1 }}>
              <Text style={[styles.rejectedTitle, { color: "#EF4444", fontFamily: "Inter_600SemiBold" }]}>Previous submission rejected</Text>
              <Text style={[styles.rejectedReason, { color: "#EF4444", fontFamily: "Inter_400Regular" }]}>{currentUser.kycRejectionReason}</Text>
            </View>
          </View>
        )}

        {/* ── Step 1: ID Type ── */}
        {step === 1 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Choose your ID type</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Select a government-issued photo ID to verify your identity.
            </Text>
            <View style={styles.idTypeGrid}>
              {ID_TYPES.map((t) => (
                <TouchableOpacity
                  key={t.id}
                  style={[styles.idTypeCard, {
                    backgroundColor: idType === t.id ? colors.primary + "18" : colors.surface,
                    borderColor: idType === t.id ? colors.primary : colors.border,
                  }]}
                  onPress={() => setIdType(t.id)}
                  activeOpacity={0.7}
                >
                  <Feather name={t.icon} size={22} color={idType === t.id ? colors.primary : colors.textMuted} />
                  <Text style={[styles.idTypeLabel, { color: idType === t.id ? colors.primary : colors.text, fontFamily: "Inter_600SemiBold" }]}>{t.label}</Text>
                  {idType === t.id && (
                    <View style={[styles.selectedDot, { backgroundColor: colors.primary }]}>
                      <Feather name="check" size={10} color="#fff" />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
            <PrimaryBtn label="Continue" onPress={handleStep1Next} colors={colors} icon="arrow-right" />
          </View>
        )}

        {/* ── Step 2: ID Number ── */}
        {step === 2 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{idTypeLabel} number</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Enter the number exactly as it appears on your {idTypeLabel}.
            </Text>
            <Text style={[styles.fieldLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>
              {idType === "ghana_card" ? "GHANA CARD NUMBER" : idType === "passport" ? "PASSPORT NUMBER" : "VOTER ID NUMBER"}
            </Text>
            <TextInput
              style={[styles.fieldInput, {
                backgroundColor: colors.surfaceElevated,
                color: colors.text,
                borderColor: idNumberError ? "#EF4444" : colors.border,
                fontFamily: "Inter_400Regular",
              }]}
              placeholder={idType === "ghana_card" ? "GHA-XXXXXXXXX-X" : "Enter ID number"}
              placeholderTextColor={colors.textMuted}
              autoCapitalize="characters"
              value={idNumber}
              onChangeText={(v) => { setIdNumber(v); setIdNumberError(""); }}
              returnKeyType="next"
              onSubmitEditing={handleStep2Next}
            />
            {idNumberError ? <Text style={styles.fieldError}>{idNumberError}</Text> : null}
            <PrimaryBtn label="Continue" onPress={handleStep2Next} colors={colors} icon="arrow-right" disabled={!idNumber.trim()} />
          </View>
        )}

        {/* ── Step 3: Front Photo ── */}
        {step === 3 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Front of {idTypeLabel}</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Take a clear photo of the front of your {idTypeLabel}. Ensure all text is readable.
            </Text>
            <CaptureSlot uri={frontUri} label="Tap to capture front" onCapture={() => pickOrCapture(true, handleFrontCapture)} colors={colors} />
            <PrimaryBtn label="Continue" onPress={handleStep3Next} colors={colors} icon="arrow-right" disabled={!frontUri} />
          </View>
        )}

        {/* ── Step 4: Back Photo ── */}
        {step === 4 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Back of {idTypeLabel}</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Take a clear photo of the back of your {idTypeLabel}.
            </Text>
            <InfoBox colors={colors} text="Face Verification requires both the front and back of your ID. Please upload this photo before continuing." />
            <CaptureSlot uri={backUri} label="Tap to capture back" onCapture={() => pickOrCapture(false, handleBackCapture)} colors={colors} />
            <PrimaryBtn label="Continue" onPress={handleStep4Next} colors={colors} icon="arrow-right" disabled={!backUri} />
          </View>
        )}

        {/* ── Step 5: Selfie ── */}
        {step === 5 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Face Verification</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Take a clear selfie with your face fully visible. Ensure good lighting.
            </Text>
            {(!frontUri || !backUri) && (
              <InfoBox colors={colors} text="Please upload the back of your ID before continuing." type="error" />
            )}
            <CaptureSlot uri={selfieUri} label="Tap to take selfie" onCapture={() => {
              if (!frontUri || !backUri) {
                Alert.alert(
                  "Back ID required",
                  "Please upload the back of your ID before taking a selfie.",
                  [{ text: "Go back", onPress: () => setStep(4) }, { text: "OK" }]
                );
                return;
              }
              pickOrCapture(false, handleSelfieCapture, true);
            }} colors={colors} round />
            <PrimaryBtn label="Continue" onPress={handleStep5Next} colors={colors} icon="arrow-right" disabled={!selfieUri || !frontUri || !backUri} />
          </View>
        )}

        {/* ── Step 6: Review & Submit ── */}
        {step === 6 && (
          <View style={styles.section}>
            <Text style={[styles.stepTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Review & Submit</Text>
            <Text style={[styles.stepSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              Review your information before submitting. Once submitted, it cannot be edited.
            </Text>

            {/* Summary card */}
            <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <ReviewRow label="ID Type" value={idTypeLabel} colors={colors} />
              <ReviewRow label="ID Number" value={idNumber} colors={colors} />
              <View style={[styles.reviewDivider, { backgroundColor: colors.border }]} />
              <View style={styles.reviewImages}>
                <View style={styles.reviewImageSlot}>
                  <Text style={[styles.reviewImageLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>FRONT</Text>
                  {frontUri && <Image source={{ uri: frontUri }} style={styles.reviewThumb} resizeMode="cover" />}
                </View>
                <View style={styles.reviewImageSlot}>
                  <Text style={[styles.reviewImageLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>BACK</Text>
                  {backUri && <Image source={{ uri: backUri }} style={styles.reviewThumb} resizeMode="cover" />}
                </View>
                <View style={styles.reviewImageSlot}>
                  <Text style={[styles.reviewImageLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>SELFIE</Text>
                  {selfieUri && <Image source={{ uri: selfieUri }} style={[styles.reviewThumb, { borderRadius: 50 }]} resizeMode="cover" />}
                </View>
              </View>
            </View>

            {submitError ? (
              <View style={[styles.errorBanner, { backgroundColor: "#EF444418", borderColor: "#EF444444" }]}>
                <Feather name="alert-circle" size={14} color="#EF4444" />
                <Text style={[styles.errorText, { color: "#EF4444", fontFamily: "Inter_400Regular" }]}>{submitError}</Text>
              </View>
            ) : null}

            <TouchableOpacity
              style={[styles.submitBtn, {
                backgroundColor: (frontUri && backUri && selfieUri && idNumber) ? colors.primary : colors.surfaceElevated,
              }]}
              onPress={handleSubmit}
              disabled={!frontUri || !backUri || !selfieUri || !idNumber.trim()}
              activeOpacity={0.8}
            >
              <Feather name="shield" size={18} color={frontUri && backUri && selfieUri ? "#fff" : colors.textMuted} />
              <Text style={[styles.submitBtnText, {
                color: (frontUri && backUri && selfieUri && idNumber) ? "#fff" : colors.textMuted,
                fontFamily: "Inter_700Bold",
              }]}>Submit Verification</Text>
            </TouchableOpacity>

            <Text style={[styles.secureNote, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
              🔒 Your documents are encrypted and stored securely. Review takes 1–2 business days.
            </Text>
          </View>
        )}

      </ScrollView>
    </View>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function PrimaryBtn({ label, onPress, colors, icon, disabled = false }: {
  label: string; onPress: () => void;
  colors: ReturnType<typeof useColors>; icon?: string; disabled?: boolean;
}) {
  return (
    <TouchableOpacity
      style={[styles.primaryBtn, { backgroundColor: disabled ? colors.surfaceElevated : colors.primary }]}
      onPress={onPress} disabled={disabled} activeOpacity={0.8}
    >
      <Text style={[styles.primaryBtnText, { color: disabled ? colors.textMuted : "#fff", fontFamily: "Inter_600SemiBold" }]}>{label}</Text>
      {icon && <Feather name={icon as "arrow-right"} size={16} color={disabled ? colors.textMuted : "#fff"} />}
    </TouchableOpacity>
  );
}

function InfoBox({ colors, text, type = "info" }: {
  colors: ReturnType<typeof useColors>; text: string; type?: "info" | "error";
}) {
  const color = type === "error" ? "#EF4444" : "#F59E0B";
  return (
    <View style={[styles.infoBox, { backgroundColor: color + "18", borderColor: color + "44" }]}>
      <Feather name={type === "error" ? "alert-circle" : "info"} size={14} color={color} />
      <Text style={[styles.infoText, { color, fontFamily: "Inter_400Regular" }]}>{text}</Text>
    </View>
  );
}

function CaptureSlot({ uri, label, onCapture, colors, round = false }: {
  uri: string | null; label: string; onCapture: () => void;
  colors: ReturnType<typeof useColors>; round?: boolean;
}) {
  return (
    <TouchableOpacity
      style={[styles.captureSlot, {
        backgroundColor: colors.surfaceElevated,
        borderColor: uri ? colors.primary + "66" : colors.border,
        borderRadius: round ? 80 : 14,
        aspectRatio: round ? 1 : undefined,
        height: round ? undefined : 160,
        alignSelf: round ? "center" : "stretch",
        width: round ? 160 : undefined,
      }]}
      onPress={onCapture} activeOpacity={0.7}
    >
      {uri ? (
        <Image source={{ uri }} style={[StyleSheet.absoluteFill, { borderRadius: round ? 80 : 14 }]} resizeMode="cover" />
      ) : (
        <View style={styles.captureInner}>
          <View style={[styles.captureIconCircle, { backgroundColor: colors.primary + "18" }]}>
            <Feather name={round ? "camera" : "image"} size={26} color={colors.primary} />
          </View>
          <Text style={[styles.captureLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>{label}</Text>
        </View>
      )}
      {uri && (
        <View style={styles.retakeOverlay}>
          <Feather name="refresh-cw" size={14} color="#fff" />
          <Text style={[styles.retakeText, { fontFamily: "Inter_600SemiBold" }]}>Retake</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

function ReviewRow({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={styles.reviewRow}>
      <Text style={[styles.reviewLabel, { color: colors.textMuted, fontFamily: "Inter_500Medium" }]}>{label}</Text>
      <Text style={[styles.reviewValue, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{value}</Text>
    </View>
  );
}

function StatusScreen({ colors, topPad, botPad, router, icon, iconColor, iconBg, title, body, btn, onBtnPress }: {
  colors: ReturnType<typeof useColors>;
  topPad: number; botPad: number;
  router: ReturnType<typeof useRouter>;
  icon: string; iconColor: string; iconBg: string;
  title: string; body: string; btn: string;
  onBtnPress: () => void;
}) {
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Identity Verification</Text>
        <View style={{ width: 38 }} />
      </View>
      <ScrollView contentContainerStyle={[styles.centerBlock, { paddingBottom: botPad }]}>
        <View style={[styles.iconCircle, { backgroundColor: iconBg }]}>
          <Feather name={icon as "clock"} size={40} color={iconColor} />
        </View>
        <Text style={[styles.bigTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{title}</Text>
        <Text style={[styles.bigSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{body}</Text>
        <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: colors.primary, width: "100%" }]} onPress={onBtnPress}>
          <Text style={[styles.primaryBtnText, { fontFamily: "Inter_600SemiBold" }]}>{btn}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 16, paddingBottom: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, textAlign: "center", fontSize: 17 },
  progressBar: { flexDirection: "row", height: 4, gap: 2, paddingHorizontal: 2 },
  progressSegment: { flex: 1, borderRadius: 2 },
  progressLabel: { paddingHorizontal: 20, paddingVertical: 10, alignItems: "center" },
  progressText: { fontSize: 12 },
  scroll: { padding: 20 },
  section: { gap: 10 },
  stepTitle: { fontSize: 22, marginBottom: 2 },
  stepSub: { fontSize: 14, lineHeight: 21, marginBottom: 8 },
  idTypeGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 8 },
  idTypeCard: {
    width: "47%", borderRadius: 14, borderWidth: 1.5,
    padding: 16, gap: 8, position: "relative",
  },
  idTypeLabel: { fontSize: 13 },
  selectedDot: {
    position: "absolute", top: 8, right: 8,
    width: 18, height: 18, borderRadius: 9,
    alignItems: "center", justifyContent: "center",
  },
  primaryBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    borderRadius: 14, paddingVertical: 16, gap: 8, marginTop: 8,
  },
  primaryBtnText: { color: "#fff", fontSize: 16 },
  fieldLabel: { fontSize: 11, letterSpacing: 0.8, marginBottom: 6, marginTop: 4 },
  fieldInput: { borderWidth: 1, borderRadius: 12, padding: 14, fontSize: 15 },
  fieldError: { color: "#EF4444", fontSize: 12, marginTop: 4, fontFamily: "Inter_400Regular" },
  captureSlot: {
    borderWidth: 1.5, borderStyle: "dashed",
    alignItems: "center", justifyContent: "center", overflow: "hidden",
  },
  captureInner: { alignItems: "center", gap: 10, padding: 20 },
  captureIconCircle: { width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center" },
  captureLabel: { fontSize: 13 },
  retakeOverlay: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    backgroundColor: "rgba(0,0,0,0.55)",
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    paddingVertical: 8, gap: 6,
  },
  retakeText: { color: "#fff", fontSize: 12 },
  infoBox: { flexDirection: "row", gap: 8, padding: 12, borderRadius: 10, borderWidth: 1, alignItems: "flex-start" },
  infoText: { flex: 1, fontSize: 13, lineHeight: 19 },
  summaryCard: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 12 },
  reviewRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  reviewLabel: { fontSize: 12 },
  reviewValue: { fontSize: 14 },
  reviewDivider: { height: 1 },
  reviewImages: { flexDirection: "row", gap: 8 },
  reviewImageSlot: { flex: 1, gap: 6 },
  reviewImageLabel: { fontSize: 10, letterSpacing: 0.5, textAlign: "center" },
  reviewThumb: { width: "100%", aspectRatio: 1.3, borderRadius: 8 },
  submitBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    borderRadius: 14, paddingVertical: 18, gap: 10, marginTop: 8,
  },
  submitBtnText: { fontSize: 17 },
  errorBanner: {
    flexDirection: "row", gap: 8, padding: 12,
    borderRadius: 10, borderWidth: 1, alignItems: "center",
  },
  errorText: { flex: 1, fontSize: 13 },
  secureNote: { fontSize: 12, textAlign: "center", lineHeight: 18, marginTop: 16, opacity: 0.7 },
  centerBlock: { flex: 1, alignItems: "center", paddingTop: 60, gap: 16, paddingHorizontal: 20 },
  iconCircle: { width: 90, height: 90, borderRadius: 45, alignItems: "center", justifyContent: "center", marginBottom: 8 },
  bigTitle: { fontSize: 24, textAlign: "center" },
  bigSub: { fontSize: 15, textAlign: "center", lineHeight: 23 },
  rejectedBanner: {
    flexDirection: "row", gap: 10, padding: 14,
    borderRadius: 12, borderWidth: 1, marginBottom: 8, alignItems: "flex-start",
  },
  rejectedTitle: { fontSize: 13, marginBottom: 2 },
  rejectedReason: { fontSize: 12, lineHeight: 18 },
});
