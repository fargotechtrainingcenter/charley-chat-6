import AsyncStorage from "@react-native-async-storage/async-storage";
import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import * as Sharing from "expo-sharing";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Alert,
  Animated,
  Image,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { setSoundsEnabled, SOUND_SETTING_KEY } from "@/lib/sounds";
import { apiOrigin } from "@/lib/api-base";

// ── Shared inline numpad ───────────────────────────────────────────────────────
function NumPad({ onPress, onDelete, disabled }: { onPress: (d: string) => void; onDelete: () => void; disabled?: boolean }) {
  const colors = useColors();
  const keys = ["1","2","3","4","5","6","7","8","9","","0","⌫"];
  return (
    <View style={np.grid}>
      {keys.map((k, i) => {
        if (k === "") return <View key={i} style={np.keyEmpty} />;
        const isDel = k === "⌫";
        return (
          <TouchableOpacity key={i} style={[np.key, { backgroundColor: colors.surfaceElevated, opacity: disabled ? 0.4 : 1 }]}
            onPress={() => !disabled && (isDel ? onDelete() : onPress(k))} activeOpacity={0.6}>
            {isDel
              ? <Feather name="delete" size={19} color={colors.text} />
              : <Text style={[np.keyText, { color: colors.text, fontFamily: "Inter_500Medium" }]}>{k}</Text>}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
const np = StyleSheet.create({
  grid:     { flexDirection: "row", flexWrap: "wrap", width: 240, justifyContent: "center", gap: 10, marginTop: 8 },
  key:      { width: 68, height: 50, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  keyEmpty: { width: 68, height: 50 },
  keyText:  { fontSize: 22 },
});

// ── PIN Management Modal ───────────────────────────────────────────────────────
// mode="create": new → confirm → success (no old PIN needed)
// mode="change": current → new → confirm → success
type PinStep = "current" | "new" | "confirm" | "success";

function PinManagementModal({ visible, onClose, mode, verifyPin, createPinApi, changePinApi, onPinSet }: {
  visible: boolean;
  onClose: () => void;
  mode: "create" | "change";
  verifyPin: (pin: string) => Promise<boolean>;
  createPinApi: (pin: string) => Promise<{ ok: boolean; error?: string }>;
  changePinApi: (current: string, next: string) => Promise<{ ok: boolean; error?: string }>;
  onPinSet: () => void;
}) {
  const colors = useColors();
  const firstStep: PinStep = mode === "create" ? "new" : "current";
  const [step, setStep]         = useState<PinStep>(firstStep);
  const [currentPin, setCurrentPin] = useState("");
  const [newPin,     setNewPin]     = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error,  setError]  = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const submittingRef = useRef(false);
  const shakeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0)).current;

  const activePin = step === "current" ? currentPin : step === "new" ? newPin : confirmPin;

  // Reset on open
  useEffect(() => {
    if (visible) {
      setStep(mode === "create" ? "new" : "current");
      setCurrentPin(""); setNewPin(""); setConfirmPin("");
      setError(null); setLoading(false);
      submittingRef.current = false;
    }
  }, [visible, mode]);

  // Animate success checkmark
  useEffect(() => {
    if (step === "success") {
      scaleAnim.setValue(0);
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, damping: 12, stiffness: 180 }).start();
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, [step, scaleAnim]);

  const shake = useCallback(() => {
    shakeAnim.setValue(0);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 12,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -12, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8,   duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8,  duration: 55, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,   duration: 50, useNativeDriver: true }),
    ]).start();
  }, [shakeAnim]);

  const errClear = useCallback((msg: string, clearSetter: (v: string) => void) => {
    setLoading(false);
    submittingRef.current = false;
    shake();
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    setError(msg);
    clearSetter("");
  }, [shake]);

  // Numpad handlers
  const handleDigit = useCallback((d: string) => {
    if (loading || submittingRef.current || step === "success") return;
    setError(null);
    if (step === "current") setCurrentPin(p => p.length < 4 ? p + d : p);
    else if (step === "new")     setNewPin(p => p.length < 4 ? p + d : p);
    else if (step === "confirm") setConfirmPin(p => p.length < 4 ? p + d : p);
  }, [loading, step]);

  const handleDelete = useCallback(() => {
    if (loading || submittingRef.current || step === "success") return;
    setError(null);
    if (step === "current") setCurrentPin(p => p.slice(0, -1));
    else if (step === "new")     setNewPin(p => p.slice(0, -1));
    else if (step === "confirm") setConfirmPin(p => p.slice(0, -1));
  }, [loading, step]);

  // Auto-submit when 4 digits reached
  useEffect(() => {
    if (activePin.length !== 4 || step === "success" || submittingRef.current) return;
    submittingRef.current = true;
    setLoading(true);
    setError(null);

    (async () => {
      if (step === "current") {
        const ok = await verifyPin(activePin);
        if (!ok) return errClear("Incorrect PIN", setCurrentPin);
        setLoading(false); submittingRef.current = false;
        setStep("new"); setNewPin("");

      } else if (step === "new") {
        setLoading(false); submittingRef.current = false;
        setStep("confirm"); setConfirmPin("");

      } else if (step === "confirm") {
        if (activePin !== newPin) return errClear("PINs don't match", setConfirmPin);
        const result = mode === "create"
          ? await createPinApi(newPin)
          : await changePinApi(currentPin, newPin);
        if (!result.ok) return errClear(result.error ?? "Failed. Please try again.", setConfirmPin);
        setLoading(false); submittingRef.current = false;
        setStep("success");
        onPinSet();
      }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePin, step]);

  const steps: PinStep[] = mode === "create" ? ["new", "confirm"] : ["current", "new", "confirm"];
  const stepLabel: Record<PinStep, string> = {
    current: "Enter your current PIN",
    new:     mode === "create" ? "Choose a 4-digit send PIN" : "Enter your new PIN",
    confirm: "Confirm your new PIN",
    success: "",
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={ms.backdrop}>
        <View style={[ms.card, { backgroundColor: colors.surface }]}>

          {step === "success" ? (
            /* ── Success Screen ── */
            <View style={{ alignItems: "center", paddingVertical: 8 }}>
              <Animated.View style={[ms.successRing, { borderColor: "#22C55E", transform: [{ scale: scaleAnim }] }]}>
                <Feather name="check" size={36} color="#22C55E" />
              </Animated.View>
              <Text style={[ms.title, { color: colors.text, fontFamily: "Inter_700Bold", marginTop: 16 }]}>
                {mode === "create" ? "PIN Created!" : "PIN Updated!"}
              </Text>
              <Text style={[ms.sub, { color: colors.textMuted, fontFamily: "Inter_400Regular", textAlign: "center" }]}>
                {mode === "create"
                  ? "Your send PIN is set. You'll be asked for it every time you send money."
                  : "Your send PIN has been updated successfully."}
              </Text>
              <TouchableOpacity style={[ms.doneBtn, { backgroundColor: "#22C55E" }]} onPress={onClose}>
                <Text style={[ms.doneBtnText, { fontFamily: "Inter_600SemiBold" }]}>Done</Text>
              </TouchableOpacity>
            </View>
          ) : (
            /* ── Entry Steps ── */
            <>
              <View style={[ms.iconWrap, { backgroundColor: colors.primary + "20" }]}>
                <Feather name="lock" size={26} color={colors.primary} />
              </View>
              <Text style={[ms.title, { color: colors.text, fontFamily: "Inter_700Bold" }]}>
                {mode === "create" ? "Create Send PIN" : "Change Send PIN"}
              </Text>
              <Text style={[ms.sub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
                {stepLabel[step]}
              </Text>

              {/* Dot indicators */}
              <Animated.View style={[ms.dots, { transform: [{ translateX: shakeAnim }] }]}>
                {[0, 1, 2, 3].map((i) => (
                  <View key={i} style={[ms.dot, {
                    backgroundColor: i < activePin.length ? (error ? "#EF4444" : colors.primary) : colors.surfaceElevated,
                    borderWidth: 2,
                    borderColor: i < activePin.length
                      ? (error ? "#EF4444" : colors.primary)
                      : (i === activePin.length ? colors.primary : colors.border),
                    transform: [{ scale: i < activePin.length ? 1.1 : 1 }],
                  }]} />
                ))}
              </Animated.View>

              {error
                ? <Text style={ms.errText}>{error}</Text>
                : <Text style={[ms.hint, { color: colors.textMuted }]}>{loading ? "Verifying…" : " "}</Text>
              }

              {/* Inline numpad */}
              <NumPad onPress={handleDigit} onDelete={handleDelete} disabled={loading} />

              {/* Step progress indicators */}
              <View style={[ms.progress, { marginTop: 16 }]}>
                {steps.map((s) => (
                  <View key={s} style={[ms.dot2, {
                    backgroundColor: s === step ? colors.primary : colors.border,
                    width: s === step ? 18 : 8,
                  }]} />
                ))}
              </View>

              <TouchableOpacity onPress={onClose} style={ms.cancel}>
                <Text style={{ color: colors.textMuted, fontFamily: "Inter_500Medium", fontSize: 14 }}>Cancel</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

// ── Broadcast Modal ────────────────────────────────────────────────────────────
function BroadcastModal({ visible, onClose, onSend }: {
  visible: boolean; onClose: () => void; onSend: (msg: string) => void;
}) {
  const colors = useColors();
  const [text, setText] = useState("");
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <TouchableOpacity style={ms.backdrop} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={[ms.sheet, { backgroundColor: colors.surface }]}>
          <View style={[ms.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[ms.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Broadcast Message</Text>
          <Text style={[ms.sheetSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>
            Send a message to all your contacts at once
          </Text>
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder="Type your broadcast message…"
            placeholderTextColor={colors.textMuted}
            multiline
            style={[ms.broadcastInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border, fontFamily: "Inter_400Regular" }]}
          />
          <TouchableOpacity
            style={[ms.sendBtn, { backgroundColor: text.trim() ? colors.primary : colors.surfaceElevated }]}
            onPress={() => { if (text.trim()) { onSend(text.trim()); setText(""); onClose(); } }}
          >
            <Feather name="send" size={16} color={text.trim() ? "#fff" : colors.textMuted} />
            <Text style={[ms.sendBtnText, { color: text.trim() ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>
              {"  "}Send to All Contacts
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose} style={ms.cancel}>
            <Text style={{ color: colors.textMuted, fontFamily: "Inter_500Medium", fontSize: 14 }}>Cancel</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ── Wallpaper Picker ───────────────────────────────────────────────────────────
export const WALLPAPERS = [
  { id: "default",  label: "Default",   bg: null,       img: null },
  { id: "ghana",    label: "Ghana",     bg: "#4a3728",  img: require("../assets/images/wallpaper-ghana.jpg") },
  { id: "dusk",     label: "Dusk",      bg: "#1a1a2e",  img: null },
  { id: "sage",     label: "Sage",      bg: "#2d4a3e",  img: null },
  { id: "violet",   label: "Violet",    bg: "#2e1a47",  img: null },
  { id: "ocean",    label: "Ocean",     bg: "#0a2540",  img: null },
  { id: "clay",     label: "Clay",      bg: "#3d2314",  img: null },
  { id: "blush",    label: "Blush",     bg: "#4a1942",  img: null },
  { id: "sand",     label: "Sand",      bg: "#3d3018",  img: null },
];

export const WALLPAPER_STORAGE_KEY = "@charley/chat_wallpaper";

function WallpaperModal({ visible, onClose, current, onSelect }: {
  visible: boolean; onClose: () => void; current: string; onSelect: (id: string) => void;
}) {
  const colors = useColors();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <TouchableOpacity style={ms.backdrop} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={[ms.sheet, { backgroundColor: colors.surface }]}>
          <View style={[ms.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[ms.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Chat Wallpaper</Text>
          <View style={ms.wallpaperGrid}>
            {WALLPAPERS.map((w) => (
              <TouchableOpacity key={w.id} onPress={() => { onSelect(w.id); onClose(); }} style={[
                ms.wallpaperSwatch,
                { backgroundColor: w.bg ?? colors.background, borderWidth: current === w.id ? 3 : 1.5, borderColor: current === w.id ? colors.primary : colors.border, overflow: "hidden" },
              ]}>
                {w.img ? (
                  <Image source={w.img} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
                ) : null}
                {current === w.id && (
                  <View style={{ position: "absolute", top: 4, right: 4, backgroundColor: colors.primary, borderRadius: 10, width: 20, height: 20, alignItems: "center", justifyContent: "center" }}>
                    <Feather name="check" size={11} color="#fff" />
                  </View>
                )}
                <View style={{ position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "rgba(0,0,0,0.45)", paddingVertical: 3 }}>
                  <Text style={[ms.wallpaperLabel, { color: "#fff", fontFamily: "Inter_500Medium" }]}>{w.label}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity onPress={onClose} style={ms.cancel}>
            <Text style={{ color: colors.textMuted, fontFamily: "Inter_500Medium", fontSize: 14 }}>Close</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ── Language Picker ────────────────────────────────────────────────────────────
const LANGUAGES = [
  { code: "en", label: "English", native: "English" },
  { code: "fr", label: "French", native: "Français" },
  { code: "ar", label: "Arabic", native: "العربية" },
  { code: "ha", label: "Hausa", native: "Hausa" },
  { code: "yo", label: "Yoruba", native: "Yorùbá" },
  { code: "tw", label: "Twi", native: "Twi" },
  { code: "ee", label: "Ewe", native: "Eʋegbe" },
  { code: "ga", label: "Ga", native: "Ga" },
];

function LanguageModal({ visible, onClose, current, onSelect }: {
  visible: boolean; onClose: () => void; current: string; onSelect: (code: string) => void;
}) {
  const colors = useColors();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <TouchableOpacity style={ms.backdrop} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={[ms.sheet, { backgroundColor: colors.surface }]}>
          <View style={[ms.sheetHandle, { backgroundColor: colors.border }]} />
          <Text style={[ms.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>App Language</Text>
          <ScrollView style={{ maxHeight: 340 }} showsVerticalScrollIndicator={false}>
            {LANGUAGES.map((lang) => (
              <TouchableOpacity key={lang.code} onPress={() => { onSelect(lang.code); onClose(); }}
                style={[ms.langRow, { borderBottomColor: colors.border }]}>
                <View style={{ flex: 1 }}>
                  <Text style={[ms.langLabel, { color: colors.text, fontFamily: "Inter_600SemiBold" }]}>{lang.label}</Text>
                  <Text style={[ms.langNative, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{lang.native}</Text>
                </View>
                {current === lang.code && <Feather name="check" size={18} color={colors.primary} />}
              </TouchableOpacity>
            ))}
          </ScrollView>
          <TouchableOpacity onPress={onClose} style={ms.cancel}>
            <Text style={{ color: colors.textMuted, fontFamily: "Inter_500Medium", fontSize: 14 }}>Close</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ── Report Modal ───────────────────────────────────────────────────────────────
const REPORT_REASONS = ["Spam or scam", "Fake account", "Harassment or bullying", "Inappropriate content", "Fraud or financial scam", "Other"];

function ReportModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const [selected, setSelected] = useState<string | null>(null);
  const [details, setDetails] = useState("");
  const [sent, setSent] = useState(false);

  useEffect(() => { if (visible) { setSelected(null); setDetails(""); setSent(false); } }, [visible]);

  const submit = () => {
    if (!selected) return;
    setSent(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <TouchableOpacity style={ms.backdrop} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} style={[ms.sheet, { backgroundColor: colors.surface }]}>
          <View style={[ms.sheetHandle, { backgroundColor: colors.border }]} />
          {sent ? (
            <View style={{ alignItems: "center", paddingVertical: 20 }}>
              <View style={[ms.iconWrap, { backgroundColor: "#22C55E20", marginBottom: 12 }]}>
                <Feather name="check-circle" size={28} color="#22C55E" />
              </View>
              <Text style={[ms.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Report Submitted</Text>
              <Text style={[ms.sheetSub, { color: colors.textMuted, textAlign: "center", fontFamily: "Inter_400Regular" }]}>
                Thank you. Our team will review this report within 24 hours.
              </Text>
              <TouchableOpacity onPress={onClose} style={[ms.sendBtn, { backgroundColor: colors.primary, marginTop: 12 }]}>
                <Text style={{ color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 14 }}>Done</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              <Text style={[ms.sheetTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Report an Account</Text>
              <Text style={[ms.sheetSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>What's the reason for this report?</Text>
              {REPORT_REASONS.map((r) => (
                <TouchableOpacity key={r} onPress={() => setSelected(r)}
                  style={[ms.reportRow, { borderColor: selected === r ? colors.primary : colors.border, backgroundColor: selected === r ? colors.primary + "10" : "transparent" }]}>
                  <Text style={[ms.reportText, { color: selected === r ? colors.primary : colors.text, fontFamily: selected === r ? "Inter_600SemiBold" : "Inter_400Regular" }]}>{r}</Text>
                  {selected === r && <Feather name="check-circle" size={16} color={colors.primary} />}
                </TouchableOpacity>
              ))}
              {selected === "Other" && (
                <TextInput value={details} onChangeText={setDetails} placeholder="Describe the issue…"
                  placeholderTextColor={colors.textMuted} multiline style={[ms.broadcastInput, { backgroundColor: colors.surfaceElevated, color: colors.text, borderColor: colors.border, fontFamily: "Inter_400Regular", marginTop: 8 }]} />
              )}
              <TouchableOpacity style={[ms.sendBtn, { backgroundColor: selected ? "#EF4444" : colors.surfaceElevated, marginTop: 12 }]} onPress={submit}>
                <Text style={[ms.sendBtnText, { color: selected ? "#fff" : colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>Submit Report</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={onClose} style={ms.cancel}>
                <Text style={{ color: colors.textMuted, fontFamily: "Inter_500Medium", fontSize: 14 }}>Cancel</Text>
              </TouchableOpacity>
            </>
          )}
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ── Settings Row Component ─────────────────────────────────────────────────────
function SettingsRow({
  icon, iconBg, label, sub, onPress, rightElement, isLast,
}: {
  icon: keyof typeof Feather.glyphMap;
  iconBg: string;
  label: string;
  sub?: string;
  onPress?: () => void;
  rightElement?: React.ReactNode;
  isLast?: boolean;
}) {
  const colors = useColors();
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={onPress ? 0.7 : 1}
      style={[styles.row, { borderBottomColor: isLast ? "transparent" : colors.border }]}
    >
      <View style={[styles.rowIcon, { backgroundColor: iconBg }]}>
        <Feather name={icon} size={17} color="#fff" />
      </View>
      <View style={styles.rowText}>
        <Text style={[styles.rowLabel, { color: colors.text, fontFamily: "Inter_500Medium" }]}>{label}</Text>
        {sub && <Text style={[styles.rowSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{sub}</Text>}
      </View>
      {rightElement ?? (onPress && <Feather name="chevron-right" size={18} color={colors.textMuted} />)}
    </TouchableOpacity>
  );
}

function SettingsSection({ title, children }: { title: string; children: React.ReactNode }) {
  const colors = useColors();
  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, { color: colors.textMuted, fontFamily: "Inter_600SemiBold" }]}>{title.toUpperCase()}</Text>
      <View style={[styles.sectionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        {children}
      </View>
    </View>
  );
}

// ── helpers ────────────────────────────────────────────────────────────────────
async function getTokenAndDomain(): Promise<{ token: string | null; domain: string }> {
  const AsyncStorage = (await import("@react-native-async-storage/async-storage")).default;
  const token  = await AsyncStorage.getItem("@fp_access").catch(() => null);
  const domain = process.env["EXPO_PUBLIC_DOMAIN"] ?? "";
  return { token, domain };
}

// ── Main Settings Screen ───────────────────────────────────────────────────────
export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { currentUser, verifyPin, conversations, sendMessage } = useApp();

  const [showPinModal,   setShowPinModal]   = useState(false);
  const [pinMode,        setPinMode]        = useState<"create" | "change">("create");
  const [hasPin,         setHasPin]         = useState(false);
  const [hasPinLoaded,   setHasPinLoaded]   = useState(false);
  const [showBroadcast,  setShowBroadcast]  = useState(false);
  const [showWallpaper,  setShowWallpaper]  = useState(false);
  const [showLanguage,   setShowLanguage]   = useState(false);
  const [showReport,     setShowReport]     = useState(false);
  const [twoStepEnabled, setTwoStepEnabled] = useState(false);
  const [soundsOn, setSoundsOn] = useState(true);
  const [wallpaper,      setWallpaper]      = useState("ghana");
  const [language,       setLanguage]       = useState("en");

  // Load persisted wallpaper on mount
  useEffect(() => {
    AsyncStorage.getItem(WALLPAPER_STORAGE_KEY).then(v => { if (v) setWallpaper(v); }).catch(() => {});
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(SOUND_SETTING_KEY).then(v => { if (v !== null) setSoundsOn(v === "true"); }).catch(() => {});
  }, []);

  // Load pin status on mount
  useEffect(() => {
    (async () => {
      const { token, domain } = await getTokenAndDomain();
      if (!token || !domain) return;
      try {
        const res = await fetch(`${apiOrigin(domain)}/api/auth/pin-status`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const body = await res.json() as { hasPin: boolean };
          setHasPin(body.hasPin);
        }
      } catch { /* ignore */ }
      setHasPinLoaded(true);
    })();
  }, []);

  const openPinModal = useCallback((mode: "create" | "change") => {
    setPinMode(mode);
    setShowPinModal(true);
  }, []);

  const createPinApi = useCallback(async (pin: string): Promise<{ ok: boolean; error?: string }> => {
    const { token, domain } = await getTokenAndDomain();
    if (!token || !domain) return { ok: false, error: "Not authenticated" };
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/auth/create-pin`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ pin }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        return { ok: false, error: (body as any).error ?? "Failed to create PIN" };
      }
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error. Please try again." };
    }
  }, []);

  const changePinApi = useCallback(async (currentPin: string, newPin: string): Promise<{ ok: boolean; error?: string }> => {
    const { token, domain } = await getTokenAndDomain();
    if (!token || !domain) return { ok: false, error: "Not authenticated" };
    try {
      const res = await fetch(`${apiOrigin(domain)}/api/auth/change-pin`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPin, newPin }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        return { ok: false, error: (body as any).error ?? "Failed to change PIN" };
      }
      return { ok: true };
    } catch {
      return { ok: false, error: "Network error. Please try again." };
    }
  }, []);

  const handleBroadcast = useCallback((msg: string) => {
    conversations.forEach((c) => sendMessage(c.id, msg));
    Alert.alert("Broadcast Sent", `Message sent to ${conversations.length} contact${conversations.length !== 1 ? "s" : ""}.`);
  }, [conversations, sendMessage]);

  const handleInvite = useCallback(async () => {
    const domain = process.env["EXPO_PUBLIC_DOMAIN"] ?? "";
    const link = `${apiOrigin(domain)}/download`;
    const msg = `Hey! Join me on CharLey — the easy way to send money and chat. Download here: ${link}`;
    try {
      const isAvailable = await Sharing.isAvailableAsync();
      if (isAvailable) {
        await Clipboard.setStringAsync(msg);
        Alert.alert("Link Copied", "Invite link copied to clipboard. Share it with your contacts!");
      } else {
        await Clipboard.setStringAsync(msg);
        Alert.alert("Link Copied", "Invite link copied to clipboard!");
      }
    } catch {
      await Clipboard.setStringAsync(msg);
      Alert.alert("Link Copied", "Invite link copied to clipboard!");
    }
  }, []);

  const toggleSounds = (val: boolean) => {
    setSoundsOn(val);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    void setSoundsEnabled(val);
  };

  const toggleTwoStep = (val: boolean) => {
    setTwoStepEnabled(val);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert(
      val ? "Two-Step Verification Enabled" : "Two-Step Verification Disabled",
      val
        ? "You will now be asked for an extra code when logging in."
        : "Two-step verification has been turned off.",
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text, fontFamily: "Inter_700Bold" }]}>Settings</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]} showsVerticalScrollIndicator={false}>

        {/* Account info pill */}
        {currentUser && (
          <View style={[styles.profilePill, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.avatarCircle, { backgroundColor: colors.primary + "25" }]}>
              <Text style={[styles.avatarInitial, { color: colors.primary, fontFamily: "Inter_700Bold" }]}>
                {currentUser.name?.[0]?.toUpperCase() ?? "?"}
              </Text>
            </View>
            <View>
              <Text style={[styles.profileName, { color: colors.text, fontFamily: "Inter_700Bold" }]}>{currentUser.name}</Text>
              <Text style={[styles.profilePhone, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>{currentUser.phone}</Text>
            </View>
          </View>
        )}

        {/* Account & Security */}
        <SettingsSection title="Account & Security">
          {/* PIN row — changes label/action based on whether PIN is set */}
          {hasPinLoaded ? (
            hasPin ? (
              /* PIN exists: show row with "Change PIN" sub-action */
              <View style={[styles.row, { borderBottomColor: colors.border }]}>
                <View style={[styles.rowIcon, { backgroundColor: "#12D9A0" }]}>
                  <Feather name="lock" size={17} color="#fff" />
                </View>
                <View style={styles.rowText}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Text style={[styles.rowLabel, { color: colors.text, fontFamily: "Inter_500Medium" }]}>Send PIN</Text>
                    <View style={[styles.pinBadge, { backgroundColor: "#22C55E20" }]}>
                      <Feather name="check-circle" size={11} color="#22C55E" />
                      <Text style={[styles.pinBadgeText, { color: "#22C55E", fontFamily: "Inter_600SemiBold" }]}>Set</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => openPinModal("change")} activeOpacity={0.7}>
                    <Text style={[styles.rowSub, { color: colors.primary, fontFamily: "Inter_500Medium" }]}>
                      Change PIN →
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              /* No PIN: prompt to create */
              <SettingsRow icon="lock" iconBg="#12D9A0" label="Create Send PIN"
                sub="Set a 4-digit PIN to secure your payments"
                onPress={() => openPinModal("create")} />
            )
          ) : (
            <View style={[styles.row, { borderBottomColor: colors.border }]}>
              <View style={[styles.rowIcon, { backgroundColor: "#12D9A0" }]}><Feather name="lock" size={17} color="#fff" /></View>
              <Text style={[styles.rowSub, { color: colors.textMuted, fontFamily: "Inter_400Regular" }]}>Loading…</Text>
            </View>
          )}
          <SettingsRow icon="shield" iconBg="#0EA5E9" label="Two-Step Verification"
            sub={twoStepEnabled ? "Enabled" : "Disabled"}
            rightElement={
              <Switch value={twoStepEnabled} onValueChange={toggleTwoStep}
                trackColor={{ false: colors.border, true: colors.primary + "88" }}
                thumbColor={twoStepEnabled ? colors.primary : colors.textMuted} />
            }
          />
          <SettingsRow icon="key" iconBg="#F59E0B" label="Reset Password"
            sub="Change your login PIN via SMS verification"
            onPress={() => router.push("/forgot-password" as any)} isLast />
        </SettingsSection>

        {/* Messaging */}
        <SettingsSection title="Messaging">
          <SettingsRow icon="radio" iconBg="#22C55E" label="Broadcast Message"
            sub="Send a message to all your contacts"
            onPress={() => setShowBroadcast(true)} />
          <SettingsRow icon="image" iconBg="#EC4899" label="Chat Wallpaper"
            sub={WALLPAPERS.find(w => w.id === wallpaper)?.label ?? "Default"}
            onPress={() => setShowWallpaper(true)} />
          <SettingsRow icon="volume-2" iconBg="#8B5CF6" label="Message Sounds"
            sub={soundsOn ? "On" : "Off"}
            rightElement={
              <Switch value={soundsOn} onValueChange={toggleSounds}
                trackColor={{ false: colors.border, true: colors.primary + "88" }}
                thumbColor={soundsOn ? colors.primary : colors.textMuted} />
            }
            isLast />
        </SettingsSection>

        {/* Preferences */}
        <SettingsSection title="Preferences">
          <SettingsRow icon="globe" iconBg="#06B6D4" label="App Language"
            sub={LANGUAGES.find(l => l.code === language)?.label ?? "English"}
            onPress={() => setShowLanguage(true)} isLast />
        </SettingsSection>

        {/* More */}
        <SettingsSection title="More">
          <SettingsRow icon="activity" iconBg="#F59E0B" label="Activities"
            sub="View your transfers, deals and pay links"
            onPress={() => router.push("/(tabs)/activities" as any)} />
          <SettingsRow icon="flag" iconBg="#EF4444" label="Report an Account"
            sub="Flag suspicious or harmful accounts"
            onPress={() => setShowReport(true)} />
          <SettingsRow icon="user-plus" iconBg="#10B981" label="Invite a Contact"
            sub="Share CharLey with friends & earn rewards"
            onPress={handleInvite} isLast />
        </SettingsSection>

      </ScrollView>

      {/* Modals */}
      <PinManagementModal
        visible={showPinModal}
        onClose={() => setShowPinModal(false)}
        mode={pinMode}
        verifyPin={verifyPin}
        createPinApi={createPinApi}
        changePinApi={changePinApi}
        onPinSet={() => setHasPin(true)}
      />
      <BroadcastModal
        visible={showBroadcast}
        onClose={() => setShowBroadcast(false)}
        onSend={handleBroadcast}
      />
      <WallpaperModal
        visible={showWallpaper}
        onClose={() => setShowWallpaper(false)}
        current={wallpaper}
        onSelect={(id) => {
          setWallpaper(id);
          AsyncStorage.setItem(WALLPAPER_STORAGE_KEY, id).catch(() => {});
        }}
      />
      <LanguageModal
        visible={showLanguage}
        onClose={() => setShowLanguage(false)}
        current={language}
        onSelect={setLanguage}
      />
      <ReportModal
        visible={showReport}
        onClose={() => setShowReport(false)}
      />
    </View>
  );
}

// ── Modal Styles (ms) ──────────────────────────────────────────────────────────
const ms = StyleSheet.create({
  backdrop:       { flex: 1, backgroundColor: "rgba(0,0,0,0.55)", alignItems: "center", justifyContent: "center" },
  card:           { width: 300, borderRadius: 24, padding: 28, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.3, shadowRadius: 20, elevation: 20 },
  sheet:          { width: "100%", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, paddingTop: 12, position: "absolute", bottom: 0, shadowColor: "#000", shadowOpacity: 0.25, shadowRadius: 20, elevation: 20 },
  sheetHandle:    { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 16 },
  sheetTitle:     { fontSize: 18, marginBottom: 6, textAlign: "center" },
  sheetSub:       { fontSize: 13, marginBottom: 16, textAlign: "center", lineHeight: 18 },
  iconWrap:       { width: 60, height: 60, borderRadius: 30, alignItems: "center", justifyContent: "center", marginBottom: 14 },
  title:          { fontSize: 18, marginBottom: 4 },
  sub:            { fontSize: 13, marginBottom: 20, textAlign: "center" },
  hiddenInput:    { position: "absolute", opacity: 0, width: 1, height: 1 },
  dots:           { flexDirection: "row", gap: 18, marginVertical: 20 },
  dot:            { width: 18, height: 18, borderRadius: 9 } as any,
  dot2:           { width: 8, height: 8, borderRadius: 4 } as any,
  progress:       { flexDirection: "row", gap: 8, marginTop: 4 },
  errText:        { color: "#EF4444", fontSize: 13, marginBottom: 4 },
  hint:           { fontSize: 12, marginBottom: 4 },
  cancel:         { marginTop: 14, paddingVertical: 8, paddingHorizontal: 20, alignSelf: "center" },
  broadcastInput: { borderWidth: 1, borderRadius: 14, padding: 14, fontSize: 14, minHeight: 100, textAlignVertical: "top", marginBottom: 4 },
  sendBtn:        { flexDirection: "row", alignItems: "center", justifyContent: "center", borderRadius: 14, paddingVertical: 14, paddingHorizontal: 20, width: "100%" },
  sendBtnText:    { fontSize: 15 },
  wallpaperGrid:  { flexDirection: "row", flexWrap: "wrap", gap: 10, marginVertical: 8 },
  wallpaperSwatch:{ width: "22%", aspectRatio: 1, borderRadius: 14, alignItems: "center", justifyContent: "center", gap: 4 },
  wallpaperLabel: { fontSize: 10, textAlign: "center" },
  langRow:        { flexDirection: "row", alignItems: "center", paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  langLabel:      { fontSize: 15, marginBottom: 2 },
  langNative:     { fontSize: 12 },
  reportRow:      { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 8 },
  reportText:     { fontSize: 14 },
  successRing:    { width: 80, height: 80, borderRadius: 40, borderWidth: 3, alignItems: "center", justifyContent: "center", marginBottom: 4 },
  doneBtn:        { borderRadius: 14, paddingVertical: 14, paddingHorizontal: 40, marginTop: 20, alignItems: "center" },
  doneBtnText:    { color: "#fff", fontSize: 16 },
});

// ── Screen Styles ──────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  root:         { flex: 1 },
  header:       { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn:      { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  headerTitle:  { flex: 1, fontSize: 18, textAlign: "center" },
  scroll:       { paddingHorizontal: 16, paddingTop: 16 },
  profilePill:  { flexDirection: "row", alignItems: "center", gap: 14, padding: 16, borderRadius: 16, marginBottom: 20, borderWidth: 1 },
  avatarCircle: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  avatarInitial:{ fontSize: 20 },
  profileName:  { fontSize: 16, marginBottom: 2 },
  profilePhone: { fontSize: 13 },
  section:      { marginBottom: 20 },
  sectionTitle: { fontSize: 11, letterSpacing: 0.8, marginBottom: 8, marginLeft: 4 },
  sectionCard:  { borderRadius: 18, borderWidth: 1, overflow: "hidden" },
  row:          { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 15, gap: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  rowIcon:      { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  rowText:      { flex: 1 },
  rowLabel:     { fontSize: 15, marginBottom: 1 },
  rowSub:       { fontSize: 12, lineHeight: 16 },
  pinBadge:     { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 } as any,
  pinBadgeText: { fontSize: 10 },
});
