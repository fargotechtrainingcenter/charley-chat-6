import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { Platform, TextInput } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { setBaseUrl } from "@workspace/api-client-react";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider, useApp } from "@/context/AppContext";
import { apiOrigin } from "@/lib/api-base";

// Remove Android underline on every TextInput in the app
if ((TextInput as any).defaultProps === undefined) {
  (TextInput as any).defaultProps = {};
}
(TextInput as any).defaultProps.underlineColorAndroid = "transparent";

// Configure API base URL at module load time (before any fetch calls)
const _apiDomain = process.env.EXPO_PUBLIC_DOMAIN;
if (_apiDomain) {
  setBaseUrl(apiOrigin(_apiDomain));
}

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  const { isAuthenticated, authLoading } = useApp();
  const router = useRouter();
  const segments = useSegments();

  useEffect(() => {
    if (authLoading) return;
    const inTabsGroup = segments[0] === "(tabs)";
    const inAuthScreen = segments[0] === "welcome" || segments[0] === "login" || segments[0] === "register";

    if (!isAuthenticated && inTabsGroup) {
      router.replace("/welcome");
    } else if (isAuthenticated && inAuthScreen) {
      router.replace("/(tabs)");
    }
  }, [isAuthenticated, authLoading, segments]);

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="welcome" />
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="chat/[id]" />
      <Stack.Screen name="story/[id]" />
      <Stack.Screen name="status/create" />
      <Stack.Screen name="paylink/[code]" />
      <Stack.Screen name="forgot-password" />
      <Stack.Screen name="call-history" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="settings" />
      <Stack.Screen name="kyc-verify" />
      <Stack.Screen name="movie/[id]" />
      <Stack.Screen name="my-list" />
      <Stack.Screen name="+not-found" />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  useEffect(() => {
    if (Platform.OS === "web") {
      const style = document.createElement("style");
      style.textContent = `
        html, body {
          width: 100%;
          max-width: 100vw;
          overflow-x: hidden;
          margin: 0;
          padding: 0;
          -webkit-text-size-adjust: 100%;
          box-sizing: border-box;
        }
        *, *::before, *::after {
          box-sizing: inherit;
        }
        #root, [data-rnwc] {
          width: 100%;
          max-width: 100vw;
          overflow-x: hidden;
        }
        input:focus, textarea:focus {
          outline: none !important;
          box-shadow: none !important;
        }
        input, textarea {
          background-color: transparent;
          -webkit-appearance: none;
        }
      `;
      document.head.appendChild(style);
    }
  }, []);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AppProvider>
                <RootLayoutNav />
              </AppProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
