import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useLocalSearchParams, useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Animated,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp, type Story } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useGetStoryViews } from "@workspace/api-client-react";

const STORY_DURATION_IMAGE = 6000;
const STORY_DURATION_VIDEO = 15000;
const QUICK_EMOJIS = ["❤️", "😂", "😮", "😢", "👍", "🙏"];

function storyDuration(s: Story) {
  return s.storyType === "video" ? STORY_DURATION_VIDEO : STORY_DURATION_IMAGE;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

// ── Viewers bottom sheet ──────────────────────────────────────────────────────

function ViewersSheet({
  storyId,
  visible,
  onClose,
}: {
  storyId: string;
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const { data: viewData } = useGetStoryViews(storyId, {
    query: { enabled: visible && !!storyId, queryKey: ["story-views", storyId] },
  });
  const views = (viewData as any)?.views ?? [];
  const count = (viewData as any)?.viewCount ?? 0;

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose} />
      <View style={[styles.sheet, { backgroundColor: colors.surface }]}>
        <View style={styles.handle} />
        <Text style={[styles.sheetTitle, { color: colors.text }]}>Seen by {count}</Text>
        {views.length === 0 ? (
          <View style={styles.emptyCenter}>
            <Feather name="eye" size={32} color={colors.textMuted} />
            <Text style={[styles.emptyText, { color: colors.textMuted }]}>No views yet</Text>
          </View>
        ) : (
          <ScrollView showsVerticalScrollIndicator={false}>
            {views.map((v: any) => {
              const name = v.fullName ?? v.viewerId?.slice(0, 8) ?? "User";
              return (
                <View key={v.viewerId} style={[styles.viewerRow, { borderBottomColor: colors.border }]}>
                  <View style={[styles.viewerAvatar, { backgroundColor: colors.primary }]}>
                    <Text style={styles.viewerInitials}>{name.slice(0, 2).toUpperCase()}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.viewerName, { color: colors.text }]}>{name}</Text>
                    {v.viewedAt && (
                      <Text style={[styles.viewerTime, { color: colors.textMuted }]}>{timeAgo(v.viewedAt)}</Text>
                    )}
                  </View>
                </View>
              );
            })}
          </ScrollView>
        )}
      </View>
    </Modal>
  );
}

// ── Menu bottom sheet ─────────────────────────────────────────────────────────

function MenuSheet({
  visible,
  isMyStory,
  userName,
  onClose,
  onDelete,
  onMute,
}: {
  visible: boolean;
  isMyStory: boolean;
  userName: string;
  onClose: () => void;
  onDelete: () => void;
  onMute: () => void;
}) {
  const colors = useColors();
  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose} />
      <View style={[styles.sheet, { backgroundColor: colors.surface }]}>
        <View style={styles.handle} />
        {isMyStory ? (
          <>
            <TouchableOpacity style={[styles.menuRow, { borderBottomColor: colors.border }]}
              onPress={() => { onClose(); onDelete(); }} activeOpacity={0.8}>
              <Feather name="trash-2" size={20} color="#E53E3E" />
              <Text style={[styles.menuLabel, { color: "#E53E3E" }]}>Delete Status</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuRow}
              onPress={() => { onClose(); Alert.alert("Forward", "Forwarding coming soon."); }} activeOpacity={0.8}>
              <Feather name="share-2" size={20} color={colors.text} />
              <Text style={[styles.menuLabel, { color: colors.text }]}>Forward</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <TouchableOpacity style={[styles.menuRow, { borderBottomColor: colors.border }]}
              onPress={() => { onClose(); onMute(); }} activeOpacity={0.8}>
              <Feather name="volume-x" size={20} color={colors.text} />
              <Text style={[styles.menuLabel, { color: colors.text }]}>Mute {userName}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.menuRow, { borderBottomColor: colors.border }]}
              onPress={() => { onClose(); Alert.alert("Forward", "Forwarding coming soon."); }} activeOpacity={0.8}>
              <Feather name="share-2" size={20} color={colors.text} />
              <Text style={[styles.menuLabel, { color: colors.text }]}>Forward</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuRow}
              onPress={() => { onClose(); Alert.alert("Report", "This status has been reported."); }} activeOpacity={0.8}>
              <Feather name="flag" size={20} color="#E53E3E" />
              <Text style={[styles.menuLabel, { color: "#E53E3E" }]}>Report</Text>
            </TouchableOpacity>
          </>
        )}
        <View style={{ height: 24 }} />
      </View>
    </Modal>
  );
}

// ── Main viewer ───────────────────────────────────────────────────────────────

export default function StoryViewer() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const appCtx = useApp() as any;
  const { storyGroups, viewStory, reactToStory, removeStoryReaction,
          deleteStory, muteUser, replyToStory } = appCtx;

  // ── Find entry point ──────────────────────────────────────────────────────

  const initGi = useMemo(() => {
    if (!id) return 0;
    const gi = (storyGroups as any[]).findIndex((g: any) => g.stories.some((s: any) => s.id === id));
    return Math.max(gi, 0);
  }, []);

  const initSi = useMemo(() => {
    if (!id) return 0;
    const gi = (storyGroups as any[]).findIndex((g: any) => g.stories.some((s: any) => s.id === id));
    if (gi < 0) return 0;
    return Math.max((storyGroups as any[])[gi]?.stories.findIndex((s: any) => s.id === id) ?? 0, 0);
  }, []);

  const [groupIndex, setGroupIndex] = useState(initGi);
  const [storyIndex, setStoryIndex] = useState(initSi);
  const [paused, setPaused] = useState(false);
  const [showViewers, setShowViewers] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [replySent, setReplySent] = useState(false);

  const progressAnim = useRef(new Animated.Value(0)).current;
  const animRef = useRef<Animated.CompositeAnimation | null>(null);
  const pausedRef = useRef(false);
  useEffect(() => { pausedRef.current = paused; }, [paused]);

  const currentGroup = (storyGroups as any[])[groupIndex];
  const currentStory: Story | undefined = currentGroup?.stories?.[storyIndex];
  const isMyStory: boolean = currentGroup?.isMe ?? false;
  const topPad = Platform.OS === "web" ? 20 : (insets.top || 44);
  const botPad = Platform.OS === "web" ? 20 : (insets.bottom || 20);

  // ── Navigate ──────────────────────────────────────────────────────────────

  const goNext = useCallback(() => {
    const group = (storyGroups as any[])[groupIndex];
    if (group && storyIndex < group.stories.length - 1) {
      setStoryIndex((i) => i + 1);
    } else if (groupIndex < (storyGroups as any[]).length - 1) {
      setGroupIndex((g) => g + 1);
      setStoryIndex(0);
    } else {
      safeGoBack(router);
    }
  }, [storyGroups, groupIndex, storyIndex, router]);

  const goPrev = useCallback(() => {
    if (storyIndex > 0) {
      setStoryIndex((i) => i - 1);
    } else if (groupIndex > 0) {
      const pg = (storyGroups as any[])[groupIndex - 1];
      setGroupIndex((g) => g - 1);
      setStoryIndex(Math.max((pg?.stories?.length ?? 1) - 1, 0));
    }
  }, [storyGroups, groupIndex, storyIndex]);

  // ── Mark viewed ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (!currentStory || isMyStory || currentStory.viewedByMe) return;
    viewStory?.(currentStory.id).catch(() => {});
  }, [currentStory?.id, isMyStory]);

  // ── Progress animation ────────────────────────────────────────────────────

  useEffect(() => {
    if (!currentStory) return;
    progressAnim.setValue(0);
    animRef.current?.stop();
    if (!paused) {
      animRef.current = Animated.timing(progressAnim, {
        toValue: 1,
        duration: storyDuration(currentStory),
        useNativeDriver: false,
      });
      animRef.current.start(({ finished }) => {
        if (finished && !pausedRef.current) goNext();
      });
    }
    return () => { animRef.current?.stop(); };
  }, [currentStory?.id, groupIndex, storyIndex, paused]);

  // ── Action handlers ───────────────────────────────────────────────────────

  const handleReact = async (emoji: string) => {
    if (!currentStory) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      if (currentStory.myReaction === emoji) {
        await removeStoryReaction?.(currentStory.id);
      } else {
        await reactToStory?.(currentStory.id, emoji);
      }
    } catch {}
  };

  const handleSendReply = async () => {
    if (!currentStory || !replyText.trim()) return;
    try {
      await replyToStory?.(currentStory.id, replyText.trim());
      setReplyText("");
      setReplySent(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => setReplySent(false), 2500);
    } catch {
      Alert.alert("Failed", "Could not send reply.");
    }
  };

  const handleDelete = () => {
    if (!currentStory) return;
    Alert.alert("Delete Status", "This status will be permanently deleted.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete", style: "destructive",
        onPress: async () => {
          try { await deleteStory?.(currentStory.id); goNext(); }
          catch { Alert.alert("Failed", "Could not delete status."); }
        },
      },
    ]);
  };

  const handleMute = () => {
    if (!currentGroup) return;
    Alert.alert(`Mute ${currentGroup.userName}?`, "You won't see their status updates anymore.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Mute", style: "destructive",
        onPress: async () => {
          try { await muteUser?.(currentGroup.userId); goNext(); } catch {}
        },
      },
    ]);
  };

  // ── No story fallback ─────────────────────────────────────────────────────

  if (!currentGroup || !currentStory) {
    return (
      <View style={[styles.root, { backgroundColor: "#000" }]}>
        <TouchableOpacity
          style={[styles.closeAbsolute, { top: topPad + 8 }]}
          onPress={() => safeGoBack(router)}
        >
          <Feather name="x" size={24} color="#fff" />
        </TouchableOpacity>
        <View style={styles.centered}>
          <Feather name="eye-off" size={40} color="rgba(255,255,255,0.35)" />
          <Text style={styles.emptyText}>No status to show</Text>
        </View>
      </View>
    );
  }

  const totalStories = currentGroup.stories.length;

  // ── Media render ──────────────────────────────────────────────────────────

  const renderMedia = () => {
    if (currentStory.storyType === "text") {
      return (
        <View style={[styles.textStory, { backgroundColor: currentStory.textBg ?? "#075E54" }]}>
          <Text style={[styles.textContent, { color: currentStory.textColor ?? "#fff" }]}>
            {currentStory.caption}
          </Text>
        </View>
      );
    }
    if (currentStory.mediaUrl) {
      return (
        <View style={styles.mediaWrap}>
          <Image source={{ uri: currentStory.mediaUrl }} style={styles.mediaImg} resizeMode="contain" />
          {currentStory.storyType === "video" && (
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <View style={styles.playCircle}>
                <Feather name="play" size={30} color="#fff" style={{ paddingLeft: 4 }} />
              </View>
            </View>
          )}
          {currentStory.caption ? (
            <View style={styles.captionBadge}>
              <Text style={styles.captionBadgeText}>{currentStory.caption}</Text>
            </View>
          ) : null}
        </View>
      );
    }
    return (
      <View style={[styles.textStory, { backgroundColor: "#1a1a2e" }]}>
        <Feather name="image" size={52} color="rgba(255,255,255,0.25)" />
        <Text style={styles.emptyText}>Media unavailable</Text>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: "#000" }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      {/* Progress bars */}
      <View style={[styles.progressRow, { paddingTop: topPad + 4 }]}>
        {Array.from({ length: totalStories }).map((_, i) => (
          <View key={i} style={[styles.track, { backgroundColor: "rgba(255,255,255,0.35)" }]}>
            <Animated.View
              style={[
                styles.fill,
                {
                  width:
                    i < storyIndex ? "100%"
                    : i === storyIndex
                      ? progressAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] })
                    : "0%",
                },
              ]}
            />
          </View>
        ))}
      </View>

      {/* Header */}
      <View style={[styles.header, { top: topPad + 20 }]}>
        <View style={styles.headerLeft}>
          <View style={[styles.avatar, { backgroundColor: currentGroup.userColor }]}>
            {currentGroup.userAvatarUrl
              ? <Image source={{ uri: currentGroup.userAvatarUrl }} style={styles.avatarImg} />
              : <Text style={styles.avatarInitials}>{currentGroup.userInitials}</Text>
            }
          </View>
          <View style={{ marginLeft: 10 }}>
            <Text style={styles.headerName}>{currentGroup.userName}</Text>
            <Text style={styles.headerTime}>{timeAgo(currentStory.createdAt)}</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity
            style={styles.iconBtn}
            onPress={() => { setShowMenu(true); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
          >
            <Feather name="more-vertical" size={22} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={() => safeGoBack(router)}>
            <Feather name="x" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Media area + tap zones */}
      <Pressable
        style={styles.mediaArea}
        onLongPress={() => {
          setPaused(true);
          animRef.current?.stop();
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }}
        onPressOut={() => setPaused(false)}
      >
        {renderMedia()}
        <Pressable style={styles.tapLeft} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); goPrev(); }} />
        <Pressable style={styles.tapRight} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); goNext(); }} />
      </Pressable>

      {/* Bottom bar */}
      {isMyStory ? (
        <View style={[styles.ownBar, { paddingBottom: botPad + 8 }]}>
          <TouchableOpacity
            style={styles.seenBtn}
            onPress={() => { setShowViewers(true); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
            activeOpacity={0.8}
          >
            <Feather name="eye" size={16} color="#fff" />
            <Text style={styles.seenText}>
              {currentStory.viewCount} {currentStory.viewCount === 1 ? "view" : "views"}
            </Text>
            <Feather name="chevron-up" size={14} color="rgba(255,255,255,0.6)" />
          </TouchableOpacity>
        </View>
      ) : (
        <View style={[styles.othersBar, { paddingBottom: botPad + 8 }]}>
          <View style={styles.emojiRow}>
            {QUICK_EMOJIS.map((e) => (
              <TouchableOpacity
                key={e}
                style={[styles.emojiBtn, currentStory.myReaction === e && styles.emojiBtnActive]}
                onPress={() => handleReact(e)}
                activeOpacity={0.75}
              >
                <Text style={styles.emojiGlyph}>{e}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.replyRow}>
            <TextInput
              style={styles.replyInput}
              placeholder={replySent ? "✓ Reply sent!" : `Reply to ${currentGroup.userName}…`}
              placeholderTextColor={replySent ? "#4CAF50" : "rgba(255,255,255,0.45)"}
              value={replyText}
              onChangeText={setReplyText}
              onSubmitEditing={handleSendReply}
              returnKeyType="send"
            />
            <TouchableOpacity
              style={[styles.sendBtn, { opacity: replyText.trim() ? 1 : 0.35 }]}
              onPress={handleSendReply}
              disabled={!replyText.trim()}
              activeOpacity={0.8}
            >
              <Feather name="send" size={17} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>
      )}

      <ViewersSheet storyId={currentStory.id} visible={showViewers} onClose={() => setShowViewers(false)} />
      <MenuSheet
        visible={showMenu}
        isMyStory={isMyStory}
        userName={currentGroup.userName}
        onClose={() => setShowMenu(false)}
        onDelete={handleDelete}
        onMute={handleMute}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  progressRow: {
    position: "absolute", left: 0, right: 0, zIndex: 20,
    flexDirection: "row", gap: 3, paddingHorizontal: 10, paddingBottom: 6,
  },
  track: { flex: 1, height: 2.5, borderRadius: 2, overflow: "hidden" },
  fill: { height: "100%", backgroundColor: "#fff", borderRadius: 2 },

  header: {
    position: "absolute", left: 0, right: 0, zIndex: 20,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 14,
  },
  headerLeft: { flexDirection: "row", alignItems: "center", flex: 1 },
  headerRight: { flexDirection: "row", gap: 4 },
  avatar: {
    width: 38, height: 38, borderRadius: 19,
    alignItems: "center", justifyContent: "center",
    borderWidth: 2, borderColor: "rgba(255,255,255,0.5)", overflow: "hidden",
  },
  avatarImg: { width: 38, height: 38, borderRadius: 19 },
  avatarInitials: { color: "#fff", fontSize: 13, fontWeight: "700" },
  headerName: { color: "#fff", fontSize: 14, fontWeight: "700", fontFamily: "Inter_700Bold" },
  headerTime: { color: "rgba(255,255,255,0.65)", fontSize: 11, marginTop: 1 },
  iconBtn: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },

  mediaArea: { flex: 1, position: "relative" },
  mediaWrap: { flex: 1, backgroundColor: "#000" },
  mediaImg: { width: "100%", height: "100%" },
  textStory: { flex: 1, alignItems: "center", justifyContent: "center", padding: 36 },
  textContent: { fontSize: 26, fontWeight: "700", fontFamily: "Inter_700Bold", textAlign: "center", lineHeight: 34 },

  playCircle: {
    position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
    alignItems: "center", justifyContent: "center",
  },
  captionBadge: {
    position: "absolute", bottom: 8, left: 24, right: 24, alignItems: "center",
  },
  captionBadgeText: {
    color: "#fff", fontSize: 14, textAlign: "center",
    backgroundColor: "rgba(0,0,0,0.5)", borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 5, overflow: "hidden",
  },

  tapLeft: { position: "absolute", left: 0, top: 0, bottom: 0, width: "33%" },
  tapRight: { position: "absolute", right: 0, top: 0, bottom: 0, width: "33%" },

  ownBar: {
    paddingHorizontal: 20, paddingTop: 12, backgroundColor: "rgba(0,0,0,0.35)",
    alignItems: "center",
  },
  seenBtn: {
    flexDirection: "row", alignItems: "center", gap: 8,
    paddingHorizontal: 24, paddingVertical: 11,
    borderRadius: 24, backgroundColor: "rgba(255,255,255,0.13)",
    borderWidth: 1, borderColor: "rgba(255,255,255,0.2)",
  },
  seenText: { color: "#fff", fontSize: 14, fontWeight: "600" },

  othersBar: { paddingHorizontal: 12, paddingTop: 8, gap: 8, backgroundColor: "rgba(0,0,0,0.4)" },
  emojiRow: { flexDirection: "row", justifyContent: "center", gap: 8 },
  emojiBtn: {
    width: 42, height: 42, borderRadius: 21,
    alignItems: "center", justifyContent: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
  },
  emojiBtnActive: {
    backgroundColor: "rgba(255,255,255,0.28)",
    borderWidth: 1.5, borderColor: "#fff",
  },
  emojiGlyph: { fontSize: 22 },

  replyRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  replyInput: {
    flex: 1, backgroundColor: "rgba(255,255,255,0.11)",
    borderRadius: 24, paddingHorizontal: 16, paddingVertical: 10,
    color: "#fff", fontSize: 14,
    borderWidth: 1, borderColor: "rgba(255,255,255,0.2)",
  },
  sendBtn: {
    width: 42, height: 42, borderRadius: 21,
    alignItems: "center", justifyContent: "center",
    backgroundColor: "rgba(0,168,132,0.85)",
  },

  closeAbsolute: { position: "absolute", right: 16, zIndex: 30, width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyText: { color: "rgba(255,255,255,0.4)", fontSize: 15 },

  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)" },
  sheet: {
    borderTopLeftRadius: 22, borderTopRightRadius: 22,
    paddingTop: 12, paddingHorizontal: 20, minHeight: 220,
  },
  handle: {
    width: 36, height: 4, borderRadius: 2,
    backgroundColor: "rgba(128,128,128,0.35)",
    alignSelf: "center", marginBottom: 14,
  },
  sheetTitle: { fontSize: 17, fontWeight: "700", fontFamily: "Inter_700Bold", marginBottom: 16 },

  viewerRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  viewerAvatar: {
    width: 42, height: 42, borderRadius: 21,
    alignItems: "center", justifyContent: "center",
  },
  viewerInitials: { color: "#fff", fontSize: 13, fontWeight: "700" },
  viewerName: { fontSize: 15, fontWeight: "600" },
  viewerTime: { fontSize: 12, marginTop: 2 },
  emptyCenter: { alignItems: "center", paddingTop: 40, gap: 12 },

  menuRow: {
    flexDirection: "row", alignItems: "center", gap: 14,
    paddingVertical: 16, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  menuLabel: { fontSize: 16, fontWeight: "500" },
});
