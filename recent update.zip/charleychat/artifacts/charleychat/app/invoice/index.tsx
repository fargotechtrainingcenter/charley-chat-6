import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { safeGoBack } from "@/lib/navigation";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { customFetch } from "@workspace/api-client-react";

// ─── Types ─────────────────────────────────────────────────────────────────────
interface InvoiceItem { description: string; quantity: number; unitPricePesewas: number; }
interface Invoice {
  id: string; invoiceNumber: string; clientName: string; clientEmail?: string;
  totalPesewas: number; status: string; isPdfGenerated: boolean;
  generationFeePaidAt?: string; dueDate?: string; notes?: string;
  items: InvoiceItem[]; createdAt: string;
}

const STATUS_COLOR: Record<string, string> = {
  draft: "#7B6FA3", unpaid: "#F59E0B", paid: "#10B981", overdue: "#EF4444", cancelled: "#6B7280",
};

// ─── Screen ─────────────────────────────────────────────────────────────────────
export default function InvoiceScreen() {
  const router = useRouter();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { balance } = useApp();

  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState<Invoice | null>(null);
  const [payingFee, setPayingFee] = useState(false);

  // ─── Form state ─────────────────────────────────────────────────────────────
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [issueDate, setIssueDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = useState("");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState<InvoiceItem[]>([{ description: "", quantity: 1, unitPricePesewas: 0 }]);
  const [creating, setCreating] = useState(false);

  // ─── Load invoices ───────────────────────────────────────────────────────────
  const loadInvoices = useCallback(async () => {
    setLoading(true);
    try {
      const data = await customFetch<{ items: Invoice[] }>("/api/invoices");
      setInvoices((data as { items: Invoice[] }).items ?? []);
    } catch { /* silent */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadInvoices(); }, [loadInvoices]);

  // ─── Item helpers ────────────────────────────────────────────────────────────
  const updateItem = (idx: number, field: keyof InvoiceItem, val: string) => {
    setItems((prev) => prev.map((it, i) => {
      if (i !== idx) return it;
      if (field === "description") return { ...it, description: val };
      if (field === "quantity") return { ...it, quantity: parseInt(val) || 0 };
      if (field === "unitPricePesewas") return { ...it, unitPricePesewas: Math.round((parseFloat(val) || 0) * 100) };
      return it;
    }));
  };

  const totalPesewas = items.reduce((sum, it) => sum + it.quantity * it.unitPricePesewas, 0);

  // ─── Create invoice ──────────────────────────────────────────────────────────
  const handleCreate = async () => {
    if (!clientName.trim()) { Alert.alert("Required", "Enter client name."); return; }
    if (!issueDate.trim()) { Alert.alert("Required", "Enter issue date."); return; }
    if (!dueDate.trim()) { Alert.alert("Required", "Enter due date."); return; }
    if (items.some((it) => !it.description.trim() || it.quantity <= 0 || it.unitPricePesewas <= 0)) {
      Alert.alert("Required", "All line items must have a description, quantity > 0, and price > 0.");
      return;
    }
    setCreating(true);
    try {
      const body = {
        clientName: clientName.trim(),
        clientEmail: clientEmail.trim() || undefined,
        issueDate: issueDate.trim(),
        dueDate: dueDate.trim(),
        notes: notes.trim() || undefined,
        items: items.map((it) => ({ description: it.description.trim(), quantity: it.quantity, unitPricePesewas: it.unitPricePesewas })),
      };
      await customFetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      setShowCreate(false);
      resetForm();
      await loadInvoices();
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not create invoice.");
    } finally {
      setCreating(false);
    }
  };

  const resetForm = () => {
    setClientName(""); setClientEmail("");
    setIssueDate(new Date().toISOString().slice(0, 10));
    setDueDate(""); setNotes("");
    setItems([{ description: "", quantity: 1, unitPricePesewas: 0 }]);
  };

  // ─── Pay generation fee ──────────────────────────────────────────────────────
  const handlePayFee = async (inv: Invoice) => {
    const FEE = 500; // GHS 5
    if ((balance ?? 0) < FEE) {
      Alert.alert("Insufficient balance", "You need GH₵ 5.00 in your wallet to generate a PDF.");
      return;
    }
    Alert.alert("Generate PDF", "Pay GH₵ 5.00 to generate a professional PDF invoice?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Pay GH₵ 5.00", onPress: async () => {
          setPayingFee(true);
          try {
            await customFetch(`/api/invoices/${inv.id}/pay-fee`, { method: "POST" });
            await loadInvoices();
            const updated = invoices.find((i) => i.id === inv.id);
            setShowDetail(updated ? { ...updated, generationFeePaidAt: new Date().toISOString() } : null);
            Alert.alert("Success!", "PDF invoice generated. Download from the invoice detail.");
          } catch (e: any) {
            Alert.alert("Error", e?.message ?? "Payment failed.");
          } finally {
            setPayingFee(false);
          }
        },
      },
    ]);
  };

  // ─── Mark paid ────────────────────────────────────────────────────────────────
  const handleMarkPaid = async (inv: Invoice) => {
    try {
      await customFetch(`/api/invoices/${inv.id}/mark-paid`, { method: "PATCH" });
      await loadInvoices();
      setShowDetail(null);
    } catch (e: any) {
      Alert.alert("Error", e?.message ?? "Could not update invoice.");
    }
  };

  // ─── Render invoice card ──────────────────────────────────────────────────────
  const renderInvoice = ({ item }: { item: Invoice }) => {
    const statusColor = STATUS_COLOR[item.status] ?? "#7B6FA3";
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
        onPress={() => setShowDetail(item)}
        activeOpacity={0.8}
      >
        <View style={styles.cardLeft}>
          <View style={[styles.invoiceIcon, { backgroundColor: colors.primary + "22" }]}>
            <Feather name="file-text" size={20} color={colors.primary} />
          </View>
          <View>
            <Text style={[styles.invoiceNum, { color: colors.primary }]}>{item.invoiceNumber}</Text>
            <Text style={[styles.invoiceClient, { color: colors.text }]}>{item.clientName}</Text>
            <Text style={[styles.invoiceDate, { color: colors.textMuted }]}>
              {new Date(item.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
            </Text>
          </View>
        </View>
        <View style={styles.cardRight}>
          <Text style={[styles.invoiceAmount, { color: colors.text }]}>{fmtGHS(item.totalPesewas)}</Text>
          <View style={[styles.badge, { backgroundColor: statusColor + "22" }]}>
            <Text style={[styles.badgeText, { color: statusColor }]}>{item.status}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => safeGoBack(router)} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Invoices</Text>
        <TouchableOpacity style={[styles.newBtn, { backgroundColor: colors.primary }]} onPress={() => setShowCreate(true)}>
          <Feather name="plus" size={16} color="#fff" />
          <Text style={styles.newBtnText}>New</Text>
        </TouchableOpacity>
      </View>

      {/* List */}
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} size="large" /></View>
      ) : invoices.length === 0 ? (
        <View style={styles.center}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.primary + "22" }]}>
            <Feather name="file-text" size={36} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No invoices yet</Text>
          <Text style={[styles.emptyDesc, { color: colors.textMuted }]}>Create professional invoices and get paid faster.</Text>
          <TouchableOpacity style={[styles.createBtn, { backgroundColor: colors.primary }]} onPress={() => setShowCreate(true)}>
            <Text style={styles.createBtnText}>Create Invoice</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={invoices}
          keyExtractor={(i) => i.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          renderItem={renderInvoice}
        />
      )}

      {/* Create Invoice Modal */}
      <Modal visible={showCreate} animationType="slide" transparent>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.modalOverlay}>
          <View style={[styles.sheet, { backgroundColor: colors.surface }]}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, { color: colors.text }]}>New Invoice</Text>
              <TouchableOpacity onPress={() => { setShowCreate(false); resetForm(); }}>
                <Feather name="x" size={22} color={colors.textMuted} />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: 0 }}>
              {/* Client info */}
              <Text style={[styles.section, { color: colors.textMuted }]}>CLIENT INFO</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                value={clientName} onChangeText={setClientName}
                placeholder="Client Name *" placeholderTextColor={colors.textMuted}
              />
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                value={clientEmail} onChangeText={setClientEmail}
                placeholder="Client Email (optional)" placeholderTextColor={colors.textMuted}
                keyboardType="email-address" autoCapitalize="none"
              />
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                value={issueDate} onChangeText={setIssueDate}
                placeholder="Issue Date (YYYY-MM-DD) *" placeholderTextColor={colors.textMuted}
              />
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border }]}
                value={dueDate} onChangeText={setDueDate}
                placeholder="Due Date (YYYY-MM-DD) *" placeholderTextColor={colors.textMuted}
              />

              {/* Line items */}
              <Text style={[styles.section, { color: colors.textMuted }]}>LINE ITEMS</Text>
              {items.map((item, idx) => (
                <View key={idx} style={[styles.lineItem, { backgroundColor: colors.background, borderColor: colors.border }]}>
                  <View style={styles.lineItemRow}>
                    <TextInput
                      style={[styles.lineInput, { color: colors.text, flex: 1 }]}
                      value={item.description} onChangeText={(v) => updateItem(idx, "description", v)}
                      placeholder="Item description" placeholderTextColor={colors.textMuted}
                    />
                    {items.length > 1 && (
                      <TouchableOpacity onPress={() => setItems((p) => p.filter((_, i) => i !== idx))}>
                        <Feather name="trash-2" size={16} color="#EF4444" />
                      </TouchableOpacity>
                    )}
                  </View>
                  <View style={styles.lineItemNums}>
                    <View style={styles.lineNumField}>
                      <Text style={[styles.lineNumLabel, { color: colors.textMuted }]}>Qty</Text>
                      <TextInput
                        style={[styles.lineNumInput, { color: colors.text, borderColor: colors.border }]}
                        value={item.quantity.toString()} onChangeText={(v) => updateItem(idx, "quantity", v)}
                        keyboardType="number-pad"
                      />
                    </View>
                    <View style={[styles.lineNumField, { flex: 1 }]}>
                      <Text style={[styles.lineNumLabel, { color: colors.textMuted }]}>Unit Price (GHS)</Text>
                      <TextInput
                        style={[styles.lineNumInput, { color: colors.text, borderColor: colors.border }]}
                        value={item.unitPricePesewas ? (item.unitPricePesewas / 100).toFixed(2) : ""}
                        onChangeText={(v) => updateItem(idx, "unitPricePesewas", v)}
                        keyboardType="decimal-pad" placeholder="0.00"
                        placeholderTextColor={colors.textMuted}
                      />
                    </View>
                    <View style={styles.lineNumField}>
                      <Text style={[styles.lineNumLabel, { color: colors.textMuted }]}>Total</Text>
                      <Text style={[styles.lineTotal, { color: colors.primary }]}>
                        {fmtGHS(item.quantity * item.unitPricePesewas)}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}

              <TouchableOpacity
                style={[styles.addItemBtn, { borderColor: colors.primary }]}
                onPress={() => setItems((p) => [...p, { description: "", quantity: 1, unitPricePesewas: 0 }])}
              >
                <Feather name="plus" size={14} color={colors.primary} />
                <Text style={[styles.addItemText, { color: colors.primary }]}>Add Line Item</Text>
              </TouchableOpacity>

              {/* Notes */}
              <Text style={[styles.section, { color: colors.textMuted }]}>NOTES</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.background, color: colors.text, borderColor: colors.border, height: 72, textAlignVertical: "top" }]}
                value={notes} onChangeText={setNotes}
                placeholder="Payment terms, bank details, etc." placeholderTextColor={colors.textMuted}
                multiline
              />

              {/* Total */}
              <View style={[styles.totalRow, { borderColor: colors.border }]}>
                <Text style={[styles.totalLabel, { color: colors.textMuted }]}>Invoice Total</Text>
                <Text style={[styles.totalValue, { color: colors.text }]}>{fmtGHS(totalPesewas)}</Text>
              </View>
              <Text style={[styles.feeNote, { color: colors.textMuted }]}>
                GH₵ 5.00 fee to generate a professional PDF (charged separately)
              </Text>

              <View style={styles.sheetActions}>
                <TouchableOpacity
                  style={[styles.btn, styles.btnCancel, { borderColor: colors.border }]}
                  onPress={() => { setShowCreate(false); resetForm(); }}
                >
                  <Text style={[styles.btnText, { color: colors.textMuted }]}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.btn, { backgroundColor: colors.primary }]}
                  onPress={handleCreate} disabled={creating}
                >
                  {creating
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={[styles.btnText, { color: "#fff" }]}>Create Invoice</Text>}
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* Invoice Detail Modal */}
      <Modal visible={!!showDetail} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.sheet, styles.sheetTall, { backgroundColor: colors.surface }]}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, { color: colors.text }]}>{showDetail?.invoiceNumber}</Text>
              <TouchableOpacity onPress={() => setShowDetail(null)}>
                <Feather name="x" size={22} color={colors.textMuted} />
              </TouchableOpacity>
            </View>
            {showDetail && (
              <ScrollView showsVerticalScrollIndicator={false}>
                {/* Status badge */}
                <View style={styles.detailStatus}>
                  <View style={[styles.badge, { backgroundColor: (STATUS_COLOR[showDetail.status] ?? "#7B6FA3") + "22" }]}>
                    <Text style={[styles.badgeText, { color: STATUS_COLOR[showDetail.status] ?? "#7B6FA3", fontSize: 13 }]}>
                      {showDetail.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                {/* Client info */}
                <View style={[styles.detailCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
                  <DetailRow label="Client" value={showDetail.clientName} colors={colors} />
                  {showDetail.clientEmail && <DetailRow label="Email" value={showDetail.clientEmail} colors={colors} />}
                  {showDetail.dueDate && <DetailRow label="Due Date" value={showDetail.dueDate} colors={colors} />}
                </View>

                {/* Items */}
                <Text style={[styles.section, { color: colors.textMuted }]}>LINE ITEMS</Text>
                {showDetail.items?.map((it, i) => (
                  <View key={i} style={[styles.detailCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
                    <Text style={[styles.itemDesc, { color: colors.text }]}>{it.description}</Text>
                    <View style={styles.itemRow}>
                      <Text style={[styles.itemMeta, { color: colors.textMuted }]}>{it.quantity} × {fmtGHS(it.unitPricePesewas)}</Text>
                      <Text style={[styles.itemTotal, { color: colors.primary }]}>{fmtGHS(it.quantity * it.unitPricePesewas)}</Text>
                    </View>
                  </View>
                ))}

                <View style={[styles.totalRow, { borderColor: colors.border }]}>
                  <Text style={[styles.totalLabel, { color: colors.textMuted }]}>Total</Text>
                  <Text style={[styles.totalValue, { color: colors.text }]}>{fmtGHS(showDetail.totalPesewas)}</Text>
                </View>

                {showDetail.notes && (
                  <>
                    <Text style={[styles.section, { color: colors.textMuted }]}>NOTES</Text>
                    <Text style={[styles.notesText, { color: colors.text }]}>{showDetail.notes}</Text>
                  </>
                )}

                {/* PDF section */}
                <View style={[styles.pdfCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
                  {showDetail.isPdfGenerated ? (
                    <>
                      <View style={styles.pdfRow}>
                        <Feather name="check-circle" size={18} color="#10B981" />
                        <Text style={[styles.pdfText, { color: "#10B981" }]}>PDF Generated</Text>
                      </View>
                      <TouchableOpacity style={[styles.pdfBtn, { backgroundColor: "#10B98122" }]}>
                        <Feather name="download" size={14} color="#10B981" />
                        <Text style={[styles.pdfBtnText, { color: "#10B981" }]}>Download PDF</Text>
                      </TouchableOpacity>
                    </>
                  ) : (
                    <>
                      <View style={styles.pdfRow}>
                        <Feather name="file-text" size={18} color={colors.textMuted} />
                        <Text style={[styles.pdfText, { color: colors.textMuted }]}>No PDF yet</Text>
                      </View>
                      <TouchableOpacity
                        style={[styles.pdfBtn, { backgroundColor: colors.primary + "22" }]}
                        onPress={() => handlePayFee(showDetail)}
                        disabled={payingFee}
                      >
                        {payingFee
                          ? <ActivityIndicator color={colors.primary} size="small" />
                          : <>
                            <Feather name="zap" size={14} color={colors.primary} />
                            <Text style={[styles.pdfBtnText, { color: colors.primary }]}>Generate PDF — GH₵ 5.00</Text>
                          </>}
                      </TouchableOpacity>
                    </>
                  )}
                </View>

                {/* Actions */}
                {showDetail.status === "unpaid" && (
                  <TouchableOpacity
                    style={[styles.markPaidBtn, { backgroundColor: "#10B981" }]}
                    onPress={() => handleMarkPaid(showDetail)}
                  >
                    <Feather name="check" size={16} color="#fff" />
                    <Text style={styles.markPaidText}>Mark as Paid</Text>
                  </TouchableOpacity>
                )}
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

function DetailRow({ label, value, colors }: { label: string; value: string; colors: any }) {
  return (
    <View style={styles.detailRow}>
      <Text style={[styles.detailLabel, { color: colors.textMuted }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: colors.text }]}>{value}</Text>
    </View>
  );
}

function fmtGHS(p?: number | null) {
  if (!p) return "GH₵ 0.00";
  return `GH₵ ${(p / 100).toFixed(2)}`;
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  backBtn: { padding: 4, marginRight: 8 },
  title: { flex: 1, fontSize: 20, fontFamily: "Inter_700Bold" },
  newBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 10 },
  newBtnText: { color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 13 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 32 },
  emptyIcon: { width: 72, height: 72, borderRadius: 24, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold", marginBottom: 8 },
  emptyDesc: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 20, marginBottom: 20 },
  createBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  createBtnText: { color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 15 },
  listContent: { padding: 16, gap: 10 },
  card: { flexDirection: "row", alignItems: "center", borderRadius: 14, padding: 14, borderWidth: 1 },
  cardLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  invoiceIcon: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  invoiceNum: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  invoiceClient: { fontSize: 15, fontFamily: "Inter_600SemiBold", marginTop: 2 },
  invoiceDate: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  cardRight: { alignItems: "flex-end", gap: 6 },
  invoiceAmount: { fontSize: 16, fontFamily: "Inter_700Bold" },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  badgeText: { fontSize: 10, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 0.5 },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 36, maxHeight: "90%" },
  sheetTall: { maxHeight: "94%" },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: "#ffffff33", alignSelf: "center", marginBottom: 16 },
  sheetHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 },
  sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold" },
  section: { fontSize: 11, fontFamily: "Inter_600SemiBold", textTransform: "uppercase", letterSpacing: 0.8, marginTop: 16, marginBottom: 8 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, fontFamily: "Inter_400Regular", marginBottom: 8 },
  lineItem: { borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 8 },
  lineItemRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  lineInput: { fontSize: 14, fontFamily: "Inter_400Regular" },
  lineItemNums: { flexDirection: "row", gap: 8, marginTop: 8, alignItems: "flex-end" },
  lineNumField: { alignItems: "flex-start" },
  lineNumLabel: { fontSize: 10, fontFamily: "Inter_500Medium", marginBottom: 4 },
  lineNumInput: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 6, fontSize: 14, fontFamily: "Inter_400Regular", width: 60 },
  lineTotal: { fontSize: 14, fontFamily: "Inter_700Bold", paddingVertical: 6 },
  addItemBtn: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderStyle: "dashed", borderRadius: 10, padding: 10, justifyContent: "center", marginBottom: 4 },
  addItemText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  totalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, paddingTop: 14, marginTop: 8 },
  totalLabel: { fontSize: 14, fontFamily: "Inter_500Medium" },
  totalValue: { fontSize: 20, fontFamily: "Inter_700Bold" },
  feeNote: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 6, marginBottom: 4 },
  sheetActions: { flexDirection: "row", gap: 10, marginTop: 20 },
  btn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  btnCancel: { borderWidth: 1 },
  btnText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  // Detail
  detailStatus: { alignItems: "center", marginBottom: 12 },
  detailCard: { borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 8 },
  detailRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 4 },
  detailLabel: { fontSize: 13, fontFamily: "Inter_500Medium" },
  detailValue: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  itemDesc: { fontSize: 14, fontFamily: "Inter_500Medium", marginBottom: 6 },
  itemRow: { flexDirection: "row", justifyContent: "space-between" },
  itemMeta: { fontSize: 13, fontFamily: "Inter_400Regular" },
  itemTotal: { fontSize: 13, fontFamily: "Inter_700Bold" },
  notesText: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 20 },
  pdfCard: { borderWidth: 1, borderRadius: 14, padding: 14, marginTop: 12, gap: 10 },
  pdfRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  pdfText: { fontSize: 14, fontFamily: "Inter_500Medium" },
  pdfBtn: { flexDirection: "row", alignItems: "center", gap: 6, padding: 10, borderRadius: 10, justifyContent: "center" },
  pdfBtnText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  markPaidBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, padding: 14, borderRadius: 12, marginTop: 14 },
  markPaidText: { color: "#fff", fontSize: 15, fontFamily: "Inter_600SemiBold" },
});
