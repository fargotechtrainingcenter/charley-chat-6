export type StreamKind = "movie" | "show";

export interface StreamTitle {
  id: string;
  title: string;
  kind: StreamKind;
  genre: string;
  year: number;
  duration: string;
  rating: number;
  ageRating: string;
  description: string;
  gradient: [string, string];
  posterUrl?: string;
  videoUrl?: string;
  isPremium?: boolean;
  progress?: number;
  seasonInfo?: string;
  isNew?: boolean;
}

export const FEATURED: StreamTitle = {
  id: "shadow-protocol",
  title: "Shadow Protocol",
  kind: "movie",
  genre: "Action • Thriller",
  year: 2024,
  duration: "2h 9m",
  rating: 4.7,
  ageRating: "16+",
  description:
    "A disavowed intelligence officer races across three continents to stop a rogue algorithm from triggering a global blackout — with only 48 hours before it's too late.",
  gradient: ["#0F2A3D", "#070C14"],
};

export const CONTINUE_WATCHING: StreamTitle[] = [
  {
    id: "the-equalizer-run",
    title: "Night Runner",
    kind: "movie",
    genre: "Action",
    year: 2023,
    duration: "1h 58m",
    rating: 4.3,
    ageRating: "16+",
    description: "A vigilante fixer takes on Accra's most dangerous cartel to protect a witness who saw too much.",
    gradient: ["#0D9488", "#0C1524"],
    progress: 0.6,
  },
  {
    id: "money-web",
    title: "Money Web",
    kind: "show",
    genre: "Crime Drama",
    year: 2022,
    duration: "S2 · E3",
    rating: 4.5,
    ageRating: "18+",
    description: "A group of ordinary Ghanaians pull off the continent's most audacious heist to save their community bank.",
    gradient: ["#134E4A", "#0C1524"],
    progress: 0.45,
    seasonInfo: "Season 2",
  },
  {
    id: "the-elders",
    title: "The Elders",
    kind: "show",
    genre: "Fantasy",
    year: 2021,
    duration: "S1 · E6",
    rating: 4.6,
    ageRating: "13+",
    description: "Ancient guardians wake in modern-day Kumasi to protect the realm from a rising darkness.",
    gradient: ["#164E63", "#0C1524"],
    progress: 0.25,
    seasonInfo: "Season 1",
  },
];

export const POPULAR_ON_STREAM: StreamTitle[] = [
  {
    id: "web-guardian",
    title: "Web Guardian",
    kind: "movie",
    genre: "Superhero",
    year: 2024,
    duration: "2h 21m",
    rating: 4.8,
    ageRating: "13+",
    description: "A masked protector must balance ordinary life with saving the city from an army of shadow clones.",
    gradient: ["#0D9488", "#0F2A3D"],
  },
  {
    id: "fast-current",
    title: "Fast Current",
    kind: "movie",
    genre: "Action",
    year: 2023,
    duration: "2h 21m",
    rating: 4.2,
    ageRating: "16+",
    description: "An underground street-racing crew is pulled into an international smuggling plot they can't outrun.",
    gradient: ["#155E63", "#0C1524"],
  },
  {
    id: "panther-legacy",
    title: "Panther Legacy",
    kind: "movie",
    genre: "Superhero",
    year: 2022,
    duration: "2h 41m",
    rating: 4.6,
    ageRating: "13+",
    description: "A new champion rises to defend a hidden kingdom's legacy of innovation and honor.",
    gradient: ["#134E4A", "#070C14"],
  },
  {
    id: "the-witness-tree",
    title: "The Witness Tree",
    kind: "movie",
    genre: "Thriller",
    year: 2023,
    duration: "1h 47m",
    rating: 4.1,
    ageRating: "16+",
    description: "A journalist uncovers a decades-old conspiracy buried beneath her hometown.",
    gradient: ["#0E7490", "#0C1524"],
  },
];

export const NEW_RELEASES: StreamTitle[] = [
  {
    id: "kingdom-of-tomorrow",
    title: "Kingdom of Tomorrow",
    kind: "movie",
    genre: "Sci-Fi",
    year: 2024,
    duration: "2h 25m",
    rating: 4.4,
    ageRating: "13+",
    description: "Centuries after a great collapse, a young engineer discovers the key to rebuilding civilization.",
    gradient: ["#0D9488", "#0C1524"],
    isNew: true,
  },
  {
    id: "second-chance-city",
    title: "Second Chance City",
    kind: "movie",
    genre: "Comedy",
    year: 2024,
    duration: "1h 52m",
    rating: 4.0,
    ageRating: "13+",
    description: "Two rival hustlers are forced to run a failing restaurant together — and fall for the chaos.",
    gradient: ["#164E63", "#070C14"],
    isNew: true,
  },
  {
    id: "the-wager",
    title: "The Wager",
    kind: "movie",
    genre: "Drama",
    year: 2024,
    duration: "2h 4m",
    rating: 4.3,
    ageRating: "16+",
    description: "A high-stakes bet between old friends spirals into a reckoning with the past.",
    gradient: ["#134E4A", "#0F2A3D"],
    isNew: true,
  },
  {
    id: "aftershock",
    title: "Aftershock",
    kind: "movie",
    genre: "Disaster",
    year: 2024,
    duration: "2h 12m",
    rating: 3.9,
    ageRating: "13+",
    description: "A coastal town has hours to evacuate before the next, bigger quake hits.",
    gradient: ["#0E7490", "#070C14"],
    isNew: true,
  },
];

export const TOP_PICKS: StreamTitle[] = [
  {
    id: "horizon-lost",
    title: "Horizon Lost",
    kind: "movie",
    genre: "Sci-Fi • Drama",
    year: 2021,
    duration: "2h 49m",
    rating: 4.8,
    ageRating: "13+",
    description: "A crew of explorers travels through a wormhole in a desperate attempt to save humanity.",
    gradient: ["#0D9488", "#070C14"],
  },
  {
    id: "quiet-signal",
    title: "Quiet Signal",
    kind: "movie",
    genre: "Sci-Fi",
    year: 2020,
    duration: "1h 56m",
    rating: 4.2,
    ageRating: "13+",
    description: "A lone radio operator picks up a transmission that shouldn't exist.",
    gradient: ["#155E63", "#0C1524"],
  },
  {
    id: "gravity-well",
    title: "Gravity Well",
    kind: "movie",
    genre: "Sci-Fi",
    year: 2019,
    duration: "2h 11m",
    rating: 4.0,
    ageRating: "13+",
    description: "Stranded scientists must improvise a way home after their station drifts off course.",
    gradient: ["#134E4A", "#0C1524"],
  },
  {
    id: "the-long-orbit",
    title: "The Long Orbit",
    kind: "show",
    genre: "Sci-Fi",
    year: 2022,
    duration: "S1 · E1",
    rating: 4.5,
    ageRating: "13+",
    description: "A generation ship's crew grapples with a mutiny decades into their voyage.",
    gradient: ["#0E7490", "#070C14"],
    seasonInfo: "Season 1",
  },
];

export const CATEGORY_CHIPS = ["For You", "Movies", "TV Shows", "Kids", "Categories"] as const;

export const ALL_TITLES: StreamTitle[] = [
  FEATURED,
  ...CONTINUE_WATCHING,
  ...POPULAR_ON_STREAM,
  ...NEW_RELEASES,
  ...TOP_PICKS,
];

export function findTitle(id: string): StreamTitle | undefined {
  return ALL_TITLES.find((t) => t.id === id);
}

export function moreLikeThis(current: StreamTitle, count = 4): StreamTitle[] {
  return ALL_TITLES
    .filter((t) => t.id !== current.id && t.genre.split(" ")[0] === current.genre.split(" ")[0])
    .slice(0, count)
    .concat(ALL_TITLES.filter((t) => t.id !== current.id))
    .filter((t, i, arr) => arr.findIndex((x) => x.id === t.id) === i)
    .slice(0, count);
}
