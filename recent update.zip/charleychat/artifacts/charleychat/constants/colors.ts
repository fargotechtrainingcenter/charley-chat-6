const colors = {
  light: {
    // ── Surfaces ──────────────────────────────────────────────────────────────
    background:      "#070C14",   // near-black navy void
    surface:         "#0C1524",   // deep navy-black
    surfaceElevated: "#132038",   // elevated card layer

    // ── Text ──────────────────────────────────────────────────────────────────
    foreground:      "#E8F6F1",   // off-white with cool teal tint
    text:            "#E8F6F1",
    textMuted:       "#6B8A94",   // muted teal-gray
    textDim:         "#2E4550",   // very dim

    // ── Primary — teal / emerald ─────────────────────────────────────────────
    primary:          "#12D9A0",  // bright teal-emerald
    primaryLight:     "#5EEAD4",  // aqua/cyan light
    primaryForeground:"#04140F",

    // ── Gold accent — amber-yellow ─────────────────────────────────────────────
    gold:     "#F59E0B",          // vivid amber / gold-yellow
    goldLight:"#FCD34D",          // bright yellow
    goldDim:  "rgba(245,158,11,0.16)",

    // ── Semantic ──────────────────────────────────────────────────────────────
    success:    "#12D9A0",
    successBg:  "rgba(18,217,160,0.12)",
    warning:    "#F59E0B",
    warningBg:  "rgba(245,158,11,0.13)",
    danger:     "#F87171",
    dangerBg:   "rgba(248,113,113,0.13)",

    // ── Structure ─────────────────────────────────────────────────────────────
    border:  "#16283A",           // dark teal-navy border
    divider: "#0C1524",
    input:   "#132038",

    // ── Legacy / compat aliases ───────────────────────────────────────────────
    card:                 "#0C1524",
    cardForeground:       "#E8F6F1",
    indigo:               "#12D9A0",
    indigoDeep:           "#0D9488",
    indigoLight:          "#5EEAD4",
    parchment:            "#070C14",
    parchmentDark:        "#0C1524",
    ink:                  "#E8F6F1",
    inkSoft:              "#6B8A94",
    white:                "#E8F6F1",
    muted:                "#132038",
    mutedForeground:      "#6B8A94",
    secondary:            "#0C1524",
    secondaryForeground:  "#E8F6F1",
    accent:               "#F59E0B",
    accentForeground:     "#070C14",
    destructive:          "#F87171",
    destructiveForeground:"#FFFFFF",
  },
  radius: 14,
};

export default colors;
