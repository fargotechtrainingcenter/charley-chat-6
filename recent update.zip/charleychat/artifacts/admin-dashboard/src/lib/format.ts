export function formatGHS(pesewas: number | undefined | null): string {
  if (pesewas == null) return "GHS 0.00";
  return `GHS ${(pesewas / 100).toFixed(2)}`;
}

export function formatDate(dateString: string | undefined | null): string {
  if (!dateString) return "";
  const date = new Date(dateString);
  return new Intl.DateTimeFormat("en-GH", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}
