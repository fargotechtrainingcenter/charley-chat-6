import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider, QueryCache } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Users from "@/pages/users";
import UserDetail from "@/pages/user-detail";
import Wallets from "@/pages/wallets";
import Transactions from "@/pages/transactions";
import Escrow from "@/pages/escrow";
import Kyc from "@/pages/kyc";
import Stories from "@/pages/stories";
import PaymentLinks from "@/pages/payment-links";
import Notifications from "@/pages/notifications";
import Sessions from "@/pages/sessions";
import SmsLogs from "@/pages/sms-logs";
import Admins from "@/pages/admins";
import Reels from "@/pages/reels";
import Messages from "@/pages/messages";
import Groups from "@/pages/groups";
import Movies from "@/pages/movies";
import Invoices from "@/pages/invoices";
import Settings from "@/pages/settings";

const queryClient = new QueryClient({
  queryCache: new QueryCache({
    onError: (error: any) => {
      const status = error?.status ?? error?.response?.status;
      if (status === 401) {
        localStorage.removeItem("charley_admin_token");
        queryClient.clear();
        window.location.href = import.meta.env.BASE_URL ?? "/charley-admin/";
      }
    },
  }),
  defaultOptions: {
    queries: {
      retry: (failureCount, error: any) => {
        if ((error?.status ?? error?.response?.status) === 401) return false;
        return failureCount < 2;
      },
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Login} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/users" component={Users} />
        <Route path="/users/:id" component={UserDetail} />
        <Route path="/wallets" component={Wallets} />
        <Route path="/transactions" component={Transactions} />
        <Route path="/escrow" component={Escrow} />
        <Route path="/kyc" component={Kyc} />
        <Route path="/stories" component={Stories} />
        <Route path="/payment-links" component={PaymentLinks} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/sessions" component={Sessions} />
        <Route path="/sms-logs" component={SmsLogs} />
        <Route path="/admins" component={Admins} />
        <Route path="/reels" component={Reels} />
        <Route path="/messages" component={Messages} />
        <Route path="/groups" component={Groups} />
        <Route path="/movies" component={Movies} />
        <Route path="/invoices" component={Invoices} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
