import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Users,
  Wallet,
  ArrowRightLeft,
  ShieldCheck,
  BookOpen,
  Link as LinkIcon,
  Bell,
  Activity,
  MessageSquare,
  Shield,
  LogOut,
  Menu,
  Search,
  Settings,
  HelpCircle,
  User,
  TrendingUp,
  Play,
  UsersRound,
  FileText,
  Film,
} from "lucide-react";
import { useEffect } from "react";

import { AdminNotificationBell } from "@/components/AdminNotificationBell";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuthLogout } from "@workspace/api-client-react";

const BASE = import.meta.env.BASE_URL;

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  color: string;
}

const fargoPayNav: NavItem[] = [
  { href: "/dashboard",      label: "Dashboard",      icon: LayoutDashboard, color: "gold"   },
  { href: "/users",          label: "Users",           icon: Users,           color: "pink"   },
  { href: "/wallets",        label: "Wallets",         icon: Wallet,          color: "gold"   },
  { href: "/transactions",   label: "Transactions",    icon: ArrowRightLeft,  color: "blue"   },
  { href: "/escrow",         label: "Escrow",          icon: ShieldCheck,     color: "indigo" },
  { href: "/kyc",            label: "KYC",             icon: ShieldCheck,     color: "pink"   },
  { href: "/stories",        label: "Stories",         icon: BookOpen,        color: "gold"   },
  { href: "/reels",          label: "Reels",           icon: Play,            color: "pink"   },
  { href: "/groups",         label: "Groups",          icon: UsersRound,      color: "indigo" },
  { href: "/movies",         label: "Movies",          icon: Film,            color: "indigo" },
  { href: "/messages",       label: "Messages",        icon: MessageSquare,   color: "blue"   },
  { href: "/invoices",       label: "Invoices",        icon: FileText,        color: "gold"   },
  { href: "/payment-links",  label: "Payment Links",   icon: LinkIcon,        color: "pink"   },
  { href: "/notifications",  label: "Notifications",   icon: Bell,            color: "gold"   },
  { href: "/sessions",       label: "Sessions",        icon: Activity,        color: "blue"   },
  { href: "/sms-logs",       label: "SMS Logs",        icon: MessageSquare,   color: "ash"    },
  { href: "/admins",         label: "Admins",          icon: Shield,          color: "indigo" },
  { href: "/settings",       label: "Settings",        icon: Settings,        color: "ash"    },
];

const allNavItems = [...fargoPayNav];

const colorMap: Record<string, string> = {
  gold:    "text-[hsl(43,96%,54%)]",
  pink:    "text-[hsl(330,80%,60%)]",
  blue:    "text-[hsl(210,88%,54%)]",
  indigo:  "text-[hsl(243,72%,70%)]",
  ash:     "text-[hsl(220,10%,65%)]",
  emerald: "text-[hsl(160,70%,50%)]",
  amber:   "text-[hsl(38,95%,52%)]",
};

const activeBgMap: Record<string, string> = {
  gold:    "bg-[hsl(43,96%,54%,0.15)]   border-l-[3px] border-[hsl(43,96%,54%)]",
  pink:    "bg-[hsl(330,80%,60%,0.15)]  border-l-[3px] border-[hsl(330,80%,60%)]",
  blue:    "bg-[hsl(210,88%,54%,0.15)]  border-l-[3px] border-[hsl(210,88%,54%)]",
  indigo:  "bg-[hsl(243,72%,56%,0.20)]  border-l-[3px] border-[hsl(243,72%,70%)]",
  ash:     "bg-[hsl(220,10%,60%,0.15)]  border-l-[3px] border-[hsl(220,10%,65%)]",
  emerald: "bg-[hsl(160,70%,50%,0.15)]  border-l-[3px] border-[hsl(160,70%,50%)]",
  amber:   "bg-[hsl(38,95%,52%,0.15)]   border-l-[3px] border-[hsl(38,95%,52%)]",
};

function NavLink({ item, pathname }: { item: NavItem; pathname: string }) {
  const isActive = pathname.startsWith(item.href);
  const iconColor = colorMap[item.color] ?? "text-white/50";
  return (
    <Link href={item.href}>
      <div
        className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-all cursor-pointer ${
          isActive
            ? `${activeBgMap[item.color]} text-white`
            : "text-white/55 hover:text-white hover:bg-white/8"
        }`}
      >
        <item.icon className={`h-4 w-4 shrink-0 ${isActive ? iconColor : ""}`} />
        {item.label}
        {isActive && <div className={`ml-auto w-1.5 h-1.5 rounded-full ${iconColor.replace("text-", "bg-")}`} />}
      </div>
    </Link>
  );
}

function SidebarNav({ pathname }: { pathname: string }) {
  const [_, setLocation] = useLocation();
  const logout = useAuthLogout();

  const handleLogout = () => {
    logout.mutate(
      { data: { refreshToken: "" } },
      { onSettled: () => { localStorage.removeItem("charley_admin_token"); setLocation("/"); } }
    );
  };

  return (
    <div className="flex h-full flex-col border-r" style={{ background: "hsl(243,55%,13%)" }}>
      {/* Brand */}
      <div className="px-4 py-4 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <img
            src={`${BASE}charley-icon.png`}
            alt="FargoPay"
            className="shrink-0 object-contain rounded-md"
            style={{ width: 36, height: 36 }}
          />
          <div className="flex flex-col min-w-0">
            <span className="text-white font-extrabold text-base tracking-tight leading-tight">FargoPay</span>
            <span className="text-[9px] text-white/40 font-semibold tracking-[0.16em] uppercase mt-0.5">
              Admin Console
            </span>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
          {fargoPayNav.map((item) => (
          <NavLink key={item.href} item={item} pathname={pathname} />
        ))}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-white/10">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm text-white/50 hover:text-white hover:bg-white/8 transition-colors cursor-pointer"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </div>
  );
}

function TopHeader({ pathname }: { pathname: string }) {
  const label = allNavItems.find((n) => pathname.startsWith(n.href))?.label ?? "Overview";

  return (
    <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-4 border-b bg-background/90 backdrop-blur-sm px-6">
      {/* Left: breadcrumb */}
      <div className="flex items-center gap-2 min-w-0">
        <TrendingUp className="h-4 w-4 shrink-0" style={{ color: "hsl(43,96%,54%)" }} />
        <span className="text-sm font-semibold text-foreground truncate">{label}</span>
      </div>

      {/* Right: palette pill buttons */}
      <div className="palette-group">
        <button className="palette-btn" title="Search">
          <Search className="h-4 w-4" />
        </button>

        <div style={{ width: 1, height: 20, background: "hsl(var(--border))" }} />

        <button className="palette-btn gold" title="Activity">
          <Activity className="h-4 w-4" />
        </button>
        <AdminNotificationBell />
        <button className="palette-btn blue" title="Help">
          <HelpCircle className="h-4 w-4" />
        </button>
        <button className="palette-btn indigo" title="Settings">
          <Settings className="h-4 w-4" />
        </button>

        <div style={{ width: 1, height: 20, background: "hsl(var(--border))" }} />

        <button className="palette-btn ash" title="Profile">
          <User className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [pathname, setLocation] = useLocation();

  // Redirect to login if no admin token (handles browser refresh)
  useEffect(() => {
    if (pathname !== "/" && !localStorage.getItem("charley_admin_token")) {
      setLocation("/");
    }
  }, [pathname, setLocation]);

  if (pathname === "/") {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      {/* Desktop Sidebar */}
      <div className="hidden w-60 shrink-0 md:block">
        <div className="sticky top-0 h-screen overflow-hidden">
          <SidebarNav pathname={pathname} />
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        {/* Mobile header */}
        <div className="flex h-14 items-center gap-4 border-b bg-background px-4 md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-60 p-0">
              <SidebarNav pathname={pathname} />
            </SheetContent>
          </Sheet>
          <img src={`${BASE}charley-icon.png`} alt="FargoPay" className="h-7 object-contain object-left" />
        </div>

        {/* Desktop top header with palette buttons */}
        <div className="hidden md:block">
          <TopHeader pathname={pathname} />
        </div>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <div className="mx-auto max-w-6xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
