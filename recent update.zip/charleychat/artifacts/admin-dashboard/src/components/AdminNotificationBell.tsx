import { useState, useEffect, useRef } from "react";
import { Bell, BellOff, ShoppingBag, Package, Users, Wallet, X, CheckCheck } from "lucide-react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const SOUND_KEY = "charley_admin_notif_sound";

function authHeaders() {
  return {
    Authorization: `Bearer ${localStorage.getItem("charley_admin_token") ?? ""}`,
    "Content-Type": "application/json",
  };
}

function playNotifTone(urgent: boolean) {
  try {
    const ctx = new AudioContext();
    const notes = urgent
      ? [587, 740, 880]
      : [659, 880];
    const step = urgent ? 0.18 : 0.22;
    const vol  = urgent ? 0.28 : 0.18;

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      g.gain.setValueAtTime(0, ctx.currentTime + i * step);
      g.gain.linearRampToValueAtTime(vol, ctx.currentTime + i * step + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * step + 0.38);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(ctx.currentTime + i * step);
      osc.stop(ctx.currentTime + i * step + 0.4);
    });
  } catch (_) {}
}

type AdminNotif = {
  id: string;
  type: string;
  title: string;
  message: string;
  data: Record<string, unknown>;
  is_read: boolean;
  created_at: string;
};

function typeIcon(type: string) {
  if (type === "new_order")      return <ShoppingBag className="w-4 h-4 text-emerald-400" />;
  if (type === "new_product")    return <Package className="w-4 h-4 text-blue-400" />;
  if (type === "new_vendor")     return <Users className="w-4 h-4 text-purple-400" />;
  if (type === "payout_request") return <Wallet className="w-4 h-4 text-amber-400" />;
  return <Bell className="w-4 h-4 text-gray-400" />;
}

function typeDot(type: string) {
  if (type === "new_order")      return "bg-emerald-400";
  if (type === "new_product")    return "bg-blue-400";
  if (type === "new_vendor")     return "bg-purple-400";
  if (type === "payout_request") return "bg-amber-400";
  return "bg-gray-400";
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export function AdminNotificationBell() {
  const [open, setOpen]       = useState(false);
  const [notifs, setNotifs]   = useState<AdminNotif[]>([]);
  const [unread, setUnread]   = useState(0);
  const [loading, setLoading] = useState(false);
  const [soundOn, setSoundOn] = useState(() => {
    try { return localStorage.getItem(SOUND_KEY) !== "off"; } catch { return true; }
  });

  const [hasUnreadOrders, setHasUnreadOrders] = useState(false);
  const [ringing, setRinging] = useState(false);
  const prevUnreadRef = useRef<number | null>(null);
  const dropdownRef   = useRef<HTMLDivElement>(null);

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSoundOn((prev) => {
      const next = !prev;
      try { localStorage.setItem(SOUND_KEY, next ? "on" : "off"); } catch {}
      return next;
    });
  };

  const fetchNotifs = async () => {
    try {
      const res = await fetch(`${BASE}/api/africart/admin/notifications`, { headers: authHeaders() });
      if (!res.ok) return;
      const data = await res.json();
      const incoming: AdminNotif[] = data.notifications ?? [];
      const newUnread: number      = data.unreadCount ?? 0;
      const unreadOrders = incoming.filter((n) => !n.is_read && n.type === "new_order");

      if (prevUnreadRef.current !== null && newUnread > prevUnreadRef.current && soundOn) {
        playNotifTone(unreadOrders.length > 0);
        setRinging(true);
        setTimeout(() => setRinging(false), 700);
      }
      prevUnreadRef.current = newUnread;
      setHasUnreadOrders(unreadOrders.length > 0);
      setNotifs(incoming);
      setUnread(newUnread);
    } catch (_) {}
  };

  useEffect(() => {
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 30000);
    return () => clearInterval(interval);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [soundOn]);

  // Repeat alarm every 60s while unread orders exist
  useEffect(() => {
    if (!hasUnreadOrders || !soundOn) return;
    const alarm = setInterval(() => playNotifTone(true), 60000);
    return () => clearInterval(alarm);
  }, [hasUnreadOrders, soundOn]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [open]);

  const markAllRead = async () => {
    setLoading(true);
    try {
      await fetch(`${BASE}/api/africart/admin/notifications/read-all`, {
        method: "PATCH", headers: authHeaders(),
      });
      setNotifs((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnread(0);
      prevUnreadRef.current = 0;
    } finally {
      setLoading(false);
    }
  };

  const markOneRead = async (id: string) => {
    await fetch(`${BASE}/api/africart/admin/notifications/${id}/read`, {
      method: "PATCH", headers: authHeaders(),
    });
    setNotifs((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true } : n));
    setUnread((prev) => {
      const next = Math.max(0, prev - 1);
      prevUnreadRef.current = next;
      return next;
    });
  };

  return (
    <div className="relative flex items-center gap-1" ref={dropdownRef}>
      {/* Mute toggle */}
      <button
        title={soundOn ? "Mute notification sounds" : "Enable notification sounds"}
        onClick={toggleSound}
        className="palette-btn indigo opacity-70 hover:opacity-100"
      >
        {soundOn
          ? <Bell className="h-3.5 w-3.5" />
          : <BellOff className="h-3.5 w-3.5" />}
      </button>

      {/* Main bell */}
      <button
        className="palette-btn pink relative"
        title="Notifications"
        onClick={() => setOpen((v) => !v)}
      >
        <Bell className={`h-4 w-4 ${ringing ? "animate-bell-ring" : ""}`} style={{ transformOrigin: "top center" }} />
        {unread > 0 && (
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center leading-none animate-pulse">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div
          className="absolute right-0 top-10 w-96 max-h-[520px] flex flex-col rounded-2xl border bg-background shadow-2xl z-50 overflow-hidden"
          style={{ borderColor: "hsl(var(--border))" }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "hsl(var(--border))" }}>
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-pink-400" />
              <span className="font-semibold text-sm">Notifications</span>
              {unread > 0 && (
                <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unread}</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={toggleSound}
                title={soundOn ? "Mute sounds" : "Unmute sounds"}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                {soundOn ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
                {soundOn ? "Sound on" : "Muted"}
              </button>
              {unread > 0 && (
                <button
                  onClick={markAllRead}
                  disabled={loading}
                  className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  Mark all read
                </button>
              )}
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List */}
          <div className="overflow-y-auto flex-1">
            {notifs.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-2">
                <Bell className="w-8 h-8 opacity-30" />
                <p className="text-sm">No notifications yet</p>
              </div>
            ) : (
              notifs.map((n) => (
                <button
                  key={n.id}
                  onClick={() => !n.is_read && markOneRead(n.id)}
                  className={`w-full text-left flex items-start gap-3 px-4 py-3 border-b transition-colors hover:bg-muted/40 ${!n.is_read ? "bg-muted/20" : ""}`}
                  style={{ borderColor: "hsl(var(--border))" }}
                >
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0 mt-0.5">
                    {typeIcon(n.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-foreground truncate">{n.title}</span>
                      {!n.is_read && <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${typeDot(n.type)}`} />}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">{n.message}</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-1">{timeAgo(n.created_at)}</p>
                  </div>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
