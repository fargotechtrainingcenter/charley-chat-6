import { useState } from "react";
import { useAdminListWallets, getAdminListWalletsQueryKey, useAdjustWalletBalance } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatGHS, formatDate } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function Wallets() {
  const [search, setSearch] = useState("");
  const [page] = useState(1);
  const queryClient = useQueryClient();

  const { data, isLoading } = useAdminListWallets({ search, page, limit: 50 });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Wallets</h1>
      
      <div className="flex items-center gap-4">
        <Input 
          placeholder="Search phone or name..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User Name</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Last Updated</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : data?.items.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8">No wallets found.</TableCell></TableRow>
            ) : (
              data?.items.map(wallet => (
                <TableRow key={wallet.id}>
                  <TableCell className="font-medium">{wallet.userName}</TableCell>
                  <TableCell>{wallet.userPhone}</TableCell>
                  <TableCell className="font-mono">{formatGHS(wallet.balancePesewas)}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(wallet.updatedAt)}</TableCell>
                  <TableCell className="text-right">
                    <AdjustWalletModal walletId={wallet.id} currentBalance={wallet.balancePesewas} onAdjust={() => {
                      queryClient.invalidateQueries({ queryKey: getAdminListWalletsQueryKey() });
                    }} />
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function AdjustWalletModal({ walletId, currentBalance, onAdjust }: { walletId: string, currentBalance: number, onAdjust: () => void }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const adjustMutation = useAdjustWalletBalance();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountPesewas = Math.round(parseFloat(amount) * 100);
    adjustMutation.mutate({ id: walletId, data: { amountPesewas, reason } }, {
      onSuccess: () => {
        setOpen(false);
        onAdjust();
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">Adjust Balance</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Adjust Wallet Balance</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Current Balance</Label>
            <div className="font-mono text-lg">{formatGHS(currentBalance)}</div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="amount">Adjustment Amount (GHS)</Label>
            <Input id="amount" type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="-50.00 or 100.00" required />
            <p className="text-xs text-muted-foreground">Use negative numbers to deduct, positive to add.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Adjustment</Label>
            <Input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Refund for failed transaction" required />
          </div>
          <Button type="submit" className="w-full" disabled={adjustMutation.isPending}>Submit Adjustment</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
