import { useState } from "react";
import { useListAdmins, getListAdminsQueryKey, useCreateAdminUser, useDeleteAdminUser } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDate } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, ShieldCheck, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function authHeaders() {
  const token = localStorage.getItem("charley_admin_token");
  return { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
}

export default function Admins() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading } = useListAdmins({
    query: { queryKey: getListAdminsQueryKey() }
  });

  const deleteMutation = useDeleteAdminUser();
  const [rolePending, setRolePending] = useState<string | null>(null);

  const handleDelete = (id: string, email: string) => {
    if (confirm(`Permanently remove admin "${email}"?`)) {
      deleteMutation.mutate({ id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAdminsQueryKey() });
          toast({ title: "Admin removed" });
        },
        onError: () => toast({ title: "Failed to remove admin", variant: "destructive" }),
      });
    }
  };

  const handleRoleChange = async (id: string, newRole: string) => {
    setRolePending(id);
    try {
      const res = await fetch(`${BASE}/api/admin/admins/${id}/role`, {
        method: "PATCH",
        headers: authHeaders(),
        body: JSON.stringify({ role: newRole }),
      });
      if (!res.ok) throw new Error();
      await queryClient.invalidateQueries({ queryKey: getListAdminsQueryKey() });
      toast({ title: "Role updated successfully" });
    } catch {
      toast({ title: "Failed to update role", variant: "destructive" });
    } finally {
      setRolePending(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Accounts</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Manage admin users and their access roles. Super Admins can create, modify, and remove admins.
          </p>
        </div>
        <CreateAdminModal onCreated={() => queryClient.invalidateQueries({ queryKey: getListAdminsQueryKey() })} />
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
            ) : !data?.length ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No admin accounts found.</TableCell></TableRow>
            ) : (
              data.map(admin => (
                <TableRow key={admin.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {admin.role === "super_admin"
                        ? <ShieldCheck className="h-4 w-4 text-indigo-400" />
                        : <Shield className="h-4 w-4 text-slate-400" />}
                      {admin.email}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Select
                      value={admin.role ?? "admin"}
                      onValueChange={(v) => handleRoleChange(admin.id, v)}
                      disabled={rolePending === admin.id}
                    >
                      <SelectTrigger className="h-8 w-36 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">
                          <div className="flex items-center gap-1.5">
                            <Shield className="h-3 w-3" /> Admin
                          </div>
                        </SelectItem>
                        <SelectItem value="super_admin">
                          <div className="flex items-center gap-1.5">
                            <ShieldCheck className="h-3 w-3" /> Super Admin
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{formatDate(admin.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => handleDelete(admin.id, admin.email ?? "")}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function CreateAdminModal({ onCreated }: { onCreated: () => void }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("admin");
  const createMutation = useCreateAdminUser();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({ data: { email, password, role } }, {
      onSuccess: () => {
        setOpen(false);
        setEmail("");
        setPassword("");
        setRole("admin");
        onCreated();
        toast({ title: "Admin account created" });
      },
      onError: () => toast({ title: "Failed to create admin — email may already be in use", variant: "destructive" }),
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Shield className="h-4 w-4 mr-2" /> New Admin
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Register New Admin</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@example.com" required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Strong password" required />
          </div>
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin — standard access</SelectItem>
                <SelectItem value="super_admin">Super Admin — full access including admin management</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full" disabled={createMutation.isPending}>
            {createMutation.isPending ? "Creating..." : "Create Admin Account"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
