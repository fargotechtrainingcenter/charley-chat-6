import { useState } from "react";
import { useRoute, Link } from "wouter";
import {
  useAdminGetUser, getAdminGetUserQueryKey,
  useSuspendUser, useUnsuspendUser, useFlagUser, useUnflagUser,
  useHoldUser, useAdminGetUserNotes, useAdminAddUserNote,
  getAdminGetUserNotesQueryKey,
  type AddAdminNoteInputNoteType,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatGHS, formatDate } from "@/lib/format";
import {
  ArrowLeft, ShieldCheck, ShieldAlert, ShieldOff, ShieldBan,
  Wallet, ArrowRightLeft, User, Phone, Mail, CreditCard,
  Clock, CalendarDays, AlertTriangle, Info, CheckCircle2,
  XCircle, Plus, ChevronDown,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const GOLD   = "hsl(43,96%,54%)";
const PINK   = "hsl(330,80%,60%)";
const BLUE   = "hsl(210,88%,54%)";
const INDIGO = "hsl(243,72%,56%)";
const GREEN  = "hsl(142,72%,42%)";
const RED    = "hsl(0,84%,60%)";
const ASH    = "hsl(220,10%,60%)";

const NOTE_META: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  suspension: { label: "Suspension",  color: RED,    icon: ShieldBan     },
  hold:       { label: "Temporary Hold", color: PINK, icon: Clock        },
  flag:       { label: "Flagged",     color: GOLD,   icon: ShieldAlert   },
  warning:    { label: "Warning",     color: GOLD,   icon: AlertTriangle },
  violation:  { label: "Violation",   color: RED,    icon: XCircle       },
  info:       { label: "Note",        color: BLUE,   icon: Info          },
  unsuspend:  { label: "Unsuspended", color: GREEN,  icon: CheckCircle2  },
  unflag:     { label: "Unflagged",   color: GREEN,  icon: ShieldCheck   },
};

function InfoRow({ icon: Icon, label, value, color }: { icon: React.ElementType; label: string; value: React.ReactNode; color?: string }) {
  return (
    <div className="flex items-start gap-3 py-3 border-b last:border-0">
      <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
           style={{ background: `${color ?? ASH}18` }}>
        <Icon className="h-3.5 w-3.5" style={{ color: color ?? ASH }} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-xs text-muted-foreground mb-0.5">{label}</div>
        <div className="text-sm font-semibold text-foreground break-all">{value}</div>
      </div>
    </div>
  );
}

export default function UserDetail() {
  const [, params]    = useRoute("/users/:id");
  const id            = params?.id ?? "";
  const queryClient   = useQueryClient();
  const { toast }     = useToast();

  const [holdOpen,    setHoldOpen]    = useState(false);
  const [noteOpen,    setNoteOpen]    = useState(false);
  const [holdDays,    setHoldDays]    = useState("3");
  const [holdReason,  setHoldReason]  = useState("");
  const [noteType,    setNoteType]    = useState("info");
  const [noteText,    setNoteText]    = useState("");
  const [notesExpanded, setNotesExpanded] = useState(true);

  const { data: user, isLoading } = useAdminGetUser(id, {
    query: { queryKey: getAdminGetUserQueryKey(id), enabled: !!id }
  });
  const { data: notes = [] } = useAdminGetUserNotes(id, {
    query: { queryKey: getAdminGetUserNotesQueryKey(id), enabled: !!id }
  });

  const suspendMutation  = useSuspendUser();
  const unsuspendMutation = useUnsuspendUser();
  const flagMutation     = useFlagUser();
  const unflagMutation   = useUnflagUser();
  const holdMutation     = useHoldUser();
  const addNoteMutation  = useAdminAddUserNote();

  const refetch = () => {
    queryClient.invalidateQueries({ queryKey: getAdminGetUserQueryKey(id) });
    queryClient.invalidateQueries({ queryKey: getAdminGetUserNotesQueryKey(id) });
  };

  const doAction = async (action: "suspend" | "unsuspend" | "flag" | "unflag") => {
    try {
      if (action === "suspend")   await suspendMutation.mutateAsync({ id });
      if (action === "unsuspend") await unsuspendMutation.mutateAsync({ id });
      if (action === "flag")      await flagMutation.mutateAsync({ id });
      if (action === "unflag")    await unflagMutation.mutateAsync({ id });
      refetch();
      toast({ title: "Done", description: `Account ${action}d successfully.` });
    } catch { toast({ title: "Error", variant: "destructive" }); }
  };

  const doHold = async () => {
    if (!holdReason.trim()) { toast({ title: "Please enter a reason", variant: "destructive" }); return; }
    try {
      await holdMutation.mutateAsync({ id, data: { days: Number(holdDays), reason: holdReason } });
      refetch();
      setHoldOpen(false);
      setHoldReason("");
      toast({ title: `Account held for ${holdDays} days` });
    } catch { toast({ title: "Error", variant: "destructive" }); }
  };

  const doAddNote = async () => {
    if (!noteText.trim()) { toast({ title: "Please enter note text", variant: "destructive" }); return; }
    try {
      await addNoteMutation.mutateAsync({ id, data: { noteType: noteType as AddAdminNoteInputNoteType, note: noteText } });
      refetch();
      setNoteOpen(false);
      setNoteText("");
      toast({ title: "Note added" });
    } catch { toast({ title: "Error", variant: "destructive" }); }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-48 bg-muted rounded-xl animate-pulse" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2 space-y-4">
            <div className="h-48 rounded-2xl bg-muted animate-pulse" />
            <div className="h-32 rounded-2xl bg-muted animate-pulse" />
          </div>
          <div className="h-64 rounded-2xl bg-muted animate-pulse" />
        </div>
      </div>
    );
  }

  if (!user) return (
    <div className="flex flex-col items-center justify-center h-60 gap-3 text-muted-foreground">
      <ShieldOff className="h-10 w-10 opacity-30" />
      <p>User not found.</p>
    </div>
  );

  const isOnHold = user.isSuspended && user.suspendedUntil;
  const holdUntil = user.suspendedUntil ? new Date(user.suspendedUntil) : null;

  return (
    <div className="space-y-5">
      {/* Back nav */}
      <div className="flex items-center gap-2">
        <Link href="/users">
          <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="h-4 w-4" />
            Users
          </button>
        </Link>
        <span className="text-muted-foreground/40">/</span>
        <span className="text-sm font-medium truncate">{user.fullName}</span>
      </div>

      {/* Profile hero */}
      <div className="relative overflow-hidden rounded-2xl border bg-card shadow-sm"
           style={{ borderColor: `${INDIGO}25` }}>
        <div className="absolute top-0 left-0 right-0 h-1"
             style={{ background: `linear-gradient(90deg,${INDIGO},${PINK})` }} />
        <div className="p-6">
          <div className="flex items-start gap-5 flex-wrap">
            {/* Avatar */}
            <div className="relative shrink-0">
              {user.avatarUrl ? (
                <img src={user.avatarUrl} alt="" className="w-20 h-20 rounded-2xl object-cover" />
              ) : (
                <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-bold text-white"
                     style={{ background: `linear-gradient(135deg,${INDIGO},${PINK})` }}>
                  {user.fullName?.[0]?.toUpperCase() ?? "?"}
                </div>
              )}
              <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-background flex items-center justify-center`}
                   style={{ background: user.isSuspended ? RED : user.isFlagged ? GOLD : GREEN }}>
                <div className="w-2 h-2 rounded-full bg-white" />
              </div>
            </div>

            {/* Name + badges */}
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-extrabold tracking-tight mb-1">{user.fullName}</h1>
              <p className="text-muted-foreground text-sm font-mono mb-3">{user.phone}</p>
              <div className="flex flex-wrap gap-2">
                {user.isKycVerified && (
                  <span className="badge-green flex items-center gap-1" style={{ background:`${GREEN}15`, color:GREEN, border:`1px solid ${GREEN}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    <ShieldCheck className="h-3 w-3" /> KYC Verified
                  </span>
                )}
                {user.isVendor && (
                  <span style={{ background:`${BLUE}15`, color:BLUE, border:`1px solid ${BLUE}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    Vendor
                  </span>
                )}
                {isOnHold ? (
                  <span style={{ background:`${PINK}15`, color:PINK, border:`1px solid ${PINK}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    <Clock className="h-3 w-3 inline mr-1" />
                    Held until {holdUntil?.toLocaleDateString()}
                  </span>
                ) : user.isSuspended ? (
                  <span style={{ background:`${RED}15`, color:RED, border:`1px solid ${RED}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    Permanently Suspended
                  </span>
                ) : null}
                {user.isFlagged && (
                  <span style={{ background:`${GOLD}15`, color:GOLD, border:`1px solid ${GOLD}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    <ShieldAlert className="h-3 w-3 inline mr-1" />
                    Flagged
                  </span>
                )}
                {!user.isSuspended && !user.isFlagged && !user.isKycVerified && (
                  <span style={{ background:`${ASH}15`, color:ASH, border:`1px solid ${ASH}35`, borderRadius:9999, padding:"3px 10px", fontSize:"0.75rem", fontWeight:600 }}>
                    Unverified
                  </span>
                )}
              </div>
            </div>

            {/* Quick financials */}
            <div className="flex gap-4 shrink-0">
              <div className="rounded-xl border px-4 py-3 text-center min-w-[100px]"
                   style={{ borderColor:`${GOLD}30`, background:`${GOLD}08` }}>
                <div className="text-lg font-extrabold" style={{ color: GOLD }}>{formatGHS(user.walletBalancePesewas)}</div>
                <div className="text-xs text-muted-foreground mt-0.5">Balance</div>
              </div>
              <div className="rounded-xl border px-4 py-3 text-center min-w-[80px]"
                   style={{ borderColor:`${BLUE}30`, background:`${BLUE}08` }}>
                <div className="text-lg font-extrabold" style={{ color: BLUE }}>{user.transactionCount}</div>
                <div className="text-xs text-muted-foreground mt-0.5">Transactions</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: Account details + Actions */}
        <div className="lg:col-span-2 space-y-5">
          {/* Account Info */}
          <div className="rounded-2xl border bg-card shadow-sm overflow-hidden"
               style={{ borderColor:`${INDIGO}20` }}>
            <div className="px-5 py-4 border-b flex items-center gap-2"
                 style={{ borderColor:`${INDIGO}15` }}>
              <User className="h-4 w-4" style={{ color: INDIGO }} />
              <span className="font-semibold text-sm">Account Details</span>
            </div>
            <div className="px-5 py-1">
              <InfoRow icon={Phone}       label="Phone Number"   value={user.phone}                               color={BLUE}   />
              <InfoRow icon={Mail}        label="Email"          value={user.email ?? <span className="text-muted-foreground italic">Not provided</span>} color={PINK} />
              <InfoRow icon={CreditCard}  label="Ghana Card ID"  value={user.ghanaCardId ?? <span className="text-muted-foreground italic">Not provided</span>} color={GOLD} />
              <InfoRow icon={CalendarDays} label="Joined"        value={formatDate(user.createdAt)}               color={INDIGO} />
              <InfoRow icon={ShieldCheck}  label="KYC Status"    value={user.isKycVerified ? "Verified" : "Not verified"} color={user.isKycVerified ? GREEN : ASH} />
              <InfoRow icon={User}         label="Account ID"    value={<span className="font-mono text-xs">{user.id}</span>} color={ASH} />
              <div className="py-3 flex items-center gap-3 border-b last:border-0">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                     style={{ background: `${ASH}18` }}>
                  <ShieldOff className="h-3.5 w-3.5" style={{ color: ASH }} />
                </div>
                <div className="flex-1">
                  <div className="text-xs text-muted-foreground mb-0.5">PIN / Password</div>
                  <div className="text-sm text-muted-foreground italic">Hidden for security — cannot be revealed</div>
                </div>
              </div>
            </div>
          </div>

          {/* Actions Panel */}
          <div className="rounded-2xl border bg-card shadow-sm overflow-hidden"
               style={{ borderColor:`${PINK}20` }}>
            <div className="px-5 py-4 border-b flex items-center gap-2"
                 style={{ borderColor:`${PINK}15` }}>
              <ShieldBan className="h-4 w-4" style={{ color: PINK }} />
              <span className="font-semibold text-sm">Account Actions</span>
            </div>
            <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Flag / Unflag */}
              <button
                onClick={() => doAction(user.isFlagged ? "unflag" : "flag")}
                disabled={flagMutation.isPending || unflagMutation.isPending}
                className="flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-all hover:shadow-md disabled:opacity-50 cursor-pointer"
                style={{ borderColor:`${GOLD}35`, background:`${GOLD}08`, color: GOLD }}
              >
                <ShieldAlert className="h-4 w-4" />
                {user.isFlagged ? "Remove Flag" : "Flag for Review"}
              </button>

              {/* Hold */}
              <Dialog open={holdOpen} onOpenChange={setHoldOpen}>
                <DialogTrigger asChild>
                  <button
                    className="flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-all hover:shadow-md cursor-pointer"
                    style={{ borderColor:`${PINK}35`, background:`${PINK}08`, color: PINK }}
                  >
                    <Clock className="h-4 w-4" />
                    Hold Account
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-sm">
                  <DialogHeader>
                    <DialogTitle>Hold Account Temporarily</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-2">
                    <div>
                      <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Duration</label>
                      <Select value={holdDays} onValueChange={setHoldDays}>
                        <SelectTrigger className="mt-1.5">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 day</SelectItem>
                          <SelectItem value="3">3 days</SelectItem>
                          <SelectItem value="7">7 days</SelectItem>
                          <SelectItem value="14">14 days</SelectItem>
                          <SelectItem value="30">30 days</SelectItem>
                          <SelectItem value="90">90 days</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Reason</label>
                      <Textarea
                        className="mt-1.5"
                        placeholder="Why is this account being held?"
                        value={holdReason}
                        onChange={e => setHoldReason(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <button
                      onClick={doHold}
                      disabled={holdMutation.isPending}
                      className="w-full rounded-xl py-2.5 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50 cursor-pointer"
                      style={{ background: `linear-gradient(90deg,${PINK},${INDIGO})` }}
                    >
                      {holdMutation.isPending ? "Applying…" : `Hold for ${holdDays} day(s)`}
                    </button>
                  </div>
                </DialogContent>
              </Dialog>

              {/* Suspend / Unsuspend */}
              {user.isSuspended ? (
                <button
                  onClick={() => doAction("unsuspend")}
                  disabled={unsuspendMutation.isPending}
                  className="flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-all hover:shadow-md disabled:opacity-50 cursor-pointer sm:col-span-2"
                  style={{ borderColor:`${GREEN}35`, background:`${GREEN}08`, color: GREEN }}
                >
                  <CheckCircle2 className="h-4 w-4" />
                  {unsuspendMutation.isPending ? "Lifting suspension…" : "Lift Suspension / Unban"}
                </button>
              ) : (
                <button
                  onClick={() => doAction("suspend")}
                  disabled={suspendMutation.isPending}
                  className="flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-all hover:shadow-md disabled:opacity-50 cursor-pointer sm:col-span-2"
                  style={{ borderColor:`${RED}35`, background:`${RED}08`, color: RED }}
                >
                  <ShieldBan className="h-4 w-4" />
                  {suspendMutation.isPending ? "Suspending…" : "Permanently Ban / Suspend"}
                </button>
              )}

              {/* View Transactions */}
              <Link href={`/transactions?search=${user.phone}`} className="sm:col-span-2">
                <button className="w-full flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-semibold transition-all hover:shadow-md cursor-pointer"
                        style={{ borderColor:`${BLUE}35`, background:`${BLUE}08`, color: BLUE }}>
                  <ArrowRightLeft className="h-4 w-4" />
                  View All Transactions
                </button>
              </Link>
            </div>
          </div>
        </div>

        {/* Right: Notes / Reports log */}
        <div className="space-y-5">
          <div className="rounded-2xl border bg-card shadow-sm overflow-hidden"
               style={{ borderColor:`${GOLD}20` }}>
            <div className="px-5 py-4 border-b flex items-center justify-between"
                 style={{ borderColor:`${GOLD}15` }}>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" style={{ color: GOLD }} />
                <span className="font-semibold text-sm">Activity Log</span>
                {notes.length > 0 && (
                  <span className="rounded-full px-2 py-0.5 text-xs font-bold"
                        style={{ background:`${GOLD}20`, color: GOLD }}>
                    {notes.length}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Dialog open={noteOpen} onOpenChange={setNoteOpen}>
                  <DialogTrigger asChild>
                    <button className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors hover:opacity-90 cursor-pointer"
                            style={{ background: INDIGO, color: "white" }}>
                      <Plus className="h-3 w-3" /> Add
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-w-sm">
                    <DialogHeader>
                      <DialogTitle>Add Note / Report</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 pt-2">
                      <div>
                        <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Type</label>
                        <Select value={noteType} onValueChange={setNoteType}>
                          <SelectTrigger className="mt-1.5">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="violation">Violation</SelectItem>
                            <SelectItem value="warning">Warning</SelectItem>
                            <SelectItem value="flag">Flag</SelectItem>
                            <SelectItem value="info">Info / Note</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Details</label>
                        <Textarea
                          className="mt-1.5"
                          placeholder="Describe the issue or note…"
                          value={noteText}
                          onChange={e => setNoteText(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <button
                        onClick={doAddNote}
                        disabled={addNoteMutation.isPending}
                        className="w-full rounded-xl py-2.5 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50 cursor-pointer"
                        style={{ background: `linear-gradient(90deg,${INDIGO},${PINK})` }}
                      >
                        {addNoteMutation.isPending ? "Saving…" : "Save Note"}
                      </button>
                    </div>
                  </DialogContent>
                </Dialog>
                <button onClick={() => setNotesExpanded(x => !x)}
                        className="text-muted-foreground hover:text-foreground transition-colors">
                  <ChevronDown className={`h-4 w-4 transition-transform ${notesExpanded ? "" : "-rotate-90"}`} />
                </button>
              </div>
            </div>

            {notesExpanded && (
              <div className="divide-y" style={{ maxHeight: 520, overflowY: "auto" }}>
                {notes.length === 0 ? (
                  <div className="px-5 py-8 text-center text-sm text-muted-foreground">
                    No activity recorded yet.
                  </div>
                ) : (
                  notes.map((n) => {
                    const meta = NOTE_META[n.noteType] ?? NOTE_META.info;
                    const NoteIcon = meta.icon;
                    return (
                      <div key={n.id} className="px-5 py-4">
                        <div className="flex items-start gap-3">
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                               style={{ background:`${meta.color}18` }}>
                            <NoteIcon className="h-3.5 w-3.5" style={{ color: meta.color }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <span className="text-xs font-bold" style={{ color: meta.color }}>{meta.label}</span>
                              <span className="text-xs text-muted-foreground">{formatDate(n.createdAt)}</span>
                            </div>
                            <p className="text-sm text-foreground/80 leading-relaxed">{n.note}</p>
                            {n.adminEmail && (
                              <p className="text-xs text-muted-foreground mt-1">by {n.adminEmail}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* Wallet card */}
          <div className="rounded-2xl border bg-card shadow-sm p-5"
               style={{ borderColor:`${GOLD}25` }}>
            <div className="flex items-center gap-2 mb-4">
              <Wallet className="h-4 w-4" style={{ color: GOLD }} />
              <span className="font-semibold text-sm">Financials</span>
            </div>
            <div className="rounded-xl p-4 text-center"
                 style={{ background:`linear-gradient(135deg,${GOLD}18,${PINK}10)`, border:`1px solid ${GOLD}25` }}>
              <div className="text-3xl font-extrabold" style={{ color: GOLD }}>
                {formatGHS(user.walletBalancePesewas)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">Wallet Balance</div>
            </div>
            <div className="mt-3 rounded-xl p-3 flex items-center justify-between"
                 style={{ background:`${BLUE}10`, border:`1px solid ${BLUE}20` }}>
              <div className="flex items-center gap-2 text-sm">
                <ArrowRightLeft className="h-3.5 w-3.5" style={{ color: BLUE }} />
                <span className="text-muted-foreground">Transactions</span>
              </div>
              <span className="font-bold text-sm" style={{ color: BLUE }}>{user.transactionCount}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
