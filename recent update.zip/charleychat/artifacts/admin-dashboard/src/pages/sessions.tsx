import { useAdminListSessions, getAdminListSessionsQueryKey, useAdminRevokeSession } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDate } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";

export default function Sessions() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useAdminListSessions({
    query: { queryKey: getAdminListSessionsQueryKey() }
  });

  const revokeMutation = useAdminRevokeSession();

  const handleRevoke = (id: string) => {
    revokeMutation.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListSessionsQueryKey() })
    });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Active Sessions</h1>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User Phone</TableHead>
              <TableHead>Started At</TableHead>
              <TableHead>Expires At</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : data?.length === 0 ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8">No active sessions found.</TableCell></TableRow>
            ) : (
              data?.map(session => (
                <TableRow key={session.id}>
                  <TableCell className="font-medium">{session.userPhone}</TableCell>
                  <TableCell>{formatDate(session.createdAt)}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(session.expiresAt)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="destructive" size="sm" onClick={() => handleRevoke(session.id)} disabled={revokeMutation.isPending}>
                      Revoke
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
