import { useState } from "react";
import { useBroadcastNotification } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

export default function Notifications() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const { toast } = useToast();
  
  const broadcastMutation = useBroadcastNotification();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    broadcastMutation.mutate({ data: { title, body } }, {
      onSuccess: (data) => {
        toast({
          title: "Broadcast Sent",
          description: `Notification sent to ${data.sent} users.`,
        });
        setTitle("");
        setBody("");
      },
      onError: () => {
        toast({
          title: "Broadcast Failed",
          description: "An error occurred while sending the notification.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold tracking-tight">Push Notifications</h1>
      
      <Card>
        <CardHeader>
          <CardTitle>Broadcast Notification</CardTitle>
          <CardDescription>Send a push notification to all active devices.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Notification Title</Label>
              <Input 
                id="title" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                placeholder="System Update" 
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="body">Message Body</Label>
              <Textarea 
                id="body" 
                value={body} 
                onChange={(e) => setBody(e.target.value)} 
                placeholder="FargoPay will be undergoing maintenance..." 
                className="h-32"
                required 
              />
            </div>
            <Button type="submit" className="w-full gap-2" disabled={broadcastMutation.isPending}>
              <Send className="w-4 h-4" />
              {broadcastMutation.isPending ? "Sending Broadcast..." : "Send to All Users"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
