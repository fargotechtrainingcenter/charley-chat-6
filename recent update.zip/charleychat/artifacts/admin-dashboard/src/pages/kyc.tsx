import { useState } from "react";
import { useAdminListKyc, getAdminListKycQueryKey, useAdminApproveKyc, useAdminRejectKyc } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { CheckCircle, XCircle, Clock, Eye, Hash } from "lucide-react";

export default function Kyc() {
  const [status, setStatus] = useState<string>("pending");
  const [viewImage, setViewImage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data, isLoading } = useAdminListKyc({ status: status === "all" ? undefined : status });
  const approveMutation = useAdminApproveKyc();

  const handleApprove = (id: string) => {
    approveMutation.mutate({ id }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListKycQueryKey() })
    });
  };

  const counts = {
    pending: data?.filter(k => k.status === "pending").length ?? 0,
    approved: data?.filter(k => k.status === "approved").length ?? 0,
    rejected: data?.filter(k => k.status === "rejected").length ?? 0,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">KYC Verification</h1>
        <div className="flex gap-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-1"><Clock size={14} className="text-amber-500" /> {counts.pending} pending</span>
          <span className="flex items-center gap-1"><CheckCircle size={14} className="text-emerald-500" /> {counts.approved} approved</span>
          <span className="flex items-center gap-1"><XCircle size={14} className="text-red-500" /> {counts.rejected} rejected</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Submissions</SelectItem>
            <SelectItem value="pending">Pending Review</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Image lightbox */}
      {viewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setViewImage(null)}
        >
          <img src={viewImage} className="max-h-[80vh] max-w-[90vw] rounded-xl object-contain shadow-2xl" alt="Document" />
          <button className="absolute top-4 right-4 text-white opacity-80 hover:opacity-100 text-2xl">✕</button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">Loading KYC submissions…</div>
        ) : !data?.length ? (
          <div className="col-span-full text-center py-12">
            <div className="text-5xl mb-3">🛡️</div>
            <div className="text-muted-foreground">No {status === "all" ? "" : status} KYC submissions found.</div>
          </div>
        ) : (
          data.map(kyc => (
            <div key={kyc.id} className="border rounded-xl bg-card overflow-hidden flex flex-col">
              {/* Header */}
              <div className="p-4 border-b space-y-2">
                <div className="flex justify-between items-start gap-2">
                  <div className="min-w-0">
                    <div className="font-semibold truncate">{(kyc as any).userFullName ?? "Unknown User"}</div>
                    <div className="text-sm text-muted-foreground truncate">
                      {(kyc as any).userPhone ?? ""}
                      {(kyc as any).userFpId ? <span className="ml-1 text-xs font-mono text-muted-foreground/60">· {(kyc as any).userFpId}</span> : ""}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      <span className="capitalize">{kyc.idType?.replace("_", " ")}</span> · <span className="font-mono">{kyc.idNumber}</span>
                    </div>
                  </div>
                  <Badge
                    variant={kyc.status === "pending" ? "secondary" : kyc.status === "approved" ? "default" : "destructive"}
                    className="shrink-0"
                  >
                    {kyc.status === "pending" && <Clock size={10} className="mr-1" />}
                    {kyc.status === "approved" && <CheckCircle size={10} className="mr-1" />}
                    {kyc.status === "rejected" && <XCircle size={10} className="mr-1" />}
                    {kyc.status}
                  </Badge>
                </div>

                {/* Reference number */}
                {(kyc as any).referenceNumber && (
                  <div className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground bg-muted/50 rounded px-2 py-1">
                    <Hash size={10} />
                    {(kyc as any).referenceNumber}
                  </div>
                )}

                <div className="text-xs text-muted-foreground">Submitted: {formatDate(kyc.createdAt)}</div>
                {kyc.reviewedAt && (
                  <div className="text-xs text-muted-foreground">Reviewed: {formatDate(kyc.reviewedAt)}</div>
                )}
                {(kyc as any).rejectionReason && (
                  <div className="text-xs text-red-500 bg-red-50 dark:bg-red-950/20 rounded p-2">
                    Rejection reason: {(kyc as any).rejectionReason}
                  </div>
                )}
              </div>

              {/* Document images */}
              <div className="p-4 grid grid-cols-2 gap-2 bg-muted/30 flex-1">
                <div>
                  <div className="text-xs font-medium mb-1">ID Front</div>
                  <button onClick={() => setViewImage(kyc.idFrontUrl)} className="block w-full">
                    <img
                      src={kyc.idFrontUrl}
                      className="w-full h-24 object-cover rounded-md border bg-muted hover:opacity-90 transition-opacity cursor-zoom-in"
                      alt="ID Front"
                    />
                  </button>
                </div>
                <div>
                  <div className="text-xs font-medium mb-1">ID Back</div>
                  <button onClick={() => setViewImage(kyc.idBackUrl)} className="block w-full">
                    <img
                      src={kyc.idBackUrl}
                      className="w-full h-24 object-cover rounded-md border bg-muted hover:opacity-90 transition-opacity cursor-zoom-in"
                      alt="ID Back"
                    />
                  </button>
                </div>
                {kyc.selfieUrl && (
                  <div className="col-span-2">
                    <div className="text-xs font-medium mb-1">Selfie / Face Verification</div>
                    <button onClick={() => setViewImage(kyc.selfieUrl!)} className="block w-full">
                      <img
                        src={kyc.selfieUrl}
                        className="w-full h-32 object-cover rounded-md border bg-muted hover:opacity-90 transition-opacity cursor-zoom-in"
                        alt="Selfie"
                      />
                    </button>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              {kyc.status === "pending" && (
                <div className="p-4 flex gap-2 border-t bg-card">
                  <Button
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={() => handleApprove(kyc.id)}
                    disabled={approveMutation.isPending}
                  >
                    <CheckCircle size={14} className="mr-1.5" />
                    Approve
                  </Button>
                  <RejectKycModal kycId={kyc.id} onReject={() => queryClient.invalidateQueries({ queryKey: getAdminListKycQueryKey() })} />
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function RejectKycModal({ kycId, onReject }: { kycId: string; onReject: () => void }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const rejectMutation = useAdminRejectKyc();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    rejectMutation.mutate({ id: kycId, data: { reason: reason.trim() } }, {
      onSuccess: () => { setOpen(false); setReason(""); onReject(); }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex-1 text-destructive hover:bg-destructive/10 border-destructive/30">
          <XCircle size={14} className="mr-1.5" />
          Reject
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reject KYC Submission</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Rejection Reason</label>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. ID is blurry, document expired, face doesn't match ID…"
              required
            />
            <p className="text-xs text-muted-foreground">
              This reason will be shown to the user so they can fix and resubmit.
            </p>
          </div>
          <Button type="submit" className="w-full" variant="destructive" disabled={rejectMutation.isPending || !reason.trim()}>
            {rejectMutation.isPending ? "Rejecting…" : "Confirm Rejection"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
