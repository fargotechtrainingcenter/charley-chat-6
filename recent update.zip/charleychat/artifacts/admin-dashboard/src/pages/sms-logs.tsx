import { useState } from "react";
import { useAdminListSmsLogs } from "@workspace/api-client-react";
import { formatDate } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, RefreshCw, AlertCircle } from "lucide-react";

function extractOtpCode(message: string): string | null {
  const match = message.match(/code is:\s*(\d{6})/i);
  return match ? match[1] : null;
}

const purposeLabels: Record<string, string> = {
  registration: "Registration",
  login: "Login",
  password_reset: "Password Reset",
};

const statusVariant = (status: string): "default" | "destructive" | "secondary" | "outline" => {
  if (status === "sent" || status === "delivered") return "default";
  if (status === "simulated") return "secondary";
  if (status === "failed") return "destructive";
  return "outline";
};

export default function SmsLogs() {
  const [phoneFilter, setPhoneFilter] = useState("");
  const { data, isLoading, isError, refetch, isFetching } = useAdminListSmsLogs({ page: 1, limit: 200 });

  const filtered = phoneFilter.trim()
    ? (data ?? []).filter(log => log.phone?.includes(phoneFilter.trim()))
    : (data ?? []);

  const hasDevLogs = (data ?? []).some(l => l.provider === "development");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">SMS Logs</h1>
        <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {hasDevLogs && (
        <div className="flex items-start gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-3 py-2.5 text-sm">
          <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Development Mode active</span> — OTP_DEV_MODE is on or no SMS provider is configured.
            SMS messages are simulated. OTP codes are shown below for admin reference; users do not receive any SMS.
          </div>
        </div>
      )}

      <div className="relative w-72">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by phone number…"
          value={phoneFilter}
          onChange={e => setPhoneFilter(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Phone</TableHead>
              <TableHead>OTP Code</TableHead>
              <TableHead>Purpose</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>Provider</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Sent At</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8">Loading…</TableCell></TableRow>
            ) : isError ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  <div className="flex flex-col items-center gap-2 text-destructive">
                    <AlertCircle className="h-5 w-5" />
                    <span className="font-medium">Could not load SMS logs.</span>
                    <span className="text-muted-foreground text-sm">Your session may have expired — log out and log in again.</span>
                    <Button variant="outline" size="sm" className="mt-1" onClick={() => refetch()}>Try again</Button>
                  </div>
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  {phoneFilter ? `No logs found for "${phoneFilter}"` : "No SMS logs found."}
                </TableCell>
              </TableRow>
            ) : (
              filtered.map(log => {
                const code = extractOtpCode(log.message ?? "");
                return (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium whitespace-nowrap">{log.phone}</TableCell>
                    <TableCell>
                      {code ? (
                        <span className="font-mono font-bold text-base tracking-widest text-emerald-500">{code}</span>
                      ) : (
                        <span className="text-muted-foreground text-xs">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      {log.purpose ? purposeLabels[log.purpose] ?? log.purpose : <span className="text-muted-foreground text-xs">—</span>}
                    </TableCell>
                    <TableCell className="text-sm max-w-xs truncate text-muted-foreground">{log.message}</TableCell>
                    <TableCell>
                      <Badge variant={log.provider === "development" ? "secondary" : "outline"} className="text-xs">
                        {log.provider ?? "unknown"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusVariant(log.status ?? "")}>
                        {log.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground whitespace-nowrap">{formatDate(log.createdAt)}</TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {!isLoading && !isError && data && (
        <p className="text-xs text-muted-foreground">
          Showing {filtered.length} of {data.length} log{data.length !== 1 ? "s" : ""}
        </p>
      )}
    </div>
  );
}
