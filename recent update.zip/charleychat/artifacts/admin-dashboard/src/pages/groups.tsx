import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/format";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Users, Search, ShieldOff, ShieldCheck, Trash2, Lock } from "lucide-react";

interface Group {
  id: string; name: string; description?: string;
  isPaid: boolean; membershipFeePesewas?: number;
  memberCount: number; isSuspended: boolean; createdAt: string;
  ownerName: string; ownerPhone: string;
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function authHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem("charley_admin_token") ?? ""}`, "Content-Type": "application/json" };
}

export default function Groups() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-groups", page],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/groups?page=${page}&limit=30`, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to load groups");
      return res.json() as Promise<{ items: Group[]; total: number; page: number; limit: number }>;
    },
  });

  const suspendMut = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`${BASE}/api/admin/groups/${id}/suspend`, { method: "PATCH", headers: authHeaders(), body: "{}" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-groups"] }); toast({ title: "Group suspended" }); },
  });

  const restoreMut = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`${BASE}/api/admin/groups/${id}/restore`, { method: "PATCH", headers: authHeaders(), body: "{}" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-groups"] }); toast({ title: "Group restored" }); },
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`${BASE}/api/admin/groups/${id}`, { method: "DELETE", headers: authHeaders() });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-groups"] }); toast({ title: "Group deleted" }); },
    onError: () => toast({ title: "Delete failed", variant: "destructive" }),
  });

  const filtered = (data?.items ?? []).filter((g) =>
    !search || g.name.toLowerCase().includes(search.toLowerCase()) || g.ownerName.toLowerCase().includes(search.toLowerCase())
  );

  const fmtGHS = (p?: number) => p ? `GHS ${(p / 100).toFixed(2)}` : "—";

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-7 h-7 text-[#8B5CF6]" />
          <div>
            <h1 className="text-2xl font-bold text-white">Groups</h1>
            <p className="text-[#7B6FA3] text-sm">{data?.total ?? 0} groups on platform</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B6FA3]" />
          <Input
            className="pl-9 w-64 bg-[#0D0B1C] border-[#1E1B3A] text-white"
            placeholder="Search groups or owners…"
            value={search} onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-xl border border-[#1E1B3A] bg-[#0D0B1C] overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-[#1E1B3A] hover:bg-transparent">
              <TableHead className="text-[#7B6FA3]">Group</TableHead>
              <TableHead className="text-[#7B6FA3]">Owner</TableHead>
              <TableHead className="text-[#7B6FA3]">Type</TableHead>
              <TableHead className="text-[#7B6FA3]">Members</TableHead>
              <TableHead className="text-[#7B6FA3]">Status</TableHead>
              <TableHead className="text-[#7B6FA3]">Created</TableHead>
              <TableHead className="text-[#7B6FA3] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center text-[#7B6FA3] py-12">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center text-[#7B6FA3] py-12">No groups found</TableCell></TableRow>
            ) : filtered.map((g) => (
              <TableRow key={g.id} className="border-[#1E1B3A] hover:bg-[#1E1B3A]/30">
                <TableCell>
                  <div>
                    <p className="font-medium text-white">{g.name}</p>
                    {g.description && <p className="text-xs text-[#7B6FA3] truncate max-w-[180px]">{g.description}</p>}
                  </div>
                </TableCell>
                <TableCell>
                  <p className="text-white text-sm">{g.ownerName}</p>
                  <p className="text-[#7B6FA3] text-xs">{g.ownerPhone}</p>
                </TableCell>
                <TableCell>
                  {g.isPaid ? (
                    <div>
                      <Badge className="bg-[#F59E0B]/20 text-[#F59E0B] border-0 text-xs">
                        <Lock className="w-3 h-3 mr-1" /> Paid
                      </Badge>
                      <p className="text-xs text-[#7B6FA3] mt-1">{fmtGHS(g.membershipFeePesewas)}</p>
                    </div>
                  ) : (
                    <Badge className="bg-[#8B5CF6]/20 text-[#8B5CF6] border-0 text-xs">Free</Badge>
                  )}
                </TableCell>
                <TableCell className="text-white font-medium">{g.memberCount}</TableCell>
                <TableCell>
                  {g.isSuspended ? (
                    <Badge className="bg-red-500/20 text-red-400 border-0">Suspended</Badge>
                  ) : (
                    <Badge className="bg-green-500/20 text-green-400 border-0">Active</Badge>
                  )}
                </TableCell>
                <TableCell className="text-[#7B6FA3] text-sm">{formatDate(g.createdAt)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center gap-2 justify-end">
                    {g.isSuspended ? (
                      <Button size="sm" variant="ghost" className="text-green-400 hover:text-green-300 hover:bg-green-500/10"
                        onClick={() => restoreMut.mutate(g.id)}>
                        <ShieldCheck className="w-4 h-4" />
                      </Button>
                    ) : (
                      <Button size="sm" variant="ghost" className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/10"
                        onClick={() => suspendMut.mutate(g.id)}>
                        <ShieldOff className="w-4 h-4" />
                      </Button>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-[#0D0B1C] border-[#1E1B3A]">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">Delete Group?</AlertDialogTitle>
                          <AlertDialogDescription className="text-[#7B6FA3]">
                            Permanently delete "{g.name}" and all its messages? This cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-[#1E1B3A] text-white border-0">Cancel</AlertDialogCancel>
                          <AlertDialogAction className="bg-red-600 hover:bg-red-700"
                            onClick={() => deleteMut.mutate(g.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {(data?.total ?? 0) > 30 && (
        <div className="flex items-center justify-between">
          <p className="text-[#7B6FA3] text-sm">Page {page} of {Math.ceil((data?.total ?? 0) / 30)}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}
              className="border-[#1E1B3A] text-white">Prev</Button>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil((data?.total ?? 0) / 30)} onClick={() => setPage(p => p + 1)}
              className="border-[#1E1B3A] text-white">Next</Button>
          </div>
        </div>
      )}
    </div>
  );
}
