import { useGetAdminStats, getGetAdminStatsQueryKey } from "@workspace/api-client-react";
import { formatGHS } from "@/lib/format";
import { Users, Wallet, ArrowRightLeft, ShieldAlert, ShieldCheck, TrendingUp, ArrowUpRight } from "lucide-react";
import { Link } from "wouter";

const GOLD   = "hsl(43,96%,54%)";
const PINK   = "hsl(330,80%,60%)";
const BLUE   = "hsl(210,88%,54%)";
const INDIGO = "hsl(243,72%,56%)";
const ASH    = "hsl(220,10%,60%)";

function StatCard({
  title, value, sub, icon: Icon, color, bg, urgent,
}: {
  title: string; value: string | number; sub: string;
  icon: React.ElementType; color: string; bg: string; urgent?: boolean;
}) {
  return (
    <div
      className="relative overflow-hidden rounded-2xl border bg-card p-6 shadow-sm transition-shadow hover:shadow-md"
      style={{ borderColor: urgent ? "hsl(0,84%,60%,0.4)" : `${color}30` }}
    >
      {/* Top gradient strip */}
      <div className="absolute top-0 left-0 right-0 h-1 rounded-t-2xl"
           style={{ background: urgent ? "hsl(0,84%,60%)" : color }} />

      {/* Icon badge */}
      <div className="flex items-start justify-between mb-4">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center"
             style={{ background: urgent ? "hsl(0,84%,60%,0.12)" : bg }}>
          <Icon className="h-5 w-5" style={{ color: urgent ? "hsl(0,84%,60%)" : color }} />
        </div>
        <div className="flex items-center gap-1 text-xs font-medium rounded-full px-2 py-1"
             style={{ background: `${color}15`, color }}>
          <TrendingUp className="h-3 w-3" />
          Live
        </div>
      </div>

      {/* Value */}
      <div className="text-3xl font-extrabold tracking-tight mb-1"
           style={{ color: urgent ? "hsl(0,84%,60%)" : undefined }}>
        {value}
      </div>
      <div className="text-sm font-medium text-foreground/80">{title}</div>
      <div className="text-xs text-muted-foreground mt-1">{sub}</div>

      {/* Decorative circle */}
      <div className="absolute -bottom-4 -right-4 w-20 h-20 rounded-full opacity-[0.06]"
           style={{ background: color }} />
    </div>
  );
}

function ActionCard({
  title, value, link, color, icon: Icon, desc,
}: {
  title: string; value: number; link: string; color: string; icon: React.ElementType; desc: string;
}) {
  return (
    <Link href={link}>
      <div className="group relative overflow-hidden rounded-2xl border bg-card p-6 shadow-sm cursor-pointer transition-all hover:shadow-md hover:-translate-y-0.5"
           style={{ borderColor: `${color}25` }}>
        <div className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl transition-all group-hover:h-1"
             style={{ background: color }} />
        <div className="flex items-center justify-between mb-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
               style={{ background: `${color}15` }}>
            <Icon className="h-5 w-5" style={{ color }} />
          </div>
          <ArrowUpRight className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
        </div>
        <div className="text-4xl font-extrabold mb-1" style={{ color }}>{value}</div>
        <div className="text-sm font-semibold text-foreground">{title}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </div>
    </Link>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useGetAdminStats({
    query: { queryKey: getGetAdminStatsQueryKey() }
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="space-y-1">
          <div className="h-9 bg-muted rounded-xl w-72 animate-pulse" />
          <div className="h-4 bg-muted rounded w-48 animate-pulse" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[GOLD, PINK, BLUE, INDIGO].map((c, i) => (
            <div key={i} className="h-40 rounded-2xl animate-pulse border"
                 style={{ background: `${c}08`, borderColor: `${c}20` }} />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[PINK, BLUE, GOLD].map((c, i) => (
            <div key={i} className="h-32 rounded-2xl animate-pulse border"
                 style={{ background: `${c}08`, borderColor: `${c}20` }} />
          ))}
        </div>
      </div>
    );
  }

  if (!stats) return (
    <div className="flex items-center justify-center h-48 text-muted-foreground">
      Failed to load stats.
    </div>
  );

  const statCards = [
    { title: "Total Users",          value: stats.totalUsers,                     sub: `+${stats.newUsersToday} new today`,   icon: Users,          color: PINK,   bg: `${PINK}15`   },
    { title: "Total Revenue",        value: formatGHS(stats.totalRevenuePesewas), sub: "All-time platform earnings",          icon: Wallet,         color: GOLD,   bg: `${GOLD}15`   },
    { title: "Transactions Today",   value: stats.transactionsToday,              sub: "Completed today",                     icon: ArrowRightLeft, color: BLUE,   bg: `${BLUE}15`   },
    { title: "Flagged Users",        value: stats.flaggedUserCount,               sub: "Requires immediate attention",        icon: ShieldAlert,    color: INDIGO, bg: `${INDIGO}15`, urgent: stats.flaggedUserCount > 0 },
  ];

  return (
    <div className="space-y-8">
      {/* Page header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight"
              style={{ background: `linear-gradient(90deg,${INDIGO},${PINK})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            Control Room
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">Real-time platform metrics — live data from FargoPay</p>
        </div>
        <div className="hidden md:flex items-center gap-2 rounded-full border px-4 py-2 text-xs text-muted-foreground bg-card shadow-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          All systems operational
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((c, i) => <StatCard key={i} {...c} />)}
      </div>

      {/* Divider label */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1" style={{ background: `linear-gradient(90deg,${GOLD}40,transparent)` }} />
        <span className="text-xs font-semibold tracking-widest uppercase text-muted-foreground">Action Queues</span>
        <div className="h-px flex-1" style={{ background: `linear-gradient(90deg,transparent,${PINK}40)` }} />
      </div>

      {/* Action cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ActionCard title="Pending KYC"      value={stats.pendingKycCount}    link="/kyc"     color={PINK}  icon={ShieldCheck}  desc="Identity verifications awaiting review" />
        <ActionCard title="Active Escrows"   value={stats.activeEscrowCount}  link="/escrow"  color={GOLD}  icon={Wallet}       desc="Funds currently held in escrow" />
      </div>
    </div>
  );
}
