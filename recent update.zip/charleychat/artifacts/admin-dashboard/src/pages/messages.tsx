import {
  useAdminListMessages,
  getAdminListMessagesQueryKey,
  useAdminDeleteMessage,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trash2, Search, Image, Mic, DollarSign, MessageSquare } from "lucide-react";
import { formatDate } from "@/lib/format";

const TYPE_META: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  text:            { label: "Text",          icon: <MessageSquare className="h-3 w-3" />, color: "text-blue-400"   },
  image:           { label: "Image",         icon: <Image className="h-3 w-3" />,         color: "text-pink-400"   },
  voice_note:      { label: "Voice",         icon: <Mic className="h-3 w-3" />,           color: "text-purple-400" },
  payment_request: { label: "Pay Request",   icon: <DollarSign className="h-3 w-3" />,    color: "text-emerald-400"},
};

export default function Messages() {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [userId, setUserId] = useState("");
  const [search, setSearch] = useState("");

  const { data, isLoading } = useAdminListMessages(
    { page, limit: 30, userId: userId || undefined },
    { query: { queryKey: getAdminListMessagesQueryKey({ page, limit: 30, userId: userId || undefined }) } }
  );

  const deleteMut = useAdminDeleteMessage();

  const handleDelete = (id: string) => {
    if (!confirm("Permanently delete this message?")) return;
    deleteMut.mutate(
      { id },
      {
        onSuccess: () =>
          queryClient.invalidateQueries({
            queryKey: getAdminListMessagesQueryKey({ page, limit: 30, userId: userId || undefined }),
          }),
      }
    );
  };

  const handleSearch = () => {
    setUserId(search.trim());
    setPage(1);
  };

  const items: any[] = (data as any)?.items ?? [];
  const total: number = (data as any)?.total ?? 0;
  const totalPages = Math.ceil(total / 30);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Message Monitoring</h1>
        <p className="text-muted-foreground text-sm mt-1">
          View and moderate all platform messages. Filter by user ID to see a specific conversation.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Messages</div>
          <div className="text-2xl font-bold">{total.toLocaleString()}</div>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">This Page</div>
          <div className="text-2xl font-bold">{items.length}</div>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">With Media</div>
          <div className="text-2xl font-bold text-pink-500">
            {items.filter((m) => m.messageType === "image" || m.messageType === "voice_note").length}
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <div className="flex-1 flex gap-2">
          <Input
            placeholder="Filter by user ID (paste UUID)…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            className="font-mono text-sm"
          />
          <Button variant="outline" onClick={handleSearch}>
            <Search className="h-4 w-4 mr-1" />
            Filter
          </Button>
          {userId && (
            <Button
              variant="ghost"
              onClick={() => { setUserId(""); setSearch(""); setPage(1); }}
            >
              Clear
            </Button>
          )}
        </div>
      </div>

      {userId && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-lg px-3 py-2">
          <span>Showing messages involving user:</span>
          <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">{userId}</code>
        </div>
      )}

      <div className="rounded-xl border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type</TableHead>
              <TableHead>From</TableHead>
              <TableHead>To</TableHead>
              <TableHead>Content</TableHead>
              <TableHead>Read</TableHead>
              <TableHead>Sent</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                  Loading messages…
                </TableCell>
              </TableRow>
            ) : !items.length ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                  No messages found.
                </TableCell>
              </TableRow>
            ) : (
              items.map((msg: any) => {
                const meta = TYPE_META[msg.messageType] ?? TYPE_META["text"];
                return (
                  <TableRow key={msg.id}>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`gap-1 ${meta.color} border-current/30`}
                      >
                        {meta.icon}
                        {meta.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs font-mono">{msg.senderId?.slice(0, 8)}…</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs font-mono">{msg.receiverId?.slice(0, 8)}…</span>
                    </TableCell>
                    <TableCell className="max-w-[260px]">
                      {msg.mediaUrl ? (
                        <a
                          href={msg.mediaUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-xs text-blue-400 hover:underline flex items-center gap-1"
                        >
                          <Image className="h-3 w-3" />
                          View media
                        </a>
                      ) : (
                        <span className="text-sm truncate block max-w-[260px]">
                          {msg.content || <em className="text-muted-foreground">empty</em>}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>
                      {msg.isRead ? (
                        <Badge variant="outline" className="text-emerald-500 border-emerald-500/30 text-[10px]">
                          Read
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-amber-500 border-amber-500/30 text-[10px]">
                          Unread
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {formatDate(msg.createdAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        onClick={() => handleDelete(msg.id)}
                        disabled={deleteMut.isPending}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">
            Page {page} of {totalPages} · {total.toLocaleString()} total
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
