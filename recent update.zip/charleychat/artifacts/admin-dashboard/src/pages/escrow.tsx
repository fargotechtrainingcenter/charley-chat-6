import { useState } from "react";
import { useAdminListEscrow, getAdminListEscrowQueryKey, useAdminResolveDispute } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatGHS, formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export default function Escrow() {
  const [status, setStatus] = useState<string>("all");
  const queryClient = useQueryClient();

  const { data, isLoading } = useAdminListEscrow({ status: status === "all" ? undefined : status });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Escrow Operations</h1>
      
      <div className="flex items-center gap-4">
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="locked">Locked</SelectItem>
            <SelectItem value="disputed">Disputed</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="refunded">Refunded</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : data?.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">No escrows found.</TableCell></TableRow>
            ) : (
              data?.map(escrow => (
                <TableRow key={escrow.id}>
                  <TableCell className="font-medium">
                    {escrow.title}
                    <div className="text-xs text-muted-foreground truncate max-w-xs">{escrow.description}</div>
                  </TableCell>
                  <TableCell className="font-medium">{formatGHS(escrow.amountPesewas)}</TableCell>
                  <TableCell>
                    <Badge variant={escrow.status === 'disputed' ? 'destructive' : escrow.status === 'locked' ? 'default' : 'secondary'}>
                      {escrow.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDate(escrow.dueDate)}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(escrow.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    {escrow.status === 'disputed' && (
                      <ResolveDisputeModal escrowId={escrow.id} onResolved={() => queryClient.invalidateQueries({ queryKey: getAdminListEscrowQueryKey() })} />
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function ResolveDisputeModal({ escrowId, onResolved }: { escrowId: string, onResolved: () => void }) {
  const [open, setOpen] = useState(false);
  const [resolution, setResolution] = useState<"release" | "refund">("release");
  const [adminNote, setAdminNote] = useState("");
  const resolveMutation = useAdminResolveDispute();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    resolveMutation.mutate({ id: escrowId, data: { resolution, adminNote } }, {
      onSuccess: () => {
        setOpen(false);
        onResolved();
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="destructive" size="sm">Resolve Dispute</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Resolve Escrow Dispute</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Resolution Action</label>
            <Select value={resolution} onValueChange={(v: any) => setResolution(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="release">Release funds to Seller</SelectItem>
                <SelectItem value="refund">Refund funds to Buyer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Resolution Notes (Internal)</label>
            <Textarea value={adminNote} onChange={(e) => setAdminNote(e.target.value)} placeholder="Reason for this decision..." />
          </div>
          <Button type="submit" className="w-full" variant="destructive" disabled={resolveMutation.isPending}>Execute Resolution</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
