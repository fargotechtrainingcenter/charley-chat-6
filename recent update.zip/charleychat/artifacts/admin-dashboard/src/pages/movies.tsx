import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/format";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Film, Plus, Trash2, Upload, Eye } from "lucide-react";

interface Movie {
  id: string;
  title: string;
  description: string | null;
  posterUrl: string | null;
  videoUrl: string;
  genre: string | null;
  releaseYear: number | null;
  durationMinutes: number | null;
  rating: number | null;
  isPremium: boolean;
  isPublished: boolean;
  viewCount: number;
  createdAt: string;
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function authHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem("charley_admin_token") ?? ""}`, "Content-Type": "application/json" };
}

/** Uploads a file via the shared presigned-URL flow, reporting progress. Returns the servable URL. */
async function uploadFile(file: File, onProgress: (pct: number) => void): Promise<string> {
  const reqRes = await fetch(`${BASE}/api/storage/uploads/request-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
  });
  if (!reqRes.ok) throw new Error("Failed to get upload URL");
  const { uploadURL, objectPath } = await reqRes.json();

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", uploadURL);
    xhr.setRequestHeader("Content-Type", file.type);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
    xhr.onload = () => (xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`Upload failed: ${xhr.status}`)));
    xhr.onerror = () => reject(new Error("Upload network error"));
    xhr.send(file);
  });

  const objectKey = String(objectPath).split("/").pop();
  return `${window.location.origin}${BASE}/api/storage/objects/uploads/${objectKey}`;
}

function AddMovieDialog() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [genre, setGenre] = useState("");
  const [releaseYear, setReleaseYear] = useState("");
  const [durationMinutes, setDurationMinutes] = useState("");
  const [rating, setRating] = useState("");
  const [isPremium, setIsPremium] = useState(true);
  const [posterUrl, setPosterUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [posterProgress, setPosterProgress] = useState<number | null>(null);
  const [videoProgress, setVideoProgress] = useState<number | null>(null);
  const posterInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setTitle(""); setDescription(""); setGenre(""); setReleaseYear(""); setDurationMinutes("");
    setRating(""); setIsPremium(true); setPosterUrl(null); setVideoUrl(null);
    setPosterProgress(null); setVideoProgress(null);
  };

  const handlePosterSelect = async (file: File) => {
    setPosterProgress(0);
    try {
      const url = await uploadFile(file, setPosterProgress);
      setPosterUrl(url);
    } catch {
      toast({ title: "Poster upload failed", variant: "destructive" });
    } finally {
      setPosterProgress(null);
    }
  };

  const handleVideoSelect = async (file: File) => {
    setVideoProgress(0);
    try {
      const url = await uploadFile(file, setVideoProgress);
      setVideoUrl(url);
    } catch {
      toast({ title: "Video upload failed", variant: "destructive" });
    } finally {
      setVideoProgress(null);
    }
  };

  const createMut = useMutation({
    mutationFn: async () => {
      if (!videoUrl) throw new Error("Please upload the video file first");
      const res = await fetch(`${BASE}/api/admin/movies`, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
          title,
          description: description || undefined,
          posterUrl: posterUrl || undefined,
          videoUrl,
          genre: genre || undefined,
          releaseYear: releaseYear ? Number(releaseYear) : undefined,
          durationMinutes: durationMinutes ? Number(durationMinutes) : undefined,
          rating: rating ? Math.round(Number(rating) * 10) : undefined,
          isPremium,
          isPublished: true,
        }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? "Failed to create movie");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-movies"] });
      toast({ title: "Movie added", description: `"${title}" is now live for users.` });
      reset();
      setOpen(false);
    },
    onError: (err: Error) => toast({ title: "Couldn't add movie", description: err.message, variant: "destructive" }),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4 mr-2" />Add Movie</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add a Movie</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ghana Nights" />
          </div>
          <div>
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label>Genre</Label>
              <Input value={genre} onChange={(e) => setGenre(e.target.value)} placeholder="Drama" />
            </div>
            <div>
              <Label>Release year</Label>
              <Input type="number" value={releaseYear} onChange={(e) => setReleaseYear(e.target.value)} placeholder="2025" />
            </div>
            <div>
              <Label>Duration (min)</Label>
              <Input type="number" value={durationMinutes} onChange={(e) => setDurationMinutes(e.target.value)} placeholder="110" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 items-end">
            <div>
              <Label>Rating (0–5)</Label>
              <Input type="number" step="0.1" min="0" max="5" value={rating} onChange={(e) => setRating(e.target.value)} placeholder="4.2" />
            </div>
            <div className="flex items-center gap-2 pb-2">
              <Switch checked={isPremium} onCheckedChange={setIsPremium} id="premium" />
              <Label htmlFor="premium">Requires subscription</Label>
            </div>
          </div>

          <div>
            <Label>Poster image (optional)</Label>
            <input ref={posterInputRef} type="file" accept="image/*" className="hidden"
              onChange={(e) => e.target.files?.[0] && handlePosterSelect(e.target.files[0])} />
            <Button type="button" variant="outline" className="w-full mt-1" onClick={() => posterInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-2" />
              {posterUrl ? "Poster uploaded ✓" : "Choose poster image"}
            </Button>
            {posterProgress !== null && <Progress value={posterProgress * 100} className="mt-2" />}
          </div>

          <div>
            <Label>Video file</Label>
            <input ref={videoInputRef} type="file" accept="video/*" className="hidden"
              onChange={(e) => e.target.files?.[0] && handleVideoSelect(e.target.files[0])} />
            <Button type="button" variant="outline" className="w-full mt-1" onClick={() => videoInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-2" />
              {videoUrl ? "Video uploaded ✓" : "Choose video file"}
            </Button>
            {videoProgress !== null && <Progress value={videoProgress * 100} className="mt-2" />}
          </div>
        </div>
        <DialogFooter>
          <Button
            onClick={() => createMut.mutate()}
            disabled={!title || !videoUrl || createMut.isPending || posterProgress !== null || videoProgress !== null}
          >
            {createMut.isPending ? "Adding…" : "Add Movie"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function Movies() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-movies"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/movies`, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to load movies");
      return res.json() as Promise<Movie[]>;
    },
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`${BASE}/api/admin/movies/${id}`, { method: "DELETE", headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-movies"] }); toast({ title: "Movie deleted" }); },
  });

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Film className="h-6 w-6 text-indigo-600" />
          <h1 className="text-2xl font-bold">Movies</h1>
        </div>
        <AddMovieDialog />
      </div>

      <div className="rounded-lg border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Genre</TableHead>
              <TableHead>Year</TableHead>
              <TableHead>Access</TableHead>
              <TableHead>Views</TableHead>
              <TableHead>Added</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">Loading…</TableCell></TableRow>
            )}
            {!isLoading && (data?.length ?? 0) === 0 && (
              <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">No movies uploaded yet.</TableCell></TableRow>
            )}
            {data?.map((m) => (
              <TableRow key={m.id}>
                <TableCell className="font-medium">{m.title}</TableCell>
                <TableCell>{m.genre ?? "—"}</TableCell>
                <TableCell>{m.releaseYear ?? "—"}</TableCell>
                <TableCell>
                  <Badge variant={m.isPremium ? "default" : "secondary"}>
                    {m.isPremium ? "Premium" : "Free"}
                  </Badge>
                </TableCell>
                <TableCell><div className="flex items-center gap-1"><Eye className="h-3.5 w-3.5 text-muted-foreground" />{m.viewCount}</div></TableCell>
                <TableCell>{formatDate(m.createdAt)}</TableCell>
                <TableCell className="text-right">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete "{m.title}"?</AlertDialogTitle>
                        <AlertDialogDescription>This removes it from the catalog immediately. This can't be undone.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => deleteMut.mutate(m.id)}>Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
