import { useState } from "react";
import { useAdminListUsers, getAdminListUsersQueryKey, useSuspendUser, useUnsuspendUser, useFlagUser, useUnflagUser } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { formatDate, formatGHS } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Users() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();

  const params = { search, status: status === "all" ? undefined : status, page, limit: 20 };
  const { data, isLoading } = useAdminListUsers(params);

  const suspendMutation = useSuspendUser();
  const unsuspendMutation = useUnsuspendUser();
  const flagMutation = useFlagUser();
  const unflagMutation = useUnflagUser();

  const handleAction = async (action: 'suspend' | 'unsuspend' | 'flag' | 'unflag', id: string) => {
    try {
      if (action === 'suspend') await suspendMutation.mutateAsync({ id });
      if (action === 'unsuspend') await unsuspendMutation.mutateAsync({ id });
      if (action === 'flag') await flagMutation.mutateAsync({ id });
      if (action === 'unflag') await unflagMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Users</h1>
      
      <div className="flex items-center gap-4">
        <Input 
          placeholder="Search phone or name..." 
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            <SelectItem value="suspended">Suspended</SelectItem>
            <SelectItem value="flagged">Flagged</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Balance</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : data?.items.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">No users found.</TableCell></TableRow>
            ) : (
              data?.items.map(user => (
                <TableRow key={user.id}>
                  <TableCell>
                    <Link href={`/users/${user.id}`} className="font-medium hover:underline text-primary">
                      {user.fullName}
                    </Link>
                  </TableCell>
                  <TableCell>{user.phone}</TableCell>
                  <TableCell>{formatGHS(user.walletBalancePesewas)}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      {user.isSuspended && <Badge variant="destructive">Suspended</Badge>}
                      {user.isFlagged && <Badge variant="outline" className="text-amber-500 border-amber-500">Flagged</Badge>}
                      {user.isKycVerified && <Badge variant="outline" className="text-green-500 border-green-500">KYC</Badge>}
                      {!user.isSuspended && !user.isFlagged && !user.isKycVerified && <Badge variant="secondary">Normal</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(user.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleAction(user.isFlagged ? 'unflag' : 'flag', user.id)}>
                        {user.isFlagged ? 'Unflag' : 'Flag'}
                      </Button>
                      <Button variant={user.isSuspended ? "outline" : "destructive"} size="sm" onClick={() => handleAction(user.isSuspended ? 'unsuspend' : 'suspend', user.id)}>
                        {user.isSuspended ? 'Unsuspend' : 'Suspend'}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
