import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatGHS } from "@/lib/format";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { FileText, Search, Trash2, CheckCircle2, Clock, AlertCircle } from "lucide-react";

interface Invoice {
  id: string; invoiceNumber: string; clientName: string;
  totalPesewas: number; status: string; isPdfGenerated: boolean;
  generationFeePaidAt?: string; createdAt: string;
  userName: string; userPhone: string;
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function authHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem("charley_admin_token") ?? ""}`, "Content-Type": "application/json" };
}

const statusConfig: Record<string, { label: string; className: string }> = {
  draft:     { label: "Draft",     className: "bg-gray-500/20 text-gray-400" },
  unpaid:    { label: "Unpaid",    className: "bg-yellow-500/20 text-yellow-400" },
  paid:      { label: "Paid",      className: "bg-green-500/20 text-green-400" },
  overdue:   { label: "Overdue",   className: "bg-red-500/20 text-red-400" },
  cancelled: { label: "Cancelled", className: "bg-gray-500/20 text-gray-500" },
};

export default function Invoices() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-invoices", page],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/invoices?page=${page}&limit=30`, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to load invoices");
      return res.json() as Promise<{ items: Invoice[]; total: number; page: number; limit: number; generationRevenuePesewas: number }>;
    },
  });

  const deleteMut = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`${BASE}/api/admin/invoices/${id}`, { method: "DELETE", headers: authHeaders() });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["admin-invoices"] }); toast({ title: "Invoice deleted" }); },
    onError: () => toast({ title: "Delete failed", variant: "destructive" }),
  });

  const filtered = (data?.items ?? []).filter((i) =>
    !search ||
    i.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
    i.clientName.toLowerCase().includes(search.toLowerCase()) ||
    i.userName.toLowerCase().includes(search.toLowerCase())
  );

  const totalRevenue = data?.generationRevenuePesewas ?? 0;

  const statuses = ["draft", "unpaid", "paid", "overdue"] as const;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileText className="w-7 h-7 text-[#8B5CF6]" />
          <div>
            <h1 className="text-2xl font-bold text-white">Invoices</h1>
            <p className="text-[#7B6FA3] text-sm">
              {data?.total ?? 0} invoices · {formatGHS(totalRevenue)} platform revenue
            </p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B6FA3]" />
          <Input
            className="pl-9 w-64 bg-[#0D0B1C] border-[#1E1B3A] text-white"
            placeholder="Search invoices…"
            value={search} onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {statuses.map(s => {
          const cfg = statusConfig[s]!;
          const cnt = (data?.items ?? []).filter(i => i.status === s).length;
          return (
            <div key={s} className="bg-[#0D0B1C] border border-[#1E1B3A] rounded-xl p-4">
              <p className="text-[#7B6FA3] text-xs uppercase tracking-wide">{cfg.label}</p>
              <p className="text-2xl font-bold text-white mt-1">{cnt}</p>
            </div>
          );
        })}
      </div>

      <div className="rounded-xl border border-[#1E1B3A] bg-[#0D0B1C] overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-[#1E1B3A] hover:bg-transparent">
              <TableHead className="text-[#7B6FA3]">Invoice #</TableHead>
              <TableHead className="text-[#7B6FA3]">Creator</TableHead>
              <TableHead className="text-[#7B6FA3]">Client</TableHead>
              <TableHead className="text-[#7B6FA3]">Amount</TableHead>
              <TableHead className="text-[#7B6FA3]">Status</TableHead>
              <TableHead className="text-[#7B6FA3]">PDF</TableHead>
              <TableHead className="text-[#7B6FA3]">Date</TableHead>
              <TableHead className="text-[#7B6FA3] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="text-center text-[#7B6FA3] py-12">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center text-[#7B6FA3] py-12">No invoices found</TableCell></TableRow>
            ) : filtered.map((inv) => {
              const cfg = statusConfig[inv.status] ?? statusConfig["draft"]!;
              return (
                <TableRow key={inv.id} className="border-[#1E1B3A] hover:bg-[#1E1B3A]/30">
                  <TableCell className="font-mono text-[#8B5CF6] text-sm font-medium">{inv.invoiceNumber}</TableCell>
                  <TableCell>
                    <p className="text-white text-sm">{inv.userName}</p>
                    <p className="text-[#7B6FA3] text-xs">{inv.userPhone}</p>
                  </TableCell>
                  <TableCell className="text-white text-sm">{inv.clientName}</TableCell>
                  <TableCell className="text-white font-medium">{formatGHS(inv.totalPesewas)}</TableCell>
                  <TableCell>
                    <Badge className={`${cfg.className} border-0 text-xs`}>{cfg.label}</Badge>
                  </TableCell>
                  <TableCell>
                    {inv.isPdfGenerated
                      ? <Badge className="bg-green-500/20 text-green-400 border-0 text-xs">Generated</Badge>
                      : inv.generationFeePaidAt
                        ? <Badge className="bg-yellow-500/20 text-yellow-400 border-0 text-xs">Fee Paid</Badge>
                        : <Badge className="bg-gray-500/20 text-gray-400 border-0 text-xs">Draft</Badge>
                    }
                  </TableCell>
                  <TableCell className="text-[#7B6FA3] text-sm">{formatDate(inv.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-[#0D0B1C] border-[#1E1B3A]">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-white">Delete Invoice?</AlertDialogTitle>
                          <AlertDialogDescription className="text-[#7B6FA3]">
                            Permanently delete invoice {inv.invoiceNumber}? This cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-[#1E1B3A] text-white border-0">Cancel</AlertDialogCancel>
                          <AlertDialogAction className="bg-red-600 hover:bg-red-700"
                            onClick={() => deleteMut.mutate(inv.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {(data?.total ?? 0) > 30 && (
        <div className="flex items-center justify-between">
          <p className="text-[#7B6FA3] text-sm">Page {page} of {Math.ceil((data?.total ?? 0) / 30)}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}
              className="border-[#1E1B3A] text-white">Prev</Button>
            <Button variant="outline" size="sm" disabled={page >= Math.ceil((data?.total ?? 0) / 30)} onClick={() => setPage(p => p + 1)}
              className="border-[#1E1B3A] text-white">Next</Button>
          </div>
        </div>
      )}
    </div>
  );
}
