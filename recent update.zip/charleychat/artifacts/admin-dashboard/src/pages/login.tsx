import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAdminLogin } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Lock, Mail, ArrowRight, Shield } from "lucide-react";

const BASE = import.meta.env.BASE_URL;

export default function Login() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [_, setLocation]        = useLocation();

  // Already authenticated → skip login screen and go straight to dashboard
  useEffect(() => {
    if (localStorage.getItem("charley_admin_token")) {
      setLocation("/dashboard");
    }
  }, [setLocation]);
  const { toast }               = useToast();
  const loginMutation           = useAdminLogin();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ data: { email, password } }, {
      onSuccess: (data) => {
        localStorage.setItem("charley_admin_token", data.accessToken);
        setLocation("/dashboard");
      },
      onError: () => {
        toast({ title: "Login failed", description: "Invalid credentials or unauthorized access.", variant: "destructive" });
      },
    });
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 relative overflow-hidden"
         style={{ background: "hsl(243,55%,10%)" }}>

      {/* Background blobs */}
      <div className="absolute top-[-10%] left-[-5%] w-[500px] h-[500px] rounded-full opacity-20 blur-3xl"
           style={{ background: "radial-gradient(circle, hsl(243,72%,56%), transparent 70%)" }} />
      <div className="absolute bottom-[-10%] right-[-5%] w-[400px] h-[400px] rounded-full opacity-15 blur-3xl"
           style={{ background: "radial-gradient(circle, hsl(330,80%,60%), transparent 70%)" }} />
      <div className="absolute top-[40%] right-[20%] w-[300px] h-[300px] rounded-full opacity-10 blur-3xl"
           style={{ background: "radial-gradient(circle, hsl(43,96%,54%), transparent 70%)" }} />

      {/* Card */}
      <div className="relative w-full max-w-md rounded-3xl overflow-hidden shadow-2xl"
           style={{ background: "hsl(243,45%,14%)", border: "1px solid hsl(243,30%,24%)" }}>

        {/* Top gradient bar */}
        <div className="h-1.5 w-full"
             style={{ background: "linear-gradient(90deg, hsl(43,96%,54%), hsl(330,80%,60%), hsl(243,72%,56%))" }} />

        <div className="p-8">
          {/* Brand */}
          <div className="flex flex-col items-center mb-8">
            <img
              src={`${BASE}charley-icon.png`}
              alt="FargoPay"
              className="w-16 h-16 object-contain rounded-2xl mb-3"
            />
            <span className="text-white font-extrabold text-2xl tracking-tight mb-1">FargoPay</span>
            <p className="text-sm" style={{ color: "hsl(220,10%,55%)" }}>Admin Console · Authorised Personnel Only</p>
          </div>

          {/* Security badge */}
          <div className="flex items-center gap-2 rounded-xl px-4 py-2.5 mb-6"
               style={{ background: "hsl(243,40%,18%)", border: "1px solid hsl(243,30%,26%)" }}>
            <Shield className="h-4 w-4 shrink-0" style={{ color: "hsl(43,96%,54%)" }} />
            <span className="text-xs" style={{ color: "hsl(220,10%,60%)" }}>
              Session is encrypted · Admin access only
            </span>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Email */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold tracking-wide uppercase"
                     style={{ color: "hsl(220,10%,55%)" }}>
                Admin Email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4"
                      style={{ color: "hsl(243,72%,66%)" }} />
                <Input
                  type="email"
                  placeholder="admin@charleychat.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-10 rounded-xl border-0 text-white placeholder:text-white/25"
                  style={{ background: "hsl(243,40%,18%)", outline: "1px solid hsl(243,30%,26%)" }}
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold tracking-wide uppercase"
                     style={{ color: "hsl(220,10%,55%)" }}>
                Password
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4"
                      style={{ color: "hsl(330,80%,60%)" }} />
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pl-10 rounded-xl border-0 text-white placeholder:text-white/25"
                  style={{ background: "hsl(243,40%,18%)", outline: "1px solid hsl(243,30%,26%)" }}
                />
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full flex items-center justify-center gap-2 rounded-xl py-3 mt-2 font-bold text-sm text-white transition-opacity hover:opacity-90 disabled:opacity-50 cursor-pointer"
              style={{ background: "linear-gradient(90deg, hsl(243,72%,56%), hsl(330,80%,60%))" }}
            >
              {loginMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Authenticating…
                </span>
              ) : (
                <>
                  Access Control Room
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
