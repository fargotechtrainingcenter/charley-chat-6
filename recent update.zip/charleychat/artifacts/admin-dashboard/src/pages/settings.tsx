import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, RefreshCw, Shield, DollarSign, Bell, Globe } from "lucide-react";

interface PlatformSettings {
  escrowFeePercent: number;
  paidGroupCommissionPercent: number;
  invoiceGenerationFeePesewas: number;
  p2pTransferLimitPesewas: number;
  maintenanceMode: boolean;
  registrationEnabled: boolean;
  kycRequired: boolean;
}

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
function authHeaders() {
  return { Authorization: `Bearer ${localStorage.getItem("charley_admin_token") ?? ""}`, "Content-Type": "application/json" };
}

const DEFAULT: PlatformSettings = {
  escrowFeePercent: 2.5,
  paidGroupCommissionPercent: 10,
  invoiceGenerationFeePesewas: 500,
  p2pTransferLimitPesewas: 500000,
  maintenanceMode: false,
  registrationEnabled: true,
  kycRequired: true,
};

function SettingRow({ label, description, children }: { label: string; description: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between py-4 border-b border-[#1E1B3A] last:border-0">
      <div className="flex-1 mr-8">
        <p className="text-white font-medium text-sm">{label}</p>
        <p className="text-[#7B6FA3] text-xs mt-1">{description}</p>
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`w-12 h-6 rounded-full transition-colors relative ${value ? "bg-[#8B5CF6]" : "bg-[#1E1B3A]"}`}
    >
      <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${value ? "translate-x-7" : "translate-x-1"}`} />
    </button>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState<PlatformSettings>(DEFAULT);
  const [edited, setEdited] = useState(false);

  const { isLoading, data: loadedSettings } = useQuery<PlatformSettings>({
    queryKey: ["admin-settings"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/admin/settings`, { headers: authHeaders() });
      if (!res.ok) throw new Error("Failed to load settings");
      return res.json() as Promise<PlatformSettings>;
    },
  });

  useEffect(() => {
    if (loadedSettings && !edited) setSettings(loadedSettings);
  }, [loadedSettings]);

  const set = <K extends keyof PlatformSettings>(key: K, val: PlatformSettings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: val }));
    setEdited(true);
  };

  const saveMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${BASE}/api/admin/settings`, {
        method: "PATCH", headers: authHeaders(), body: JSON.stringify(settings),
      });
      if (!res.ok) throw new Error("Save failed");
      return res.json() as Promise<PlatformSettings>;
    },
    onSuccess: (data: PlatformSettings) => {
      setSettings(data);
      setEdited(false);
      queryClient.setQueryData(["admin-settings"], data);
      toast({ title: "Settings saved" });
    },
    onError: () => toast({ title: "Save failed", variant: "destructive" }),
  });

  const sections = [
    {
      icon: <DollarSign className="w-5 h-5 text-[#F59E0B]" />,
      title: "Fees & Commissions",
      bg: "bg-[#F59E0B]/10",
      rows: [
        {
          label: "Escrow Fee (%)",
          description: "Platform fee on escrow transactions",
          control: (
            <Input className="w-24 bg-[#07060F] border-[#1E1B3A] text-white text-right"
              type="number" value={settings.escrowFeePercent}
              onChange={(e) => set("escrowFeePercent", parseFloat(e.target.value) || 0)} />
          ),
        },
        {
          label: "Paid Group Commission (%)",
          description: "Platform commission on group membership fees",
          control: (
            <Input className="w-24 bg-[#07060F] border-[#1E1B3A] text-white text-right"
              type="number" value={settings.paidGroupCommissionPercent}
              onChange={(e) => set("paidGroupCommissionPercent", parseFloat(e.target.value) || 0)} />
          ),
        },
        {
          label: "Invoice PDF Fee (pesewas)",
          description: "Fee to generate a professional PDF invoice (100 = GHS 1.00)",
          control: (
            <div className="flex items-center gap-2">
              <Input className="w-28 bg-[#07060F] border-[#1E1B3A] text-white text-right"
                type="number" value={settings.invoiceGenerationFeePesewas}
                onChange={(e) => set("invoiceGenerationFeePesewas", parseInt(e.target.value) || 0)} />
              <span className="text-[#7B6FA3] text-xs">= GHS {(settings.invoiceGenerationFeePesewas / 100).toFixed(2)}</span>
            </div>
          ),
        },
        {
          label: "P2P Transfer Limit (pesewas)",
          description: "Maximum single P2P transfer amount",
          control: (
            <div className="flex items-center gap-2">
              <Input className="w-28 bg-[#07060F] border-[#1E1B3A] text-white text-right"
                type="number" value={settings.p2pTransferLimitPesewas}
                onChange={(e) => set("p2pTransferLimitPesewas", parseInt(e.target.value) || 0)} />
              <span className="text-[#7B6FA3] text-xs">= GHS {(settings.p2pTransferLimitPesewas / 100).toFixed(2)}</span>
            </div>
          ),
        },
      ],
    },
    {
      icon: <Shield className="w-5 h-5 text-[#10B981]" />,
      title: "Security & Access",
      bg: "bg-[#10B981]/10",
      rows: [
        {
          label: "KYC Required",
          description: "Users must complete KYC before sending money, escrow, or joining paid groups",
          control: <Toggle value={settings.kycRequired} onChange={(v) => set("kycRequired", v)} />,
        },
        {
          label: "User Registration",
          description: "Allow new users to register on the platform",
          control: <Toggle value={settings.registrationEnabled} onChange={(v) => set("registrationEnabled", v)} />,
        },
      ],
    },
    {
      icon: <Globe className="w-5 h-5 text-[#8B5CF6]" />,
      title: "Platform Status",
      bg: "bg-[#8B5CF6]/10",
      rows: [
        {
          label: "Maintenance Mode",
          description: "When enabled, users see a maintenance message and cannot transact",
          control: (
            <div className="flex items-center gap-3">
              {settings.maintenanceMode && (
                <Badge className="bg-red-500/20 text-red-400 border-0 text-xs">Active</Badge>
              )}
              <Toggle value={settings.maintenanceMode} onChange={(v) => set("maintenanceMode", v)} />
            </div>
          ),
        },
      ],
    },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Settings className="w-7 h-7 text-[#8B5CF6]" />
          <div>
            <h1 className="text-2xl font-bold text-white">Platform Settings</h1>
            <p className="text-[#7B6FA3] text-sm">Configure fees, security, and platform behaviour</p>
          </div>
        </div>
        {edited && (
          <Button
            onClick={() => saveMut.mutate()}
            disabled={saveMut.isPending}
            className="bg-[#8B5CF6] hover:bg-[#7C3AED] text-white gap-2"
          >
            <Save className="w-4 h-4" />
            {saveMut.isPending ? "Saving…" : "Save Changes"}
          </Button>
        )}
      </div>

      {settings.maintenanceMode && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-center gap-3">
          <RefreshCw className="w-5 h-5 text-red-400 animate-spin" />
          <div>
            <p className="text-red-400 font-semibold text-sm">Maintenance Mode Active</p>
            <p className="text-red-400/70 text-xs">Users cannot access the platform. Disable when maintenance is complete.</p>
          </div>
        </div>
      )}

      <div className="space-y-6">
        {sections.map((section) => (
          <div key={section.title} className="rounded-xl border border-[#1E1B3A] bg-[#0D0B1C] overflow-hidden">
            <div className={`flex items-center gap-3 p-4 border-b border-[#1E1B3A] ${section.bg}`}>
              {section.icon}
              <h2 className="text-white font-semibold">{section.title}</h2>
            </div>
            <div className="px-4">
              {section.rows.map((row) => (
                <SettingRow key={row.label} label={row.label} description={row.description}>
                  {row.control}
                </SettingRow>
              ))}
            </div>
          </div>
        ))}
      </div>

      <p className="text-[#7B6FA3] text-xs text-center">
        Settings are applied immediately after saving. Fee changes affect new transactions only.
      </p>
    </div>
  );
}
