import {
  useAdminListReels,
  getAdminListReelsQueryKey,
  useAdminSuspendReel,
  useAdminRestoreReel,
  useAdminListReelReports,
  getAdminListReelReportsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Play, Pause, Flag, AlertTriangle } from "lucide-react";
import { formatDate } from "@/lib/format";

export default function Reels() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState("reels");

  const { data: reels, isLoading: reelsLoading } = useAdminListReels({
    query: { queryKey: getAdminListReelsQueryKey() },
  });

  const { data: reports, isLoading: reportsLoading } = useAdminListReelReports({
    query: { queryKey: getAdminListReelReportsQueryKey() },
  });

  const suspendMut = useAdminSuspendReel();
  const restoreMut = useAdminRestoreReel();

  const handleSuspend = (id: string) => {
    if (!confirm("Suspend this reel? It will be hidden from all users.")) return;
    suspendMut.mutate(
      { id },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListReelsQueryKey() }) }
    );
  };

  const handleRestore = (id: string) => {
    restoreMut.mutate(
      { id },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListReelsQueryKey() }) }
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Reels Moderation</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Manage all video reels — suspend, restore, and review user reports.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Reels</div>
          <div className="text-2xl font-bold">{reels?.length ?? 0}</div>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Suspended</div>
          <div className="text-2xl font-bold text-red-500">
            {reels?.filter((r: any) => r.isSuspended).length ?? 0}
          </div>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Reports</div>
          <div className="text-2xl font-bold text-amber-500">{reports?.length ?? 0}</div>
        </div>
        <div className="rounded-xl border bg-card p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Active</div>
          <div className="text-2xl font-bold text-emerald-500">
            {reels?.filter((r: any) => !r.isSuspended).length ?? 0}
          </div>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="reels">All Reels</TabsTrigger>
          <TabsTrigger value="reports">
            Reports
            {(reports?.length ?? 0) > 0 && (
              <Badge variant="destructive" className="ml-1.5 px-1.5 py-0 text-[10px]">
                {reports?.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="reels">
          <div className="rounded-xl border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Reel</TableHead>
                  <TableHead>Creator</TableHead>
                  <TableHead className="text-center">Views</TableHead>
                  <TableHead className="text-center">Likes</TableHead>
                  <TableHead className="text-center">Comments</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Posted</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reelsLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                      Loading reels…
                    </TableCell>
                  </TableRow>
                ) : !reels?.length ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                      No reels found.
                    </TableCell>
                  </TableRow>
                ) : (
                  reels.map((reel: any) => (
                    <TableRow key={reel.id} className={reel.isSuspended ? "opacity-50" : ""}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          {reel.mediaUrl ? (
                            <div
                              className="w-12 h-16 rounded-lg bg-muted overflow-hidden shrink-0 relative"
                              style={{ background: "hsl(var(--muted))" }}
                            >
                              <video
                                src={reel.mediaUrl}
                                className="w-full h-full object-cover"
                                muted
                              />
                              <div className="absolute inset-0 flex items-center justify-center">
                                <Play className="h-4 w-4 text-white/80" />
                              </div>
                            </div>
                          ) : (
                            <div className="w-12 h-16 rounded-lg bg-muted shrink-0 flex items-center justify-center">
                              <Play className="h-4 w-4 text-muted-foreground" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate max-w-[180px]">
                              {reel.caption || "No caption"}
                            </p>
                            <p className="text-xs text-muted-foreground truncate max-w-[180px]">
                              {reel.id.slice(0, 8)}…
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs font-mono">{reel.userId?.slice(0, 8)}…</span>
                      </TableCell>
                      <TableCell className="text-center">{reel.viewCount ?? 0}</TableCell>
                      <TableCell className="text-center">{reel.likeCount ?? 0}</TableCell>
                      <TableCell className="text-center">{reel.commentCount ?? 0}</TableCell>
                      <TableCell>
                        {reel.isSuspended ? (
                          <Badge variant="destructive">Suspended</Badge>
                        ) : (
                          <Badge variant="outline" className="text-emerald-500 border-emerald-500/30">
                            Active
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(reel.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        {reel.isSuspended ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRestore(reel.id)}
                            disabled={restoreMut.isPending}
                          >
                            <Play className="h-3 w-3 mr-1" />
                            Restore
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleSuspend(reel.id)}
                            disabled={suspendMut.isPending}
                          >
                            <Pause className="h-3 w-3 mr-1" />
                            Suspend
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <div className="rounded-xl border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reel ID</TableHead>
                  <TableHead>Reporter</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Reported</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reportsLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                      Loading reports…
                    </TableCell>
                  </TableRow>
                ) : !reports?.length ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                      No reports yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  reports.map((report: any) => (
                    <TableRow key={report.id}>
                      <TableCell>
                        <span className="text-xs font-mono">{report.reelId?.slice(0, 8)}…</span>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs font-mono">{report.reporterId?.slice(0, 8)}…</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-amber-500 border-amber-500/30">
                          <Flag className="h-3 w-3 mr-1" />
                          {report.reason}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-[200px] truncate">
                        {report.details || "—"}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(report.createdAt)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
