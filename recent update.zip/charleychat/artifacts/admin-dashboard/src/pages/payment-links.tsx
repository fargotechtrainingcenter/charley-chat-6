import { useState } from "react";
import { useAdminListPaymentLinks } from "@workspace/api-client-react";
import { formatGHS, formatDate } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default function PaymentLinks() {
  const [page] = useState(1);

  const { data, isLoading } = useAdminListPaymentLinks({ page, limit: 50 });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Payment Links</h1>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Payments</TableHead>
              <TableHead>Created</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : data?.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">No payment links found.</TableCell></TableRow>
            ) : (
              data?.map(link => (
                <TableRow key={link.id}>
                  <TableCell className="font-mono font-medium">{link.code}</TableCell>
                  <TableCell>
                    {link.title}
                    <div className="text-xs text-muted-foreground truncate max-w-[200px]">{link.description}</div>
                  </TableCell>
                  <TableCell>
                    {link.isFixedAmount ? formatGHS(link.amountPesewas) : <span className="text-muted-foreground italic">Any amount</span>}
                  </TableCell>
                  <TableCell>
                    <Badge variant={link.isActive ? "default" : "secondary"}>
                      {link.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">{link.totalPaidCount}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(link.createdAt)}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
