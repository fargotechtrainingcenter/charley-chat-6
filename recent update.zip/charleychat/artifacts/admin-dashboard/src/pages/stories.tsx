import {
  useAdminListStories,
  getAdminListStoriesQueryKey,
  useAdminDeleteStory,
  useAdminRestrictStory,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Trash2, ShieldAlert, ShieldCheck } from "lucide-react";

export default function Stories() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useAdminListStories({
    query: { queryKey: getAdminListStoriesQueryKey() }
  });

  const deleteMutation = useAdminDeleteStory();
  const restrictMutation = useAdminRestrictStory();

  const handleDelete = (id: string) => {
    if (confirm("Delete this story?")) {
      deleteMutation.mutate({ id }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListStoriesQueryKey() })
      });
    }
  };

  const handleToggleRestrict = (id: string, currentlyRestricted: boolean) => {
    const action = currentlyRestricted ? "Remove 18+ restriction from" : "Mark as 18+";
    if (confirm(`${action} this story?`)) {
      restrictMutation.mutate(
        { id, data: { isAgeRestricted: !currentlyRestricted } },
        {
          onSuccess: () => queryClient.invalidateQueries({ queryKey: getAdminListStoriesQueryKey() })
        }
      );
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold tracking-tight">Stories Moderation</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {isLoading ? (
          <div className="col-span-full text-center py-8">Loading...</div>
        ) : data?.length === 0 ? (
          <div className="col-span-full text-center py-8">No active stories.</div>
        ) : (
          data?.map(story => (
            <div key={story.id} className="relative group rounded-xl overflow-hidden bg-muted aspect-[9/16] border">
              {story.isAgeRestricted && (
                <div className="absolute top-2 left-2 z-10 bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                  18+
                </div>
              )}

              {story.mediaUrl ? (
                <img src={story.mediaUrl} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-4 text-center bg-primary text-primary-foreground font-medium text-lg">
                  {story.caption}
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/60 p-3 flex flex-col justify-between opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="text-white text-xs space-y-1">
                  <div className="font-semibold truncate">User: {story.userId.slice(0, 8)}...</div>
                  <div>Exp: {formatDate(story.expiresAt)}</div>
                </div>

                <div className="space-y-1">
                  {story.mediaUrl && story.caption && (
                    <div className="text-white text-sm mb-2 line-clamp-2">{story.caption}</div>
                  )}
                  <Button
                    variant={story.isAgeRestricted ? "outline" : "secondary"}
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => handleToggleRestrict(story.id, story.isAgeRestricted)}
                    disabled={restrictMutation.isPending}
                  >
                    {story.isAgeRestricted ? (
                      <><ShieldCheck className="w-4 h-4" /> Remove 18+</>
                    ) : (
                      <><ShieldAlert className="w-4 h-4" /> Mark 18+</>
                    )}
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => handleDelete(story.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" /> Delete
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
