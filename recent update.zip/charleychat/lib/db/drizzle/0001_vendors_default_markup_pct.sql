ALTER TABLE "vendors" ADD COLUMN IF NOT EXISTS "default_markup_pct" integer DEFAULT 10 NOT NULL;
