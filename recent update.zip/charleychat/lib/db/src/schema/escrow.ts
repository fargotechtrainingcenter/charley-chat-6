import { pgTable, uuid, integer, text, timestamp, date, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { walletsTable } from "./wallets";

export const escrowStatusEnum = pgEnum("escrow_status", [
  "pending",
  "in_escrow",
  "pending_release",
  "released",
  "disputed",
  "cancelled",
]);

export const escrowTransactionsTable = pgTable("escrow_transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  buyerId: uuid("buyer_id")
    .notNull()
    .references(() => usersTable.id),
  sellerId: uuid("seller_id")
    .notNull()
    .references(() => usersTable.id),
  walletId: uuid("wallet_id")
    .references(() => walletsTable.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  amountPesewas: integer("amount_pesewas").notNull(),
  feePesewas: integer("fee_pesewas").notNull().default(0),
  status: escrowStatusEnum("status").notNull().default("pending"),
  releaseCode: text("release_code").notNull(),
  dueDate: date("due_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [
  index("escrow_buyer_id_idx").on(t.buyerId),
  index("escrow_seller_id_idx").on(t.sellerId),
]);

export const insertEscrowSchema = createInsertSchema(escrowTransactionsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertEscrow = z.infer<typeof insertEscrowSchema>;
export type EscrowTransaction = typeof escrowTransactionsTable.$inferSelect;
