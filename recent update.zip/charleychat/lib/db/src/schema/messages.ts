import { pgTable, uuid, text, boolean, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const messageTypeEnum = pgEnum("message_type", [
  "text",
  "voice_note",
  "image",
  "payment_request",
  "video",
  "location",
  "escrow_deal",
  "payment_sent",
  "document",
]);

export const messagesTable = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  senderId: uuid("sender_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  receiverId: uuid("receiver_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  content: text("content"),
  messageType: messageTypeEnum("message_type").notNull().default("text"),
  mediaUrl: text("media_url"),
  isRead: boolean("is_read").notNull().default(false),
  isDelivered: boolean("is_delivered").notNull().default(false),
  replyToId: uuid("reply_to_id"),
  isEdited: boolean("is_edited").notNull().default(false),
  editedAt: timestamp("edited_at", { withTimezone: true }),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
  deletedForEveryone: boolean("deleted_for_everyone").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  // Conversation history lookups filter/sort on (sender, receiver, created_at)
  // in both directions — without these, every chat open was a full table scan.
  index("messages_sender_receiver_idx").on(t.senderId, t.receiverId, t.createdAt),
  index("messages_receiver_sender_idx").on(t.receiverId, t.senderId, t.createdAt),
  // Unread-count / inbox queries filter on (receiver, is_read)
  index("messages_receiver_unread_idx").on(t.receiverId, t.isRead),
]);

export const insertMessageSchema = createInsertSchema(messagesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messagesTable.$inferSelect;
