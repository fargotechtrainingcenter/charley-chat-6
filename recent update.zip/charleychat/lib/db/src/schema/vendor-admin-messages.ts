import { pgTable, uuid, text, timestamp } from "drizzle-orm/pg-core";
import { vendorsTable } from "./vendors";

export const vendorAdminMessagesTable = pgTable("vendor_admin_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  vendorId: uuid("vendor_id")
    .notNull()
    .references(() => vendorsTable.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  sentBy: uuid("sent_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type VendorAdminMessage = typeof vendorAdminMessagesTable.$inferSelect;
