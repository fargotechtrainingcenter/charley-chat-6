import { pgTable, uuid, text, jsonb, timestamp, index } from "drizzle-orm/pg-core";

export const aliexpressWebhookEventsTable = pgTable(
  "aliexpress_webhook_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventType: text("event_type").notNull(),
    topic: text("topic"),
    msgId: text("msg_id"),
    sellerId: text("seller_id"),
    payload: jsonb("payload").notNull().$type<Record<string, unknown>>(),
    rawBody: text("raw_body").notNull(),
    signatureValid: text("signature_valid").notNull().default("unknown"),
    processedAt: timestamp("processed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("aliexpress_webhook_events_event_type_idx").on(t.eventType),
    index("aliexpress_webhook_events_msg_id_idx").on(t.msgId),
    index("aliexpress_webhook_events_created_at_idx").on(t.createdAt),
  ],
);

export type AliexpressWebhookEvent = typeof aliexpressWebhookEventsTable.$inferSelect;
export type InsertAliexpressWebhookEvent = typeof aliexpressWebhookEventsTable.$inferInsert;
