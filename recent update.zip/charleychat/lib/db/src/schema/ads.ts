import { pgTable, uuid, text, integer, timestamp, pgEnum, jsonb, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const adStatusEnum = pgEnum("ad_status", [
  "pending_approval",
  "approved",
  "rejected",
  "active",
  "completed",
  "cancelled",
]);

export const adLinkTypeEnum = pgEnum("ad_link_type", ["marketplace", "website"]);
export const adMediaTypeEnum = pgEnum("ad_media_type", ["image", "video"]);
export const adPlacementEnum = pgEnum("ad_placement", ["story", "reel", "discover", "marketplace"]);
export const adEventTypeEnum = pgEnum("ad_event_type", ["impression", "view", "click", "purchase"]);

export const PRICE_PER_DAY_PESEWAS = 1000; // GH₵10/day

export const adsTable = pgTable("ads", {
  id: uuid("id").primaryKey().defaultRandom(),
  advertiserId: uuid("advertiser_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  mediaUrl: text("media_url").notNull(),
  mediaType: adMediaTypeEnum("media_type").notNull(),
  linkType: adLinkTypeEnum("link_type").notNull(),
  linkUrl: text("link_url").notNull(),
  audienceInterests: jsonb("audience_interests").$type<string[]>().notNull().default([]),
  durationDays: integer("duration_days").notNull(),
  totalCostPesewas: integer("total_cost_pesewas").notNull(),
  status: adStatusEnum("status").notNull().default("pending_approval"),
  rejectionReason: text("rejection_reason"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  endsAt: timestamp("ends_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("ads_advertiser_id_idx").on(t.advertiserId, t.createdAt),
  index("ads_status_ends_idx").on(t.status, t.endsAt),
]);

/** Every impression/view/click/purchase against an ad, for advertiser analytics. */
export const adEventsTable = pgTable("ad_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  adId: uuid("ad_id").notNull().references(() => adsTable.id, { onDelete: "cascade" }),
  eventType: adEventTypeEnum("event_type").notNull(),
  placement: adPlacementEnum("placement").notNull(),
  userId: uuid("user_id").references(() => usersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("ad_events_ad_id_idx").on(t.adId, t.createdAt),
  index("ad_events_ad_type_idx").on(t.adId, t.eventType),
]);

export type Ad = typeof adsTable.$inferSelect;
export type AdEvent = typeof adEventsTable.$inferSelect;
