import { pgTable, uuid, text, timestamp, jsonb, index } from "drizzle-orm/pg-core";
import { adminUsersTable } from "./admin-users";

/**
 * Generic audit log for admin actions across the platform — wallet funding
 * verification, escrow dispute resolution, KYC approval/rejection, refunds,
 * ad approval, etc. Every admin action that affects a user or moves money
 * should write a row here so there's a complete, queryable trail.
 */
export const auditLogsTable = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  adminId: uuid("admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  adminEmail: text("admin_email"),
  action: text("action").notNull(), // e.g. "wallet_funding.approve", "escrow.refund", "kyc.reject"
  entityType: text("entity_type").notNull(), // e.g. "wallet_funding_request", "escrow_transaction"
  entityId: text("entity_id").notNull(),
  metadata: jsonb("metadata"), // free-form details: amounts, reasons, before/after state
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("audit_logs_entity_idx").on(t.entityType, t.entityId),
  index("audit_logs_admin_created_idx").on(t.adminId, t.createdAt),
]);

export type AuditLog = typeof auditLogsTable.$inferSelect;
