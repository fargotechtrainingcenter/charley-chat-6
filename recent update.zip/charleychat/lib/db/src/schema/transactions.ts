import { pgTable, uuid, integer, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { walletsTable } from "./wallets";

export const transactionTypeEnum = pgEnum("transaction_type", [
  "momo_in",
  "momo_out",
  "bank_in",
  "bank_out",
  "visa_in",
  "escrow_hold",
  "escrow_release",
  "escrow_refund",
  "p2p_send",
  "p2p_receive",
  "bill_payment",
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending",
  "completed",
  "failed",
]);

export const transactionsTable = pgTable("transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id")
    .notNull()
    .references(() => walletsTable.id, { onDelete: "cascade" }),
  type: transactionTypeEnum("type").notNull(),
  amountPesewas: integer("amount_pesewas").notNull(),
  feePesewas: integer("fee_pesewas").notNull().default(0),
  network: text("network"),
  reference: text("reference").notNull().unique(),
  status: transactionStatusEnum("status").notNull().default("pending"),
  counterpartyPhone: text("counterparty_phone"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
