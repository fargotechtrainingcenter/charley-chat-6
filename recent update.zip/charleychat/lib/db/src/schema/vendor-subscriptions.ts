import { pgTable, uuid, text, integer, boolean, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { vendorsTable } from "./vendors";

export const vendorSubscriptionTierEnum = pgEnum("vendor_subscription_tier", ["basic", "pro"]);
export const vendorSubscriptionStatusEnum = pgEnum("vendor_subscription_status", ["active", "expired", "cancelled"]);

/**
 * Marketplace seller subscription — one row per billing period.
 *
 * Tiers (per spec):
 *  - basic: GH₵50/month, up to 10 product listings
 *  - pro:   GH₵100/month, 20+ product listings (used as the effective cap
 *           for anything above the basic tier's 10-listing limit, since the
 *           spec doesn't define a rate for the 11–19 range)
 */
export const vendorSubscriptionsTable = pgTable("vendor_subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  vendorId: uuid("vendor_id").notNull().references(() => vendorsTable.id, { onDelete: "cascade" }),
  tier: vendorSubscriptionTierEnum("tier").notNull(),
  productLimit: integer("product_limit").notNull(),
  pricePesewas: integer("price_pesewas").notNull(),
  status: vendorSubscriptionStatusEnum("status").notNull().default("active"),
  autoRenew: boolean("auto_renew").notNull().default(true),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("vendor_subscriptions_vendor_id_idx").on(t.vendorId, t.createdAt),
  index("vendor_subscriptions_status_expires_idx").on(t.status, t.expiresAt),
]);

export type VendorSubscription = typeof vendorSubscriptionsTable.$inferSelect;

export const VENDOR_SUBSCRIPTION_TIERS = {
  basic: { productLimit: 10, pricePesewas: 5000 },
  pro: { productLimit: 100000, pricePesewas: 10000 },
} as const;
