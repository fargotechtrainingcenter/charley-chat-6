import { pgTable, uuid, text, integer, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { adminUsersTable } from "./admin-users";

export const walletFundingRequestStatusEnum = pgEnum("wallet_funding_request_status", [
  "pending",
  "approved",
  "rejected",
]);

/**
 * Support form for when a user's MoMo/card payment was deducted but their
 * Charley Wallet was never credited (webhook failure, network interruption,
 * etc.). Reviewed manually by admin support staff against the payment
 * provider's records before crediting the wallet.
 */
export const walletFundingRequestsTable = pgTable("wallet_funding_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  momoNumber: text("momo_number").notNull(),
  transactionReference: text("transaction_reference").notNull(),
  amountPesewas: integer("amount_pesewas").notNull(),
  paymentDate: timestamp("payment_date", { withTimezone: true }).notNull(),
  screenshotUrl: text("screenshot_url"),
  comments: text("comments"),
  status: walletFundingRequestStatusEnum("status").notNull().default("pending"),
  reviewedByAdminId: uuid("reviewed_by_admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("wallet_funding_requests_user_id_idx").on(t.userId),
  index("wallet_funding_requests_status_idx").on(t.status),
]);

export type WalletFundingRequest = typeof walletFundingRequestsTable.$inferSelect;
