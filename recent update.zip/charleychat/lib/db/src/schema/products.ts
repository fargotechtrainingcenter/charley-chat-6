import { pgTable, uuid, text, boolean, integer, timestamp, numeric, pgEnum, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { vendorsTable } from "./vendors";

// ── Legacy products table (6-category enum, used by dead products.ts route) ──
export const productCategoryEnum = pgEnum("product_category", [
  "Electronics",
  "Fashion",
  "EV & Bikes",
  "Wholesale",
  "Food & Agri",
  "Beauty",
]);

export const productsTable = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  vendorId: uuid("vendor_id")
    .notNull()
    .references(() => vendorsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  category: productCategoryEnum("category").notNull(),
  pricePesewas: integer("price_pesewas").notNull(),
  images: text("images").array().notNull().default([]),
  inStock: boolean("in_stock").notNull().default(true),
  isWholesale: boolean("is_wholesale").notNull().default(false),
  moq: integer("moq"),
  ratingAvg: numeric("rating_avg", { precision: 3, scale: 2 }).notNull().default("0.00"),
  totalReviews: integer("total_reviews").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertProductSchema = createInsertSchema(productsTable).omit({
  id: true, ratingAvg: true, totalReviews: true, createdAt: true, updatedAt: true,
});
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;

// ── africart_products — the live marketplace table (text category, 19 cats) ──
export const africartProductsTable = pgTable("africart_products", {
  id: uuid("id").primaryKey().defaultRandom(),
  vendorId: uuid("vendor_id")
    .notNull()
    .references(() => vendorsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  brand: text("brand"),
  tags: text("tags").array().notNull().default([]),
  condition: text("condition").notNull().default("new"),
  sellerPricePesewas: integer("seller_price_pesewas").notNull(),
  pricePesewas: integer("price_pesewas").notNull(),
  flashDealPricePesewas: integer("flash_deal_price_pesewas"),
  flashDealEndsAt: timestamp("flash_deal_ends_at", { withTimezone: true }),
  images: text("images").array().notNull().default([]),
  inStock: boolean("in_stock").notNull().default(true),
  isWholesale: boolean("is_wholesale").notNull().default(false),
  moq: integer("moq"),
  ratingAvg: numeric("rating_avg", { precision: 3, scale: 2 }).notNull().default("0.00"),
  reviewCount: integer("review_count").notNull().default(0),
  status: text("status").notNull().default("pending"),
  isApproved: boolean("is_approved").notNull().default(false),
  isDeleted: boolean("is_deleted").notNull().default(false),
  rejectionReason: text("rejection_reason"),
  aliexpressProductId: text("aliexpress_product_id"),
  aliexpressPricePesewas: integer("aliexpress_price_pesewas"),
  aliexpressSyncedAt: timestamp("aliexpress_synced_at", { withTimezone: true }),
  aliexpressRaw: jsonb("aliexpress_raw"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAfricartProductSchema = createInsertSchema(africartProductsTable).omit({
  id: true, ratingAvg: true, reviewCount: true, status: true,
  isApproved: true, isDeleted: true, rejectionReason: true, createdAt: true, updatedAt: true,
});
export type InsertAfricartProduct = z.infer<typeof insertAfricartProductSchema>;
export type AfricartProduct = typeof africartProductsTable.$inferSelect;
