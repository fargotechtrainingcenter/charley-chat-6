import { pgTable, uuid, integer, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const paymentLinksTable = pgTable("payment_links", {
  id: uuid("id").primaryKey().defaultRandom(),
  sellerId: uuid("seller_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  amountPesewas: integer("amount_pesewas"),
  isFixedAmount: boolean("is_fixed_amount").notNull().default(true),
  code: text("code").notNull().unique(),
  isActive: boolean("is_active").notNull().default(true),
  totalPaidCount: integer("total_paid_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertPaymentLinkSchema = createInsertSchema(paymentLinksTable).omit({
  id: true,
  createdAt: true,
  totalPaidCount: true,
});
export type InsertPaymentLink = z.infer<typeof insertPaymentLinkSchema>;
export type PaymentLink = typeof paymentLinksTable.$inferSelect;
