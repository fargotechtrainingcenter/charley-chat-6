import { pgTable, uuid, text, timestamp, unique } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { storiesTable } from "./stories";

export const storyReactionsTable = pgTable(
  "story_reactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    storyId: uuid("story_id")
      .notNull()
      .references(() => storiesTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    emoji: text("emoji").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.storyId, t.userId)],
);

export type StoryReaction = typeof storyReactionsTable.$inferSelect;
