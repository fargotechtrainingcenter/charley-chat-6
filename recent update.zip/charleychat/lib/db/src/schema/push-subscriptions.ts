import { pgTable, uuid, text, timestamp, unique } from "drizzle-orm/pg-core";

/**
 * Push notification subscriptions — covers both:
 *  - Web/PWA push (endpoint + p256dh + auth, via web-push/VAPID)
 *  - Native mobile push (expoPushToken, via Expo Push API on Android/iOS)
 *
 * subscriberType distinguishes regular users from admin dashboard users.
 * subscriberId is a plain text column (not an FK) because it can reference
 * either usersTable.id or adminUsersTable.id depending on subscriberType.
 */
export const pushSubscriptionsTable = pgTable(
  "push_subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    subscriberType: text("subscriber_type").notNull(), // 'user' | 'admin'
    subscriberId: text("subscriber_id").notNull(),

    // Web/PWA push fields (nullable — not used for native push)
    endpoint: text("endpoint"),
    p256dh: text("p256dh"),
    auth: text("auth"),

    // Native mobile push field (nullable — not used for web push)
    expoPushToken: text("expo_push_token"),
    platform: text("platform"), // 'ios' | 'android' | 'web'

    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    // One row per (subscriber, endpoint) for web push upserts
    unique("push_subscriptions_subscriber_endpoint_unique").on(table.subscriberId, table.endpoint),
    // One row per (subscriber, expo token) for native push upserts
    unique("push_subscriptions_subscriber_expo_token_unique").on(table.subscriberId, table.expoPushToken),
  ],
);

export type PushSubscription = typeof pushSubscriptionsTable.$inferSelect;
