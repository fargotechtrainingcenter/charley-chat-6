import { pgTable, uuid, text, timestamp } from "drizzle-orm/pg-core";

export const smsLogsTable = pgTable("sms_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  phone: text("phone").notNull(),
  message: text("message").notNull(),
  status: text("status", { enum: ["sent", "failed", "pending", "simulated"] }).notNull().default("pending"),
  provider: text("provider"),
  purpose: text("purpose", { enum: ["registration", "login", "password_reset"] }),
  source: text("source", { enum: ["fargopay", "africart"] }).notNull().default("fargopay"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type SmsLog = typeof smsLogsTable.$inferSelect;
