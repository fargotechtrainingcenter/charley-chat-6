import { pgTable, uuid, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { vendorsTable } from "./vendors";

export const africartVendorFeePaymentsTable = pgTable("africart_vendor_fee_payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  vendorId: uuid("vendor_id")
    .notNull()
    .references(() => vendorsTable.id, { onDelete: "cascade" }),
  reference: text("reference").notNull().unique(),
  paystackId: text("paystack_id"),
  amountPesewas: integer("amount_pesewas").notNull().default(20000),
  status: text("status").notNull().default("pending"),
  gatewayResponse: text("gateway_response"),
  channel: text("channel"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  webhookPayload: jsonb("webhook_payload"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AfricartVendorFeePayment = typeof africartVendorFeePaymentsTable.$inferSelect;
