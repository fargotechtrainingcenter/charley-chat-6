import { pgTable, uuid, text, integer, timestamp, index } from "drizzle-orm/pg-core";
import { vendorsTable } from "./vendors";
import { africartProductsTable } from "./products";

export const aliexpressImportJobsTable = pgTable(
  "aliexpress_import_jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    vendorId: uuid("vendor_id")
      .notNull()
      .references(() => vendorsTable.id, { onDelete: "cascade" }),
    aliexpressProductId: text("aliexpress_product_id").notNull(),
    aliexpressTitle: text("aliexpress_title"),
    status: text("status").notNull().default("queued"),
    error: text("error"),
    africartProductId: uuid("africart_product_id")
      .references(() => africartProductsTable.id, { onDelete: "set null" }),
    vendorPricePesewas: integer("vendor_price_pesewas"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("aliexpress_import_jobs_vendor_id_idx").on(t.vendorId),
    index("aliexpress_import_jobs_status_idx").on(t.status),
    index("aliexpress_import_jobs_aliexpress_product_id_idx").on(t.aliexpressProductId),
  ],
);

export type AliexpressImportJob = typeof aliexpressImportJobsTable.$inferSelect;
export type InsertAliexpressImportJob = typeof aliexpressImportJobsTable.$inferInsert;
