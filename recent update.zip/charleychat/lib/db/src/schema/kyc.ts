import { pgTable, uuid, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const kycStatusEnum = pgEnum("kyc_status", [
  "pending",
  "approved",
  "rejected",
]);

export const kycIdTypeEnum = pgEnum("kyc_id_type", [
  "ghana_card",
  "passport",
  "voter_id",
]);

export const kycVerificationsTable = pgTable("kyc_verifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .unique()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  referenceNumber: text("reference_number"),
  status: kycStatusEnum("status").notNull().default("pending"),
  idType: kycIdTypeEnum("id_type").notNull(),
  idNumber: text("id_number").notNull(),
  idFrontUrl: text("id_front_url").notNull(),
  idBackUrl: text("id_back_url").notNull(),
  selfieUrl: text("selfie_url"),
  rejectionReason: text("rejection_reason"),
  approvedBy: uuid("approved_by"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertKycSchema = createInsertSchema(kycVerificationsTable).omit({
  id: true,
  status: true,
  referenceNumber: true,
  approvedBy: true,
  reviewedAt: true,
  createdAt: true,
});
export type InsertKyc = z.infer<typeof insertKycSchema>;
export type KycVerification = typeof kycVerificationsTable.$inferSelect;
