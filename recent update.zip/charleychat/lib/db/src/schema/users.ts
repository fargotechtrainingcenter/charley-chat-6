import { pgTable, uuid, text, boolean, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  fpId: text("fp_id").unique(),
  username: text("username").unique(),
  phone: text("phone").notNull().unique(),
  pinHash: text("pin_hash").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  ghanaCardId: text("ghana_card_id"),
  dateOfBirth: text("date_of_birth"),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  interests: text("interests").array().default([]),
  latitude: real("latitude"),
  longitude: real("longitude"),
  nearbyEnabled: boolean("nearby_enabled").notNull().default(false),
  nearbyRadius: integer("nearby_radius").notNull().default(5000),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  isKycVerified: boolean("is_kyc_verified").notNull().default(false),
  isVendor: boolean("is_vendor").notNull().default(false),
  isSuspended: boolean("is_suspended").notNull().default(false),
  suspendedUntil: timestamp("suspended_until", { withTimezone: true }),
  isFlagged: boolean("is_flagged").notNull().default(false),
  notifPayments: boolean("notif_payments").notNull().default(true),
  notifEscrow: boolean("notif_escrow").notNull().default(true),
  notifMarketing: boolean("notif_marketing").notNull().default(false),
  biometricEnabled: boolean("biometric_enabled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
