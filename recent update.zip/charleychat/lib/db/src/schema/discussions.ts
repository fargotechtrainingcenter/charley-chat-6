import { pgTable, uuid, text, timestamp, boolean, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const discussionCategoriesTable = pgTable("discussion_categories", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull().unique(),
  icon: text("icon"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const discussionsTable = pgTable("discussions", {
  id: uuid("id").primaryKey().defaultRandom(),
  authorId: uuid("author_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  categoryId: uuid("category_id")
    .notNull()
    .references(() => discussionCategoriesTable.id, { onDelete: "restrict" }),
  isAnonymous: boolean("is_anonymous").notNull().default(true),
  title: text("title").notNull(),
  body: text("body"),
  viewCount: integer("view_count").notNull().default(0),
  replyCount: integer("reply_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("discussions_category_created_idx").on(t.categoryId, t.createdAt),
  index("discussions_created_at_idx").on(t.createdAt),
]);

export const discussionRepliesTable = pgTable("discussion_replies", {
  id: uuid("id").primaryKey().defaultRandom(),
  discussionId: uuid("discussion_id")
    .notNull()
    .references(() => discussionsTable.id, { onDelete: "cascade" }),
  authorId: uuid("author_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  isAnonymous: boolean("is_anonymous").notNull().default(true),
  body: text("body").notNull(),
  likeCount: integer("like_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("discussion_replies_discussion_id_idx").on(t.discussionId, t.createdAt),
]);

export const insertDiscussionCategorySchema = createInsertSchema(discussionCategoriesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertDiscussionCategory = z.infer<typeof insertDiscussionCategorySchema>;
export type DiscussionCategory = typeof discussionCategoriesTable.$inferSelect;

export const insertDiscussionSchema = createInsertSchema(discussionsTable).omit({
  id: true,
  viewCount: true,
  replyCount: true,
  createdAt: true,
});
export type InsertDiscussion = z.infer<typeof insertDiscussionSchema>;
export type Discussion = typeof discussionsTable.$inferSelect;

export const insertDiscussionReplySchema = createInsertSchema(discussionRepliesTable).omit({
  id: true,
  likeCount: true,
  createdAt: true,
});
export type InsertDiscussionReply = z.infer<typeof insertDiscussionReplySchema>;
export type DiscussionReply = typeof discussionRepliesTable.$inferSelect;
