import { pgTable, uuid, text, timestamp, integer } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const callsTable = pgTable("calls", {
  id: uuid("id").primaryKey().defaultRandom(),
  channelName: text("channel_name").notNull(),
  callerId: uuid("caller_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  receiverId: uuid("receiver_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  type: text("type").notNull().$type<"voice" | "video">(),
  status: text("status")
    .notNull()
    .default("initiated")
    .$type<"initiated" | "ringing" | "answered" | "declined" | "missed" | "ended" | "failed">(),
  startedAt: timestamp("started_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  durationSeconds: integer("duration_seconds"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Call = typeof callsTable.$inferSelect;
export type InsertCall = typeof callsTable.$inferInsert;
