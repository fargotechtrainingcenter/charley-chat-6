import { pgTable, uuid, integer, boolean, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const movieSubscriptionStatusEnum = pgEnum("movie_subscription_status", ["active", "expired", "cancelled"]);

export const MOVIE_SUBSCRIPTION_PRICE_PESEWAS = 7000; // GH₵70/month

export const movieSubscriptionsTable = pgTable("movie_subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  status: movieSubscriptionStatusEnum("status").notNull().default("active"),
  autoRenew: boolean("auto_renew").notNull().default(true),
  pricePesewas: integer("price_pesewas").notNull().default(MOVIE_SUBSCRIPTION_PRICE_PESEWAS),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  reminderSentAt: timestamp("reminder_sent_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("movie_subscriptions_user_id_idx").on(t.userId, t.createdAt),
  index("movie_subscriptions_status_expires_idx").on(t.status, t.expiresAt),
]);

export type MovieSubscription = typeof movieSubscriptionsTable.$inferSelect;
