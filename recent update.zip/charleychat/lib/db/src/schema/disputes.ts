import { pgTable, uuid, text, integer, timestamp, pgEnum, index, unique } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { adminUsersTable } from "./admin-users";
import { escrowTransactionsTable } from "./escrow";

export const disputeStatusEnum = pgEnum("dispute_status", [
  "open",
  "evidence_requested",
  "resolved",
]);

export const disputeResolutionEnum = pgEnum("dispute_resolution", [
  "released_to_seller",
  "refunded_to_buyer",
  "partial_refund",
]);

/**
 * One dispute per escrow transaction. Created the moment either party raises
 * a dispute — this immediately freezes the escrow (handled by the escrow's
 * own status field, which blocks /escrow/:id/release once set to "disputed").
 */
export const disputesTable = pgTable("disputes", {
  id: uuid("id").primaryKey().defaultRandom(),
  escrowId: uuid("escrow_id").notNull().references(() => escrowTransactionsTable.id, { onDelete: "cascade" }),
  buyerId: uuid("buyer_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  sellerId: uuid("seller_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  raisedByUserId: uuid("raised_by_user_id").notNull().references(() => usersTable.id),
  assignedAdminId: uuid("assigned_admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  status: disputeStatusEnum("status").notNull().default("open"),
  resolution: disputeResolutionEnum("resolution"),
  // For partial_refund: how much of the escrowed amount goes back to the buyer
  // (the remainder goes to the seller). Null for full release/full refund.
  buyerRefundPesewas: integer("buyer_refund_pesewas"),
  resolvedByAdminId: uuid("resolved_by_admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  resolutionNotes: text("resolution_notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("disputes_escrow_id_unique").on(t.escrowId),
  index("disputes_status_idx").on(t.status),
  index("disputes_assigned_admin_idx").on(t.assignedAdminId),
]);

export const disputeSenderRoleEnum = pgEnum("dispute_sender_role", ["buyer", "seller", "admin", "system"]);
export const disputeMediaTypeEnum = pgEnum("dispute_media_type", ["image", "video", "voice", "document"]);

/**
 * The dispute conversation thread — buyer, seller, and assigned admin all
 * post into the same thread so everyone sees the same evidence and history.
 */
export const disputeMessagesTable = pgTable("dispute_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  disputeId: uuid("dispute_id").notNull().references(() => disputesTable.id, { onDelete: "cascade" }),
  senderRole: disputeSenderRoleEnum("sender_role").notNull(),
  senderUserId: uuid("sender_user_id").references(() => usersTable.id, { onDelete: "set null" }),
  senderAdminId: uuid("sender_admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  content: text("content"),
  mediaUrl: text("media_url"),
  mediaType: disputeMediaTypeEnum("media_type"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("dispute_messages_dispute_id_idx").on(t.disputeId, t.createdAt),
]);

export type Dispute = typeof disputesTable.$inferSelect;
export type DisputeMessage = typeof disputeMessagesTable.$inferSelect;
