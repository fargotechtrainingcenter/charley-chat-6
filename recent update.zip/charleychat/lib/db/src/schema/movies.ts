import { pgTable, uuid, text, integer, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { adminUsersTable } from "./admin-users";

/**
 * Real movie catalog, replacing the old static/mock browsing list. Admins
 * upload the video file + poster via the shared object-storage presigned
 * upload flow (same one used for chat media), then create a row here
 * pointing at the resulting URLs.
 */
export const moviesTable = pgTable("movies", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  posterUrl: text("poster_url"),
  videoUrl: text("video_url").notNull(),
  genre: text("genre"),
  releaseYear: integer("release_year"),
  durationMinutes: integer("duration_minutes"),
  rating: integer("rating"), // 0-50, representing 0.0-5.0 in tenths for simple integer storage
  isPremium: boolean("is_premium").notNull().default(true),
  isPublished: boolean("is_published").notNull().default(true),
  viewCount: integer("view_count").notNull().default(0),
  uploadedByAdminId: uuid("uploaded_by_admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("movies_published_created_idx").on(t.isPublished, t.createdAt),
  index("movies_genre_idx").on(t.genre),
]);

export type Movie = typeof moviesTable.$inferSelect;
