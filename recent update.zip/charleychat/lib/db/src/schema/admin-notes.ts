import { pgTable, uuid, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { adminUsersTable } from "./admin-users";

export const adminNoteTypeEnum = pgEnum("admin_note_type", [
  "suspension",
  "hold",
  "flag",
  "warning",
  "violation",
  "info",
  "unsuspend",
  "unflag",
]);

export const adminUserNotesTable = pgTable("admin_user_notes", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  adminId: uuid("admin_id").references(() => adminUsersTable.id, { onDelete: "set null" }),
  adminEmail: text("admin_email"),
  noteType: adminNoteTypeEnum("note_type").notNull().default("info"),
  note: text("note").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminUserNote = typeof adminUserNotesTable.$inferSelect;
