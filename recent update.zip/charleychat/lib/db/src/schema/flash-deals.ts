import { pgTable, uuid, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { productsTable } from "./products";

export const flashDealsTable = pgTable("flash_deals", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id")
    .notNull()
    .references(() => productsTable.id, { onDelete: "cascade" }),
  dealPricePesewas: integer("deal_price_pesewas").notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFlashDealSchema = createInsertSchema(flashDealsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertFlashDeal = z.infer<typeof insertFlashDealSchema>;
export type FlashDeal = typeof flashDealsTable.$inferSelect;
