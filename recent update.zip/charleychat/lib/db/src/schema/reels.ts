import {
  pgTable, uuid, text, timestamp, integer, boolean, unique, index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

// ─── Main reels table ─────────────────────────────────────────────────────────

export const reelsTable = pgTable("reels", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  videoUrl: text("video_url"),
  thumbnailUrl: text("thumbnail_url"),
  caption: text("caption"),
  hashtags: text("hashtags").array().notNull().default([]),
  location: text("location"),
  musicInfo: text("music_info"),
  durationSeconds: integer("duration_seconds").notNull().default(0),
  viewCount: integer("view_count").notNull().default(0),
  likeCount: integer("like_count").notNull().default(0),
  commentCount: integer("comment_count").notNull().default(0),
  shareCount: integer("share_count").notNull().default(0),
  saveCount: integer("save_count").notNull().default(0),
  isPublished: boolean("is_published").notNull().default(true),
  isMerchant: boolean("is_merchant").notNull().default(false),
  taggedProductIds: uuid("tagged_product_ids").array().notNull().default([]),
  coverImageUrl: text("cover_image_url"),
  userFullName: text("user_full_name"),
  userAvatarUrl: text("user_avatar_url"),
  userPhone: text("user_phone"),
  isModerated: boolean("is_moderated").notNull().default(false),
  isSuspended: boolean("is_suspended").notNull().default(false),
  maxDurationSeconds: integer("max_duration_seconds"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("reels_published_created_idx").on(t.isPublished, t.createdAt),
  index("reels_user_id_idx").on(t.userId),
]);

export const insertReelSchema = createInsertSchema(reelsTable).omit({
  id: true,
  viewCount: true,
  likeCount: true,
  commentCount: true,
  shareCount: true,
  saveCount: true,
  isModerated: true,
  isSuspended: true,
  createdAt: true,
});
export type InsertReel = z.infer<typeof insertReelSchema>;
export type Reel = typeof reelsTable.$inferSelect;

// ─── Reel likes ───────────────────────────────────────────────────────────────

export const reelLikesTable = pgTable(
  "reel_likes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reelId: uuid("reel_id")
      .notNull()
      .references(() => reelsTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.reelId, t.userId)],
);
export type ReelLike = typeof reelLikesTable.$inferSelect;

// ─── Reel comments ────────────────────────────────────────────────────────────

export const reelCommentsTable = pgTable("reel_comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  reelId: uuid("reel_id")
    .notNull()
    .references(() => reelsTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  parentId: uuid("parent_id"),
  content: text("content").notNull(),
  likeCount: integer("like_count").notNull().default(0),
  userFullName: text("user_full_name"),
  userAvatarUrl: text("user_avatar_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("reel_comments_reel_id_idx").on(t.reelId, t.createdAt),
]);
export type ReelComment = typeof reelCommentsTable.$inferSelect;

// ─── Reel saves ───────────────────────────────────────────────────────────────

export const reelSavesTable = pgTable(
  "reel_saves",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reelId: uuid("reel_id")
      .notNull()
      .references(() => reelsTable.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.reelId, t.userId)],
);
export type ReelSave = typeof reelSavesTable.$inferSelect;

// ─── Reel views ───────────────────────────────────────────────────────────────

export const reelViewsTable = pgTable(
  "reel_views",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reelId: uuid("reel_id")
      .notNull()
      .references(() => reelsTable.id, { onDelete: "cascade" }),
    viewerId: uuid("viewer_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    watchedSeconds: integer("watched_seconds").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.reelId, t.viewerId)],
);
export type ReelView = typeof reelViewsTable.$inferSelect;

// ─── Reel follows (creator follows) ──────────────────────────────────────────

export const reelFollowsTable = pgTable(
  "reel_follows",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    followerId: uuid("follower_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    followeeId: uuid("followee_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.followerId, t.followeeId)],
);
export type ReelFollow = typeof reelFollowsTable.$inferSelect;

// ─── Reel reports ─────────────────────────────────────────────────────────────

export const reelReportsTable = pgTable("reel_reports", {
  id: uuid("id").primaryKey().defaultRandom(),
  reelId: uuid("reel_id")
    .notNull()
    .references(() => reelsTable.id, { onDelete: "cascade" }),
  reporterId: uuid("reporter_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  reason: text("reason").notNull(),
  details: text("details"),
  isResolved: boolean("is_resolved").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
export type ReelReport = typeof reelReportsTable.$inferSelect;
