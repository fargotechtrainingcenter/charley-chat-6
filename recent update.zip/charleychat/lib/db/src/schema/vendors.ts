import { pgTable, uuid, text, boolean, integer, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const vendorsTable = pgTable("vendors", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .unique()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  businessName: text("business_name").notNull(),
  businessType: text("business_type"),
  description: text("description"),
  logoUrl: text("logo_url"),
  coverImageUrl: text("cover_image_url"),
  location: text("location"),
  isVerified: boolean("is_verified").notNull().default(false),
  isSuspended: boolean("is_suspended").notNull().default(false),
  ratingAvg: numeric("rating_avg", { precision: 3, scale: 2 }).notNull().default("0.00"),
  totalReviews: integer("total_reviews").notNull().default(0),
  // Extended vendor management
  status: text("status").notNull().default("approved"),
  verificationLevel: text("verification_level").notNull().default("unverified"),
  rejectionReason: text("rejection_reason"),
  suspensionReason: text("suspension_reason"),
  bannedAt: timestamp("banned_at", { withTimezone: true }),
  // Onboarding KYC docs
  personalName: text("personal_name"),
  idCardUrl: text("id_card_url"),
  passportUrl: text("passport_url"),
  momoReference: text("momo_reference"),
  onboardingFeePaid: boolean("onboarding_fee_paid").notNull().default(false),
  onboardingFeePaidAt: timestamp("onboarding_fee_paid_at", { withTimezone: true }),
  // Import markup preference (percentage, e.g. 10 = 10%)
  defaultMarkupPct: integer("default_markup_pct").notNull().default(10),
  // Account controls
  walletFrozen: boolean("wallet_frozen").notNull().default(false),
  storeFrozen: boolean("store_frozen").notNull().default(false),
  disableProductPosting: boolean("disable_product_posting").notNull().default(false),
  disableStoryPosting: boolean("disable_story_posting").notNull().default(false),
  disableWithdrawals: boolean("disable_withdrawals").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVendorSchema = createInsertSchema(vendorsTable).omit({
  id: true,
  isVerified: true,
  isSuspended: true,
  ratingAvg: true,
  totalReviews: true,
  status: true,
  verificationLevel: true,
  walletFrozen: true,
  storeFrozen: true,
  disableProductPosting: true,
  disableStoryPosting: true,
  disableWithdrawals: true,
  bannedAt: true,
  createdAt: true,
});
export type InsertVendor = z.infer<typeof insertVendorSchema>;
export type Vendor = typeof vendorsTable.$inferSelect;
