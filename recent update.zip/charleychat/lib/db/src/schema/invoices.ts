import { pgTable, uuid, text, integer, boolean, timestamp, pgEnum, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const invoiceStatusEnum = pgEnum("invoice_status", ["draft", "unpaid", "paid", "overdue", "cancelled"]);

export const invoicesTable = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  invoiceNumber: text("invoice_number").notNull(),
  clientName: text("client_name").notNull(),
  clientEmail: text("client_email"),
  clientPhone: text("client_phone"),
  companyName: text("company_name"),
  companyLogoUrl: text("company_logo_url"),
  companyAddress: text("company_address"),
  companyPhone: text("company_phone"),
  companyEmail: text("company_email"),
  companyWebsite: text("company_website"),
  issueDate: text("issue_date").notNull(),
  dueDate: text("due_date").notNull(),
  taxPercent: numeric("tax_percent", { precision: 5, scale: 2 }).notNull().default("0"),
  discountPercent: numeric("discount_percent", { precision: 5, scale: 2 }).notNull().default("0"),
  subtotalPesewas: integer("subtotal_pesewas").notNull().default(0),
  taxAmountPesewas: integer("tax_amount_pesewas").notNull().default(0),
  discountAmountPesewas: integer("discount_amount_pesewas").notNull().default(0),
  totalPesewas: integer("total_pesewas").notNull().default(0),
  notes: text("notes"),
  status: invoiceStatusEnum("status").notNull().default("draft"),
  isPdfGenerated: boolean("is_pdf_generated").notNull().default(false),
  pdfUrl: text("pdf_url"),
  generationFeePaidAt: timestamp("generation_fee_paid_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const invoiceItemsTable = pgTable("invoice_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  invoiceId: uuid("invoice_id")
    .notNull()
    .references(() => invoicesTable.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull().default(1),
  unitPricePesewas: integer("unit_price_pesewas").notNull(),
  totalPesewas: integer("total_pesewas").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const insertInvoiceSchema = createInsertSchema(invoicesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  subtotalPesewas: true,
  taxAmountPesewas: true,
  discountAmountPesewas: true,
  totalPesewas: true,
  isPdfGenerated: true,
  pdfUrl: true,
  generationFeePaidAt: true,
});
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoicesTable.$inferSelect;

export const insertInvoiceItemSchema = createInsertSchema(invoiceItemsTable).omit({
  id: true,
  totalPesewas: true,
});
export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;
export type InvoiceItem = typeof invoiceItemsTable.$inferSelect;
