import { pgTable, uuid, text, timestamp, pgEnum, boolean, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const storyTypeEnum = pgEnum("story_type", ["image", "text", "video"]);
export const storyVisibilityEnum = pgEnum("story_visibility", [
  "contacts",
  "contacts_except",
  "only_share",
  "everyone",
]);

export const storiesTable = pgTable("stories", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  mediaUrl: text("media_url"),
  caption: text("caption"),
  storyType: storyTypeEnum("story_type").notNull().default("text"),
  isAgeRestricted: boolean("is_age_restricted").notNull().default(false),
  visibilityType: storyVisibilityEnum("visibility_type").notNull().default("contacts"),
  textColor: text("text_color"),
  textBg: text("text_bg"),
  viewCount: integer("view_count").notNull().default(0),
  userFullName: text("user_full_name"),
  userPhone: text("user_phone"),
  userAvatarUrl: text("user_avatar_url"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("stories_user_id_idx").on(t.userId),
  index("stories_expires_at_idx").on(t.expiresAt),
]);

export const insertStorySchema = createInsertSchema(storiesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof storiesTable.$inferSelect;
